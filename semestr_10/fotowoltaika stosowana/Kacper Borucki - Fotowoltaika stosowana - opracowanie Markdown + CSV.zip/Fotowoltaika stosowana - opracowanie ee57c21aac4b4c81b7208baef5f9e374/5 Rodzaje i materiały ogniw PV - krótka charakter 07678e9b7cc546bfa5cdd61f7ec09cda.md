# 5. Rodzaje i materiały ogniw PV - krótka charakterystyka

- Materiały wykorzystywane do fotowoltaiki - różne rodzaje ogniw
    - Monokrystaliczne
    - Polikrystaliczne
    - Amofriczne
    - Cienkowarstwoe CIS CIX arsenek galu
    - Krotka charakterystyka każdej z nich
    - Jak je dzielimy, jak wykorzystujemy?

W ogólności, wyróżnia się ogniwa grubowarstwowe (krystaliczne) oraz ogniwa cienkowarstwowe, nazywane odpowiednio ogniwami I i II generacji. 

### Ogniwa krystaliczne

**Ogniwa krzemowe monokrystaliczne**

Głównym materiałem do produkcji ogniw krzemowych jest dwutlenek krzemu, poddawany odpowiedniej obróbce. Monokrystaliczne ogniwa krzemowe tworzy się, topiąc polikrystaliczny krzem w obecności gazu obojętnego. Proces ten jest powolny i drogi, ale ogniwa tego typ mają duża sprawność i długą żywotność.

**Ogniwa krzemowe polikrystaliczne** 

Proces produkcji jest tu prostszy i wymaga mniej energii. Wypadkowa siatka krystaliczna ogniw ma większe niedoskonałości przez co w ogniwach tego typu częściej może zachodzić rekombinacja ładunków. Ich wypadkowa sprawność jest przez to mniejsza niż ogniw monokrystalicznych

**Ogniwa z arsenku galu**

Arsenek galu ze względu na swoją przerwę pasmową 1,42 eV jest bardzo wydajnym ogniwem fotowoltaicznym, najwydajniejszym ze wszystkich przy wysokim nasłonecznieniu. Przy tym, ogniwa z arsenku galu są odporne na wysokie temperatury i mają niższe współczynniki temperaturowe niż ogniwa krzemowe. Mogą być wykonywane również jako ogniwa cienkowarstwowe.

### Ogniwa cienkowarstwowe

Ogniwa cienkowarstwowe zrobione są z takich półprzewodników, które nie wymagają grubej warstwy materiału aby osiągnąć dobry poziom absorpcji fotonów. Pozwala to na redukcję energii i materiałów potrzebnych do produkcji. 

**Ogniwa krzemowe amorficzne**

W strukturze amorficznej krzemu nie każdy atom jest w stanie związać się z czterema przylegającymi atomami. Wolne elektrony dzięki wolnym wiązaniom elektronowym są w stanie dobrze pułapkować nośniki ładunku. Sprawność ogniw amorficznych jest niska i spada o 10-30% przez kilka pierwszych miesięcy użytkowania. Generują one napięcia wyższe niż tradycyjne ogniwa krzemowe. Lepiej pochłaniają światło. Mają dość krótką żywotność. Panele są jednak lekkie i elastyczne. 

**Ogniwa CIS i CIGS**

Ogniwa CIS składają się z selenu, indu i miedzi. Ich produkcja jest droga, bo ind jest rzadki. Przechwytują praktycznie całe spektrum promieniowania. Ich sprawność osiąga ok. 11%. 

Zastąpienie części indu galem pozwala na stworzenie tańszych ogniw CIGS, które mają nieco większą przerwę energetyczną, ale przy tym sprawność sięgającą prawie 20%.