# 7. Schemat blokowy systemu podłączonego na sieć i systemu pracującego samodzielnie

- Schematyczne przedstawienie elementów systemu pracującego samodzielnie (standalone)
- Podstawowe elementy systemu pracującego na sieć

### System pracujący samodzielnie

System pracujący samodzielnie, żeby zapewnić ciągłą dostawę energii elektrycznej do odbiorników, musi oprócz instalacji fotowoltaicznej zawierać również magazyn energii. 

Podstawowymi elementami takiego układu są instalacja fotowoltaiczna, kontroler solarny, bank energii (baterie), kontroler rozładowania baterii (z zabezpieczeniami) a za nim przekształtnik DC lub falownik zasilający odbiorniki. Mogą pojawić się także dodatkowe źródła energii, jak np. generator diesla. 

Jako bank energii mogą służyć wodór, baterie niklowo-kadmowe, kwasowe lub wodór.

![Untitled](7%20Schemat%20blokowy%20systemu%20pod%C5%82a%CC%A8czonego%20na%20siec%CC%81%20i%207a32a0dbbf20417c8b7e6cb138d67b0f/Untitled.png)

![Untitled](7%20Schemat%20blokowy%20systemu%20pod%C5%82a%CC%A8czonego%20na%20siec%CC%81%20i%207a32a0dbbf20417c8b7e6cb138d67b0f/Untitled%201.png)

### System pracujący na sieć

Specyfika pracy na sieć wymaga, by system był zaopatrzony w odpowiedni przekształtnik dopasowujący parametry energii elektrycznej pozyskiwanej z fotowoltaiki do parametrów wymaganych przez sieć. Ponadto, układ tego typu wymaga specjalnego rozliczania, więc oprócz układu falownika potrzebny jest odpowiedni licznik energii. 

![Untitled](7%20Schemat%20blokowy%20systemu%20pod%C5%82a%CC%A8czonego%20na%20siec%CC%81%20i%207a32a0dbbf20417c8b7e6cb138d67b0f/Untitled%202.png)

Na poniższym obrazku widać, że podstawowymi elementami takiego systemu są: instalacja fotowoltaiczna, obwód sterujący fotowoltaiką, przewód DC, falownik, miernik wyprodukowanej energii i odpowiednio przyłączenie do sieci lub do odbiorników. Nie ma tu akumulatorów ani obwodów odpowiadających za nie.

![Untitled](7%20Schemat%20blokowy%20systemu%20pod%C5%82a%CC%A8czonego%20na%20siec%CC%81%20i%207a32a0dbbf20417c8b7e6cb138d67b0f/Untitled%203.png)