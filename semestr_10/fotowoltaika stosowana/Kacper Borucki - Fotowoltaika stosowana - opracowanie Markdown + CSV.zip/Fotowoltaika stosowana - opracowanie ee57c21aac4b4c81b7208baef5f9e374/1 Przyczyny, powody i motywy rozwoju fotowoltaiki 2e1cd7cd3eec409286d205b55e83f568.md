# 1. Przyczyny, powody i motywy rozwoju fotowoltaiki

Jakie są przyczyny rozwoju fotowoltaiki? Powody dla których instalacje stały się tak popularne jak obecnie (podody / motywy rozwoju PV)

**Podpunkt 1.1 książki**

Fotowoltaika to technologia, która pozwala na bezpośrednią przemianę promieniowania słonecznego w energię elektryczną w oparciu o ogniwa słoneczne. Jest to technologia, która zwłaszcza w ostatnich latach zyskała na znaczeniu. 

Wśród przyczyn rozwoju i wzrostu znaczenia fotowoltaiki są:

- **rozwój programów kosmicznych w latach 50** - fotowoltaika została rozwinięta na potrzeby zasilania statków kosmicznych i satelit i jest stosowana tam do tej pory
- **kryzys naftowy z lat 70** - sytuacja geopolityczna sprawiła, że w latach 70 i kolejnych zaczęto poszukiwania alternatywnych dla kopalnych, odnawialnych źródeł energii
- **katastrofa w Czarnobylu w latach 80** - jej skutki społeczne sprawiły, że zaczęto poszukiwać innych niż jądrowe generatorów energii
- **czysta generacja energii -** wytwarzanie energii elektrycznej przez ogniwa solarne jest procesem bezemisyjnym, nieszkodliwym dla środowiska i nietoksycznym
- **dostępność materiałów -** promieniowanie słoneczne jest źródłem energii, natomiast krzem jest powszechnie dostępnym materiałem, występującym w postaci piasku
- **bezobsługowa eksploatacja i niezawodność**
- **uzysk energii w obszarach niewykorzystywanych** - np. pustynie, nieużytki rolne, etc.

Aktualnie jednym z głównych motywów rozwoju fotowoltaiki są naciski na odejście od paliw kopalnych i emisyjnych źródeł energii. Problemami w ekspansji są natomiast zmienna produkcja energii oraz jeszcze ciągle wysokie koszty produkcji.