# 4. Schemat i budowa ogniwa krzemowego

- Budowa ogniwa PV krzemowego jako najbardziej charakterystycznego
    - Warstwa P, złącze PN
    - Jak działa takie ogniwo

Ogniwa fotowoltaiczne w ogólności działają dzięki wewnętrznemu zjawisku fotoelektrycznemu. Polega ono na tym, że foton o odpowiedniej energii jest w stanie albo wyzwolić elektron z siatki krystalicznej materiału, albo przenieść go w półprzewodniku z pasma walencyjnego do pasma przewodzenia. Takie oddziaływanie powoduje powstanie dziury w paśmie walencyjnym. W przypadku braku zewnętrznego pola elektrycznego, niedługo potem dochodzi do rekombinacji.

W przypadku złącza PN warstw tego samego materiału, pojawienie się pola elektrycznego utrzymującego odseparowane dziury i elektrony może zachodzić bez zewnętrznego źródła napięcia. Wtedy oddziaływanie fotonu powoduje powstanie nowych par elektron-dziura, które są natychmiast od siebie oddzielane wskutek wewnętrznego zjawiska fotoelektrycznego.

W ogniwach krzemowych, na ogół warstwa n jest wystawiana na oddziaływanie słońca. Powstawanie par elektron-dziura powoduje osłabianie pola oddzielającego je od siebie na złączu PN. Panel osiąga przy tym swoje maksymalne napięcie otwartego obwodu V_OC. Jeżeli obwód jest zwarty, to pary dziura-elektron podróżują przez obwód i osiągają prąd zwartego obwodu I_sc ogniwa. 

![Untitled](4%20Schemat%20i%20budowa%20ogniwa%20krzemowego%200377f2251e4a48a6b84c3b1cc1585516/Untitled.png)

Ogniwa krzemowe zbudowane są jako duże diody półprzewodnikowe, których warstwa blokująca (barierowa) jest wystawiona na działanie światła słonecznego. Na ogół warstwa N półprzewodnika jest bardzo cienka, żeby umożliwiała wnikanie tak dużej ilości fotonów, jak to możliwe. Warstwa P jest natomiast stosunkowo gruba. 

Na górnej powierzchni płītki krzemowej umieszczone są elektrody ujemne (zbierające), na dolnej - dodatnie (przenoszące). Dolną płytkę krzemu, domieszkowaną donorowo, od górnej, domieszkowanej akceptorowo, dzieli złącze PN. 

![Untitled](4%20Schemat%20i%20budowa%20ogniwa%20krzemowego%200377f2251e4a48a6b84c3b1cc1585516/Untitled%201.png)