# 2. Metoda trzech składowych obliczania irradiancji w dowolnym punkcie na ziemi

**Metoda trzech składowych** to matematyczna metoda obliczania irradiancji (energii promieniowania na metr kwadratowy powierzchni) docierającej do pochylonego panelu fotowoltaicznego w dowolnym punkcie na ziemi. Jej zaletą jest dość **duża dokładność**, uwzględnianie lokalnych uwarunkowań klimatycznych i brak konieczności stosowania stacji referencyjnych, a przy tym uwzględnienie takich zjawisk jak częściowe zacienienie paneli.

Trzy składowe uwzględniane w tej metodzie to: promieniowanie bezpośrednie $G_{GB}, H_{GB}$, promieniowanie rozproszone $G_{GD}, H_{GD}$ oraz promieniowanie odbite $G_{GR}, H_{GR}$.

![Untitled](2%20Metoda%20trzech%20sk%C5%82adowych%20obliczania%20irradiancji%20%2089c0b4a8c4a546ad863d12088d35e829/Untitled.png)

**Promieniowanie bezpośrednie** $R_B$  jest promieniowaniem padającym bezpośrednio ze słońca na panel fotowoltaiczny. Wartość promieniowania na powierzchni panelu jest obliczana za pomocą współczynnika irradiancji bezpośredniej. Wartość tego współczynnika zależy od szerokości geograficznej, kąta nachylenia panela oraz azymutu generatora solarnego. Wielkości te są obliczane geometrycznie. 

**Promieniowanie rozproszone** to promieniowanie pochodzące od atmosfery ziemskiej, która rozprasza część promieniowania słonecznego, część przepuszcza, a część odbija np. poprzez chmury. Wartość tę oblicza się na podstawie kąta nachylenia powierzchni panela. 

**Promieniowanie odbite** to promieniowanie odbite od ziemi, docierające do powierzchni panela. Jego natężenie padające na panel zależy od kąta nachylenia panela i współczynnika odbicia powierzchni w pobliżu panelu. 

**Całkowitą energię promieniowania** docierającego do panela fotowoltaicznego oblicza się jako **sumę trzech powyższych składowych**. Można przy tym uwzględnić również współczynnik zacienienia wynikający z pory roku czy obiektów zasłaniających panele.