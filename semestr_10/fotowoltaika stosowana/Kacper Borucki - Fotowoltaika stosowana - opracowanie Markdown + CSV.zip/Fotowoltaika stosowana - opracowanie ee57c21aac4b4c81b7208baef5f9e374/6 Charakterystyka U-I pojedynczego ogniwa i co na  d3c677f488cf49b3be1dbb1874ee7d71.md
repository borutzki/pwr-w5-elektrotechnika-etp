# 6. Charakterystyka U-I pojedynczego ogniwa i co na nią wpływa

- Budowa PV i charakterystyka prąd-napięcie panele
    - Jak wpływa na nią nasłonecznienie, temperatura
    - Co jeszcze na nią wpływa?

Prąd zwarciowy ogniwa jest proporcjonalny do irradiancji pochłanianej przez panel. Napięcie otwartego obwodu jest logarytmicznie zależne od prądu zwarcia. Im wyższy prąd, tym niższe napięcie - albo na odwrót. Przy otwartym obwodzie rośnie napięcie, przy zamkniętym - prąd. 

Charakterystyka łącząca te dwie wielkości to charakterystyka U-I.

![Untitled](6%20Charakterystyka%20U-I%20pojedynczego%20ogniwa%20i%20co%20na%20%20d3c677f488cf49b3be1dbb1874ee7d71/Untitled.png)

Na charakterystyce U-I można wyznaczyć punkt maksymalnej mocy, czyli miejsce w którym iloczyn prądu i napięcia przyjmuje maksymalną wartość. Wartość tę często śledzi się w układach sterujących energią oddawaną przez instalację.

![Untitled](6%20Charakterystyka%20U-I%20pojedynczego%20ogniwa%20i%20co%20na%20%20d3c677f488cf49b3be1dbb1874ee7d71/Untitled%201.png)

Na charakterystykę U-I wpływ mają następujące czynniki:

- poziom irradiancji lub nasłonecznienia: przenosi charakterystykę odpowiednio wyżej lub niżej
    
    ![Untitled](6%20Charakterystyka%20U-I%20pojedynczego%20ogniwa%20i%20co%20na%20%20d3c677f488cf49b3be1dbb1874ee7d71/Untitled%202.png)
    
- temperatura: przenosi maksymalny punkt pracy w prawo (niższa temperatura) lub w lewo (wyższa temperatura)
    
    ![Untitled](6%20Charakterystyka%20U-I%20pojedynczego%20ogniwa%20i%20co%20na%20%20d3c677f488cf49b3be1dbb1874ee7d71/Untitled%203.png)
    
- zanieczyszczenie panela
- zacienienie
- degradacja paneli