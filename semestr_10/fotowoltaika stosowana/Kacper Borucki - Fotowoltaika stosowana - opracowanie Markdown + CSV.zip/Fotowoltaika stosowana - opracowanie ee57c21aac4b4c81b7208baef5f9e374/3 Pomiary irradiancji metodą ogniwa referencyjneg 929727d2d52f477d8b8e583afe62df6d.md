# 3. Pomiary irradiancji metodą ogniwa referencyjnego i piranometru

- Pomiary irradiancji
    - Dwa przyrządy piranometr i ogniwo referencyjne
    - Jaka jest różnica między tymi urządzeniami
    - Do czego są wykorzystywane te urządzenia?
    - Spektrum promieniowania
        - Ogniwo jest czułe tylko na spektrum wynikające z działania ogniwa

### Piranometr

Piranometr to urządzenie oparte o termostos zbudowany z wielu spiętych w szereg termopar. Służy do pomiaru irradiancji. Dwie półkule na obudowie mają za zadanie niwelować odbicia na szkle przy małych kątach padania światła. 

Piranometr za pomocą czarnego odbiornika absorbuje szerokie pasmo irradiancji, dla fal elektromagnetycznych o długości od 300 nm do 3 um. Jego wyjściem jest małe napięcie, które musi być wzmacniane za pomocą wzmacniacza pomiarowego. 

Wypadkowo, piranometry są drogie i wymagają kalibracji co kilka lat.

![Untitled](3%20Pomiary%20irradiancji%20metoda%CC%A8%20ogniwa%20referencyjneg%20929727d2d52f477d8b8e583afe62df6d/Untitled.png)

### Ogniwo referencyjne

Ogniwo referencyjne to specjalne ogniwo fotowoltaiczne, którego głównym zadaniem jest pomiar irradiancji. Irradiancja jest mierzona na podstawie prądu generowanego w ogniwach pomiarowych. Ogniwa referencyjne korzystają jedynie z części spektrum promieniowania słonecznego, w odróżnieniu od piranometrów. 

Ogniwa referencyjne muszą być kalibrowane w odpowiednich warunkach, żeby wyniki ich pomiarów były dokładne. Na ogół ich wyniki pomiarów są zaniżone względem piranometrów. Istnieją też trudności w ich kalibracji - sztuczne światło nie jest identyczne ze słonecznym, natomiast na słoneczne wpływa wiele różnych czynników zależnie od pogody. 

Ogniwa referencyjne są tańsze niż piranometry, ale oferują ograniczone dokładności pomiarów. 

![Untitled](3%20Pomiary%20irradiancji%20metoda%CC%A8%20ogniwa%20referencyjneg%20929727d2d52f477d8b8e583afe62df6d/Untitled%201.png)