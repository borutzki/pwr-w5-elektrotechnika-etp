# Opracowanie zagadnień na egzamin dyplomowy
Politechnika Wrocławska
Wydział: Elektryczny, W-5
- Kierunek: Elektrotechnika ETK
- Specjalność: Elektrotechnika Przemysłowa ETP
- Stopień II - studia magisterskie

# Opis
W tym repozytorium udostępniam swoje opracowanie do zagadnień egzaminacyjnych dla drugiego stopnia studiów na kierunku Elektrotechnika, specjalności Elektrotechnika Przemysłowa. 

Niniejsze opracowanie napisałem samodzielnie od zera, opierając się o materiały z wykładów, książki, artykuły i własne notatki z pięciu lat studiów. Wszystkie materiały z których korzystałem, przedstawiłem pod każdym z zagadnień. Znalezienie większości nie powinno sprawić problemu, natomiast ze względu na prawa autorskie, niektóre materiały (np. slajdy z wykładów) na których się opierałem mogą być trudne lub niemożliwe do znalezienia.

Opracowanie zamieszczam w trzech formatach:
- eksport z programu Notion w formacie HTML,
- pliki PDF z każdym z głównych zagadnień,
- plik PDF łączący wszystkie zagadnienia razem.

# Od autora
Mam nadzieję, że repozytorium pomoże jak największej liczbie osób przejść bez problemu egzamin dyplomowy po studiach magisterskich. Udostępniam całe to opracowanie za darmo, żeby nie zaginęło w odmętach mojego dysku. 

Powodzenia na studiach, nie dajcie się wysłać na dziekankę ;)

__*mgr inż. Kacper Borucki*__
