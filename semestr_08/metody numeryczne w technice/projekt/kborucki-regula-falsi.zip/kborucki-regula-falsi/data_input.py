from data_check import data_check


def data_input():
    data_correct = False
    expression_correct = False
    a_correct = False
    b_correct = False

    while data_correct == False:
        if expression_correct == False:
            expression_input = str(input("Wprowadź funkcję: y(x)="))
        if a_correct == False:
            a_input = input("Wprowadź początek badanego przedziału: a=")
        if b_correct == False:
            b_input = input("Wprowadź początek badanego przedziału: b=")
        expression_correct, a_correct, b_correct, data_correct = data_check(
            expression_input, a_input, b_input)

    expression = expression_input
    a = float(a_input)
    b = float(b_input)
    return expression, a, b
