from math import *


def function_parser(expression):

    def function(x):
        y = eval(expression)
        return y
    return function
