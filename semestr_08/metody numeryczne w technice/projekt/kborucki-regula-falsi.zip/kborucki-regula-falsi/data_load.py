import tkinter as tk
from tkinter import filedialog
from data_check import data_check


def data_load():
    data_correct = False

    root = tk.Tk()
    root.withdraw()
    while data_correct == False:
        file_path = filedialog.askopenfilename()
        file = open(file_path, "r")
        file_data = file.read().split('\n')
        expression_input = file_data[0]
        a_input = file_data[1]
        b_input = file_data[2]
        file.close()

        expression_correct, a_correct, b_correct, data_correct = data_check(
            expression_input, a_input, b_input)
        if data_correct == False:
            print("Wprowadzono błędne dane. \nJeśli chcesz spróbować ponownie lub wczytać inny plik, wpisz 1. \nJeśli chcesz anulować, wpisz 0.")
            cancel = input("Wybierz opcję: ")
            if cancel == 1:
                data_correct = False
                print("Wczytaj plik ponownie.")

            else:
                return None

    expression = expression_input
    a = float(a_input)
    b = float(b_input)
    return expression, a, b
