import tkinter as tk
from tkinter import filedialog
import datetime


def data_export(data):
    # parameters = locals()
    # print(parameters)
    # utworzenie nazwy pliku z aktualnej daty
    date = str(datetime.date.today())
    time = datetime.datetime.now()
    time_now = str(time.strftime("%H-%M-%S"))
    filename = "regula_falsi_" + date + "_" + time_now + ".txt"

    # otwarcie pliku
    file = open(filename, "a")

    for item in range(len(data)):

        file.write(str(data[item]) + "\n")
    file.close()

    return None


data_export([1, 2, 3])
