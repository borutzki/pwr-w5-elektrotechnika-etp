# from app import function
from function_parser import function_parser


def regula_falsi(a, b, expression):
    function = function_parser(expression)

    f_a = function(a)
    f_b = function(b)
    if a >= b:
        print("Nie spełniono warunku a < b dla podanego zakresu")
        return "Nie spełniono warunku a < b dla podanego zakresu"
    elif f_a*f_b > 0:
        print("Nie spełniono warunku f(a)*f(b) < 0 - funkcja nie zmienia znaku na zadanym przedziale")
        return "Nie spełniono warunku f(a)*f(b) < 0 - funkcja nie zmienia znaku na zadanym przedziale"
    else:
        if f_a < 0:
            f_a_sign = -1
        elif f_a == 0:
            f_a_sign = 0
        else:
            f_a_sign = 1

        root = b - f_b*(b - a) / (f_b - f_a)
        while a < root and root < b:
            f_root = function(root)
            if f_root < 0:
                f_root_sign = -1
            elif f_root == 0:
                f_root_sign = 0
            else:
                f_root_sign = 1

            if f_a_sign == f_root_sign:
                a = root
                f_a = f_root
            else:
                b = root
                f_b = f_root
            root = b - f_b * (b-a)/(f_b-f_a)
    return root
