# Metody numeryczne w technice
# Projekt MET-07-P13: Wyznaczanie pierwiastków równania nieliniowego regułą „falsi”
# Rok akademicki 2020/2021
# Wydział Elektryczny, Elektrotechnika
# Stopień II, semestr I

## Kacper Borucki 245365 ##
## Robert Leśniak 240765 ##

from regula_falsi import regula_falsi
from function_parser import function_parser
from data_load import data_load
from data_input import data_input
from data_export import data_export
from data_check import data_check

print("\nWyznaczanie pierwiastków równania nieliniowego regułą \'falsi\'\n")

while quit != 1:
    print("\nMenu:\n\n1. Wprowadź dane wejściowe\n2. Wczytaj plik z danymi wejściowymi\n3. Wyświetl wprowadzone dane\n4. Wykonaj obliczenia\n5. Zapisz wprowadzone dane i wyniki obliczeń do pliku\n6. Zakończ\n")
    menuOption = input("Wybierz opcję z menu: ")

    if menuOption == "1":
        print("Wprowadzanie danych wejściowych\n")
        expression, a, b = data_input()
        data = [expression, a, b]
        # proste menu do wklepywania danych z ręki

    elif menuOption == "2":
        print("Wczytaj dane wejściowe z pliku: ")
        try:
            expression, a, b = data_load()
            data = [expression, a, b]
            print("Wczytano dane poprawnie.")
        except TypeError:
            print("Dane nie zostały wczytane.")

        # proste menu do wczytania pliku

    elif menuOption == "3":
        print("\nWprowadzone dane: \n")
        try:
            print(expression)
        except NameError:
            print("Nie wprowadzono funkcji")
        try:
            print(a)
        except NameError:
            print("Nie wprowadzono a")
        try:
            print(b)
        except NameError:
            print("Nie wprowadzono b")

    elif menuOption == "4":
        print("Wykonywanie obliczeń")
        try:
            expression_correct, a_correct, b_correct, data_correct = data_check(
                expression, a, b)
            if data_correct == True:
                root = regula_falsi(a, b, expression)
                data.append(root)
                print("\nAnalizowana funkcja: " + expression)
                print("Badany przedział od " + str(a) + " do " + str(b))
                print("Znalezione miejsce zerowe: " + str(root) + "\n\n")
            else:
                print(
                    "Wczytano nieprawidłowe dane lub brakuje danych do obliczeń. Wprowadź dane ponownie")
        except NameError:
            print(
                "Brakuje danych do obliczeń. Wprowadź lub wczytaj a, b i wyrażenie obliczanej funkcji.")
        except SyntaxError:
            print(
                "Wprowadzono nieprawidłowe wyrażenie matematyczne. Popraw wprowadzone dane i spróbuj ponownie.")
        # wczytanie z określonego pliku;

    elif menuOption == "5":
        print("Zapisuję dane i wyniki obliczeń do pliku")
        try:
            data_export(data)
        except NameError:
            print("W programie nie ma żadnych danych do zapisania")

    elif menuOption == "6":
        quit = 1
        print("Zamknięto program")

    else:
        print("Brak dostępnej opcji w menu. Spróbuj ponownie.")
