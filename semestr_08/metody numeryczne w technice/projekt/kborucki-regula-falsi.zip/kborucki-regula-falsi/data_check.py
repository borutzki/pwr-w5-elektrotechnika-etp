def data_check(expression, a, b):
    expression_correct = False
    a_correct = False
    b_correct = False
    data_correct = False
    allowed_characters = ['x', '!', ' ', '.', '%', '+', '*', '-',
                          '/', 'exp', 'e', 'log', 'math.pi', 'log10', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '(', ')']
    if any(character not in allowed_characters for character in expression):
        print("Błąd! W wyrażeniu znaleziono nieprawidłowe znaki! Lista dopuszczalnych znaków i wyrażeń znajduje się w instrukcji do programu.")
    else:
        expression_correct = True

    try:
        float(a)
        a_correct = True
    except:
        print("Nieprawidłowa wartość a. Parametr a musi być liczbą.")

    try:
        float(b)
        b_correct = True
    except:
        print("Nieprawidłowa wartość b. Parametr b musi być liczbą.")

    if expression_correct == True and a_correct == True and b_correct == True:
        data_correct = True
    else:
        data_correct = False

    return expression_correct, a_correct, b_correct, data_correct
