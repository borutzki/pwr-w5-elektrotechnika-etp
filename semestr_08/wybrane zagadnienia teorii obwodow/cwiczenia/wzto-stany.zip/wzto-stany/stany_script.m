%% PARAMETRY OBWODU %%
% U = 10*7 % V
% d = 6 %km
% C = 1 %F
% M = 7 %
% L = 6 %H
% R = 5 %Ω

Un = 15 %kV
Uf = 15/sqrt(3) %V
Sn = 1 %GVA
f = 50 %Hz
Pg = 10000 %W
Ps = 10000 %W
cos_fi = 0.95 %-
%Ra/Xa = 0.1

Rprim = 0.434 %Ω/km
Lprim = 0.369 %mH/km
Cprim = 0.0045 %uF/km



% Źródło SEM:
c = 1.1 %-
Zk = c*Un^2/(Sn*1000) %Ω
Xa = sqrt(Zk^2/1.01) %
RN = 0.1*Xa %
Ls = (Xa/2*pi*f)/3 %H

% Linia:
Lw = Lprim*d/1000 %H
Rw = Rprim*d %Ω

% Grzejnik:
Pgf = Pg/3 %W, moc 1 fazy
R = Uf^2/Pgf %Ω

% Silnik:
Zs = Un^2/(Ps/cos_fi)
Rs = Zs*cos_fi
Xs = Zs*sin(acos(cos_fi))
L = Xs/(2*pi*f)

% Kompensator
C = 1 %F

sim("stany.slx")
