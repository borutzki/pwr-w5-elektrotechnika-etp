% parametry
P = 7; %kW
d = 6*10; %km
Un = 15; %kV
U0=15/sqrt(3); %kV
f=50;
w = 2*pi*f;

%% SILNIK %%
cos_fi=0.95;
sin_fi=sqrt(1-cos_fi^2)
P0 = P/3;
S0 = P0/cos_fi; %kVA
Z0=U0^2/S0; %
R0=Z0*cos_fi 
X0 = Z0*(sqrt(1-cos_fi^2))
L0 = X0/w

%% LINIA %%
Rp = 0.434
Lp = 0.369
Rl = Rp*d
Ll=Lp*d

%% TRAFO %%
ur = 12
ST = 25 %kVA
ZT = (ur/100)*(Un^2/ST)
XT = ZT
LT = XT/w