% parametry transformatora
Sn = 315; %kVA
PFe = 0.944; %kW
PCu = 5.195; %kW
Uzw = 0.045 % procenty

syms s;
result = 2*s;
print(result)