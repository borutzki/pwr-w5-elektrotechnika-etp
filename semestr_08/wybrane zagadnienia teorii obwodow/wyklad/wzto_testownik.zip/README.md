# PPS
Testownik z Podstaw Przetwarzania Sygnałów.

# Drugie kolokwium
Materiał do drugiego kolokwium znajduje się w gałęzi [drugie_kolo](https://github.com/TestownikiPWR/PPS/tree/drugie_kolo).

# Uwaga od autora aktualizacji do części drugiej

Testownik NIGDY nie gwarantuje zdobycia minimalnej liczby punktów na teście i powinien być stosowane WYŁĄCZNIE do 
powtórki materiału, który można znaleźć na slajdach na stronie katedry ZTS. Mimo bardzo dobrych wyników w semestrze
zimowym 2017/2018, w semestrze 2018/2019 dużo pytań może się zmienić, tym samym testownik może stać się nieaktualny.

Chciałbym podziękować wszystkim, którzy spędzili godziny wieczorami, pomagając mi poprawiać pytania i aktualizować starą
bazę pytań. MIĘDZY INNYMI są to:

Tomasz, Albert, Aleksandra, Karolina, Piotr, Marcin, Janek, Piotrek, Barto, Krystian, Juliusz, Marta i wiele innych osób..

Bazę aktualizował: Mati :)