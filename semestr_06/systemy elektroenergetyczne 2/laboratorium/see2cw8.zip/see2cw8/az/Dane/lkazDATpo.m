function [slin,UNSobl,winf] = lkazDATpo
UNSobl=110; % kV 
winf=1e+08; % nieskonczonosc 
slin={
%Linia  Od        Do     UNS    r      x      L R0R1  X0X1  tn
%max12s max12s    max12s  kV  om/km  om/km   km  -     -    -
 'L'   'GPZ10kV' 'XLK'    10  0.44   0.370  2.0 1.341 3.5  115/11
 'K'   'XLK'     'ROSN'   10  0.255  0.122  1.0 1.0   1.0  115/11
};
end
