
%PARAMETRY ZASTEPCZE ZWARCIOWE GEN. SYNCHR.
%Parametry zastepcze GS na nap. znam. UNG
%UNSobl - nap. znam. obliczeniowe
%tN - przekl. transf.:siec UNSobl -> siec UNS
%tN=tN1*tN2*... - siec promieniowa
%tN=UNSobl/UNS  - tylko sieci oczkowe
UNSobl= 110;% kV 
winf=1e+08;% nieskonczonosc 
sgen={
%Gen        Od         Do        UNS     R1     X1     R0    X0  tN
%max12s     max12s     max12s     kV     om     om     om    om   -
'G1      ' 'GPZ10kV ' 'ZIEMIA  '  10 0.1194  1.706   winf   winf 10.455
'G2      ' 'MEW     ' 'ZIEMIA  '   6 0.09263  1.323   winf   winf 17.424
 };