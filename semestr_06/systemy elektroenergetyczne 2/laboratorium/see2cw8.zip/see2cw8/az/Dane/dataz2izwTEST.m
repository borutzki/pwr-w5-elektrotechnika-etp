function [c,ZSEEk,ZGk,ZMk,Unk,psi,tz]=dataz2izwTEST
% dane do wyznaczanie pradow zwarciowych zasilanych z niezaleznych zrodel
% SEE + G + M
j=sqrt(-1);
ZSEEk=0.017+j*0.38;   % om - impedancja pol. z systemem
ZGk = 0.119+j*1.706;  % om - imp. pol. z generatorem synchr.
ZMk = 8.241+j*20.184; % om - imp. pol. z silnikiem ind.
Unk = 10; % kV - napiecie znamionowe sieci w miejscu zwarcia
psi = 0; % stopnie - kat poczatkowy sem Thevenina
tz = 0.1; % s - czas trwania zwarcia
c  = 1.1; % prad zwarciowy maksymalny
end


