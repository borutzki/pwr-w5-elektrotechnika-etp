function [c,zrodlo,In,m,Unk,Rk,Xk,tzw,psi]=datIzs_M
zrodlo='M'; % zwarcie zasilane z gen. synchr.
PnM=0.251;      % MW  - moc znamionowa mechaniczna silnika
p=2;          % liczba par biegunow
m=PnM/p;      % moc znamionowa silnika na pare biegunow
ns=6;         % liczba silnikow
etan=0.97;    % znamionowa sprawnosc silnika
cosfin=0.911;  % znam. wsp. mocy
Sn=ns*PnM/etan/cosfin; % MVA - moc znamionowa pozorna zastepczego silnika
Unk=10;            % kV - napiecie znamionowe sieci w miejscu zwarcia
In=Sn/sqrt(3)/Unk; % kA - prad znamionowy zrodla
Rk=6.8442;          % om - rezystancja obwodu zw. przy Unk
Xk=16.7049;         % om - reaktancja  obwodu zw. przy Unk
tzw=0.24;          % s - czas trwania zwarcia
psi=0;             % stopnie - kat poczatkowy sem
c=1.1;  % maksymalny prad zw.
end


