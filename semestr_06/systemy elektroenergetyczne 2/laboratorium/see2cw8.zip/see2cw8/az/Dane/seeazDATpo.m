function [see,UNSobl,winf] = seeazDATpo
UNSobl=110.0; % kV 
winf=1e8; % nieskonczonosc
see={
%SiecZasil    wezel     UNQ   SkQ   c  R0X1 X0X1  tn
%12s          12s        kV   MVA   -     -    -   -
'SEE'   'GPZ110kV'      110  1500 1.1   0.0  1.0 1.0
};
end 
