function [c,zrodlo,In,m,Unk,Rk,Xk,tzw,psi]=datIzs_SEE
% zrodlo - tylko pojedyncze zrodlo zasilajace zwarcie: 
zrodlo='SEE';
Sn = [];   % MVA - moc znamionowa zrodla
In=[];     % kA - prad znamionowy zrodla
m=[];      % moc znamionowa silnika na pare biegunow
Unk=10;    % kV - napiecie znamionowe sieci w miejscu zwarcia
Rk=0.01892; % om - rezystancja obwodu zw. przy Unk
Xk=0.400329; % om - reaktancja  obwodu zw. przy Unk
tzw=0.24;  % s - czas trwania zwarcia
psi=0;     % stopnie - kat poczatkowy sem
c=1.1; % maksymalny prad zw.
end

