function [c,zrodlo,In,m,Unk,Rk,Xk,tzw,psi]=datIzs_GZ
zrodlo='GZ'; % zwarcie zasilane z zastepczego zrodla
SnG=11; %MVA - moc znamionowa GS
PnM=0.2;      % MW  - moc znamionowa mechaniczna silnika
p=2;          % liczba par biegunow
m=PnM/p;      % moc znamionowa silnika na pare biegunow
ns=6;         % liczba silnikow
etan=0.97;    % znamionowa sprawnosc silnika
cosfin=0.86;  % znam. wsp. mocy
SnM=ns*PnM/etan/cosfin; % MVA - moc znamionowa pozorna zastepczego silnika
Sn = SnG+SnM;   % MVA - moc znamionowa zastepczego zrodla
Unk=10;    % kV - napiecie znamionowe sieci w miejscu zwarcia
In=Sn/sqrt(3)/Unk; % kA - prad znamionowy zastepczego zrodla
j=sqrt(-1);
RkGk=0.016; % om - rezystancja od gen. synchr. do zwarcia przy Unk
XkGk=0.307; % om - reaktancja  od gen. synchr. do zwarcia przy Unk
ZkGk=RkGk+j*XkGk;
RkMk=8.241;   % om - rezystancja od silnika do zwarcia przy Unk
XkMk=20.184   % om - reaktancja  od silnika do zwarcia przy Unk
ZkMk=RkMk+j*XkMk;
Yk=1/ZkGk+1/ZkMk;
Zk=1/Yk;
Rk=real(Zk); Xk=imag(Zk);
tzw=0.24;  % s - czas trwania zwarcia
psi=0;     % stopnie - kat poczatkowy sem
c=1.1; % maksymalny prad zw.
end
