function az2izw
% wyznaczanie pradu zwarcia 3f - met. niezaleznych zrodel:
% SEE + G + M
% wyznaczanie przebiegu czasowego pr�du zwarcia 3-fazowego
% kolejno dodawne wykresy + legenda za pomoca hold on
% czytanie danych
t0=clock; % czas rozpoczecia obliczen
rok=int2str(t0(1));miesiac=int2str(t0(2));dzien=int2str(t0(3));
godz=int2str(t0(4));mins=int2str(t0(5));secs=int2str(t0(6));
czas=['_' rok '-' miesiac '-' dzien '_' godz 'h' mins];
sciezka0=pwd; cd([sciezka0 '\Wyniki']); sciezka1=pwd;
plikWy= strcat([sciezka1 '\az2izwOUT',czas,'.m']);
fd=fopen(plikWy,'wt');  % plik z przeczytanymi danymi do obliczen
cd ..
fprintf(fd,'\n%s - z3f zasilane z niezaleznych zr.: SEE,G,M ***',plikWy);
fprintf(   '\n%s - z3f zasilane z niezaleznych zr.: SEE,G,M ***',plikWy);
fprintf(fd,...
'\n Data: %5d-%2d-%2d  godz. %2d, %2dmin, %2.0fs',clock);
% czytanie danych
wdold=cd;
[fname,sciezka]=...
uigetfile('dataz2izw*.*','WYBIERZ m-plik z danymi:');
fprintf('\n... wybrano: %s%s.m',sciezka,fname);
eval(['cd(''',sciezka,''')']);
% czytanie wybranego pliku 
plikdat=strtok(fname,'.');
[c,ZSEE, ZG, ZM, Unk, psi, tz]=feval(plikdat);
eval(['cd(''',wdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
IkSEE=c*Unk/sqrt(3)/abs(ZSEE); SkSEE=sqrt(3)*Unk*IkSEE; % system SEE
IkG=c*Unk/sqrt(3)/abs(ZG);      SkG=sqrt(3)*Unk*IkG;% gen.synchr. G
IkM=c*Unk/sqrt(3)/abs(ZM);      SkM=sqrt(3)*Unk*IkM;% silnik ind. M
Iksuma=IkSEE + IkG  + IkM;
Sksuma=SkSEE + SkG  + SkM;
fprintf(fd,'\n\n Metoda niezaleznych zrodel zasilajacych zwarcie');
fprintf(fd,...
'\n Impedancje zwarciowe galezi zrodlo - punkt zwarcia 3-fazowego');
fprintf(fd,...
'\n ZkSEE = RkSEE+jXkSEE = (%6.3f + j%6.3f) om - imp. zw. pol. z SEE',...
    real(ZSEE),imag(ZSEE));
fprintf(fd,...
'\n   ZkG = RkG   +jXkG  = (%6.3f + j%6.3f) om - imp. zw. pol. z GS',...
    real(ZG),imag(ZG));
fprintf(fd,...
'\n   ZkM = RkM   +jXkM  = (%6.3f + j%6.3f) om - imp. zw. pol. z M',...
    real(ZM),imag(ZM));
fprintf(fd,...
'\n Unk = %5.1f kV - znamionowe napiecie sieci w punkcie zwarcia',Unk);
fprintf(fd,'\n Prady zwarciowe poczatkowe');
fprintf(fd,'\n c = %4.2g ',c);
fprintf(fd,...
    '\n  IkSEE = %6.3f kA (%5.1f%%) - prad zw. poczatkowy od SEE',...
    IkSEE,IkSEE/Iksuma*100);
fprintf(fd,...
    '\n    IkG = %6.3f kA (%5.1f%%) - prad zw. poczatkowy od GS',...
    IkG,IkG/Iksuma*100);
fprintf(fd,...
    '\n    IkM = %6.3f kA (%5.1f%%) - prad zw. poczatkowy od M',...
    IkM,IkM/Iksuma*100);
fprintf(fd,...
    '\n     Ik = %6.3f kA (%5.1f%%) - prad zw. poczatkowy sumaryczny',...
    Iksuma,Iksuma/Iksuma*100);
fprintf(fd,'\n Moce zwarciowe');
fprintf(fd,'\n  SkSEE = %6.0f MVA - moc zwarciowa od SEE',SkSEE);
fprintf(fd,'\n    SkG = %6.0f MVA - moc zwarciowa od  GS',SkG);
fprintf(fd,'\n    SkM = %6.0f MVA - moc zwarciowa od   M',SkM);
fprintf(fd,'\n     Sk = %6.0f MVA - moc zwarciowa sumaryczna',Sksuma);
% przebiegi czasowe pradu zwarciowego
% impedancja Thevenina widziana z miejscu zwarcia
Ykk=1/ZSEE+1/ZG+1/ZM;
Zkk=1/Ykk; % impedancja Thevenina
R=real(Zkk); X=imag(Zkk);
Ik=c*Unk/sqrt(3)/abs(Zkk);
Sk=sqrt(3)*Unk*Ik;
U=Unk;
Um = sqrt(2)*U; % amplituda nap. zasilajacego
Z = sqrt(R^2+X^2); % impedancja pozorna obwodu
fi = atan(X/R); % kat impedancji
f = 50; % czestotliwosc napiecia , Hz
w = 2*pi*f; % czestosc napiecia
L = X/w; % indukcyjnosc obwodu
tau = L/R; %stala zanikania
fprintf(fd,'\n\n Metoda Thevenina - imp. widziana z miejsca zwarcia');
fprintf(fd,'\n 1/Zkk = 1/ZSEE + 1/ZG + 1/ZM');
fprintf(fd,'\n Zkk = Rkk +jXkk = (%6.3f + j%6.3f) om ',R,X);
fprintf(fd,'\n Ik = %9.3f kA  - prad zwarciowy poczatkowy',Ik);
fprintf(fd,'\n Sk = %9.1f MVA - moc zwarciowa\n',Sk);
% WYZNACZANIE PRZEBIEGU NIEUSTALONEGO PRADU 
psist=psi; % kat SEM w stopniach
psi=psi/180*pi; % kat w radianach  
cpsist=num2str(psist,2);
Tmax = tz ; % max czas analizy
stz=num2str(tz,3); sc=num2str(c,3);
T = 0:0.001:Tmax; % przedzial czasu analizy od 0 do 1 sekundy
nT=length(T); % liczba punktow czasowych
p0 = zeros(1,nT); % os zerowa
Im = Um/Z; % amplituda pradu
iAC = Um/Z * sin(w.*T + psi - fi); % skladowa okresowa
iDC = - Um/Z*exp(-T./tau)*sin(psi-fi); %skladowa nieokresowa
iRL = iAC + iDC; 
%wykres skladowej okresowej iAC
plot(T,iAC,'-.b', T,p0,'-k','LineWidth',1.5);
title(['c=' sc ', tz=' stz ', kat poczatkowy= ' cpsist 'st - iAC(t)']);
xlabel('t,s'); ylabel('kA');
% skalowanie wykresu % axis (xmin, xmax, ymin, ymax);
Imax = 1.1*Im; % skala osi rzednych dla iAC, iDC
Imax2=2*Imax;  % skala osi rzednych dla pradu zwarciowego
axis([0 Tmax -Imax Imax]); grid on; legend('iAC');
pause(3);
saveas(gcf,'iAC','emf'); close;
%wykres skladowej okresowej iDC
plot(T,iDC,':r', T, p0,'-k','LineWidth',1.5);
title(['c=' sc ', tz=' stz ', kat poczatkowy= ' cpsist 'st - iDC(t)']);
xlabel('t,s'); ylabel('kA');
axis([0 Tmax -Imax Imax]); grid on; legend('iDC');
pause(3);
saveas(gcf,'iDC','emf'); close;
%wykres chwilowych wartosci pradu zwarciowego
plot(T,iRL,'-k', T,iAC,'-.b',T,iDC,':r','LineWidth',1.5);
title(['c=' sc ', tz=' stz ', kat poczatkowy= ' cpsist 'st - i(t)=iAC(t)+iDC(t)']);
xlabel('t,s'); ylabel('kA');
axis([0 Tmax -Imax2 Imax2]); grid on;
legend('i=iAC+iDC','iAC','iDC');
pause(3);
saveas(gcf,'iAC_DC','emf'); close;
fclose('all');
fprintf('\n\n Wyniki w m-pliku: %s',plikWy);
end
