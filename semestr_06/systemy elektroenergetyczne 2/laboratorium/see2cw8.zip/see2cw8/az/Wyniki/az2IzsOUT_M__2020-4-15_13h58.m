
*** O:\OneDrive - Politechnika Wroclawska\studia\Systemy elektroenergetyczne 2\lab\see2cw8\az\Wyniki\az2IzsOUT_M__2020-4-15_13h58.m - z3f wg IEC (SEE,G,M,GZ): Ik,ip,Ib,Ibasym,Ith
 Data:  2020- 4-15  godz. 13, 58min, 57s
ZWARCIE 3-fazowe zasilane przez :M
 Napiecie znamionowe sieci     Unk =     10 kV
 Prad. znam. zrodla przy Unk    In = 0.0984 kA
 Rezystancja zw.                Rk =  6.844 om
 Reaktancja  zw.                Xk =   16.7 om
 stosunek Rk do Xk           Rk/Xk = 0.4097
 stala czasowa zanikania  tau=Lk/Rk = 0.007769 s
 wsp. udarowy                 kappa =  1.307
 Impedancja  zw.                 Zk = 18.0526 om
 wsp. obl. zw.                    c =    1.1
 Prad zw. pocz.                  Ik = 0.3518 kA
 MOC ZWARCIOWA                   Sk =  6.093 MVA
 Prad obwiedni                  Ikm =  0.995 kA
 Prad udarowy                    ip = 0.6501 kA
 Czas trwania zw.                tz =   0.24 s
 wsp. odl. zrodla od zwarcia  Ik/In =  3.575
 Ik/In>2  - zwarcie bliskie zrodla ...
 wsp. wyl. w chwili tz           mi =      1
 moc silnika na pare biegunow     m = 0.1255 MW
 wsp. q dla silnikow              q = 0.07035
 wsp. wyl. w chwili tz         mi*q = 0.07035
 Prad wylaczeniowy w chwili tz   Ib = 0.01992 kA
 Prad nieokresowy  w chwili tz  iDC = 1.766e-14 kA
 Prad wyl. asym. w chwili tz Ibasym = 0.01992 kA
 Prad zast. cieplny chwili tz   Ith = 0.3579 kA
 - wyznaczony dla wsp. n=1 oraz   m = 0.03525
 Przebiegi czasowe pradow opisujacych zwarcie 3-fazowe
  t,s   izw,kA   iAC,kA   Ib,kA   iDC,kA  Ibasym,kA Ith,kA Ith(1s),kA
 0.00    0.000   -0.460      NaN    0.460      NaN      NaN      NaN
 0.01    0.587    0.460      NaN    0.127      NaN    0.468    0.047
 0.02   -0.425   -0.460    0.259    0.035    0.260    0.419    0.059
 0.03    0.470    0.460    0.228    0.010    0.228    0.398    0.069
 0.04   -0.458   -0.460    0.197    0.003    0.197    0.387    0.077
 0.05    0.461    0.460    0.168    0.001    0.168    0.380    0.085
 0.06   -0.460   -0.460    0.153    0.000    0.153    0.376    0.092
 0.07    0.460    0.460    0.139    0.000    0.139    0.372    0.099
 0.08   -0.460   -0.460    0.124    0.000    0.124    0.370    0.105
 0.09    0.460    0.460    0.110    0.000    0.110    0.368    0.110
 0.10   -0.460   -0.460    0.096    0.000    0.096    0.366    0.116
 0.11    0.460    0.460    0.090    0.000    0.090    0.365    0.121
 0.12   -0.460   -0.460    0.085    0.000    0.085    0.364    0.126
 0.13    0.460    0.460    0.079    0.000    0.079    0.363    0.131
 0.14   -0.460   -0.460    0.073    0.000    0.073    0.362    0.136
 0.15    0.460    0.460    0.068    0.000    0.068    0.362    0.140
 0.16   -0.460   -0.460    0.062    0.000    0.062    0.361    0.144
 0.17    0.460    0.460    0.057    0.000    0.057    0.360    0.149
 0.18   -0.460   -0.460    0.052    0.000    0.052    0.360    0.153
 0.19    0.460    0.460    0.046    0.000    0.046    0.360    0.157
 0.20   -0.460   -0.460    0.041    0.000    0.041    0.359    0.161
 0.21    0.460    0.460    0.036    0.000    0.036    0.359    0.164
 0.22   -0.460   -0.460    0.030    0.000    0.030    0.358    0.168
 0.23    0.460    0.460    0.025    0.000    0.025    0.358    0.172
 0.24   -0.460   -0.460    0.020    0.000    0.020    0.358    0.175
! Czas trwania analizy zwarc: 20.59 sekund !