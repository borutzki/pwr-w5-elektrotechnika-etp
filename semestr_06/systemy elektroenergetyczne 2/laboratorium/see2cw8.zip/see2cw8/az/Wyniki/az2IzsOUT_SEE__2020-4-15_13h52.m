
*** O:\OneDrive - Politechnika Wroclawska\studia\Systemy elektroenergetyczne 2\lab\see2cw8\az\Wyniki\az2IzsOUT_SEE__2020-4-15_13h52.m - z3f wg IEC (SEE,G,M,GZ): Ik,ip,Ib,Ibasym,Ith
 Data:  2020- 4-15  godz. 13, 52min, 52s
ZWARCIE 3-fazowe zasilane przez :SEE
 Napiecie znamionowe sieci     Unk =     10 kV
 Prad. znam. zrodla przy Unk    In =  15.85 kA
 Rezystancja zw.                Rk = 0.01892 om
 Reaktancja  zw.                Xk = 0.4003 om
 stosunek Rk do Xk           Rk/Xk = 0.04726
 stala czasowa zanikania  tau=Lk/Rk = 0.06735 s
 wsp. udarowy                 kappa =   1.87
 Impedancja  zw.                 Zk = 0.4008 om
 wsp. obl. zw.                    c =    1.1
 Prad zw. pocz.                  Ik =  15.85 kA
 MOC ZWARCIOWA                   Sk =  274.5 MVA
 Prad obwiedni                  Ikm =  44.82 kA
 Prad udarowy                    ip =  41.92 kA
 Czas trwania zw.                tz =   0.24 s
 wsp. odl. zrodla od zwarcia  Ik/In =      1
 Ik/In<=2 - zwarcie odlegle od zrodla ...
 wsp. wyl. w chwili tz           mi =      1
 Prad wylaczeniowy w chwili tz   Ib =  15.85 kA
 Prad nieokresowy  w chwili tz  iDC = 0.6344 kA
 Prad wyl. asym. w chwili tz Ibasym =  15.85 kA
 Prad zast. cieplny chwili tz   Ith =  18.07 kA
 - wyznaczony dla wsp. n=1 oraz   m = 0.2999
 Przebiegi czasowe pradow opisujacych zwarcie 3-fazowe
  t,s   izw,kA   iAC,kA   Ib,kA   iDC,kA  Ibasym,kA Ith,kA Ith(1s),kA
 0.00    0.000  -22.385   15.846   22.385   22.398      NaN      NaN
 0.01   41.682   22.385   15.846   19.297   20.911   26.262    2.626
 0.02   -5.751  -22.385   15.846   16.634   19.735   25.230    3.568
 0.03   36.724   22.385   15.846   14.339   18.812   24.331    4.214
 0.04  -10.025  -22.385   15.846   12.360   18.097   23.547    4.709
 0.05   33.040   22.385   15.846   10.655   17.546   22.863    5.112
 0.06  -13.200  -22.385   15.846    9.185   17.126   22.264    5.454
 0.07   30.303   22.385   15.846    7.917   16.806   21.739    5.752
 0.08  -15.560  -22.385   15.846    6.825   16.565   21.278    6.018
 0.09   28.269   22.385   15.846    5.883   16.383   20.872    6.262
 0.10  -17.314  -22.385   15.846    5.072   16.247   20.514    6.487
 0.11   26.757   22.385   15.846    4.372   16.145   20.196    6.698
 0.12  -18.617  -22.385   15.846    3.769   16.069   19.913    6.898
 0.13   25.634   22.385   15.846    3.249   16.012   19.661    7.089
 0.14  -19.585  -22.385   15.846    2.800   15.970   19.435    7.272
 0.15   24.799   22.385   15.846    2.414   15.938   19.233    7.449
 0.16  -20.304  -22.385   15.846    2.081   15.915   19.050    7.620
 0.17   24.179   22.385   15.846    1.794   15.897   18.884    7.786
 0.18  -20.839  -22.385   15.846    1.546   15.884   18.734    7.948
 0.19   23.718   22.385   15.846    1.333   15.874   18.598    8.107
 0.20  -21.236  -22.385   15.846    1.149   15.867   18.473    8.261
 0.21   23.376   22.385   15.846    0.990   15.862   18.359    8.413
 0.22  -21.531  -22.385   15.846    0.854   15.858   18.254    8.562
 0.23   23.121   22.385   15.846    0.736   15.855   18.157    8.708
 0.24  -21.751  -22.385   15.846    0.634   15.853   18.067    8.851
! Czas trwania analizy zwarc: 25.94 sekund !