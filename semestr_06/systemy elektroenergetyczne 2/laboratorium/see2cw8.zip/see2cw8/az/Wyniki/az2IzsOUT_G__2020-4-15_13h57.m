
*** O:\OneDrive - Politechnika Wroclawska\studia\Systemy elektroenergetyczne 2\lab\see2cw8\az\Wyniki\az2IzsOUT_G__2020-4-15_13h57.m - z3f wg IEC (SEE,G,M,GZ): Ik,ip,Ib,Ibasym,Ith
 Data:  2020- 4-15  godz. 13, 57min, 15s
ZWARCIE 3-fazowe zasilane przez :G
 Napiecie znamionowe sieci     Unk =     10 kV
 Prad. znam. zrodla przy Unk    In = 0.6645 kA
 Rezystancja zw.                Rk =  0.117 om
 Reaktancja  zw.                Xk =  1.672 om
 stosunek Rk do Xk           Rk/Xk = 0.06998
 stala czasowa zanikania  tau=Lk/Rk = 0.04549 s
 wsp. udarowy                 kappa =  1.814
 Impedancja  zw.                 Zk = 1.6761 om
 wsp. obl. zw.                    c =    1.1
 Prad zw. pocz.                  Ik =  3.789 kA
 MOC ZWARCIOWA                   Sk =  65.63 MVA
 Prad obwiedni                  Ikm =  10.72 kA
 Prad udarowy                    ip =  9.723 kA
 Czas trwania zw.                tz =   0.24 s
 wsp. odl. zrodla od zwarcia  Ik/In =  5.702
 Ik/In>2  - zwarcie bliskie zrodla ...
 wsp. wyl. w chwili tz           mi = 0.6722
 Prad wylaczeniowy w chwili tz   Ib =  2.547 kA
 Prad nieokresowy  w chwili tz  iDC = 0.02733 kA
 Prad wyl. asym. w chwili tz Ibasym =  2.547 kA
 Prad zast. cieplny chwili tz   Ith =  4.156 kA
 - wyznaczony dla wsp. n=1 oraz   m =  0.203
 Przebiegi czasowe pradow opisujacych zwarcie 3-fazowe
  t,s   izw,kA   iAC,kA   Ib,kA   iDC,kA  Ibasym,kA Ith,kA Ith(1s),kA
 0.00    0.000   -5.346      NaN    5.346      NaN      NaN      NaN
 0.01    9.636    5.346      NaN    4.291      NaN    6.157    0.616
 0.02   -1.902   -5.346    3.407    3.444    4.187    5.826    0.824
 0.03    8.110    5.346    3.284    2.764    3.822    5.556    0.962
 0.04   -3.127   -5.346    3.162    2.219    3.530    5.335    1.067
 0.05    7.126    5.346    3.040    1.781    3.290    5.153    1.152
 0.06   -3.916   -5.346    2.989    1.429    3.156    5.002    1.225
 0.07    6.493    5.346    2.939    1.147    3.049    4.877    1.290
 0.08   -4.425   -5.346    2.889    0.921    2.962    4.772    1.350
 0.09    6.085    5.346    2.839    0.739    2.887    4.684    1.405
 0.10   -4.752   -5.346    2.789    0.593    2.821    4.608    1.457
 0.11    5.822    5.346    2.772    0.476    2.792    4.544    1.507
 0.12   -4.963   -5.346    2.755    0.382    2.768    4.488    1.555
 0.13    5.652    5.346    2.737    0.307    2.746    4.440    1.601
 0.14   -5.099   -5.346    2.720    0.246    2.726    4.397    1.645
 0.15    5.543    5.346    2.703    0.198    2.706    4.360    1.689
 0.16   -5.187   -5.346    2.685    0.159    2.688    4.327    1.731
 0.17    5.473    5.346    2.668    0.127    2.670    4.297    1.772
 0.18   -5.243   -5.346    2.651    0.102    2.652    4.271    1.812
 0.19    5.428    5.346    2.634    0.082    2.634    4.247    1.851
 0.20   -5.280   -5.346    2.616    0.066    2.617    4.225    1.890
 0.21    5.398    5.346    2.599    0.053    2.599    4.206    1.927
 0.22   -5.303   -5.346    2.582    0.042    2.582    4.188    1.964
 0.23    5.380    5.346    2.564    0.034    2.565    4.171    2.000
 0.24   -5.318   -5.346    2.547    0.027    2.547    4.156    2.036
! Czas trwania analizy zwarc: 23.86 sekund !