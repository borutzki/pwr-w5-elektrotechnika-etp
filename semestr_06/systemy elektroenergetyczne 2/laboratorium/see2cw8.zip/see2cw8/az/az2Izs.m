function az2Izs
% analiza zwarcia 3-f wg iec
t0=clock; % czas rozpoczecia obliczen
rok=int2str(t0(1));miesiac=int2str(t0(2));dzien=int2str(t0(3));
godz=int2str(t0(4));mins=int2str(t0(5));secs=int2str(t0(6));
czas=['_' rok '-' miesiac '-' dzien '_' godz 'h' mins];
% czytanie danych
wdold=cd;
[fname,sciezka]=...
uigetfile('datIzs_*.*','WYBIERZ m-plik z danymi:');
fprintf(   '\n... wybrano: %s%s.m',sciezka,fname);
eval(['cd(''',sciezka,''')']);
% czytanie wybranego pliku 
plikdat=strtok(fname,'.');
[c,zrodlo,In,m,Unk,Rk,Xk,tz,psi]=feval(plikdat);
eval(['cd(''',wdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
% otwieranie pliku na wyniki
sciezka0=pwd; cd([sciezka0 '\Wyniki']); sciezka1=pwd;
plikWy= strcat([sciezka1 '\az2IzsOUT_' zrodlo '_' czas '.m']);
fd=fopen(plikWy,'wt');  % plik z przeczytanymi danymi do obliczen
cd ..
fprintf(fd,'\n*** %s - z3f wg IEC (SEE,G,M,GZ): Ik,ip,Ib,Ibasym,Ith',plikWy);
fprintf(   '\n*** %s - z3f wg IEC (SEE,G,M,GZ): Ik,ip,Ib,Ibasym,Ith',plikWy);
fprintf(fd,...
'\n Data: %5d-%2d-%2d  godz. %2d, %2dmin, %2.0fs',clock);
stz=num2str(tz,3); % czas trwania zwarcia
%
U=Unk/sqrt(3); % sem Thevenina
Um = c*sqrt(2)*U; % amplituda nap. zasilajacego
if Rk == 0 Rk=Xk*1e-5; end % w celu uninki�cie dzielenia przez 0
Zk=abs(Rk+j*Xk);
Ik=c*Unk/sqrt(3)/Zk; % prad zwarciowy poczatkowy
Ikm=2*sqrt(2)*Ik; % prad obwiedni w chwili t=0_
RkXk=Rk/Xk; % stosunke rezystancji do rekatancji
kappa=1.02+0.98*exp(-3*RkXk);%kappa - wsp. udaru 
ip=kappa*(sqrt(2))*Ik;   %ip - prad udarowy
sUnk=num2str(Unk,3);
sRk=num2str(Rk,3);sXk=num2str(Xk,3); spsi=num2str(psi,1);
opis=['zrodlo: ' zrodlo ' - tz=' stz 's,' 'Unk=' sUnk 'kV, Rk='...
    sRk 'om, Xk=' sXk 'om, psi=' spsi 'st'];
fi = atan(Xk/Rk); % kat impedancji obwodu 
f = 50; % czestotliwosc napiecia , Hz
w = 2*pi*f; % czestosc napiecia
Lk = Xk/w; % indukcyjnosc obwodu
tau = Lk/Rk; %stala zanikania
psi=psi/180*pi; % przeliczenie stopni na radiany
Tmax = tz ; % czas trwania zwarcia
T = 0:0.001:Tmax; % przedzial czasu analizy zwarcia
nT=length(T); % liczba punktow czasowych
p0 = zeros(1,nT);% os zerowa
p1 = ones(1,nT); % os jedynkowa
Ikt=p1*Ik;
Ikmt=p1*Ikm;
ipt=p1*ip;
Im = Um/Zk; % amplituda pradu
iAC = Im*sin(w.*T + psi - fi); % skladowa okresowa
iDC = - Im*exp(-T./tau)*sin(psi-fi); %skladowa nieokresowa
izw = iAC + iDC; 
%wykres chwilowych wartosci pradu zwarciowego
plot(T,izw,':k', T,Ikt,'--m',T,ipt,'-.b',T,Ikmt,'-r','LineWidth',1.5);
title(opis);
xlabel('t,s'); ylabel('kA');
axis([0 Tmax -1.05*Im 1.05*Ikm]); grid on;
legend('izw(t)','Ik=c*Unk/sqrt(3)/Zk','ip','2*sqrt(2)*Ik');
saveas(gcf,'izwt','emf'); pause(5); close;
%wykres izw,iAC,iDC
plot(T,izw,'-k', T,iAC,'-.b',T,iDC,'--r','LineWidth',1.5);
title(opis);
xlabel('t,s'); ylabel('kA');
axis([0 Tmax -2.1*Im 2.1*Im]); grid on;
legend('izw=iAC+iDC','iAC','iDC');
saveas(gcf,'izw_iAC_iDC','emf'); pause(5); close;
%
zr=[];
if strcmp(zrodlo,'G')  zr=1; end
if strcmp(zrodlo,'M') zr=2; end
if strcmp(zrodlo,'SEE') zr=3; end
if strcmp(zrodlo,'GZ')  zr=4; end
if isempty(zr)
    fprintf(fd,'\n Nie zidentyfikowano rodzaju zrodla');
    fprintf(fd,'\n Podaj: SEE, G, M lub GZ');
    return
    fprintf('\n Nie zidentyfikowano rodzaju zrodla');
    fprintf('\n Podaj: SEE, G, M lub GZ');
end
% OBLICZENIA PRADOW CHARAKTERYZUJACYCH ZWARCIE

c=1.1;
Sk=sqrt(3)*Unk*Ik; 
%
iAC=[]; iDC=[]; izw=[]; Ib=[];Ibasym=[]; mi=[]; q=[];
t=0:0.01:tz;%czas trwania zwarcia maksymalny
wt=length(t);
jeden=ones(wt,1);
%
w =2*pi*50;  %omega - pulsacja pradu
iAC=[]; iDC=[];
iAC = Im*sin(w.*t + psi - fi); % skladowa okresowa
iDC = - Im*exp(-t./tau)*sin(psi-fi); %skladowa nieokresowa
%iDCtz=- Im*exp(-tz/tau)*sin(psi-fi)
IkG=0; IkM=0; IkQ=0; 
if zr == 1 | zr == 4
    IkG=Ik; InG=In;
    sg=IkG/InG; % stosunek pradu zw. poczatkowego do pradu znam. zrodla
    if sg > 2
        [mi]=iz3fmi(sg,t);        IbG=IkG.*mi;
 
    else
        mi=jeden; IbG=IkG.*mi;
    end %if sg > 2
    Ib=IbG;
    mitz=mi(wt); % wsp. pradu wyl. Ib
end %if zr == 1 | zr == 4
%
if zr == 2
    sm=0;    IkM=Ik;  InM=In;  sm=IkM/InM;    [q]=iz3fq(m,t);
        if sm>2
           [mi]=iz3fmi(sm,t);
           IbM=IkM*mi.*q;
        else 
           IbM=IkM.*q;
        end %if sm>2
        mi=jeden; Ib=IbM.*mi;
        mitz=mi(wt); % wsp. pradu wyl. Ib
        qtz=q(wt);   % korekta wsp. pradu wyl. Ib dla silnika
        miqtz=mitz*qtz;
end %if zr == 2
%
if zr == 3
    IbQ = Ik;   mi=jeden; Ib = IbQ.*mi;
    mitz=mi(wt); % wsp. pradu wyl. Ib
end
 %prad wylaczeniowy symetryczny i asymetryczny
Ibasym=sqrt((Ib.^2)+(iDC'/(sqrt(2))).^2);
Ikt=Ik*jeden; 
% wykresy Ib(t), iDC(t), Ibasym(t)
plot(t,Ikt,':k',t,Ib,'-r',t,iDC,'-.b',t,Ibasym,'--g','LineWidth',2.0);
legend('Ik -opr.zw.pocz', 'Ib(t)','iDC(t)','Ibasym(t)');
title(opis);
xlabel('t[s]'); ylabel('Ik,Ib,iDC,Ibasym, [kA]'); grid on;
saveas(gcf,'IbiDCIbasym','emf'); pause(3);
close;
% prad zastepczy cieplny wykresy Ith(t)
wm=(1./(2*50*t*log(kappa-1))).*( exp(4*50*t*log(kappa-1))-1); 
%wmtz=(1./(2*50*tz*log(kappa-1))).*( exp(4*50*tz*log(kappa-1))-1); 
wn=1;
wmtz=wm(wt);
Ith=Ik*sqrt(wm+wn);     % prad zastepczy cieplny
Ith1s=Ith.*(sqrt(t/1));  % prad cieplny 1 - sekundowy
% wykres Ith(t)
plot(t,Ikt,'--k',t,Ith,'-r');
title(opis);xlabel('t[s]'); ylabel('Ith[kA]'); grid on;
legend('Ik - prad zw. poczatkowy','Ith(t)-prad zw. zast. cieplny');
saveas(gcf,'Ith','emf'); pause(3);
close;%
%
Ibtz=Ib(wt); iDCtz=iDC(wt); Ibasymtz=Ibasym(wt); Ithtz=Ith(wt);
if zr == 2
    mitz=mi(wt); qtz=q(wt); miqtz=mitz*qtz;
end
if isempty(In) In=Ik; end
IkIn=Ik/In; % wsp. odleglosci zrodla od miejsca zwarcia 
% wyniki analizy
fprintf(fd,'\nZWARCIE 3-fazowe zasilane przez :%s',zrodlo);
fprintf(fd,'\n Napiecie znamionowe sieci     Unk = %6.4g kV',Unk);
fprintf(fd,'\n Prad. znam. zrodla przy Unk    In = %6.4g kA',In);
fprintf(fd,'\n Rezystancja zw.                Rk = %6.4g om',Rk);
fprintf(fd,'\n Reaktancja  zw.                Xk = %6.4g om',Xk);
fprintf(fd,'\n stosunek Rk do Xk           Rk/Xk = %6.4g',RkXk);
fprintf(fd,'\n stala czasowa zanikania  tau=Lk/Rk = %6.4g s',tau);
fprintf(fd,'\n wsp. udarowy                 kappa = %6.4g',kappa);
fprintf(fd,'\n Impedancja  zw.                 Zk = %6.4f om',Zk);
fprintf(fd,'\n wsp. obl. zw.                    c = %6.4g',c);
fprintf(fd,'\n Prad zw. pocz.                  Ik = %6.4g kA',Ik);
fprintf(fd,'\n MOC ZWARCIOWA                   Sk = %6.4g MVA',Sk');
fprintf(fd,'\n Prad obwiedni                  Ikm = %6.4g kA',Ikm);
fprintf(fd,'\n Prad udarowy                    ip = %6.4g kA',ip);
fprintf(fd,'\n Czas trwania zw.                tz = %6.4g s',tz);
fprintf(fd,'\n wsp. odl. zrodla od zwarcia  Ik/In = %6.4g',IkIn);
if IkIn>2
fprintf(fd,'\n Ik/In>2  - zwarcie bliskie zrodla ...'); 
else
fprintf(fd,'\n Ik/In<=2 - zwarcie odlegle od zrodla ...');     
end
fprintf(fd,'\n wsp. wyl. w chwili tz           mi = %6.4g',mitz);
if zr == 2
fprintf(fd,'\n moc silnika na pare biegunow     m = %6.4g MW',m);
fprintf(fd,'\n wsp. q dla silnikow              q = %6.4g',qtz);
fprintf(fd,'\n wsp. wyl. w chwili tz         mi*q = %6.4g',miqtz);
end
fprintf(fd,'\n Prad wylaczeniowy w chwili tz   Ib = %6.4g kA',Ibtz);
fprintf(fd,'\n Prad nieokresowy  w chwili tz  iDC = %6.4g kA',iDCtz);
fprintf(fd,'\n Prad wyl. asym. w chwili tz Ibasym = %6.4g kA',Ibtz);
fprintf(fd,'\n Prad zast. cieplny chwili tz   Ith = %6.4g kA',Ithtz);
fprintf(fd,'\n - wyznaczony dla wsp. n=1 oraz   m = %6.4g', wmtz);
% przebiegi czasowe  pradow iAC(t),Ib(t),iDC(t),Ibasym(t),Ith(t),Ith1s(t)
fprintf(fd,...
'\n Przebiegi czasowe pradow opisujacych zwarcie 3-fazowe');
fprintf(fd,...
'\n  t,s   izw,kA   iAC,kA   Ib,kA   iDC,kA  Ibasym,kA Ith,kA Ith(1s),kA');
izw=[]; izw=iAC+iDC;
for i=1:wt
    fprintf(fd,'\n %4.2f %8.3f %8.3f %8.3f %8.3f %8.3f %8.3f %8.3f'...
        ,t(i),izw(i),iAC(i),Ib(i),iDC(i),Ibasym(i),Ith(i),Ith1s(i));
end %for i=1:wt
et=etime(clock,t0); % calkowity czas obliczen
fprintf(fd, '\n! Czas trwania analizy zwarc: %.2f sekund !', et);
fprintf(    '\n! Czas trwania analizy zwarc: %.2f sekund !', et);
fclose('all');
fprintf('\n\n z3fiec() - wyniki w pliku: %s',plikWy);
end % koniec z3fiec() 

function [wmi]= iz3fmi (s,t,tz)
%funkcja obliczajaca wspolczynnik mi potrzebny 
%do wyliczania symetrycznych pradow wylaczeniowych,
 T=[0.02 0.05 0.1 0.25 0.5];  
for i=1:length(T)
    if T(i)==0.02
    mi(i,1)=0.84+0.26.*(exp(-0.26.*s));end
    if T(i)==0.05
     mi(i,1)=0.71+0.51.*(exp(-0.30.*s));end
    if T(i)==0.1
    mi(i,1)=0.62+0.72.*(exp(-0.32.*s));end
    if T(i)>=0.25
    mi(i,1)=0.56+0.94.*(exp(-0.38.*s));end
end %for i=1:length(T)
yi=interp1(T,mi,t);
[nyi,myi]=size(yi);
if nyi == 1 
    wmi=yi'; % wartosc wspolczynnika mi
else
    wmi=yi;
end
end

function [wqi]= iz3fq (m,t,tz)
%funkcja obliczajaca wspolczynnik q potrzebny
%do wyliczania pradow zwarciowych wylaczeniowych silnikow indukcyjnych
 T=[0.02 0.05 0.1 0.25 0.5];  
for i=1:length(T)
    if T(i)==0.02
        q(i,1)=1.03+0.12.*log(m);end
    if T(i)==0.05
        q(i,1)=0.79+0.12.*log(m);end
    if T(i)==0.1   q(i,1)=0.57+0.12.*log(m);end
    if T(i)>=0.25
        q(i,1)=0.26+0.10.*log(m);end
end %for i=1:length(T)
yi=interp1(T,q,t);[nyi,myi]=size(yi);
if nyi == 1 
    wqi=yi'; % wartosc wspolczynnika q
else
    wqi=yi;
end %if nyi == 1 
end



