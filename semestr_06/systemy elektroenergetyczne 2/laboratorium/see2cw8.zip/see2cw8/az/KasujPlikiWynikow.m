function KasujPlikiWynikow
sciezka0=pwd; cd([sciezka0 '\Wyniki']);
fprintf('\n\n Kasowanie plikow wymikow *.txt?');
fprintf('\n 1- TAK, 0 - NIE');
fprintf('\n... podaj: 1 lub 0 \n');
odptxt=input(' ');
if odptxt
delete *.txt
fprintf('\n\n ... skasowano wszystkie pliki wynikow *.txt ...');
fprintf('\n ... w katalogu: %s ...\n\n',pwd);
end
fprintf('\n\n Kasowanie plikow wymikow *.m?');
fprintf('\n 1- TAK, 0 - NIE');
fprintf('\n... podaj: 1 lub 0 \n');
odpm=input(' ');
if odptxt
delete *.m
fprintf('\n\n ... skasowano wszystkie pliki wynikow *.m ...');
fprintf('\n ... w katalogu: %s ...\n\n',pwd);
end
cd ..
end

