function [Vbus,SLBUS,SGBUS,TUNBUS]=a2wzrostPsee(fdvs,fdpu,...
    nazwez,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,REF,PU,PQ,YSHBUS,...
    Ybus,Vbus,Ureg,opt,SGMIN,SGMAX,...
    Sbase,WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,...
    STATUS,SMAX,YPP,YPK,YKP,YKK,nazgal,UKUZW,QKOMP);
 % IDENTYFIKACJA wezlow z charakterystykami P-U
 [wezPU]=a2wezPU(fdvs,nazwez); 
 opt=1; % planowany rozplyw mocy
 [Ybus,Vbus,YPP,YPK,YKP,YKK,TMK,...
     SLBUS,SGBUS,TUNBUS,success,Ureg] = ...
 a2rm(fdvs,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
   REF,PU,PQ,Ybus,Vbus,Ureg,opt,...
    WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,YPP,YPK,YKP,YKK,...
     STATUS,SGMIN,SGMAX,nazwez,nazgal);
% moce i nap. wezlowe w planowanym rozplywie mocy
 n=size(Vbus,1);
 Pgen=real(SGBUS); Qgen=imag(SGBUS); Pgmax=real(SGMAX);
 Podb=-real(SLBUS); Qodb=-imag(SLBUS);
 Swez=SGBUS-SLBUS;  Pwez=real(Swez);  Qwez=imag(Swez);
 Um=abs(Vbus);  TYP=real(TUNBUS); UNBUS=imag(TUNBUS);
 % liczba wezlow z char. P-U nie moze przekroczyc 20
 wymwezPU=size(wezPU,1); nwezkryt=wymwezPU;
 if nwezkryt>20 nwezkryt=20; end
 idruk=0; kk=0; kwez=0;
 fprintf(fdvs,'\n Planowane moce w wezlach z char. P-U');
 fprintf(fdvs,...
 '\nnrwez  nazwa     typ    Un   PgMAX    Pgen    Qgen    ');
fprintf(fdvs,'Podb    Qodb   QKOMP');
 fprintf(fdvs,...
 '\n    -    -         -    kV      pu      pu      pu      ');
fprintf(fdvs,'pu      pu      pu');
 while kk<nwezkryt 
   kk=kk+1;   i=wezPU(kk);
   typ=TYP(i); Un=UNBUS(i);  kwez=kwez+1;
   idruk=idruk+1;  nrwez=NRBUS(i);
   nazwa=char(nazwez(nrwez,:));
   fprintf(fdvs,...
   '\n %4d %12s %1d %5.1f %7.3g %7.3g %7.3g %7.3g %7.3g %7.3g',...
   nrwez,nazwa,typ, Un, Pgen(i),Qgen(i), Pgmax(i),...
   Podb(i),Qodb(i),QKOMP(i));
end % while
nwezkryt=kwez;
if ~kwez
  fprintf(fdvs,...
  '\n\n ... przerwano, gdyz brak wezlow do krzywych P-U ...\n\n');
  fprintf(...
  '\n\n ... przerwano, gdyz brak wezlow do krzywych P-U ...\n\n');
    return
end
% DOCIAZANIE proporcjonalne wszystkich odbiorow wezlowych  
% NAJPIERW wzrost mocy odb. jest pokrywany przez wzrost Pg<PgMAX
% NASTEPNIE po osiagnieciu Pgmax - przez WEZEL BILANSUJACY
fprintf(fdvs,...
'\n *** ZAPAS PRZESYLU przy tgfi=Podb/Qodb=const ***');
fprintf(...
'\n *** ZAPAS PRZESYLU przy tgfi=Podb/Qodb=const ***');
fprintf(...
'\n ... OBLICZANIE moze potrwac kilka minut ...');
fprintf('\n ...prosze czekac !\n');
j=sqrt(-1); TYP=real(TUNBUS); UNBUS=imag(TUNBUS);
REF=find(TYP(:)==3);
WezIzol=find(TYP(:)==4); %wezly izolowane
tabPUnazwa = cell(wymwezPU,1);
tabPUstr(1)=0;tabPUlad(1)=0;tabPUodb(1)=0;
for idruk=1:wymwezPU
    i=wezPU(idruk); nazwa=char(nazwez(i,:));
    tabPUnazwa{idruk}=nazwa;
end
% DOCIAZANIE stalym krokiem Krok 
fprintf(fdvs,'\n Krok wzrost  detJef     Pstr    Qstr   Qkomp');
fprintf(fdvs,'\n    -      -       -       MW    Mvar    Mvar'); 
fprintf(     '\n Krok wzrost  detJef     Pstr    Qstr   Qkomp');
fprintf(     '\n    -      -       -       MW    Mvar    Mvar');   
iload=0; success=1;
Vbusorm=Vbus; SLBUSorm=SLBUS; SGBUSorm=SGBUS; TUNBUSorm=TUNBUS;
tabPUcload=[];tabPUnrwez=[];tabPUnap=[]; nwezPU=wymwezPU; 
Krok=0.01; % oczekiwany 5% zapas przesylu mocy
MinKrok=Krok/10; % zatrzymanie po 10-krotnym zmniejszeniu kroku
iKrok=0; Wobc=1-Krok; 
% Planowany rozplyw mocy - moce wezlowe, typy wezlow
SGBUS0=SGBUS;   SLBUS0=SLBUS;   SGMAX0=SGMAX;
PGmax0=real(SGMAX0); QGmax0=imag(SGMAX0); TUNBUS0=TUNBUS;
while Krok>=MinKrok
    % orm - zbiezny rozplyw mocy
   Vbusorm=Vbus;  SLBUSorm=SLBUS;   SGBUSorm=SGBUS;
   TUNBUSorm=TUNBUS;
   Wobc0=Wobc;
   % Krok - wsp. wzrostu planowanych mocy wezlowych 
   iKrok=iKrok+1;    Wobc=Wobc+Krok;
   SLBUS=SLBUS0*Wobc; SGBUS=SGBUS0*Wobc; 
   PGBUS=real(SGBUS);  QGBUS=imag(SGBUS);
   %wykrywanie Pg>PgMAX
   iPGmax=[]; iPGmax=find(real(SGBUS)>PGmax0);
   if ~isempty(iPGmax) PGBUS(iPGmax)=real(SGMAX(iPGmax));end
   SGBUS=PGBUS+j*QGBUS;
   fprintf(fdvs,'\n %4d %6.3f',iKrok,Wobc);
   fprintf(     '\n %4d %6.3f',iKrok,Wobc);
   opt=1;
   [Ybus,Vbus,YPP,YPK,YKP,YKK,TMK,SLBUS,SGBUS,...
       TUNBUS,success,Ureg] = ...
    a2rm(fdvs,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
         REF,PU,PQ,Ybus,Vbus,Ureg,opt,...
          WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,YPP,YPK,YKP,YKK,...
           STATUS,SGMIN,SGMAX,nazwez,nazgal);
   if success
      % orm - zbiezny rozplyw mocy
      Wobc0=Wobc;
      Vbusorm=Vbus; SLBUSorm=SLBUS; SGBUSorm=SGBUS;
      TUNBUSorm=TUNBUS;
      % wyznacznik m. Jacobiego 
      [Jmatrix]=a2Jac(PU,PQ,Ybus,Vbus);
      detJ=det(Jmatrix); if iKrok==1 detJ0=detJ; end
      w=detJ/detJ0;  detJef(iKrok)=w;
      fprintf(fdvs,' %7.4g ',w);
      fprintf(     ' %7.4g ',w);
      % zapamietanie wynikow zbieznego rozplywu mocy
      Vpu=abs(Vbus(wezPU));   tabPUcload(iKrok,1)=Wobc0;
      for idruk=1:wymwezPU
        tabPUnrwez(iKrok,idruk)=wezPU(idruk);
        tabPUnap(iKrok,idruk)=Vpu(idruk);
      end
      % stratyQ + ladowanieQ
      [SstrKSE,SkompKSE,sumSG,sumSL,sumSH] = ...
       a2bilans(fdvs,Sbase,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
                WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,...
                STATUS,SMAX,YPP,YPK,YKP,YKK,...
                    Vbus,Ybus,REF,PU,PQ,opt,nazwez,nazgal,...
                    SGMIN,SGMAX,UKUZW,QKOMP); 
      % stratyQ + kompensacjaQ
       dS=SstrKSE + SkompKSE; % straty podluzne i poprzeczne
       fprintf(fdvs,' %7.1f %7.1f', real(SstrKSE),imag(SstrKSE) );
       fprintf(fdvs,' %7.1f ',imag(SkompKSE) );
       fprintf(     ' %7.1f %7.1f', real(SstrKSE),imag(SstrKSE) );
       fprintf(     ' %7.1f ',imag(SkompKSE) );
       tabPUstr(iKrok,1)=SstrKSE;  tabPUlad(iKrok,1)=SkompKSE;
       tabPUgen(iKrok,1)=sumSG; tabPUodb(iKrok,1)=sumSL;
       tabPUshunt(iKrok,1)=sumSH;  tabPUw(iKrok,1)=w;
   else
      fprintf(fdvs,' ... utrata zbieznosci rozplywu mocy!');
      fprintf(     ' ... utrata zbieznosci rozplywu mocy!');
      Krok=Krok/2; iKrok=iKrok-1;% polowkowanie Krok
      Wobc=Wobc0;  Vbus=Vbusorm; %powrot do ostatniego zbieznego RM
      SLBUS=SLBUSorm;   SGBUS=SGBUSorm;   TUNBUS=TUNBUSorm;
   end  % if success
end % while success 
 Wobc=Wobc0; %  K O N I E C dociazania
 fprintf(fdvs,'\n ... graniczny wzrost P w SEE: %9.3f ',Wobc); 
 fprintf(     '\n ... graniczny wzrost P w SEE: %9.3f ',Wobc); 
% Zapisywanie wykresow jako funkcja a2P_Unos w pliku a2P_Unos.m
if ~isempty(tabPUnap)
 tytul=' - wzrost poboru mocy w SEE, przy tgfi=Qodb/Podb=const';
 a2P_U(fdpu,tytul,...
    Sbase,tabPUcload,tabPUnrwez,tabPUnazwa,tabPUnap,...
    tabPUstr,tabPUlad,tabPUgen,tabPUodb,tabPUshunt,tabPUw);
 fprintf(fdvs,...
 '\n Krzywe P-U zapisano jako a2P_Unos.m');
 fprintf(fdvs,...
 '\n W celu ponownego wykreslenia char. P-U - wywolac a2P_Unos');
 fprintf(...
 '\n Krzywe P-U zapisano jako a2P_Unos.m');
 fprintf(...
 '\n W celu ponownego wykreslenia char. P-U - wywolac a2P_Unos');
end %if ~isempty(tabPUnap)
% Ponowne wyznaczenie granicznego rozplyw mocy
fprintf(fdvs,'\n\n GRANICZNY ROZP�YW MOCY'); 
fprintf(     '\n\n GRANICZNY ROZP�YW MOCY'); 
opt=0; % wydruk ostatniego zbie�nego rozplywu
[Ybus,Vbus,YPP,YPK,YKP,YKK,TMK,SLBUS,SGBUS,...
    TUNBUS,success,Ureg] = ...
a2rm(fdvs,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
  REF,PU,PQ,Ybus,Vbus,Ureg,opt,...
    WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,YPP,YPK,YKP,YKK,...
      STATUS,SGMIN,SGMAX,nazwez,nazgal);
% Wydruk granicznego rozplywu mocy    
   [Nrp,Snrp,Inrp,Nrk,Snrk,Inrk,Cp,Ck,Imaxgal,overdlug] = ...
   a2rozp(fdvs,Sbase,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
    WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,STATUS,SMAX,...
     YPP,YPK,YKP,YKK,Vbus,Ybus,REF,PU,PQ,opt,...
      nazwez,nazgal,SGMIN,SGMAX,QKOMP,UKUZW);
% bilans Mocy Gen., Odb. i STRAT w granicznym rozplywie mocy
   [SstrKSE,SkompKSE,sumSG,sumSL,sumSH] = ...
   a2bilans(fdvs,Sbase,NRBUS,TUNBUS,UMK,...
    SGBUS,SLBUS,YSHBUS,WPK,ZGAL,YSHGAL,...
     TMK,TMOGR,DTRPU,STATUS,SMAX,YPP,YPK,YKP,YKK,...
      Vbus,Ybus,REF,PU,PQ,opt,nazwez,nazgal,...
       SGMIN,SGMAX,UKUZW,QKOMP);
% analiza modalna zredukowanej m. Jacobiego w p-cie granicznym
 fprintf(fdvs,...
 '\n\n Analiza modalna JR=JQU-JQd*inv(JPd)*JPU');
   a2JR(fdvs,TUNBUS,Ybus,Vbus,nazwez);
end %koniec %a2wzrostPsee()