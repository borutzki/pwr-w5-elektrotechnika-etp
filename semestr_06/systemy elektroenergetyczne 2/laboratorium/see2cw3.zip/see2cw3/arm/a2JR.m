function a2JR(fdJR,TUNBUS,Ybus,Vbus,nazwez)
% tworzenie m. JR w oparciu o pelna m. Jabobiego Jef
TYP=real(TUNBUS);
% tylko wezly PQ
PU=[];
PQ=find(...
TYP(:)==1|TYP(:)==2|TYP(:)==5|TYP(:)==6|TYP(:)==7|TYP(:)==8); 
[Jef]=a2Jac(PU,PQ,Ybus,Vbus);
nPQ=size(PQ,1); nPU=size(PU,1);
PUQ=[PU;PQ];
nw=size(PUQ,1);
% PUQ - tablica numerow wezlow w kolejnosci PU, PQ
%Jef = [ dPe , dPf; ...
%        dQe , dQf ];
JPe=Jef(     1:nw,   1:nw);    JPf=Jef(     1:nw,  nw+1:2*nw);
JQe=Jef(nw+1:2*nw,   1:nw);    JQf=Jef(nw+1:2*nw,  nw+1:2*nw);
kVbus=angle(Vbus);
d=kVbus(PUQ); sind=sin(d); cosd=cos(d);
mVbus=abs(Vbus);   U=mVbus(PUQ);
ed=-U.*sind; fd=U.*cosd;
eU=cosd;     fU=sind;
JPd=JPe*diag(ed) + JPf*diag(fd);
JPU=JPe*diag(eU) + JPf*diag(fU);
JQd=JQe*diag(ed) + JQf*diag(fd);
JQU=JQe*diag(eU) + JQf*diag(fU);
JR=JQU-JQd*inv(JPd)*JPU;
[na,lambda,Csort,iCsort,dUdQ]=JReig(JR);
rm=real(lambda); im=imag(lambda);
detJR=prod(lambda); % wyznacznik m. JR
fprintf(fdJR,...
'\nWyznacznik det(JR)=product(lambda)=%.4g',...
detJR);
[rmsort,irmsort]=sort(rm);
fprintf(fdJR,...
'\nnrw Wezel         dUkdQk Re(lamb) Im(lamb)  cki>0.01');
fprintf(fdJR,...
'\n =====================================================');
inaMAX=100; % tylko wezly z najmniejszymi wart. wlasnymi
for ina =1:na
    if ina>inaMAX break; end
    i=irmsort(ina);
    wezi=PQ(i); nazwi=nazwez(wezi,:); ddUddQ=dUdQ(i);
    fprintf(fdJR,'\n %2d %-8s %7.2g %7.4g %5.1g',...
        wezi,nazwi,ddUddQ,rm(i),im(i) );
    for kna=1:na
        kk=irmsort(kna);
     cik=Csort(i,kna);
     if abs(cik)>=0.01
        k=iCsort(i,kk); nrwez=PQ(k);  nazw=nazwez(nrwez,:);
        fprintf(fdJR,...
'\n                                             %7.2g, %-8s',...
  cik,nazw);
     end %if abs(cik)>=0.01
    end %for kk=1:na
fprintf(fdJR,...
'\n =====================================================');
end %for i =1:na
end % koniec a2JR()

function [na,lambda,Csort,iCsort,dUdQ]=JReig(A)
% wektory wlasne i wartosci wlasne macierzy A
[na,ma]=size(A); 
[V,D]=eig(A,'nobalance'); % wektory wlasne
for i=1:na lambda(i)=D(i,i); end % wartosci wlasne
M = V;  N = inv(M); % wektory prawo- i lewo-stronne
for k = 1:na % wsp. udzialu wart. wlasnej w dUk/dQk
  dUdQ(k)=0;
  for i = 1:na
    C(k,i) = M(k,i)*N(i,k);
    dUdQ(k)=dUdQ(k)+C(k,i)/abs(lambda(i));
  end %i = 1:na
end %for k = 1:na
   [Csort,iCsort]=sort(C,2,'descend');
   % [Csort,iCsort]=sort(C,2); % starsze wersje
end %koniec JReig()