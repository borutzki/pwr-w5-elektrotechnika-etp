function tr3arm
% parametry zastepcze transf. 3-uzw.
j=sqrt(-1);
sciezka0=pwd; cd([sciezka0 '\Dane']); sciezka1=pwd;
plikWy= strcat([sciezka1 '\stra_tr3.m']);
fd=fopen(plikWy,'wt'); cd ..
fprintf(fd,...
'\n%s - parametry zast. tr.3-uzw.',plikWy);
fprintf(fd,...
'\n Data: %5d-%2d-%2d  godz. %2d, %2dmin, %2.0fs',clock);
% czytanie danych z m-pliku
cdold=cd;
[plik,sciezka]=...
uigetfile('tr3armDAT*.m','Wybierz m-plik z danymi tr-3uzw.');
fprintf('\n... wybrano: %s%s.m',sciezka,plik);
eval(['cd(''',sciezka,''')']); dane=strtok(plik,'.');
[Sn,UnG,UnS,UnD,UnGs,UnSs,UnDs,p,streg,Pfe,Io,...
    straGS,straGD,straSD]= feval(dane);
eval(['cd(''',cdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
Un=UnG;     % par. zast. transf. 3-uzw. na nap. gorne
Smax=Sn;    % maksymalne dopuszczalne obc.
Zn=Un^2/Sn; % impedancja znamionowa
st=1;   % stan 1- zal.
tnGS=UnG/UnS; tnGSs=UnGs/UnSs; 
[RGS,XGS,toGS,tkGS,tminGS,tmaxGS,dtGS,naztr,nazwpGS,nazwkGS]=...
    trp(Sn,Un,p,streg,straGS,tnGS,tnGSs);
tnGD=UnG/UnD; tnGDs=UnGs/UnDs; 
[RGD,XGD,toGD,tkGD,tminGD,tmaxGD,dtGD,naztr,nazwpGD,nazwkGD]=...
    trp(Sn,Un,p,streg,straGD,tnGD,tnGDs);
tnSD=UnS/UnD; tnSDs=UnSs/UnDs; 
[RSD,XSD,toSD,tkSD,tminSD,tmaxSD,dtSD,naztr,nazwpSD,nazwkSD]=...
    trp(Sn,Un,p,streg,straSD,tnSD,tnSDs);
% parametry zastepcze  na strone gornego napiecia Un=UnG
ZGS=RGS+j*XGS;
ZGD=RGD+j*XGD;
ZSD=RSD+j*XSD;
%przeliczenie z par uzwojen na uzwojenie zastepcze G, S, D
nazwo=strcat(deblank(naztr),'*');
ZG=(ZGS+ZGD-ZSD)/2; RG=real(ZG); XG=imag(ZG);
naztrG=strcat(deblank(naztr),'G');
ZS=(ZGS+ZSD-ZGD)/2; RS=real(ZS); XS=imag(ZS);
naztrS=strcat(deblank(naztr),'S');
ZD=(ZGD+ZSD-ZGS)/2; RD=real(ZD); XD=imag(ZD);
naztrD=strcat(deblank(naztr),'D');
G=Pfe/Un^2*1e6; B=-Io/100/Zn*1e6;
fprintf(fd,'\n stra={');
fprintf(fd,'\n%%Galaz    Od         Do             ');
fprintf(fd,'R      X    G       B Smax    ');
fprintf(fd,'tm  tk   tmin   tmax    dt st');
fprintf(fd,'\n%%max12s   max12s     max12a        ');
fprintf(fd,'om     om mikS    mikS  MVA    ');
fprintf(fd,'pu  st     pu     pu     pu -'); 
% galaz G-S
fprintf(fd,'\n''%-4s'' ''%-8s'' ''%-8s'' ',...
deblank(char(naztrG)),deblank(char(nazwpGS)),deblank(char(nazwo)));
fprintf(fd,'%6.4g %6.4g %4.1f %7.1f %4d ',...
RG,XG,G,B,Smax);
fprintf(fd,'%6.4f %2d %6.4f %6.4f %6.4f %1d',...
toGS,tkGS,tminGS,tmaxGS,dtGS,st);   
% galaz S-D
fprintf(fd,'\n''%-4s'' ''%-8s'' ''%-8s'' ',...
deblank(char(naztrS)),deblank(char(nazwo)),deblank(char(nazwpSD)));
fprintf(fd,'%6.4g %6.4g %4.1f %7.1f %4d ',...
RS,XS,0,0,Smax);
fprintf(fd,'%6.4f %2d %6.4f %6.4f %6.4f %1d',...
toSD,tkSD,0,0,0,st);   
% galaz G-D
fprintf(fd,'\n''%-4s'' ''%-8s'' ''%-8s'' ',...
deblank(char(naztrD)),deblank(char(nazwo)),deblank(char(nazwkGD)));
fprintf(fd,'%6.4g %6.4g %4.1f %7.1f %4d ',...
RD,XD,0,0,Smax);
fprintf(fd,'%6.4f %2d %6.4f %6.4f %6.4f %1d',...
toGD,tkGD,tminGD,tmaxGD,dtGD,st);
fprintf(fd,'\n }');
fclose(fd);
fprintf('\n\n stra{} zapisano w pliku: %s', plikWy);
end
function [R,X,to,tk,tmin,tmax,dt,naztr,nazwp,nazwk]=...
    trp(Sn,Un,p,streg,stra,tn,tns)
[nt,n]=size(stra);
if nt
   naztr =stra(:,1);
   nazwp =stra(:,2);   nazwk =stra(:,3); 
   tre=[cell2mat(stra(:,4:end)) ];
else    % brak tranf.
   tre=[];
end %if nt
if ~isempty(tre)
     Zn=Un^2/Sn;
     Pcu=tre(1); uk=tre(2);
     uR=Pcu/Sn*100; uX=sqrt(uk^2-uR^2); 
     R=Pcu/Sn*Zn; X=uX/100*Zn;
     to=tn/tns; tk=0;
     dt=0.01*p/streg; tmin=to-streg*dt; tmax=to+streg*dt;
else
     fprintf(fd,'\brak danych dla pary uzwojen!');
end % ~isempty(tre)
end

