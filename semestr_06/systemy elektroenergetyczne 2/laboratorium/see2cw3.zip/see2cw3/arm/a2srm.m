 function a2srm(fd,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
     REF,PU,PQ,Ybus,Vbus,Ureg,opt,...
   WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,YPP,YPK,YKP,YKK,...
   STATUS,SMAX,SGMIN,SGMAX,nazwez,nazgal,Sbase,QKOMP,UKUZW)
fprintf(fd,...
'\n*** Symulacja RM wg zadanych rozkladow prawd. mocy wez. ***');
fprintf(...
'\n*** Symulacja RM wg zadanych rozkladow prawd. mocy wez. ***');
opt=0;  j=sqrt(-1);
% wczytanie zmian Pg,Qg,Pd,Qg
nwez=length(Vbus); TYP=real(TUNBUS); UN=imag(TUNBUS); 
varPG=zeros(nwez,1); varPL=zeros(nwez,1);
tgfiG=zeros(nwez,1); tgfiL=zeros(nwez,1); sU=zeros(1,nwez); 
for i=1:nwez
 pg=real(SGBUS(i)); qg=imag(SGBUS(i)); if pg tgfiG(i)=qg/pg; end
 pl=real(SLBUS(i)); ql=imag(SLBUS(i)); if pl tgfiL(i)=ql/pl; end
end
[wezPQsrm,nowePQsrm,rozklad]=a2srmPQlos(fd,nazwez);
opcjadUk=[]; 
fprintf('\n Czy losowe zmiany rozchylow katowych napiec?');
fprintf('\n Odp.:   0 - NIE,  1 - TAK \n');
if ~opcjadUk
fprintf(fd,...
'\n wybrano 0 - bez analizy zmian rozchylow katowych');
end
if opcjadUk
fprintf(fd,'\n wybrano 1 - analiza zmian rozchylow katowych nap.');
end
opcjadUk=input(' Podaj odpowiedz 1 lub 1, Odp. =  '  );
if opcjadUk
 % rozchyl katowy na wylacznikach wg datdUk()
 [NrUkPocz, NrUkKonc, dUkdop]=a2srmdUkd(fd,nazwez);
end
% parametry rozkladu prwdopodobienstwa mocy wezlowych
SGBUS0=SGBUS; SLBUS0=SLBUS; TYP0=TYP; % wejsciowe moce wezlowe
ESGBUS=SGBUS0; ESLBUS=SLBUS0;
nPQsrm=length(wezPQsrm);
for k=1:nPQsrm
    PGimin=nowePQsrm(k,1)/Sbase; PGimax=nowePQsrm(k,2)/Sbase;
    QGimin=nowePQsrm(k,3)/Sbase; QGimax=nowePQsrm(k,4)/Sbase;
    PGmin(k)=PGimin;  PGmax(k)=PGimax;
    EPG(k)=(PGimin+PGimax)/2; DPG(k)=(PGimax-PGimin)/6;
    QGmin(k)=QGimin;  QGmax(k)=QGimax;
    EQG(k)=(QGimin+QGimax)/2; DQG(k)=(QGimax-QGimin)/6;
    PLimin=nowePQsrm(k,5)/Sbase; PLimax=nowePQsrm(k,6)/Sbase;
    QLimin=nowePQsrm(k,7)/Sbase; QLimax=nowePQsrm(k,8)/Sbase;
    PLmin(k)=PLimin;  PLmax(k)=PLimax;
    EPL(k)=(PLimin+PLimax)/2; DPL(k)=(PLimax-PLimin)/6;
    QLmin(k)=QLimin;  QLmax(k)=QLimax;
    EQL(k)=(QLimin+QLimax)/2; DQL(k)=(QLimax-QLimin)/6;
    i=wezPQsrm(k,1);  
    ESGBUS(i)=EPG(k)+j*EQG(k); % wartosci oczekiwane gen. wez.
    ESLBUS(i)=EPL(k)+j*EQL(k); % wartosci oczekiwane odb. wez.
end %  for k=1:nPQsrm
% Rozplyw mocy dla wartosci oczekiwanych
fprintf(fd,'\n... ROZPLYW MOCY DLA WARTOSCI OCZEKIWANYCH ...');
fprintf(   '\n... ROZPLYW MOCY DLA WARTOSCI OCZEKIWANYCH ...');
opt=0;
[Ybus,Vbus,YPP,YPK,YKP,YKK,TMK,SLBUS,SGBUS,TUNBUS,success,Ureg] = ...
   a2rm(fd,NRBUS,TUNBUS,UMK,ESGBUS,ESLBUS,YSHBUS,...
           REF,PU,PQ,Ybus,Vbus,Ureg,opt,...
           WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,YPP,YPK,YKP,YKK,...
           STATUS,SGMIN,SGMAX,nazwez,nazgal);
fprintf(fd,'\n... ROZPLYW MOCY DLA WARTOSCI OCZEKIWANYCH ...');
[Nrp,Snrp,Inrp,Nrk,Snrk,Inrk,Cp,Ck,Imaxgal,overdlug] = ...
 a2rozp(fd,Sbase,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
   WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,STATUS,SMAX,...
    YPP,YPK,YKP,YKK,...
      Vbus,Ybus,REF,PU,PQ,opt,...
        nazwez,nazgal,SGMIN,SGMAX,QKOMP,UKUZW);
fprintf(fd,...
'\n\n... KONIEC ROZPLYWU MOCY DLA WARTOSCI OCZEKIWANYCH\n...');
% SYMULACJA losowych realizacji mocy wezlowych 
SGBUS=SGBUS0; SLBUS=SLBUS0; % powrot do danych wejsciowych
fprintf(fd,'\n... SYMULACJA LOSOWYCH ZMIAN MOCY WEZLOWYCH ...');
fprintf(   '\n... SYMULACJA LOSOWYCH ZMIAN MOCY WEZLOWYCH ...');
if rozklad==1
fprintf(fd,'\nLosowe moce wez. - prostokatny rozklad prawd.');
fprintf(   '\nLosowe moce wez. - prostokatny rozklad prawd.');
end
if rozklad==2
fprintf(fd,'\nLosowe moce wez. - normalny rozklad prawd.');
fprintf(   '\nLosowe moce wez. - normalny rozklad prawd.');
end
Nsym=1000; % liczba symulacji dla praktycznych obliczen
%Nsym=10; %testowanie
fprintf(fd,'\n Nsym = % d - liczba symulacji',Nsym);
fprintf(   '\n Nsym = % d - liczba symulacji',Nsym);
fprintf(   '\n\n ... kolejne symulacje ... czekaj ... \n\n');
isym=0; ir=0; Ubus=[]; Ukbus=[]; 
while isym<Nsym
    ir=ir+1;
    SGBUS=SGBUS0; SLBUS=SLBUS0; TYP=TYP0;%przed losowymi zmianami
    for k=1:nPQsrm
      i=wezPQsrm(k,1);
      % losowa GENERACJA w wezle i
      if rozklad==1 % prostokatny rozklad prawd.
       x=[]; x=rand; % losowanie dla czynnej generacji
       rPG=PGmin(k)+(PGmax(k)-PGmin(k))*x;
       x=[]; x=rand; % losowanie dla biernej generacji
       rQG=QGmin(k)+(QGmax(k)-QGmin(k))*x;
       SGBUS(i)=rPG+j*rQG;
       % losowy ODBIOR w wezle i
       x=[]; x=rand; % losowanie dla czynnej generacji
       rPL=PLmin(k)+(PLmax(k)-PLmin(k))*x;
       x=[]; x=rand; % losowanie dla biernej generacji
       rQL=QLmin(k)+(QLmax(k)-QLmin(k))*x;
       SLBUS(i)=rPL+j*rQL;
      end % if rozklad==1
       if rozklad==2 % normalny rozklad prawd.
        x=[]; x=randn; % losowanie dla czynnej generacji
        rPG=EPG(k)+DPG(k)*x;
        x=[]; x=randn; % losowanie dla biernej generacji
        rQG=EQG(k)+DQG(k)*x;
        SGBUS(i)=rPG+j*rQG;
        % losowy ODBIOR w wezle i
        x=[]; x=randn; % losowanie dla czynnej generacji
        rPL=EPL(k)+DPL(k)*x;
        x=[]; x=randn; % losowanie dla biernej generacji
        rQL=EQL(k)+DQL(k)*x;
        SLBUS(i)=rPL+j*rQL;
       end % if rozklad==1
   end %  for k=1:nPQsrm
   opt=1;
   [Ybus,Vbus,YPP,YPK,YKP,YKK,TMK,...
       SLBUS,SGBUS,TUNBUS,success,Ureg]=...
   a2rm(fd,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
           REF,PU,PQ,Ybus,Vbus,Ureg,opt,...
           WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,...
           YPP,YPK,YKP,YKK,...
           STATUS,SGMIN,SGMAX,nazwez,nazgal);
   Ubus =[Ubus;    abs(Vbus)'];%losowe realizacje modulow U
   Ukbus=[Ukbus; angle(Vbus)'];%losowe realizacje katow Uk
   isym=isym+1;
end %while
% statystyczna analiza realizacji modulow napiec wezlowych
fprintf(fd,...
'\nStatystyczna analiza realizacji modulow napiec wezlowych');
zmchar='U';  wymiar='[pu]'; Umin=0.95; Umax=1.1;
fprintf(fd,...
'\n              p{Umin<=U<=Umax) - wg Fe(U)oraz FN(0,1)');
fprintf(fd,...
'\nNrw Wezel       TYP      mU        sU    Umin    Umax    ');
fprintf(fd,...
'p(Fe)   p(FN)');
fprintf(fd,...
'\n -    -           -      pu        pu      pu      pu      ');
fprintf(fd,...
'-      -   ');
a2srmU(fd,nwez,nazwez,TYP,UN,Ubus,Umin,Umax,...
    zmchar, Nsym, wymiar);
% ... koniec analizy statystycznej U
% statystyczna analiza rozchylow katowych
if opcjadUk
 dUkdop=dUkdop*pi/180; % przeliczenie na radiany
 nUkwyl=size(NrUkPocz(:,1));
 for k=1:nUkwyl
    wp=NrUkPocz(k); wk=NrUkKonc(k);
    dUkwyl(:,k)=Ukbus(:,wp)-Ukbus(:,wk);
 end
fprintf(fd,...
'\nStatystyczna analiza realizacji rozchylow katowych nap. wez.');
fprintf(...
'\nStatystyczna analiza realizacji rozchylow katowych nap. wez.');
zmchar='dUk';
fprintf(fd,...
'\n          p{dUkmin<=dUk<=dUkmax) - wg Fe(dUk)oraz FN(0,1)');
fprintf(fd,...
'\n Lp Od wezla    Do wezla        mdUk   sdUk dUkmin dUkmax ');
fprintf(fd,...
'p(Fe) p(FN)');
fprintf(fd,...
'\n  -     -           -             st     st     st     st    ');
fprintf(fd,...
'-     -');
a2srmdUk(fd,NrUkPocz,NrUkKonc,nazwez,TYP,UN,dUkwyl,dUkdop,...
    zmchar, Nsym);
else
 fprintf(fd,...
 '\n Wybrano %d i przerwano. Konieczny jest wybor 0 lub 1',...
 opcjadUk);
 fprintf(...
 '\n Wybrano %d i przerwano. Konieczny jest wybor 0 lub 1',...
     opcjadUk);
 return;
end % if opcjadUk
end %koniec a2srm()
