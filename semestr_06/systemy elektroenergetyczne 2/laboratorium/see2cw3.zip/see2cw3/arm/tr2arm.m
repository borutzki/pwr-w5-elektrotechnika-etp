function tr2arm
% parametry zastepcze transf. 2-uzw.
j=sqrt(-1);
sciezka0=pwd; cd([sciezka0 '\Dane']); sciezka1=pwd;
plikWy= strcat([sciezka1 '\stra_tr2.m']);
fd=fopen(plikWy,'wt'); cd ..
fprintf(fd,...
'\n%s - parametry zast. tr.2-uzw.',plikWy);
fprintf(fd,...
'\n Data: %5d-%2d-%2d  godz. %2d, %2dmin, %2.0fs',clock);
% czytanie danych z m-pliku
cdold=cd;
[plik,sciezka]=...
uigetfile('tr2armDAT*.m','Wybierz m-plik z danymi tr.2-uzw.');
fprintf('\n... wybrano: %s%s.m',sciezka,plik);
eval(['cd(''',sciezka,''')']); dane=strtok(plik,'.');
[stra] = eval(dane);
eval(['cd(''',cdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
[nt,n]=size(stra);
if nt
   naztr =stra(:,1);     nazwp =stra(:,2);    nazwk =stra(:,3); 
   tre=[cell2mat(stra(:,4:end)) ];   % end
else    % brak tranf.
naztr=[]; tre=[];
end %if nt
if ~isempty(tre)
   fprintf(fd,'\n stra={');
   fprintf(fd,'\n%%Galaz  Od         Do             ');
   fprintf(fd,'R      X    G       B Smax    ');
   fprintf(fd,'tm  tk   tmin   tmax    dt st');
   fprintf(fd,'\n%%max12s max12s     max12a        ');
   fprintf(fd,'om     om mikS    mikS  MVA    ');
   fprintf(fd,'pu  st     pu     pu     pu -'); 
   for i=1:nt
     Sn=tre(i,1); Smax=Sn;
     UnP=tre(i,2); UnK=tre(i,3);
     p=tre(i,4); streg=tre(i,5);
     UnPs=tre(i,6); UnKs=tre(i,7);
     Pcu=tre(i,8); uk=tre(i,9);
     Pfe=tre(i,10); Io=tre(i,11); st=1;
     % regulacja przekladni
     tn=UnP/UnK; tk=0; tns=UnPs/UnKs; to=tn/tns;
     dt=0.01*p/streg; tmin=to-streg*dt; tmax=to+streg*dt;
     % parametry przeliczone na nap. znam. od strony wezla P
     Un=UnP; Zn=Un^2/Sn; uR=Pcu/Sn*100; uX=sqrt(uk^2-uR^2); 
     RT=Pcu/Sn*Zn; XT=uX/100*Zn;
     GT=Pfe/Un^2*1e6; BT=-Io/100/Zn*1e6;
     ntr=deblank(char(naztr(i,:)));
     ntrP=deblank(char(nazwp(i,:)));
     ntrK=deblank(char(nazwk(i,:)));
     fprintf(fd,'\n''%-4s'' ''%-8s'' ''%-8s'' ',...
     ntr,ntrP,ntrK);
     fprintf(fd,'%6.4g %6.4g %4.1f %7.1f %4d ',...
     RT,XT,GT,BT,Smax);
     fprintf(fd,'%6.4f %2d %6.4f %6.4f %6.4f %1d',...
     to,tk,tmin,tmax,dt,st);
   end
   fprintf(fd,'\n };');
 else
     fprintf(fd,'\brak transf. 2-uzw.!');
end % ~isempty(tre)
fclose(fd);
fprintf('\n\n stra{} zapisano w pliku: %s',plikWy);
end % koniec tr2arm()
 
