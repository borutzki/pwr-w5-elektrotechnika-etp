function a2srmdUk(fd,NrUkPocz,NrUkKonc,nazwez,...
    TYP,UN,dUkwyl,dUkdop,zmchar, Nsym)
    tp=clock; % aktualny czas
    rok=int2str(tp(1)); miesiac=int2str(tp(2));
    dzien=int2str(tp(3));
    godz=int2str(tp(4));mins=int2str(tp(5));
    secs=int2str(tp(6));
    czas=[rok miesiac dzien godz mins secs];
    nwyl=length(NrUkPocz);
    xchar=zmchar; rad2st=180/pi;
for k=1:nwyl
    wp=NrUkPocz(k); wk=NrUkKonc(k);  
    nazwp=deblank(nazwez(wp,:)); nazwk=deblank(nazwez(wk,:));
    rxbus=[];  rxbus=dUkwyl(:,k);
    xa=-dUkdop(k); xb=dUkdop(k);
    xmin=min(rxbus)*180/pi; xmax=max(rxbus)*180/pi;
     % dystrybuanta empiryczna
    xsym=[]; xsym=rxbus;
    xsr=mean(xsym); xstd=std(xsym); 
    Ex=xsr; Dx=xstd; if ~Dx Dx=1e-12; end
    t=(xsym-xsr)/xstd; % standaryzacja zmiennej losowej
    tsort=sort(t); % sortowanie stand. zmiennej losowej
    % wartosci dystrybuanty empirycznej
    ntsort=length(tsort); prsym(:,1)=(1:ntsort)';
    prsym=prsym/ntsort;
    % przedzial zmiennosci po standaryzacji
    ta=(xa-Ex)/Dx; tb=(xb-Ex)/Dx;
    ita=[]; ita=find(tsort(:)<=ta); 
    if isempty(ita) Fta=prsym(1);
    else nita=length(ita); Fta=prsym(nita); end 
    itb=[]; itb=find(tsort(:)>=tb);
    if isempty(itb) Ftb=prsym(ntsort);
    else itb1=itb(1); Ftb=prsym(itb1); end 
    pemp=Ftb-Fta; % prawd. wg dystrybuanty empirycznej
    pN01=prnab(0,1,ta,tb); % prawd. wg rozkladu normalnego
    Ex=Ex*rad2st; Dx=Dx*rad2st; xa=xa*rad2st; xb=xb*rad2st;
    fprintf(fd,...
    '\n %2d %-12s %-12s %6.1f %6.1f %6.1f %6.1f %5.2f %5.2f',...
        k,nazwp,nazwk, Ex,Dx,xa,xb,pemp,pN01);
    [FN]=FN01(tsort);
    cNsym=int2str(Nsym);  cmx=num2str(Ex,2);csx=num2str(Dx,2);
    opis=['dUk=Uk(' nazwp ')-Uk(' nazwk ') : m' ...
        xchar '=' cmx ', s'  xchar '=' csx ', Nsym=' cNsym];
    % wykresy dystrybuant
    xsort=(xsr+tsort*xstd)*rad2st; % powrot ze standaryzacji
    p1=plot(xsort,prsym,'--b',xsort,FN,':k','LineWidth',1.5);
    xpocz=xmin; if xpocz>xa xpocz=xa; end
    xkonc=xmax; if xkonc<xb xkonc=xb; end
    % wykres dystrybuanty empirycznej i normalnej
    hold on;
    cFta=num2str(Fta,2); opisFta=['F(dUkmin)=' cFta];
    p2=plot(xa,Fta,'ro'); text(xa,Fta+0.04,opisFta);
    cFtb=num2str(Ftb,2); opisFtb=['F(dUkmax)=' cFtb];
    p3=plot(xb,Ftb,'ro'); text(xb,Ftb+0.04,opisFtb);
    linia(xa,xa,0,Ftb); linia(xpocz,xa,Fta,Fta);
    linia(xb,xb,0,Ftb); linia(xpocz,xb,Ftb,Ftb);
    probU=Ftb-Fta; cprobU=num2str(probU,2);
    cxa=num2str(xa,2); cFta=num2str(Fta,2);
    cxb=num2str(xb,2); cFtb=num2str(Ftb,2);
    text(xa, 0.32,['P(dUkmin=' cxa '<dUk<dUkmax=' cxb ')=',cprobU]);
    title(opis); grid on;  axis([xpocz 1.02*xkonc -0.02 1.24]);
    xlabel(['dUk=Uk(' nazwp ')-Uk(' nazwk ') [st]' ]);
    ylabel('F(dUk) - dystrybuanta');
    legend(p1,' rozklad empiryczny', ' rozklad normalny');
    fdUk = strcat('dUk_',nazwp,'-',nazwk,'_',czas);  
    saveas(gcf,fdUk,'emf'); pause(2); close;
end %for k=1:nwyl
end % koniec a2srmdUk()
