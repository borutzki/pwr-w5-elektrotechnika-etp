function [Ybus,Vbus,YPP,YPK,YKP,YKK,TMK,sukces] = ...
a2treg(fd,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
          REF,PU,PQ,Ybus,Vbus,Ureg,opt,...
          WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,...
          YPP,YPK,YKP,YKK,STATUS,SGMIN,SGMAX,nazwez,nazgal);
% Model transf. w danych:
% p-k = wezNapGorne-wezNapDolne, czyli tn=UnH/UnL
% Zadawane nap. po stronie UnL, czyli ten wezel musi miec typ=5
YPPold=YPP; YPKold=YPK; %przed zmiana przekladni
YKPold=YKP; YKKold=YKK; 
TMKold=TMK; % przekladnie transf, przed zmiana przekladni
dc=0; % wykluczona regulacja przekladni dla modelu DC
n=size(Vbus,1);    nbr=size(WPK,1); % liczba wezlow i galezi
% sprawdzenie, czy w sieci wystepuja transformatory
ktraf=1;     sukces=1;
nt=0; transfall=find(TMK(:)~=0 & STATUS(:));
if isempty(transfall)
   return; % powrot, bo brak transformatorow w sieci
end
% identyfikacja transformatorow z wezlami typ=5
WP=real(WPK); WK=imag(WPK); pp=WP(transfall); kk=WK(transfall);
TYP=real(TUNBUS); UNBUS=imag(TUNBUS);
tapreg = (TYP(kk)==5 & TYP(pp)~=4); % wezly z reg. nap.
transfreg=find( transfall.*tapreg); 
if size(transfreg,1) % wystepuja transf. z wezlami typu 5
   transf=transfall(transfreg);
   nt=size(transf,1); % liczba transf.
   pp=WP(transf); kk=WK(transf);
   % ustalenie wezlow w procesie regulacji przekladni
   % numer wezla typu 5 z zadanym napieciem, zawsze wezel koncowy
   % numer wezla z wyzszym napieciem, zawsze wezel poczatkowy
   p=kk;     k=pp;
   TM=real(TMK); TK=imag(TMK);
   trtr=real(ZGAL(transf));
   txtr=imag(ZGAL(transf)); % RT,XT 
   tm=TM(transf); tk=TK(transf);% modul i kat przekladni
    % zakres regulacji
   tmin=real(TMOGR(transf)); tmax=imag(TMOGR(transf));
    % krok regulacji
   tlimit=0;  tmold=tm;   dtrpu=DTRPU(transf);
   dtrpu0=find(dtrpu(:)==0);   dtrpu(dtrpu0)=1e-4;   
   %regulowane zaczepy po stronie wez. pocz. wg a2pi()
   sukcesreg=[1:nt]'; 
   else
   sukces=1; return %brak transf. z regulacja przekladni
end %if size(transfreg,1)
% proces regulacji przekladni dla wezlow typ=5
if nt~=0 
   % admitancje podluzne regulowanych transf. 
   Ytr=ZGAL(transf).^(-1);
   %max liczba zmian przekladni dla uzyskania zadanego napiecia
   for itertreg = 1:20
   sukcesreg=0;   ktraf=zeros(nt,1);
   % aktualne czworniki pi dla regulowanych transf.
   Ypp=YPP(transf); Ypk=YPK(transf);
   Ykp=YKP(transf); Ykk=YKK(transf);
   % aktualne nap. w wez. pocz. i konc. transf.
  	% Vp - strona gorna, Vk - strona dolna
   Vp=Vbus(pp);	   Vk=Vbus(kk);
   % moce zespolone plynace przez regulowane transf.
   Sp= Vp.*conj(Ypp.*Vp + Ypk.*Vk); 
   TM=real(TMK); TK=imag(TMK); 
    % RT, XT transf.
   trtr=real(ZGAL(transf)); txtr=imag(ZGAL(transf));
    % modul i kat przekladni transf.
   tm=TM(transf); tk=TK(transf);
    % zakresy regulacji
   tmin=real(TMOGR(transf)); tmax=imag(TMOGR(transf));
   tlimit=0;  tmold=tm;   dtrpu=DTRPU(transf); % krok regulacji
   dtrpu0=find(dtrpu(:)==0);
   dtrpu(dtrpu0)=1e-4; % dokladnosc obliczen
   Pp=-real(Sp); Qp=-imag(Sp); % P,Q po stronie wez. typ=5
   Vp=Vbus(p,1 );	   Vk=Vbus(k,1 ); 
   us=abs(Vk); pzad=Pp; qzad=Qp; ktraf=zeros(nt,1);
    % aktualne i zadane napiecie w wez. typ=5
   uact=abs(Vp); uset=Ureg(p);
   tapnum=zeros(nt,1); 
   % proces zmiany zaczepu
   [tm,ktraf,tapnum]=...
    a2tap(uset,uact,us,trtr,txtr,pzad,qzad,...
       tmin,tmax,tm,ktraf,tapnum,dtrpu);
   for ii=1:nt
     tmodul=tm(ii);
     if ~tmodul % nieudana reg. przekladni w transf.
        tm(ii)=1; ktraf(ii)=0; i=transf(ii);
        % nazwa i numera transformatora z nieudana regulacja
        wp=real(WPK(i)); wk=imag(WPK(i));
        nrwezp=NRBUS(wp);  nrwezk=NRBUS(wk);
        naztr=char(nazgal(i,:)); 
        nazwap=char(nazwez(nrwezp,:));
        nazwak=char(nazwez(nrwezk,:)); 
        if opt==0 % komunikat o bledzie regulacji
        fprintf(fd,'\n! BLAD regulacji tm');
        fprintf(   '\n! BLAD regulacji tm');
        fprintf(fd,'\n %8s %8s %8s : ',naztr,nazwap,nazwak);
        fprintf(fd,...
        '\nUreg=%4.2f, Uact=%4.2f, t=%6.4f, zaczep=%2d',...
        uset(ii),uact(ii),tm(ii),tapnum(ii) );
        end %if opt==0
      end %if ~tmodul
    end % for ii=1:nt
    % Korekcja m. admitancji wez. po zmianie przekladni transf. 
    sukcesreg=sukcesreg+sum(ktraf);
    tap  = tm.*exp(j*pi/180*TK(transf));% nowe przekladnie
    %zmiana admitancji wlasnych i wzajemnych czwornika pi
    Ykk=Ytr+YSHGAL(transf)*0.5; 
    Ypp=Ykk.*(tap.*conj(tap)).^(-1);
    Ypk=-Ytr.*conj(tap).^(-1);
    Ykp=-Ytr.*tap.^(-1);
    TMK(transf)=tm+j*tk; % nowe przekladnie zespolone
    % wprowadzenie zmian w macierzach czwornikow dla calej sieci
    YPP(transf)=Ypp; YPK(transf)=Ypk;
    YKP(transf)=Ykp; YKK(transf)=Ykk;
    % zmiana macierzy admitancji wezlowych dla calej sieci
    dc=0;
    [Ybus,nshunt]=a2Ybus(WPK,YPP,YPK,YKP,YKK,dc,YSHBUS,TYP);  
    % iteracyjne rozw. dla nowej m. admitancji wez.
    sukces=0; opt1=1;
    [Vbus,SLBUS,SGBUS,sukces] =...
    a2NR(fd,NRBUS,TUNBUS,SGBUS,SLBUS,REF,PU,PQ,Ybus,Vbus,Ureg,...
    opt1,SGMIN,SGMAX,nazwez);
    if sukces==0 
      %iter. rozbiezne - powrot do poprzednich czwornikow pi
      YPP=YPPold; YPK=YPKold;
      YKP=YKPold; YKK=YKKold; 
      TMK=TMKold;
        return; % powrot do miejsca wywolania
    end %if sukces==0
    if sukcesreg==0 break; end
 end %for itertreg = 1:20
 %udana reg. przekladni - osiagnieto zadane nap.
 if opt==0
   fprintf(fd,'\n *** Dokonano regulacji przekl. transf. ***');
 end
 for ii=1:nt
  %numery i wezly transf. po zmianie zaczepu
  i=transf(ii);  wp=real(WPK(i)); wk=imag(WPK(i));
  nrwezp=NRBUS(wp);  nrwezk=NRBUS(wk);
  naztr=char(nazgal(i,:));
  nazwap=char(nazwez(nrwezp,:));
  nazwak=char(nazwez(nrwezk,:)); 
  if opt==0
    fprintf(fd,'\n %8s %8s %8s : ',naztr,nazwap,nazwak);
    fprintf(fd,...
    '\nUreg=%4.2f, Uact=%4.2f, t=%6.4f, zaczep=%2d',...
        uset(ii),uact(ii),tm(ii),tapnum(ii) );
   end
  end %ii=1:nt
end %if nt~=0
end % koniec a2treg()



