function [wezQU,typQU]=a2wezQU(fd,nazwez);
% CZYTANIE nazw wezlow do krzywych nosowych Q-U z pliku
wdold=cd;
[fname,sciezka]=...
uigetfile('datQUwez*.m','Wybierz plik wezlow dla Q-U');
fprintf('\n... wybrano: %s%s.m',sciezka,fname);
eval(['cd(''',sciezka,''')']); datafile=strtok(fname,'.');
[sQU]=feval(datafile);% czytanie danych z wybranego pliku
eval(['cd(''',wdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
sp12='123456789012';  % ustala maksymalnie 12 znakow
[nw,mw]=size(nazwez); nrwez=[1:nw]'; wezQU=[]; typQU=[];
if ~isempty(sQU)
  [nl,n]=size(sQU);
  nazwp =strvcat( sp12,char(sQU(:,1)));  nazwp=nazwp(2:end,:);
  wiersze=[zeros(nl,1) cell2mat(sQU(:,2:end)) ];
  strvcatnazwp0=deblank(strvcat(nazwp));
  [nbrl,mbrl]=size(wiersze); 
  for ii=1:nw
      nazw0=deblank(nazwez(ii,:));
      wp = strmatch(nazw0,strvcatnazwp0,'exact');
      if ~isempty(wp) wiersze(wp,1)=nrwez(ii); end
   end % for ii=1:nw
   wezQU=wiersze(:,1); typQU=wiersze(:,2);
else
   return
end  %if ~isempty(sQU)
iwezQU=[]; iwezQU=find(wezQU~=0);nrwezQU=[];
if ~isempty(iwezQU)
    nrwezQU=wezQU(iwezQU); nrQU=typQU(iwezQU,:);
end
if ~isempty(nrwezQU)
    wezQU=[]; typQU=[];  wezQU=nrwezQU; typQU=nrQU;
end
end %koniec a2wezQU()
