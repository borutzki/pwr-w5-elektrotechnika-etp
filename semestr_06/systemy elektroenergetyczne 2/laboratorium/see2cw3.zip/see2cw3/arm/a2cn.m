function a2cn(fd,Sbase,NRBUS,TUNBUS,UMK,...
SGBUS,SLBUS,YSHBUS,Ureg,GALWYL,...
  WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,STATUS,SMAX,...
   YPP,YPK,YKP,YKK,Vbus,Ybus,REF,PU,PQ,opt,...
    nazwez,nazgal,SGMIN,SGMAX,UKUZW,QKOMP);
j=sqrt(-1); opt=1; winf=1e8;
t0=clock; % computation start
fprintf(fd,...
'\n ### Funkcja a2cn - analiza wyl. gal. wg datGalWyl*.m ###');
fprintf(...
'\n ### Funkcja a2cn - analiza wyl. gal. wg datGalWyl*.m ###');
fprintf('\n ... ANALIZA wylaczen moze potrwac kilka minut ...');
% RM bez wylaczen
n=size(Vbus,1); nbr=size(WPK,1);
fprintf(fd,'\n\n###  Planowany Rozplyw Mocy - BEZ WYLACZEN ###  ');
fprintf(   '\n\n###  Planowany Rozplyw Mocy - BEZ WYLACZEN ###  ');
opt=1;
[Ybus,Vbus,YPP,YPK,YKP,YKK,TMK,...
    SLBUS,SGBUS,TUNBUS,sukces,Ureg] = ...
a2rm(fd,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
   REF,PU,PQ,Ybus,Vbus,Ureg,opt,...
    WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,YPP,YPK,YKP,YKK,...
     STATUS,SGMIN,SGMAX,nazwez,nazgal);
 if sukces
   opt=1;
   [Nrp,Snrp,Inrp,Nrk,Snrk,Inrk,Cp,Ck,Imaxgal,overdlug] = ...
   a2rozp(fd,Sbase,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
    WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,...
     STATUS,SMAX,YPP,YPK,YKP,YKK,...
     Vbus,Ybus,REF,PU,PQ,opt,...
      nazwez,nazgal,SGMIN,SGMAX,QKOMP,UKUZW);                           
 else
    fprintf(fd,'... planowany rozplyw mocy jest rozbiezny!');
    fprintf(   '... planowany rozplyw mocy jest rozbiezny!');
    return
 end
 % ...orm - obliczony rozplyw mocy
TUNBUSorm=TUNBUS; YPP0=YPP;
YKK0=YKK; YPK0=YPK; YKP0=YKP;
WP=real(WPK); WK=imag(WPK); 
TYP=real(TUNBUS); UNBUS=imag(TUNBUS);
[mpolsparse,wezpol,TYP]=a2net(fd,Ybus,TYP,nazwez);
Ybusorm=Ybus; STATUSorm=STATUS;
UMKorm=UMK; Vbusorm=Vbus;
% moce i nap. wez. w planowanym pukcie pracy SEE
SGBUS0=SGBUS; SLBUS0=SLBUS; Vbus0=Vbus;
% Analiza wylaczen tablicy GALWYL[]
WP=real(WPK); WK=imag(WPK);
fprintf(fd,...
'\n\n Kryterium N-m wg kolejnosci w pliku datGalWyl*.m! ');
if isempty(GALWYL)
 fprintf(fd,...
 '\n\nprzerwano, bo w datGalWyl*.m brak poprawnych nazw GALEZI');
   return
end
nwyl=size(GALWYL,1);iwyl=0; 
for kk=1:nwyl;
 iwyl=iwyl+1; status=1; 
 Ybus=Ybusorm; UMK=UMKorm;
 % przywrocenie wartosci dla planowanego rozplywu mocy
 SGBUS=SGBUS0; SLBUS=SLBUS0; Vbus=Vbus0; TUNBUS=TUNBUSorm;
 YPP=YPP0; YKK=YKK0; YPK=YPK0; YKP=YKP0; STATUS=STATUSorm;
 % wyl. gal. wg GALWYL
  nrgal=GALWYL(kk,1:9);  tabnrgal=[]; tabnrgal=find(nrgal>0);
  if ~isempty(tabnrgal)
   [rowgal,colgal]=size(tabnrgal);
   fprintf(fd,...
   '\n\n *** ... kolejny PRZYPADEK wylaczen wg datGalWyl*.m: ***');
  for k=1:colgal
     nrgalk=nrgal(1,k); nazwag=nazgal(nrgalk,:);
     wp2=WP(nrgalk); wk2=WK(nrgalk);
     nazwap=nazwez(wp2,:); nazwak=nazwez(wk2,:);
     STATUS(nrgalk,1)=0;
     fprintf(fd,'\n%12s %12s %12s ',...
         nazwag,nazwap,nazwak);
     % Korekcja m. admitancji galeziowych po wylaczeniach
     Ykk=0; Ypp=0;  Ypk=0;  Ykp=0; 
     YPP(nrgalk)=Ypp; YPK(nrgalk)=Ypk;
     YKP(nrgalk)=Ykp; YKK(nrgalk)=Ykk;
    end %for k=1:colgal
    galNN=1; wp1=wp2; wk1=wk2; liczbapol=1;
   end %if ~isempty(tabnrgal)
 if status & liczbapol
  % Korekcja m. admitancji wezlowych
  [mpolsparse,wezpol,TYP]=a2net(fd,Ybus,TYP,nazwez);
  TUNBUS=TYP+j*UNBUS; dc=0;
  [Ybus,nshunt]=a2Ybus(WPK,YPP,YPK,YKP,YKK,dc,YSHBUS,TYP);
  dc=0; opt=1;  % wylaczenie wydrukow 
  % rozplyw mocy po wylaczeniach
  [Ybus,Vbus,YPP,YPK,YKP,YKK,TMK,...
      SLBUS,SGBUS,TUNBUS,sukces,Ureg] = ...
  a2rm(fd,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
     REF,PU,PQ,Ybus,Vbus,Ureg,opt,...
      WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,YPP,YPK,YKP,YKK,...
       STATUS,SGMIN,SGMAX,nazwez,nazgal);
  sukces0=sukces;
  if sukces==0
    fprintf(fd,' - rozbiezny Rozplyw!');
    fprintf(   ' - rozbiezny Rozplyw!');
  end
  if sukces
    opt=9; % tylko przeciazenia
    [Nrp,Snrp,Inrp,Nrk,Snrk,Inrk,Cp,Ck,Imaxgal,overdlug] = ...
    a2rozp(fd,Sbase,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
    WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,...
    STATUS,SMAX,YPP,YPK,YKP,YKK,...
    Vbus,Ybus,REF,PU,PQ,opt,...
    nazwez,nazgal,SGMIN,SGMAX,QKOMP,UKUZW);     
  end % if sukces
  komunikat=(...
  iwyl==100|iwyl==500|iwyl==1000|iwyl==2000|iwyl==5000);
  if komunikat
    fprintf(...
    '\n ... %5d - liczba przebadanych wylaczen',iwyl);
    fprintf(...
    '\n ... czekaj ... trwa dalsza analiza wylaczen ...\n!');
  end
 end %  if status & liczbapol
end %for kk=1:nbr; 
et=etime(clock,t0); % computation time
fprintf(fd,'\n Czas badania kryterium N-m: %.2f sekund  ', et);
fprintf(   '\n Czas badania kryterium N-m: %.2f sekund  ', et);
end

function ww=NazDoSpacji(w);
ww=[]; i=1;
while ~isspace(w(i))
    zn=w(i);    ww=[ww zn];   i=i+1;
end
end

function [mpolsparse,wezpol,TYP]=a2net(fd,Ybus,TYP,nazwez);
% tworzenie macierzy incydencji i badanie spojnosci sieci
[nw,mw]=size(Ybus);  [ii,jj]=find(Ybus); 
macpol=sparse(ii,jj,ones(size(ii,1),1),nw,nw);
lgalwez=sum(macpol,2);
%liczba galezi w wezle bez wlasnej
wezpol=full(lgalwez-diag(macpol));
nrwezla=find(wezpol(:)==0);
if ~isempty(nrwezla)
   for ii = 1:size(nrwezla,1)
      k=nrwezla(ii);
      typ=TYP(k);
      nazwa=nazwez(k,:); typ4=4;
      TYP(k)=typ4;
   end  % ii = 1:size(nrwezla,1)
end % ~isempty(nrwez)
mpolsparse=macpol; % do modyfikacji Ybus
end
