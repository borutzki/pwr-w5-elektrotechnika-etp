 function [tm,ktraf,tapnum]=...
 a2tap(uset,uact,us,trtr,txtr,pzad,qzad,...
 tmin,tmax,tm,ktraf,tapnum,dtrpu)
 % wybor dyskretnej wartosci przekladni
 itr=size(uset,1);
 s2=pzad.^2+qzad.^2;  u2=uset.^2;   u4=u2.^2; 
 ztr2=trtr.^2+txtr.^2;   us2=us.^2;
 duw2=ztr2.*s2./u4; pduw2=-4*duw2./uact;
 du1w=(pzad.*trtr+qzad.*txtr)/2; pdu1w=-2*du1w./uact;
 ptr2=us2./u2; ptr=us./uact; 
 tpu=(ptr2-2*du1w); ptpu=-2*ptr2./uact-2*pdu1w;
 form=tpu-4*duw2;  form=form.*(form>0);
 ptransf=(tpu+sqrt(form))/2;
 form=tpu.^2-4*duw2; 
 form=~(form < 0).*form + (form < 0)* 1e-10;
 % przyrost przekladni miedzy aktualnym i zadanym nap.
 dptr=0.125./ptr.*(ptpu+(tpu.*ptpu-2*pduw2)./sqrt(form)).*(uset-uact);
 ptransf=tm+dptr;  % nowe przekladnie bez uwzgl. strefy martwej
 differ=dtrpu/2; % strefa martwa
 % ustalenie zmiany przekladnie z uwzgl. strefy martwej
 ptransf=(ptransf < tmin).*tmin + (ptransf>=tmin).*ptransf;
 ptransf=(ptransf > tmax).*tmax + (ptransf<=tmax).*ptransf;
 tmold=tm;
 itm=[]; itm=find( abs(ptransf-tm)>differ);
 if ~isempty(itm) tm(itm)=ptransf(itm); end
 %identifikowanie zaczepu  odpowiadajacego nowej przekladni             
 tapmax=round((tmax-tmin)./dtrpu); 
 tap=round((tm-tmin)./dtrpu);
 tm=tmin+tap.*dtrpu; % dyskretna przekladnia dla nowego zaczepu
 ktraf= abs(tm-tmold) > differ; % 1/0 - zmiana dyskretnej przekladni
 if tm==0 tm=1; tap=1; ktraf=0; end % brak regulacji przekladni
 tapnum=tapmax-tap+1; % nowy numer zaczepu
 end   %koniec a2tap()              
