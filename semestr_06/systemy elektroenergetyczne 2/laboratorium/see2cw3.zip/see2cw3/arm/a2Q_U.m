function a2Q_U(fd,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
    REF,PU,PQ,Ybus,Vbus,Ureg,opt,...
       WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,YPP,YPK,YKP,YKK,...
       STATUS,SGMIN,SGMAX,nazwez,nazgal,Sbase);
% wyznaczanie krzywej nosowe Q-U 
j=sqrt(-1);
fprintf(fd,'\n a2QU.m - krzywe nosowe Q-U');
fprintf(   '\n a2QU.m - krzywe nosowe Q-U');
[wezQU,typQU]=a2wezQU(fd,nazwez);
iwezQU1=[];  iwezQU1=find(typQU==1); busq1=0;
if ~isempty(iwezQU1) busq1=wezQU(iwezQU1); end
nbusq1=length(busq1);
if nbusq1>1 
    fprintf(fd,'Tylko jeden wezel moze miec typQU=1. Popraw dane!');
    fprintf(   'Tylko jeden wezel moze miec typQU=1. Popraw dane!');
    return
end %if nbusq1>1
if isempty(iwezQU1) | ~busq1
   fprintf(fd,...
'\n ... datQUwez*.m - wystapila bledna nazwa wezla dla krzywej Q-U ...');
   fprintf(fd,'\n ... popraw nazwe wezla w datQUwez*.m ... !');
   fprintf(...
'\n ... datQUwez*.m - wystapila bledna nazwa wezla dla krzywej Q-U ...');
   fprintf('\n ... popraw nazwe wezla w datQUwez*.m ... !');
   return
end %if isempty(iwezQU1) | ~busq1
PUQ=[PU; PQ]; 
nazbusE1 =char(nazwez(busq1,:));
fprintf(fd,...
'\n a2QU() - 1-szy wezel: %s, ze wzrostem Q dla krzywych Q-U',...
    nazbusE1);
fprintf(...
'\n a2QU() - 1-szy wezel: %s, ze wzrostem Q dla krzywych Q-U',...
    nazbusE1);
% wybor innych wezlow do char. Q-U
busq2=[]; busq3=[]; busq4=[]; nazbusE2=[];
nazbusE3=[]; nazbusE4=[];
iwezQUinne=find(typQU==0);  nwezQUinne=length(iwezQUinne);
if nwezQUinne>=1
    busq2=wezQU(iwezQUinne(1));
    nazbusE2=char(nazwez(busq2,:));
 if nwezQUinne>=2
     busq3=wezQU(iwezQUinne(2));
     nazbusE3=char(nazwez(busq3,:));
  if nwezQUinne>=3
      busq4=wezQU(iwezQUinne(3));
      nazbusE4=char(nazwez(busq4,:));
  end
 end
end
Uwez=[]; Qwez=[]; Uwez1=[];
TYP=real(TUNBUS); UNBUS=imag(TUNBUS); TYPold=TYP; 
TYP(busq1)=2;%wybrany wezel ze zmiana Q ma chwilowo typ=2
%PONOWNE definiowanie typow wezlow
REF=find(TYP(:)==3);
PU=find( TYP(:)==2|TYP(:)==6);%nowe PU oraz PU z ogr. Qmin,Qmax
PU6=find( TYP(:)==6);nPU6=size(PU6,1); % PU z ogr. Qmin,Qmax
PQ=find(TYP(:)==1|TYP(:)==5|TYP(:)==7|TYP(:)==8|TYP(:)==9);%nowe PQ 
nPQ=size(PQ,1);  WezIzol=find(TYP(:)==4);
nREF=size(REF,1);nPU=size(PU,1);
nPQ=size(PQ,1);nWezIzol=size(WezIzol,1);
TUNBUS=TYP+j*UNBUS;
fprintf('\n\n Krzywe Q-U - wzrost Q[Mvar] w wezle: %s', nazbusE1);
fprintf(...
'\n\n  ... OBLICZANIE moze potrwac kilka minut ...!\n')
regnap=[]; 
fprintf('\n Wybierz rodzaj regulacji napiecia w SEE:');
fprintf(...
'\n1 - reg. nap. dla typ=2,6 oraz reg. przekl. tr. dla typ=5');
fprintf(...
'\n2 - reg. nap. tylko dla typ=2,6 \n\n');
RegNap=input(' Podaj odpowiedz 1 lub 2, Odp. =  '  );
opis=[];
if RegNap==1 regnap=1; opis='Reg. nap. dla typ=2,6,5 - ';  end
if RegNap==2
 regnap=0; opis='Reg. nap. dla typ=2,6 bez reg. przekl. - ';
end %if RegNap==2
if isempty(regnap)
 fprintf(fd,'\n Wybrano %d, konieczny jest wybor 1 lub 2',...
     regnap);
 fprintf(   '\n Wybrano %d, konieczny jest wybor 1 lub 2',...
     regnap);
 return;
end %if isempty(regnap)
if regnap
   fprintf(fd,...
 '\n ... wybrano krzywe Q-U z reg. nap. dla typ=2,6,5 ...');
   fprintf(...
 '\n ... wybrano krzywe Q-U z reg. nap. dla typ=2,6,5 ...');
else
   fprintf(fd,...
 '\n ... wybrano krzywe Q-U z reg. nap. tylko dla typ=2,6 ...');
   fprintf(...
 '\n ... wybrano krzywe Q-U z reg. nap. tylko dla typ=2,6 ...');
 iTYP=[]; iTYP=find(TYP==5);
 if ~isempty(iTYP) TYP(iTYP)=1; end
end %if regnap
TUNBUS=TYP+j*UNBUS;
sukces=1; Uzad=1.15; dU=0.01; Uzad=Uzad+dU; ii=0;
U2=[]; U3=[]; U4=[];
Qplan =imag(SLBUS(busq1))*Sbase; Uplan=abs(Vbus(busq1));
cQplan=num2str(Qplan,4);       cUplan=num2str(Uplan,2);
opisQplan=['Qplan=' cQplan 'Mvar'];
p2=plot(Qplan,Uplan,'ro'); text(0.8*Qplan,Uplan+0.1,opisQplan);
hold on;
while sukces    
   Uzad=Uzad-dU;   Ureg(busq1)=Uzad; ii=ii+1; 
   opt=1; Q1old=imag(SGBUS(busq1));
   [Ybus,Vbus,YPP,YPK,YKP,YKK,TMK,...
    SLBUS,SGBUS,TUNBUS,sukces,Ureg] = ...
   a2rm(fd,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
   REF,PU,PQ,Ybus,Vbus,Ureg,opt,...
        WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,YPP,YPK,YKP,YKK,...
        STATUS,SGMIN,SGMAX,nazwez,nazgal);
   cU=Vbus(busq1); 
   U1=abs(Vbus(busq1));
   Q1=imag(SGBUS(busq1));
   if ~isempty(busq2) U2=abs(Vbus(busq2)); end
   if ~isempty(busq3) U3=abs(Vbus(busq3)); end
   if ~isempty(busq4) U4=abs(Vbus(busq4)); end
   if sukces
       Uwez1(ii,1)=U1;    Qwez(ii,1)=-Q1*Sbase;
       if ~isempty(busq2) Uwez2(ii,1)=U2; end
       if ~isempty(busq3) Uwez3(ii,1)=U3; end
       if ~isempty(busq4) Uwez4(ii,1)=U4; end
   end %if sukces
end % while 
%rys=0; % bez rysowania krzywych nosowych Q-U
rys=1; if isempty(Qwez) rys=0; end
if rys
    hold on;
    Qmin=min(Qwez);
    linia(Qmin,Qplan,Uplan,Uplan); linia(Qplan,Qplan,0,Uplan);
    hold on;
    iQ09=[]; Q09=[];
    iQ09=find(Uwez1(:)<=0.9);
    if ~isempty(iQ09)
        Q09=Qwez(iQ09(1)); 
        cQ09=num2str(Q09,4); opisQ09=['Qkryt=' cQ09 'Mvar'];
        Qzapas=Q09-Qplan; cQzapas=num2str(Qzapas,4);
        text(Qmin, 0.55,['Qzapas=' cQzapas 'Mvar']);
        cQkomp=num2str(-Qzapas,4);
        if Qzapas<0 
          cQk =['Qzapas ujemny, dlatego potrzebna kompensacja ' ...
              cQkomp ' Mvar'];
          text(Qmin, 0.45,cQk);     
        end %if Qzapas<0 
        hold on;
        p4=plot(Q09,0.9,'ro'); text(Q09,0.8,opisQ09);
        hold on;
        linia(Q09,  Q09,  0,0.9);
        hold on;
    else
        cQk ='Uwaga! Nap. zawsze U>0.9'; hold on;
        text(Qmin, 0.45,cQk); 
    end %if ~isempty(iQ09)
    sE1=deblank(char(nazbusE1));  sE2=deblank(char(nazbusE2));
    sE3=deblank(char(nazbusE3));  sE4=deblank(char(nazbusE4)); 
    YMIN=0; YMAX=1.6;    
    nQwez=size(Qwez,1);    nload=nQwez;
    fprintf(fd,...
    '\n\n Krzywe Q-U - wzrost Q[Mvar] w wezle: %s',sE1);
    fprintf(fd,...
     '\n   Lp   Q[Mvar]   U1(%s)    U2(%s)    U3(%s)    U4(%s)',...
        sE1,sE2,sE3,sE4);
    for iii=1:nQwez
        if isempty(busq2) & isempty(busq3) & isempty(busq4)
        fprintf(fd,'\n %4d %9.1f  %12.4f',iii,Qwez(iii),Uwez1(iii));
        end
        if ~isempty(busq2) & isempty(busq3) & isempty(busq4)
        fprintf(fd,'\n %4d %9.1f  %12.4f  %12.4f',...
        iii,Qwez(iii),Uwez1(iii), Uwez2(iii) );
        end
        if ~isempty(busq2) & ~isempty(busq3) & isempty(busq4)
        fprintf(fd,'\n %4d %9.1f  %12.4f  %12.4f  %12.4f',...
        iii,Qwez(iii),Uwez1(iii),Uwez2(iii),Uwez3(iii) );
        end
        if ~isempty(busq2) & ~isempty(busq3) & ~isempty(busq4)
        fprintf(fd,'\n %4d %9.1f  %12.4f  %12.4f  %12.4f  %12.4f',...
        iii,Qwez(iii),Uwez1(iii),Uwez2(iii),Uwez3(iii),Uwez4(iii) );
        end
    end %for iii=1:nQwez
    U90=0.90*(Uwez1./Uwez1);  % linia 0.9Un
    if ~isempty(busq1)
        p1=plot(Qwez,Uwez1,'k-',Qwez,U90,'r-','LineWidth',1.5);
        legend([nazbusE1],'Udop=0.9Un');
    end %
    if ~isempty(busq2)
    p1=plot(Qwez,Uwez1,'k-',Qwez,Uwez2,'k--',Qwez,U90,'r-',...
        'LineWidth',1.5);
    legend(p1,[nazbusE1],[nazbusE2],'Udop=0.9Un');
    end %if ~isempty(busq2)
    if ~isempty(busq2) & ~isempty(busq3)
    p1=plot(...
    Qwez,Uwez1,'k-',Qwez,Uwez2,'k--',...
    Qwez,Uwez3,'k-.',Qwez,U90,'r-','LineWidth',1.5);
    legend(p1,[nazbusE1],[nazbusE2],[nazbusE3],'Udop=0.9Un');
    end %if ~isempty(busq2) & ~isempty(busq3)
    if ~isempty(busq2) & ~isempty(busq3) & ~isempty(busq4)
    p1=plot(...
    Qwez,Uwez1,'k-',Qwez,Uwez2,'k--',...
    Qwez,Uwez3,'k-.',Qwez,Uwez4,'k:',Qwez,U90,'r-',...
    'LineWidth',1.5);
    legend(p1,[nazbusE1],[nazbusE2],[nazbusE3],[nazbusE4],...
        'Udop=0.9Un');
    end %if ~isempty(busq2) & ~isempty(busq3) & ~isempty(busq4)
    grid on;  title([opis ' krzywe Q-U - wzrost Q: ',nazbusE1]);
    xlabel('Q[Mvar]'); ylabel('Upu'); 
    XMIN=min(Qwez); XMAX=max(1.1*Qwez);
    if Qplan>XMAX XMAX=1.1*Qplan; end
    if (XMIN>=XMAX)
        axis normal;
    else
        axis([XMIN XMAX YMIN YMAX]);
    end %if (XMIN>=XMAX)
    t0=clock; % aktualny czas 
    rok=int2str(t0(1)); miesiac=int2str(t0(2)); dzien=int2str(t0(3));
    godz=int2str(t0(4));mins=int2str(t0(5));secs=int2str(t0(6));
    czas=[rok miesiac dzien godz mins secs];
    QUkrzywe = strcat('cQU_',czas); 
    saveas(gcf,QUkrzywe,'emf'); pause(5); close;
end % if rys
end% koniec a2Q_U()

