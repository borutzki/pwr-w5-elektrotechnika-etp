function [Jmatrix]=a2Jac(PU,PQ,Ybus,Vbus)
% Macierz Jacobiego rownan rozplywu mocy jako sparse matrix
nPU=size(PU,1); %liczba wezlow typu PU
nPQ=size(PQ,1); % liczba wezlow typu PQ
Jmatrix=[];
PUQ=[PU;PQ];    wPUQ=size(PUQ,1); % liczba wezlow niezaleznych 
[dPe,dPf,dQe,dQf,dU2e,dU2f]=a2J(Vbus,Ybus);% m. Jacobiego
temp=dPe(:,PUQ)'; dPe =temp(:,PUQ)';
temp=dPf(:,PUQ)';  dPf =temp(:,PUQ)';
temp=dU2e(:,PUQ)';dU2e=temp(:,PU)';
temp=dU2f(:,PUQ)'; dU2f=temp(:,PU)'; 
temp=dQe(:,PUQ)'; dQe =temp(:,PQ)';
temp=dQf(:,PUQ)';  dQf =temp(:,PQ)';
    if nPU & nPQ
        Jmatrix = [ dPe , dPf; ...
                    dU2e , dU2f;...
                    dQe  , dQf ];
    elseif nPU & ~nPQ
        Jmatrix = [ dPe , dPf; ...
                    dU2e , dU2f ];
    elseif ~nPU & nPQ
        Jmatrix = [ dPe , dPf; ...
                    dQe  , dQf ];
    end
Jmatrix=sparse(Jmatrix);   
end

function [dPe,dPf,dQe,dQf,dU2e,dU2f]=a2J(Vbus,Ybus)
%Tworzenie m. Jacobiego
%Moce wezlowe
%Sbus=diag(Vbus)*conj(Ibus)=diag(conj(Ibus))*Vbus
%Prady wezlowe
%Ibus=Ybus * Vbus
%Pochodne nap. wezlowych 
%dV/de=diag( eye(n) ), dV/df=j*diag(eye(n))
%Pochodne pradow wezlowych
%dI/de=Ybus*dV/de=Ybus,	dI/df=Ybus*dV/df=j*Ybus
%Pochodne mocy wezlowych
%dS/de=diag(Vbus)*conj(dI/de)+diag(conj(Ibus))*dV/de
%     =diag(Vbus)*conj(Ybus)+conj(diag(Ibus))
%dS/df=diag(Vbus)*conj(j*Ybus)+diag(j*conj(Ibus))
%Pochodne wezlowych mocy czynnych
%dPe=real(dS/de)=real(dSe)
%dPf=real(dS/df)=real(dSf)
%Pochodne kwadratow reg. napiec 
%ureg2(PU) = e(PU).^2 + f(PU).^2;
%dU2f=diag(2*f), dU2e = diag(2*e);
%Pochodne wezlowych mocy biernych
%dQe=imag(dS/de)=imag( dSe )
%dQf=imag(dS/df)=imag( dSf )
n=size(Vbus,1);
spVbus=spdiags(Vbus, 0, n, n); j=sqrt(-1);
diagVbusYbus=spVbus*conj(Ybus);
diagconjIbus=spdiags(conj(Ybus*sparse(Vbus)),0,n,n);
dSe= diagVbusYbus + diagconjIbus;
dSf= j*(diagconjIbus-diagVbusYbus ) ;
dPe=real(dSe);          dPf=real(dSf);
dU2f = imag(2*spVbus); 	dU2e = real(2*spVbus);
dQe=imag(dSe);      	dQf=imag(dSf);
end
   
