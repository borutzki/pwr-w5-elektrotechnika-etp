function [NRBUS,TUNBUS,UMK,Vbus,SLBUS,SGBUS,...
    SGMIN,SGMAX,YSHBUS,QKOMP,...
    WPK,ZGAL,YSHGAL,SMAX,TMK,TMOGR,DTRPU,STATUS,UKUZW,...
    Sbase,nazwez,nazgal,blad,sciezka,plik]= a2read
% funkcja czyta plik danych do analizy rozplywu mocy 
tp=clock; % czas rozpoczecia obliczen
rok=int2str(tp(1)); miesiac=int2str(tp(2)); dzien=int2str(tp(3));
godz=int2str(tp(4));mins=int2str(tp(5));secs=int2str(tp(6));
czas=['_' rok '-' miesiac '-' dzien '_' godz 'h' mins];
sciezka0=pwd; cd([sciezka0 '\Wyniki']); sciezka1=pwd;
plikWy= strcat([sciezka1 '\a2readOUT_',czas,'.m']);
fdr=fopen(plikWy,'wt'); cd ..
% wybor pliku z danymi w oknie dialogowym uigetfile()
wdold=cd;  blad=0; wezly=[]; galezie=[]; nazwez=[]; nazgal=[];
[plik,sciezka]=uigetfile(...
'armDAT*.m',' Wybierz m-plik z DANYMI do obl. rozplywu mocy ...'); 
fprintf('\n... wybrano: %s%s',sciezka,plik);
eval(['cd(''',sciezka,''')']); datafile=strtok(plik,'.');
% dane w tablicach komorkowych
[sbus,slin,stra,Sbase]=feval(datafile); 
eval(['cd(''',wdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
% transformacja sbus{} do znakowej nazwez[] oraz numerycznej wezly[]
sp12='123456789012'; % maksymalnie 12 znakow
[nw,n]=size(sbus); % wymiary tablicy sbus{}
nazwez=strvcat(sp12, char(sbus(:,1))); % nazwy wezlow
nazwez=nazwez(2:end,:); % tablica znakowa nazw wezlow 
macnum=cell2mat(sbus(:,2:end));
wezly=[[1:nw]' macnum];  %zapis sbus{{} do wezly[]
[wbus,kbus]=size(wezly);
wezly=[wezly zeros(wbus,2)]; 
% uzupelnienie Pgmin, Pgmax, jesli brak kolumny 15, 16 w sbus{}
if kbus==14  wezly(:,16)= wezly(:,8); end
%przeliczenie mocy wezlowych na [pu ]
wezly(:,[6:9,12:16])=wezly(:,[6:9,12:16])/Sbase; 
Zb=wezly(:,3).^2/Sbase; % wektor impedancji bazowych dla wezlow
wezly(:,10)=wezly(:,10)*1e-6.*Zb; 
wezly(:,11)=wezly(:,11)*1e-6.*Zb;  %odbior sta�oadmitancyjny
%transformacja slin{} do znakowej nazgal[] oraz numerycznej linie[]
[nl,n]=size(slin);
if nl   % brak linii
 nazlin=strvcat( sp12,char(slin(:,1))); nazlin=nazlin(2:end,:);  
 nazwp =strvcat( sp12,char(slin(:,2))); nazwp=nazwp(2:end,:);
 nazwk =strvcat( sp12,char(slin(:,3))); nazwk=nazwk(2:end,:); 
 linie=[zeros(nl,2) cell2mat(slin(:,4:end)) ];%dane numeryczne
 strvcatnazwp0=deblank(strvcat(nazwp));
 strvcatnazwk0=deblank(strvcat(nazwk));
 for ii=1:nw
   nazw0=deblank(nazwez(ii,:));
   wp = strmatch(nazw0,strvcatnazwp0,'exact');
   if ~isempty(wp)    linie(wp,1)=ii;      end
   wk = strmatch(nazw0,strvcatnazwk0,'exact');
   if ~isempty(wk)    linie(wk,2)=ii;       end
 end % for ii=1:nw
 prawid=linie(:,1) .* linie(:,2); nrline=find(prawid ==0);
 if ~isempty(nrline)
  for ii=1:length(nrline)
   fprintf(fdr,'\n linia nr=%3d - >%s<  ma bledne nazwy wezlow',...
   nrline(ii),nazlin(nrline(ii),:));
   fprintf('\n linia nr=%3d - >%s<  ma bledne nazwy wezlow',...
   nrline(ii),nazlin(nrline(ii),:));
  end     
   blad=1;   %blad w nazwach linii
   return;   % powrot do arm()
   end  %if ~isempty(nrline)
else
   nazlin=[]; linie=[];
end  % if nl
%transformacja stra{} do znakowej nazgal[] oraz numerycznej transf[]
[nt,n]=size(stra);
if nt         
   naztr=strvcat(sp12,char(stra(:,1))); naztr=naztr(2:end,:);    
   nod  =strvcat(sp12,char(stra(:,2)));  nod=nod(2:end,:);    
   ndo  =strvcat(sp12,char(stra(:,3)));  ndo=ndo(2:end,:);    
   transf=[zeros(nt,2) cell2mat(stra(:,4:end)) ];   
   strvcatnod0=deblank(strvcat(nod));
   strvcatndo0=deblank(strvcat(ndo));
   for ii=1:nw
      nazw0=deblank(nazwez(ii,:));
      wp = strmatch(nazw0,strvcatnod0,'exact');
      if ~isempty(wp)  transf(wp,1)=ii;       end
      wk = strmatch(nazw0,strvcatndo0,'exact');
      if ~isempty(wk)  transf(wk,2)=ii;       end
   end
   prawid=transf(:,1) .* transf(:,2); nrtrafo=find(prawid ==0);
   if ~isempty(nrtrafo)
      for ii=1:length(nrtrafo)
       fprintf(...
       '\n transf. nr=%3d - >%s<  ma bledne nazwy wezlow',...
           nrtrafo(ii),naztr(nrtrafo(ii),:));
       fprintf(fdr,...
       '\n transf. nr=%3d - >%s<  ma bledne nazwy wezlow',...
           nrtrafo(ii),naztr(nrtrafo(ii),:));
      end     
      blad=2;   %blad nazw trafo
      return;
   end  %if ~isempty(nrtrafo)
nazgal=[nazlin; naztr]; 
else
   nbrt=0; transf=[]; naztr=[];
end %  if ~isempty(stra)
% polaczenie nazw linii i transf. w tablicy znakowej nazgal
nazgal=[nazlin; naztr];
% Tworzenie galezie[] oraz wykrywanie braku transf. lub linii
[n,mw]=size(wezly);
[nbrl,mbrl]=size(linie);
[nbrt,mbrt]=size(transf);
if nbrl & nbrt   % galezie = linie + transf.
   galezie=[linie(:,1:7) zeros(nbrl,5)  linie(:,8:10);
   transf(:,1:13) zeros(nbrt,2) ];
elseif nbrl & ~nbrt  %galezie=linie - brak transf. w sieci
    galezie=[linie(:,1:7) zeros(nbrl,5)  linie(:,8:10)];
   fprintf(    '\n brak transformatorow w sieci');
   fprintf(fdr,'\n brak transformatorow w sieci');
elseif ~nbrl & nbrt % galezie=transf. - brak linii w sieci
   galezie=[ transf(:,1:13) zeros(nbrl,2) ];
   fprintf(    '\n brak linii w sieci');
   fprintf(fdr,'\n brak linii w sieci');
end
%sprawdzenie poprawnosci konfiguracji sieci
prawid=galezie(:,1) .* galezie(:,2);
nrgalezie=find(prawid == 0);
% przeliczenie na [ pu ]
Zb= wezly(galezie(:,1),3).^2/Sbase;%wektor imp. bazowych galezi
galezie(:,3)=galezie(:,3)./Zb;  %  R[pu]
galezie(:,4)=galezie(:,4)./Zb;  %  X[pu]
galezie(:,5)=galezie(:,5).*Zb*1e-6;  %  G[pu]
galezie(:,6)=galezie(:,6).*Zb*1e-6;  %  B[pu]
tm=galezie(:,8); tm2=tm.^2; 
% przeliczenie impedancji transf. w pu na strone wtorna
itm=find(tm(:)~=0);
galezie(itm,3)=galezie(itm,3)./tm2(itm);
galezie(itm,4)=galezie(itm,4)./tm2(itm);
galezie(itm,5)=galezie(itm,5).*tm2(itm);
galezie(itm,6)=galezie(itm,6).*tm2(itm);
%
TYP=wezly(:,2); REF=find(TYP(:)==3);
PU=find(TYP(:)==2 | TYP(:)==6 ); 
nru=size(PU,1);% wezly z reg. nap.
PQ=find(TYP(:)==1 | TYP(:)==5 );% typ=1,5 - wektor PQ
nd=size(PQ,1);  
if REF
 fprintf(fdr,...
 '\n %s - wezel bilansujacy, nr=%d - nadany numer wezla \n',...
     nazwez(REF,:), wezly(REF,1) );
elseif nru
 REF=PU(1);    wezly(REF,2)=3; 
 fprintf(fdr,'\n ...  brak wezla bilansujacego!');
 fprintf(fdr,...
 '\n ...  %s o nr=%d wybrano na wezel bilansujacy \n',...
    nazwez(REF,:),wezly(REF,1), REF);
 fprintf('\n ...  brak wezla bilansujacego!');
 fprintf(...
 '\n ...  %s o nr=%d wybrano na wezel bilansujacy \n',...
       nazwez(REF,:),wezly(REF,1), REF);
 if nru-1
   PU=PU(2:nru);
 else
  PU=[]; % brak wezlow z reg. nap.
 end
  nru=nru-1;
else
  REF=PQ(1);
  wezly(REF,2)=3;
  fprintf(fdr,'\n ...  brak wezla bilansujacego!');
  fprintf(fdr,...
  '\n ...  %s o nr=%d wybrano na wezel bilansujacy \n',...
     nazwez(REF,:),wezly(REF,1), REF);
  fprintf('\n ...  brak wezla bilansujacego!');
  fprintf(...
  '\n ...  %s o nr=%d wybrano na wezel bilansujacy \n',...
       nazwez(REF,:),wezly(REF,1), REF);
   PQ=PQ(2:nd);
   nd=nd-1;
end
% ... tworzenie tablic danych wezlowych dla funkcji arm
%NRBUS,TUNBUS,UMK,SLBUS,SGBUS,YSHBUS,SGMIN,SGMAX,QKOMP 
NRBUS=wezly(:,1);
TUNBUS=wezly(:,2)+j*wezly(:,3);
UMK=wezly(:,4)+j*wezly(:,5);
Vbus=wezly(:,4).*exp(j*wezly(:,5)*pi/180);
SLBUS=wezly(:,6)+j*wezly(:,7);
SGBUS=wezly(:,8)+j*wezly(:,9); 
% admitancja odbiorow staloimpedancyjnych w pu przy UN
YSHBUS=wezly(:,10)+j*wezly(:,11);
%czesci rzeczywiste zarezerwowane na Pgmin i Pgmax
SGMIN= wezly(:,15)+j*wezly(:,12);
SGMAX=wezly(:,16)+j*wezly(:,13);
QKOMP=wezly(:,14); % moc kompensatorow dla Un
%zalaczenie kompensatorow podanych w QKOMP
YSHBUS=YSHBUS-j*QKOMP;
nbus=size(QKOMP,1);
fprintf(fdr,...
'\n Po przetransformowaniu sbus{} do tablicy wezly');
fprintf(fdr,...
'\n    nr  typ       UN       Um  Uk_st      Pd       Qd       ');
fprintf(fdr,'Pg       Qg      Gsh      Bsh    Qgmin    Qgmax     ');
fprintf(fdr,'QKOMP    Pgmin    Pgmax'); 
fprintf(fdr,...
'\n     -    -       kV        -    st       pu       pu       ');
fprintf(fdr,'pu       pu       pu       pu       pu       pu        ');
fprintf(fdr,'pu       pu       pu');
fprintf(fdr,...
'\n     1    2        3        4     5        6        7        ');
fprintf(fdr,'8        9       10       11       12       13        ');
fprintf(fdr,'14       15       16 ');
for i=1:nbus
nrwez=NRBUS(i); typ=real(TUNBUS(i));
Un_kV=imag(TUNBUS(i)); Um=real(UMK(i)); Uk_st=imag(UMK(i)); 
Pd=real(SLBUS(i)); Qd=imag(SLBUS(i));
Pg=real(SGBUS(i)); Qg=imag(SGBUS(i));
Gsh=real(YSHBUS(i)); Bsh=imag(YSHBUS(i));
Qgmin=imag(SGMIN(i)); Qgmax=imag(SGMAX(i));
Qk=QKOMP(i);
Pgmin=real(SGMIN(i)); Pgmax=real(SGMAX(i));
fprintf(fdr,...
'\n%6d %4d %8.3g %8.5g %5.1g %8.5g %8.5g %8.5g %8.5g %8.5g %8.5g',...
    nrwez,typ,Un_kV,Um,Uk_st,Pd,Qd,Pg,Qg,Gsh,Bsh);
fprintf(fdr,...
' %8.5g  %8.5g %8.5g %8.5g',...
    Qgmin,Qgmax,Qk,Pgmin,Pgmax);
end
% ... tworzenie tablic danych galeziowych dla funkcji arm
%WPK,ZGAL,YSHGAL,SMAX,TMK,TMOGR,DTPRU,STATUS,UKUZW
WPK=galezie(:,1)+j*galezie(:,2);
ZGAL=galezie(:,3)+j*galezie(:,4); 
YSHGAL=galezie(:,5)+j*galezie(:,6);
SMAX=galezie(:,7);
TMK=galezie(:,8)+j*galezie(:,9);
TMOGR=galezie(:,10)+j*galezie(:,11);
DTRPU=galezie(:,12);
STATUS=galezie(:,13);
 % dlugosc linii w km i przekroj przewodow w mm2 w tablicy UKZW[]
UKUZW=galezie(:,14)+j*galezie(:,15);
nbr=size(WPK,1); % liczba galezi
fprintf(fdr,...
'\n\n\n Po przetransformowaniu danych galeziowych do tablicy galezie');
fprintf(fdr,...
'\n  wp   wk        R        X        G        B ImaxSmax   ');
fprintf(fdr,'to       tk     tmin     tmax       dt  st    ');
fprintf(fdr,'  lkm  Smm2');
fprintf(fdr,...
'\n   -    -       pu       pu       pu       pu A/MVA      ');
fprintf(fdr,'pu       pu       pu       pu       pu   -       ');
fprintf(fdr,'km   mm2');
fprintf(fdr,...
'\n   1    2        3        4        5        6     7       ');
fprintf(fdr,'8        9       10       11       12  13       ');
fprintf(fdr,'14    15');
[nbr,mbr]=size(galezie);
for i=1:nbr
wp=real(WPK(i)); wk=imag(WPK(i)); 
R=real(ZGAL(i)); X=imag(ZGAL(i));
G=real(YSHGAL(i)); B=imag(YSHGAL(i)); ImaxSmax=SMAX(i);
to=real(TMK(i)); tk=imag(TMK(i));
tmin=real(TMOGR(i)); tmax=imag(TMOGR(i)); dt=DTRPU(i); 
st=STATUS(i); lkm=real(UKUZW(i)); Smm2=imag(UKUZW(i));
fprintf(fdr,...
'\n%4d %4d %8.5f %8.5f %8.5f %8.5f %5.0f',...
    wp,wk,R,X,G,B,ImaxSmax);
fprintf(fdr,...
'%8.5f %8.5f %8.5f %8.5f %8.5f %3d %8.3f %5.0f',...
    to,tk,tmin,tmax,dt,st,lkm,Smm2);
end
fprintf(...
'\n\n KONIEC a2read(), czyli czytania danych z tablic komorkowych');
fprintf('\n Wyniki czytania zapisano w pliku %s',plikWy);
fclose(fdr);
end % koniec a2read()



