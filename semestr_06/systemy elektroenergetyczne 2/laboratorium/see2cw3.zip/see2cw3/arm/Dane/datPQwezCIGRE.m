function [datNewPQ]=datPQwezCIGRE 
datNewPQ={
% nowe Pg,Qg,Pd,Qd,typ po nag�ym wy��czeniu generacji
%Wezel      Pg,MW Qq,Mvar            Pd,MW Qd,Mvar    typ
 'B08211'     0       0           200.0       80.0    1;
 'B09211'     0       0           400.0      160.0    1;
 'B10211'     0       0           300.0      120.0    1;
 'B11112'     0       0           200.0       80.0    1;
 'B12112'     0       0            20.0        8.0    1;
 'B13112'     0       0            20.0        8.0    1;
 'B15112'     0       0            20.0        8.0    1;
 'B3L112'     0       0            20.0        8.0    1;
 'B4L112'     0       0           200.0       80.0    1;
};
end

 
