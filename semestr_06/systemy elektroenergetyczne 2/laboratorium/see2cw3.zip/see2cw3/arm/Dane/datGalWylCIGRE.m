function [datwyl]=datGalWyl;
datwyl={
%N-1
{'LIN10'}; % linie
{'LIN11'};
{'LIN12'};
{'LIN13'; ''};
{'LIN2'; ''};
{'LIN20'; ''};
{'LIN21'; ''};
{'LIN22'; ''};
{'LIN23'; ''};
{'LIN24'; ''};
{'LIN25'; ''};
{'LIN26'; ''};
{'LIN27'; ''};
{'LIN4'};
{'LIN6'};
{'LIN7'};
{'LIN8'};
{'LIN9'};
{'TRA-1'; ''}; %	1-szy transf.
{'TRA-2'; ''}; %	2-gi transf.
% N-2
{'LIN10'; 'LIN11'}; %	2 linie 110 kV
{'LIN11'; 'LIN12'}; %	2 linie 110 kV
{'LIN12'; 'LIN13'}; %	2 linie 110 kV
% N-3
{'LIN11'; 'LIN12'; 'LIN13'}; %	3 linie 110 kV
% N-4
{'LIN11'; 'LIN12'; 'LIN13'; 'LIN2'}; %	3 linie 110 kV
%N-5
{'LIN11'; 'LIN12'; 'LIN13'; 'LIN2'; 'LIN20'}; %	4 linie 110 kV
};
end
