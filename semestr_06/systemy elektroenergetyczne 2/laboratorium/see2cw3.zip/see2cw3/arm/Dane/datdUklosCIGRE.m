function [sdUk]=datdUklosCIGRE 
sdUk={
% Wezly do badania rozchylu katowego wektorow napiec
%Wez1     Wez2     Rozchyl dop. [stopnie]    
'B08211' 'B09211'         10;
};
end

