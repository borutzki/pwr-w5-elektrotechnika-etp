function [sdUk]=datdUklospo 
sdUk={
% Wezly do badania rozchylu katowego wektorow napiec
%Wez1     Wez2     Rozchyl dop. [stopnie]    
'FW411'  'ELW422'         10;
'ODB111' 'ODB121'         10;
};
end

