function [GALWYL]=a2GalWyl(fgo,datwyl,nazgal);
%identyfikacja przypadkow wyl. galezi wg datGalWyl.m 
fprintf(fgo,'\n Kryterium N-1,..., N-m\n ');
j=sqrt(-1);
[nwyl, mwyl]=size(datwyl);
GALWYL=[]; iwyl=0;% rezerwacja na numery wyl. GALEZI
fprintf(fgo,'\n Przypadek    -   opis wg datGalWyl.m');
fprintf(    '\n Przypadek    -   opis wg datGalWyl.m');
if ~isempty(datwyl)
  strvcatnazgal=strvcat(nazgal);
  for i=1:nwyl
      wyl=[];      wyl=datwyl{i,1};       %wyl
      [mwyl,colwyl]=size(wyl);        %mwyl
      wyl1=[]; wyl2=[]; wyl3=[]; 
      wyl4=[]; wyl5=[]; wyl6=[]; 
      wyl7=[]; wyl8=[]; wyl9=[];
      wyl1=wyl{1,1};
      if ~isempty(wyl1) & mwyl>1 wyl2=wyl{2,1};
       if ~isempty(wyl2) & mwyl>2 wyl3=wyl{3,1};
        if ~isempty(wyl3) & mwyl>3 wyl4=wyl{4,1};
         if ~isempty(wyl4) & mwyl>4 wyl5=wyl{5,1};
          if ~isempty(wyl5) & mwyl>5 wyl6=wyl{6,1};
           if ~isempty(wyl6) & mwyl>6 wyl7=wyl{7,1};
            if ~isempty(wyl7) & mwyl>7 wyl8=wyl{8,1};
             if ~isempty(wyl8) & mwyl>8 wyl9=wyl{9,1};
             end
            end
           end
          end
         end
        end
       end
      end
  nrgal=zeros(1,9);
  if ~isempty(wyl1)  nazel1=wyl1; % nazwa wyl. gal. 1
         igal1=[]; igal1 = strmatch(nazel1,strvcatnazgal,'exact');
         if ~isempty(igal1) nrgal(1,1)=igal1; end
   end
  if ~isempty(wyl2)  nazel2=wyl2; % nazwa wyl. gal. 2
         igal2=[]; igal2 = strmatch(nazel2,strvcatnazgal,'exact');
         if ~isempty(igal2) nrgal(1,2)=igal2; end
  end
  if ~isempty(wyl3)  nazel3=wyl3; % nazwa wyl. gal. 3
         igal3=[]; igal3 = strmatch(nazel3,strvcatnazgal,'exact');
         if ~isempty(igal3) nrgal(1,3)=igal3; end
  end
  if ~isempty(wyl4)  nazel4=wyl4; % nazwa wyl. gal. 4
         igal4=[]; igal4 = strmatch(nazel4,strvcatnazgal,'exact');
         if ~isempty(igal4) nrgal(1,4)=igal4; end
  end
  if ~isempty(wyl5)  nazel5=wyl5; % nazwa wyl. gal. 5
         igal5=[]; igal5 = strmatch(nazel5,strvcatnazgal,'exact');
         if ~isempty(igal5) nrgal(1,5)=igal5; end
  end
 if ~isempty(wyl6)  nazel6=wyl6; % nazwa wyl. gal. 6
         igal6=[]; igal6 = strmatch(nazel6,strvcatnazgal,'exact');
          if ~isempty(igal6) nrgal(1,6)=igal6; end
 end
 if ~isempty(wyl7)  nazel7=wyl7; % nazwa wyl. gal. 7
         igal7=[]; igal7 = strmatch(nazel7,strvcatnazgal,'exact');
         if ~isempty(igal7) nrgal(1,7)=igal7; end
 end
 if ~isempty(wyl8)  nazel8=wyl8; % nazwa wyl. gal. 8
         igal8=[]; igal8 = strmatch(nazel8,strvcatnazgal,'exact');
         if ~isempty(igal8) nrgal(1,8)=igal8; end
 end
 if ~isempty(wyl9)  nazel9=wyl9; % nazwa wyl. gal. 9
         igal9=[]; igal9 = strmatch(nazel9,strvcatnazgal,'exact');
         if ~isempty(igal9) nrgal(1,9)=igal9; end
 end
      tabnrgal=[]; tabnrgal=find(nrgal>0);      %tabnrgal
 if ~isempty(tabnrgal)
     GALWYL=[GALWYL;nrgal];   iwyl=iwyl+1; 
     [rowgal,colgal]=size(tabnrgal);
     fprintf(fgo,'\n %3d - wylaczenie galezi:',iwyl);
     fprintf(    '\n %3d - wylaczenie galezi:',iwyl);
     for k=1:colgal
        nrgalk=nrgal(1,k); nazgk=nazgal(nrgalk,:);;
        fprintf(fgo,' %12s ',nazgk);
        fprintf(    ' %12s ',nazgk);
     end
  end %if ~isempty(tabnrgal)
 end %for i=1:nwyl
end %if ~isempty(datwyl)
if isempty(GALWYL)
 fprintf(fgo,'\n UWAGA! bledne nazwy galezi w datGalWyl*.m');
 fprintf(    '\n UWAGA! bledne nazwy galezi w datGalWyl*.m');
end
end % koniec a2GalWyl()

 