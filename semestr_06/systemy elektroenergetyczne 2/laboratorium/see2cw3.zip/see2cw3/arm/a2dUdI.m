function a2dUdI(fd,...
 Nrp,Nrk,Snrp0,Snrp,Inrp0,Inrp,Snrk0,Snrk,Inrk0,Inrk,...
   Vbus0,Sbase,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
     WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,...
       STATUS,SMAX,YPP,YPK,YKP,YKK,...
         Vbus,Ybus,REF,PU,PQ,opt,nazwez,nazgal,...
          SGMIN,SGMAX,UKUZW,QKOMP,opis);
mVbus0=abs(Vbus0); mVbus =abs(Vbus); dmVbus=mVbus-mVbus0;
n=size(Vbus,1); UNBUS=imag(TUNBUS);
nrw=1:n; % numery wezlow
cUmin=0.9*ones(n,1); cUmax=1.1*ones(n,1);
wUmin=min(mVbus); wUmax=max(mVbus);
tp=clock; % aktualny czas
rok=int2str(tp(1)); miesiac=int2str(tp(2)); dzien=int2str(tp(3));
godz=int2str(tp(4));mins=int2str(tp(5));secs=int2str(tp(6));
czas=[rok miesiac dzien godz mins];
% profil napiec przed i po zmianie PQ
    plot(nrw,mVbus0,'k-',nrw,mVbus,'b--',...
    nrw,cUmin,'-.r',nrw,cUmax,':m',...    
    'LineWidth',1.5,...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor','g',...
    'MarkerSize',10);
    grid on; 
    xlabel('nr wezlow wg kolejnosci wczytania');
    ylabel('U[pu]');
    title('Profil napiecia w sieci przed i po zmianie');
    legend(' Uprzed', 'Upo','Umin', 'Umax');
    axis([1 1.1*n 0.9*wUmin 1.2*wUmax]);
    Uzmiana = ['Uzmiana',czas]; 
    saveas(gcf,Uzmiana,'emf'); pause(5); close;
% szybkie i wolne zmiany napiecia 
fprintf(fd,...
'\n\n *** Analiza napiec po wymuszeniu zmian danych wezlowych ***');
fprintf(...
'\n\n *** Analiza napiec po wymuszeniu zmian danych wezlowych ***');
%  Procentowe absolutne przyrosty nap. wezlowych
fprintf(fd,'\n %s',opis);
fprintf(fd,...
'\nNrWez Nazwa       Uprzed     Upo     dU Uprzed    Upo  abs(dU)'); 
fprintf(...
'\n  -      -            kV      kV     kV     pu     pu       %%'); 
k=1;
while k<=n
   dmV=dmVbus(k); Unk=UNBUS(k);
   nazwak=nazwez(k,:);
   U0=mVbus0(k); U1=mVbus(k); dU=U1-U0; dUproc=abs(dU*100);
   U0kV=U0*Unk; U1kV=U1*Unk; dUkV=U1kV-U0kV;
   fprintf(fd,'\n%3d %12s %6.1f %6.1f %6.1f %6.3f %6.3f %6.1f',...
                  k,nazwak,U0kV, U1kV, dUkV,   U0,   U1, dUproc );
   dUprocRys(k)=dUproc;
   k=k+1;
end %while kkdruk<n
% Wykres procentowych przyrostow napiec
w1=ones(1,n); % wektor jedynkowy
dU2=w1*2; % wzrost wolnych zmian napiecia SN w GPZ
dU3=w1*3; % szybkie zmiany napiecia 2<n<=10 w ciagu 1 godz
dU4=w1*4; % szybkie zmiany napiecia n<=4 w ciagu 1 godz
dU6=w1*6; % szybkie zmiany napiecia n<=4 w ciagu 1 godz
wdUmin=min(dUprocRys); wdUmax=max(dUprocRys);
plot(nrw,dUprocRys,'k-',nrw,dU2,'g--',nrw,dU3,'r-');
hold on;
plot(nrw,dU4,'b-.',nrw,dU6,'m:','LineWidth',1.5);
grid on; 
xlabel('nr wezla wg kolejnosci wczytania'); ylabel('abs(dU)%)');
title(opis); axis([1 1.1*n 0.8*wdUmin 1.2*wdUmax]);
str1='abs(dU)%'; str2='<=2%'; str3='<=3%-2<n/godz<=10';
str4='<=4%n/godz<=2'; str5='<=6%-n/doba<=4';
legend(str1,str2,str3,str4,str5);
dUrys = strcat('dUzmiana',czas); 
saveas(gcf,dUrys,'emf'); pause(2); close; hold off;
fprintf(fd,...
'\n *** Analiza pradow po wymuszeniu zmian danych wezlowych ***');
fprintf(...
'\n *** Analiza pradow po wymuszeniu zmian danych wezlowych ***');
% Analiza przyrostow pradow galeziowych
dIdruk=10; % A - najmniejsza rozwazany wrost pradu galeziowego
fprintf(fd,...
'\n Galezie ze zwiekszonym pradem powyzej %3.1f A',dIdruk);
fprintf(fd,'\n  - w odniesieniu do pradu przed zmianami');
fprintf(fd,'\nNrg Galaz        Od           Do             lkm Smm2 ');
fprintf(fd,'Iprzed  Ipo Idop Ipo/Imax');
fprintf(fd,'\n -   -           -            -               km  mm2 ');
fprintf(fd,'    A     A    A    -');
dPrad=Inrp-Inrp0; wp=real(WPK); wk=imag(WPK); 
tap=real(TMK);  tr=find(tap(:)~=0 & STATUS~=0);
nl=find(tap(:)==0 & STATUS(:)~=0); tap(nl)=1.0;
SMAX(tr)=SMAX(tr)./UNBUS(wp(tr))/sqrt(3)*1000;%dla transf. MVA
%wg malejacych przyrostow pradu
[y,jj]=sort(dPrad(:,1)); kolgal(:,1)=jj;
nbr=size(dPrad,1);
% dIdruk[A] - najmniejsza zmiana pradu w galezi powodujca WYDRUK
track=0; kk=1;
while kk<=nbr
  k=kolgal(kk,1); % nowa kolejnosc
  wp0=wp(k);   wk0=wk(k);   dI=dPrad(k);
  if dI > dIdruk
   track=1;
   Imax=SMAX(k);  Iact=abs(Inrp(k));
   kobc=Iact/Imax; Iplan=Iact-dI; overI='';
   if kobc>1 overI='>'; end
   nazg=nazgal(k,:); nazp0=nazwez(wp0,:); nazk0=nazwez(wk0,:);
   lkm=real(UKUZW(k)); smm2=imag(UKUZW(k));
   fprintf(fd,...
   '\n%3d %-8s %-8s %8s %5.1f %4.0f %5.0f %5.0f %5.0f %5.2f %s',...
   k,nazg,nazp0,nazk0,lkm,smm2,Iplan,Iact,Imax,kobc, overI);
  end % if dI > dIdruk
  kk=kk+1; 
end %while kk<=nbr
if track==0 fprintf(fd,'\n brak zmian > %3.1f A',dIdruk); end
% profil obciazenia pradowego przed i po
    nrg=(1:nbr)'; Idop=nrg./nrg; 
    Iprzed=abs(Inrp0)./SMAX; Ipo=abs(Inrp)./SMAX;
    plot(nrg,Iprzed,'k-',nrg,Ipo,'b--',nrg,Idop,'r-.','LineWidth',1.5);
    grid on; 
    xlabel('nr galezi wg kolejnosci wczytania'); ylabel('I/Imax');
    title('I/Imax  - profil pradowego obciazenia galezi sieci');
    legend(' Iprzed/Imax','Ipo/Imax', 'Idop=1');
    axis([1 1.1*nbr 0 2]);
    Izmiana = ['Izmiana',czas]; 
    saveas(gcf,Izmiana,'emf'); pause(5); close;
end %koniec a2dUdI()

   