
*** prmOUT.m - promieniowy rozplyw mocy ***
 Data:  2020- 3- 4  godz. 14, 33min, 44s
 Przeczytano dane z pliku: prmdatTEST4n2r.m
 Moce wezlowe wg formuly: Pwez = Pd - Pg, Qwez = Qd - Qg 
 Program tworzy czwornik obliczajac G/2, B/2
 UNSobl=10 kV - poziom napiecia obliczeniowego
 Uzad=10.2 kV - napiecie zadane na koncu ukladu na poziomie UNSobl
 Uzad = 8.7976 kV - zmieniono nap. zadane na koncu ukladu
 Dane wezlowe do obliczania promieniowego rozplywu mocy
 nrw UNSobl   Uk      Pd      Qd      Pg      Qg    Pwez    Qwez
  -      kV   st       MW    Mvar     MW    Mvar      MW    Mvar
  1  8.7976    0   1.035   3.031       0       0   1.035   3.031
  2      10    0       0       0       0       0       0       0
  3      10    0       0       0       0       0       0       0
  4      10    0   0.551   0.251   9.208   6.906  -8.657  -6.655
  5      10    0       0       0       0       0       0       0
 Dane galeziowe
  p   k        R        X       G       B
  -   -       om       om    mikS    mikS
  2   1    0.289    3.577   23.67 -273.92
  3   2    0.385    0.184       0  108.72
  4   3    1.104    0.929       0   8.032
  5   4    0.019    0.348   276.9 -3338.8

 ANALIZA lancucha czwornikow


### czwornik p=2 - k=1 ###
 k = 1 - wezel konca czwornika:
      Uk =    8.798 kV   - napiecie w wezle k
      Pk =    1.035 MW   - moc czynna wyplywajaca z wezla k
      Qk =    3.031 Mvar - moc bierna wyplywajaca z wezla k
   Pstrk =    0.001 MW   - strata poprzeczna mocy czynnej w wezle k
   Qstrk =    0.011 Mvar - strata poprzeczna mocy biernej w wezle k
 galaz podluzna 2 - 1
      Ua =    1.271 kV   - strata podluzna   napiecia
      Ub =    0.321 kV   - strata poprzeczna napiecia
    Pstr =    0.039 MW   - strata podluzna mocy czynnej
    Qstr =    0.477 Mvar - strata podluzna mocy biernej
 p = 2 - wezel poczatku czwornika:
      Up =   10.073 kV   - napiecie w wezle p
 rozchyl =    1.828 st   - rozchyl katowy napiec
   Pstrp =    0.001 MW   - strata poprzeczna mocy czynnej w wezle p
   Qstrp =    0.014 Mvar - strata poprzeczna mocy biernej w wezle p
      Pp =    1.076 MW   - moc czynna doplywajaca do wezla p
      Qp =    3.533 Mvar - moc bierna doplywajaca do wezla p

### czwornik p=3 - k=2 ###
 k = 2 - wezel konca czwornika:
      Uk =   10.073 kV   - napiecie w wezle k
      Pk =    1.076 MW   - moc czynna wyplywajaca z wezla k
      Qk =    3.533 Mvar - moc bierna wyplywajaca z wezla k
   Pstrk =    0.000 MW   - strata poprzeczna mocy czynnej w wezle k
   Qstrk =   -0.006 Mvar - strata poprzeczna mocy biernej w wezle k
 galaz podluzna 3 - 2
      Ua =    0.106 kV   - strata podluzna   napiecia
      Ub =   -0.115 kV   - strata poprzeczna napiecia
    Pstr =    0.052 MW   - strata podluzna mocy czynnej
    Qstr =    0.025 Mvar - strata podluzna mocy biernej
 p = 3 - wezel poczatku czwornika:
      Up =   10.180 kV   - napiecie w wezle p
 rozchyl =   -0.648 st   - rozchyl katowy napiec
   Pstrp =    0.000 MW   - strata poprzeczna mocy czynnej w wezle p
   Qstrp =   -0.006 Mvar - strata poprzeczna mocy biernej w wezle p
      Pp =    1.127 MW   - moc czynna doplywajaca do wezla p
      Qp =    3.546 Mvar - moc bierna doplywajaca do wezla p

### czwornik p=4 - k=3 ###
 k = 3 - wezel konca czwornika:
      Uk =   10.180 kV   - napiecie w wezle k
      Pk =    1.127 MW   - moc czynna wyplywajaca z wezla k
      Qk =    3.546 Mvar - moc bierna wyplywajaca z wezla k
   Pstrk =    0.000 MW   - strata poprzeczna mocy czynnej w wezle k
   Qstrk =   -0.000 Mvar - strata poprzeczna mocy biernej w wezle k
 galaz podluzna 4 - 3
      Ua =    0.446 kV   - strata podluzna   napiecia
      Ub =   -0.282 kV   - strata poprzeczna napiecia
    Pstr =    0.147 MW   - strata podluzna mocy czynnej
    Qstr =    0.124 Mvar - strata podluzna mocy biernej
 p = 4 - wezel poczatku czwornika:
      Up =   10.629 kV   - napiecie w wezle p
 rozchyl =   -1.518 st   - rozchyl katowy napiec
   Pstrp =    0.000 MW   - strata poprzeczna mocy czynnej w wezle p
   Qstrp =   -0.000 Mvar - strata poprzeczna mocy biernej w wezle p
      Pp =    1.275 MW   - moc czynna doplywajaca do wezla p
      Qp =    3.669 Mvar - moc bierna doplywajaca do wezla p

### czwornik p=5 - k=4 ###
 k = 4 - wezel konca czwornika:
      Uk =   10.629 kV   - napiecie w wezle k
      Pk =   -7.382 MW   - moc czynna wyplywajaca z wezla k
      Qk =   -2.986 Mvar - moc bierna wyplywajaca z wezla k
   Pstrk =    0.016 MW   - strata poprzeczna mocy czynnej w wezle k
   Qstrk =    0.189 Mvar - strata poprzeczna mocy biernej w wezle k
 galaz podluzna 5 - 4
      Ua =   -0.105 kV   - strata podluzna   napiecia
      Ub =   -0.236 kV   - strata poprzeczna napiecia
    Pstr =    0.010 MW   - strata podluzna mocy czynnej
    Qstr =    0.191 Mvar - strata podluzna mocy biernej
 p = 5 - wezel poczatku czwornika:
      Up =   10.527 kV   - napiecie w wezle p
 rozchyl =   -1.286 st   - rozchyl katowy napiec
   Pstrp =    0.015 MW   - strata poprzeczna mocy czynnej w wezle p
   Qstrp =    0.185 Mvar - strata poprzeczna mocy biernej w wezle p
      Pp =   -7.341 MW   - moc czynna doplywajaca do wezla p
      Qp =   -2.421 Mvar - moc bierna doplywajaca do wezla p

 Koniec analizy lancucha czwornikow 


 Straty i sprawnosc przesylu
    PSEE= -7.341 MW,     QSEE= -2.421 Mvar  - moc doplywajaca z SEE
 PstrSEE=  0.248 MW,  QstrSEE=  0.817 Mvar  - straty podluzne
PstrSEEp=  0.033 MW, QstrSEEp=  0.386 Mvar  - straty poprzeczne
PstrSUMA=  0.281 MW, QstrSUMA=  1.203 Mvar  - straty sumaryczne
    PSEE= -7.341 MW - moc czynna doplywajaca z SEE
PstrSUMA=  0.281 MW - moc calkowite straty przesylowe ukladu
   PGSEE=  9.208 MW - sumaryczna gen.  mocy czynnej w ukladzie
   PLSEE=  8.927 MW - sumaryczny pobor mocy czynnej w ukladzie
     eta=   96.9%

Wyniki obliczen - napiecia i moce wezlowe
nr UNSobl      U    dU   kat    Pd     Qd     Pg     Qg   Pwez   Qwez
 -    kV     kV     %    st     MW   Mvar     MW   Mvar     MW   Mvar
 1    10  8.798 -12.0   0.0  1.035  3.031      0      0  1.035  3.031
 2    10  10.07   0.7   1.8      0      0      0      0      0      0
 3    10  10.18   1.8   1.2      0      0      0      0      0      0
 4    10  10.63   6.3  -0.3  0.551  0.251  9.208  6.906 -8.657 -6.655
 5    10  10.53   5.3  -1.6  7.341  2.421      0      0  7.341  2.421

 Nap. na koncu ukladu    Ukonc =   8.7976 kV 
 Nap. na poczatku ukladu Upocz =  10.5271 kV 