function prm
% Promieniowy rozplyw mocy
j=sqrt(-1);
plikWy=['prmOUT.m'];
fd=fopen(plikWy,'wt');
fprintf(fd,'\n*** %s - promieniowy rozplyw mocy ***',plikWy);
fprintf(   '\n*** %s - promieniowy rozplyw mocy ***',plikWy);
fprintf(fd,...
'\n Data: %5d-%2d-%2d  godz. %2d, %2dmin, %2.0fs',clock);
% czytanie danych z m-pliku
wdold=cd;
[fname,sciezka]=...
uigetfile('prmDAT*.m','WYBIERZ plik z danymi do prm()');
eval(['cd(''',sciezka,''')']);
% czytanie wybranego pliku 
plikdat=strtok(fname,'.');
[wezly, galezie, UNSobl, Uzad]=feval(plikdat); 
fprintf(fd,'\n Przeczytano dane z pliku: %s',fname);
fprintf(   '\n Przeczytano dane z pliku: %s',fname);
fprintf(fd,...
    '\n Moce wezlowe wg formuly: Pwez = Pd - Pg, Qwez = Qd - Qg '); 
fprintf(fd,'\n Program tworzy czwornik obliczajac G/2, B/2');
fprintf(fd,'\n UNSobl=%g kV - poziom napiecia obliczeniowego',UNSobl);
fprintf(   '\n UNSobl=%g kV - poziom napiecia obliczeniowego',UNSobl);
fprintf(fd,...
'\n Uzad=%g kV - napiecie zadane na koncu ukladu na poziomie UNSobl',Uzad);
fprintf(...
'\n Uzad=%g kV - napiecie zadane na koncu ukladu na poziomie UNSobl',Uzad);
odp=0;
fprintf('\n Czy chcesz zmienic Uzad na poziomie UNSobl=%g kV ?',UNSobl);
fprintf('\n Odp. 1- TAK, 0- NIE\n');
odp=input(' odp = ');
if odp 
fprintf(...
'\n\n Podaj nap. po przeliczeniu na poziom nap. obl. %g kV\n',UNSobl); 
Uzad = input(' Uzad =  ');
fprintf(fd,...
'\n Uzad = %g kV - zmieniono nap. zadane na koncu ukladu',Uzad);
fprintf(...
'\n Uzad = %g kV - zmieniono nap. zadane na koncu ukladu',Uzad);
end
wezly(1,2)=Uzad;
nrwez=wezly(:,1);
Uwez=wezly(:,2); Ukwez=wezly(:,3);
U=Uzad; UN=UNSobl;
Pd=wezly(:,4); Qd=wezly(:,5);
Pg=wezly(:,6); Qg=wezly(:,7);
Pwez=Pd-Pg; Qwez=Qd-Qg;
dUwez=(Uwez-UN)/UN*100;
etaPwez=[];
nwez=length(nrwez);
SLBUS=Pd+j*Qd; SGBUS=Pg+j*Qg; SBUS=SLBUS-SGBUS;
fprintf(fd,...
'\n Dane wezlowe do obliczania promieniowego rozplywu mocy');
fprintf(fd,...
'\n nrw UNSobl   Uk      Pd      Qd      Pg      Qg    Pwez    Qwez');
fprintf(fd,...
'\n  -      kV   st       MW    Mvar     MW    Mvar      MW    Mvar');
for i=1:nwez
  nr=nrwez(i);
  fprintf(fd,...
  '\n%3d %7.5g %4.1g %7.5g %7.5g %7.5g %7.5g %7.5g %7.5g',...
  nr,Uwez(nr),Ukwez(nr),real(SLBUS(nr)),imag(SLBUS(nr)),...
  real(SGBUS(nr)),imag(SGBUS(nr)),real(SBUS(nr)),imag(SBUS(nr)) );
end
% Program tworzy czwornik obliczajac G/2, B/2 na podstawie wartosci G,B. 
wp=galezie(:,1); wk=galezie(:,2);
rgal=galezie(:,3); xgal=galezie(:,4); ggal=galezie(:,5); bgal=galezie(:,6);
npi=length(wp);
fprintf(fd,'\n Dane galeziowe');
fprintf(fd,'\n  p   k        R        X       G       B');
fprintf(fd,'\n  -   -       om       om    mikS    mikS');
for i=1:npi
    p=wp(i); k=wk(i); R=rgal(i); X=xgal(i); G=ggal(i); B=bgal(i);
fprintf(fd,'\n %2d  %2d  %7.5g %8.5g %7.4g %7.5g',p,k,R,X,G,B);
end
fprintf(fd,'\n\n ANALIZA lancucha czwornikow\n');
fprintf(   '\n\n ANALIZA lancucha czwornikow\n');
PstrSEE=0; QstrSEE=0; PstrSEEp=0; QstrSEEp=0;
PstrSUMA=0; QstrSUMA=0;
for i=1:npi
 p=wp(i);    k=wk(i);
 R=rgal(i);  X=xgal(i);
 G=ggal(i);  B=bgal(i);
 Pk=Pwez(k); Qk=Qwez(k);  % moce na koncu
 Uk=Uwez(k); Ukk=Ukwez(k);% modul i kat nap.na koncu czwornika
 if i==1
  Uk=U; Ukk=0;  etaPwez(k)=0;  end
  %analiza kolejnego czwornika
  [fd,Up,Ukp,Pp,Qp,dUp,etaP,Pstrk,Qstrk,Pstr,Qstr,Pstrp,Qstrp]=...
  czwornik(fd,p,k,Uk,Ukk,Pk,Qk,R,X,G,B,UN);
  %wyniki analizy koleknego czwornika
  Pwez(p)=Pwez(p)+Pp; Qwez(p)=Qwez(p)+Qp; % moce na poczatku
  Uwez(p)=Up; Ukwez(p)=Ukp;   % napiecie na poczatku
  dUwez(p)=dUp; etaPwez(p)=etaP; % procentowe wskazniki
  PstrSEE=PstrSEE+Pstr;
  QstrSEE=QstrSEE+Qstr; 
  PstrSEEp=PstrSEEp+Pstrp+Pstrk;
  QstrSEEp=QstrSEEp+Qstrp+Qstrk; 
end %for i=1:npi
PSEE=Pp; QSEE=Qp;
if Pp<0
   SLBUS(nwez,1)=-Pp-j*Qp;
else
   SGBUS(nwez,1)=Pp+j*Qp;
end
SBUS(nwez,1)=SLBUS(nwez,1)-SGBUS(nwez,1);
PstrSUMA=PstrSEE+PstrSEEp;
QstrSUMA=QstrSEE+QstrSEEp;
fprintf(fd,'\n\n Koniec analizy lancucha czwornikow \n');
fprintf(fd,'\n\n Straty i sprawnosc przesylu');
fprintf(fd,...
'\n    PSEE=%7.3f MW,     QSEE=%7.3f Mvar  - moc doplywajaca z SEE',...
     PSEE,QSEE);
fprintf(fd,...
'\n PstrSEE=%7.3f MW,  QstrSEE=%7.3f Mvar  - straty podluzne',...
     PstrSEE,QstrSEE);
fprintf(fd,...
'\nPstrSEEp=%7.3f MW, QstrSEEp=%7.3f Mvar  - straty poprzeczne',...
     PstrSEEp,QstrSEEp);
fprintf(fd,...
'\nPstrSUMA=%7.3f MW, QstrSUMA=%7.3f Mvar  - straty sumaryczne',...
     PstrSUMA,QstrSUMA);
fprintf(fd,...
'\n    PSEE=%7.3f MW - moc czynna doplywajaca z SEE',PSEE);
fprintf(fd,...
'\nPstrSUMA=%7.3f MW - moc calkowite straty przesylowe ukladu',PstrSUMA);
SGSEE=sum(SGBUS); SLSEE=sum(SLBUS); 
PGSEE=real(SGSEE); PLSEE=real(SLSEE);
fprintf(fd,...
'\n   PGSEE=%7.3f MW - sumaryczna gen.  mocy czynnej w ukladzie',PGSEE);
fprintf(fd,...
'\n   PLSEE=%7.3f MW - sumaryczny pobor mocy czynnej w ukladzie',PLSEE);
PstrSUMA=PGSEE-PLSEE; eta=(1-PstrSUMA/PGSEE)*100;
fprintf(fd,'\n     eta=%7.3g%%',eta);
fprintf(fd,'\n\nWyniki obliczen - napiecia i moce wezlowe');
fprintf(fd,...
'\nnr UNSobl      U    dU   kat    Pd     Qd     Pg     Qg   Pwez   Qwez');
fprintf(fd,...
'\n -    kV     kV     %%    st     MW   Mvar     MW   Mvar     MW   Mvar');
for i=1:nwez
  nr=nrwez(i);
  fprintf(fd,...
  '\n%3d %5.3g %6.4g %5.3f %5.3f %6.4g %6.4g %6.4g %6.4g %6.4g %6.4g',...
  nr,UN,Uwez(nr),dUwez(nr),Ukwez(nr),real(SLBUS(nr)),imag(SLBUS(nr)),...
  real(SGBUS(nr)),imag(SGBUS(nr)),real(SBUS(nr)),imag(SBUS(nr)) );
end %for i=1:nwez
Ukonc=Uwez(1); Upocz=Uwez(nwez); 
fprintf(fd,'\n\n Nap. na koncu ukladu    Ukonc = %8.6g kV ',Ukonc);
fprintf(fd,'\n Nap. na poczatku ukladu Upocz = %8.6g kV ',Upocz);
fclose('all');
fprintf('\n\n *** Wyniki promieniowego rozplywu mocy w pliku: %s',plikWy);
end % koniec prm.m

