function [wezly,galezie,Uobl,Uzad,tn]=prmdatTEST6n
% Wariant pracy: 6n - 6 silnikow pobierajacych moc znamionowa
%
% Dane do obliczania rozplywu promieniowego przeliczone na poziom napiecia obliczeniowego Uobl
% 
UNH=115;  UNL=11;    tn1=UNH/UNL; % znamionowa przekladnia transformatora w GPZ 110/10 kV
UNH=10.5; UNL=0.525; tn2=UNH/UNL; % znamionowa przekladnia transformatora w  RO  10/0.5 kV
tn=[tn1 tn2];
Uobl=10.0; % poziom napiecia, na ktory przeliczone parametry galezi
Uzad=10.36; % zadane napiecie na koncu ukladu przesylowego po przeliczeniu na poziom Uobl
 wezly=[
%   nrwez - numer wezla
%   Uobl_kV - poziom napiecia, na ktory przeliczono parametry
%   Pd(+)  - moc czynna odbierana w wezle,
%   Qd(+)  - moc bierna odbierana w wezle (indukcyjna),      Qd(-)  - moc bierna generowana w wezle (pojemnosciowa)
%   Pg(+)  - moc czynna generowana w wezle lub doplywajaca do wezla z sieci
%   Qg(+)  - moc bierna indukcyjna generowana w wezle,       Qg(-)  - moc bierna pojemno�ciowa generowana w wezle


%   Uobl_kV  - napiecie, na ktore przeliczono parametry galezi 
%   Uk_st  - kat napiecia zawsze rowny zero przed wykonaniem obliczen
%nrwez  Uobl_kV    Uk_st      Pd_MW    Qd_Mvar		Pg_MW	Qg_Mvar 
%   1       2       3           4          5
    1   10.00       0       1.553      0.703        0       0
    2   10.00       0           0          0        0       0
    3   10.00       0           0          0        0       0
    4   10.00       0       0.551      0.251    9.208   6.906
    5   10.00       0           0          0        0       0
% Program wyznacza moce wezlowe wg formuly: Pwez = Pd - Pg, Qwez = Qd - Qg  
];
%
%
 galezie=[
%   k - numer wezla konca czwornika, p - numer wezla poczatku  czwornika
%   Sp=Pp+jQp--->p____R____X____k----> Sk=Pk+jQk
%   Up/Ukp       |              |      Uk/Ukk
%                Yp             Yk
%                |              |
%   -------------------------------------------
%
%   R - rezystancja podluzna, X - reaktancja podluzna
%   Yp=G/2+jB/2 - admitancja w wezle poczatkowym
%   Yk=G/2+jB/2 - admitancja poprzeczna w wezle koncowym
% UWAGA! B>0 dla linii, natomiast B<0 dla transformatora
% Nalezy podac G,B w mikrosimensach zwracajac uwage na znak B:
%  (-)minus dla transformatora,
%  (+)plus dla linii
%   p   k   R_om   X_om     G_mikroS   B_mikroS
%   1   2      3      4            5          6 
    2   1   0.317   3.575      23.673     -273.923
    3   2   0.385   0.184        0        108.720
    4   3   1.104   0.929        0        8.032
    5   4   0.019   0.348      276.942    -3338.843
% Program tworzy czwornik obliczajac G/2, B/2 na podstawie podanych wartosci G,B. 
 ];
 %

end 
