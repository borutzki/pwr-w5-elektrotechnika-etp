
*** prmOUT.m - promieniowy rozplyw mocy ***
 Data:  2020- 3- 4  godz. 17, 53min, 17s
 Przeczytano dane z pliku: prmdatTEST6n.m
 Moce wezlowe wg formuly: Pwez = Pd - Pg, Qwez = Qd - Qg 
 Program tworzy czwornik obliczajac G/2, B/2
 UNSobl=10 kV - poziom napiecia obliczeniowego
 Uzad=10.36 kV - napiecie zadane na koncu ukladu na poziomie UNSobl
 Uzad = 10.0912 kV - zmieniono nap. zadane na koncu ukladu
 Dane wezlowe do obliczania promieniowego rozplywu mocy
 nrw UNSobl   Uk      Pd      Qd      Pg      Qg    Pwez    Qwez
  -      kV   st       MW    Mvar     MW    Mvar      MW    Mvar
  1  10.091    0   1.553   0.703       0       0   1.553   0.703
  2      10    0       0       0       0       0       0       0
  3      10    0       0       0       0       0       0       0
  4      10    0   0.551   0.251   9.208   6.906  -8.657  -6.655
  5      10    0       0       0       0       0       0       0
 Dane galeziowe
  p   k        R        X       G       B
  -   -       om       om    mikS    mikS
  2   1    0.317    3.575   23.67 -273.92
  3   2    0.385    0.184       0  108.72
  4   3    1.104    0.929       0   8.032
  5   4    0.019    0.348   276.9 -3338.8

 ANALIZA lancucha czwornikow


### czwornik p=2 - k=1 ###
 k = 1 - wezel konca czwornika:
      Uk =   10.091 kV   - napiecie w wezle k
      Pk =    1.553 MW   - moc czynna wyplywajaca z wezla k
      Qk =    0.703 Mvar - moc bierna wyplywajaca z wezla k
   Pstrk =    0.001 MW   - strata poprzeczna mocy czynnej w wezle k
   Qstrk =    0.014 Mvar - strata poprzeczna mocy biernej w wezle k
 galaz podluzna 2 - 1
      Ua =    0.303 kV   - strata podluzna   napiecia
      Ub =    0.528 kV   - strata poprzeczna napiecia
    Pstr =    0.009 MW   - strata podluzna mocy czynnej
    Qstr =    0.103 Mvar - strata podluzna mocy biernej
 p = 2 - wezel poczatku czwornika:
      Up =   10.407 kV   - napiecie w wezle p
 rozchyl =    2.909 st   - rozchyl katowy napiec
   Pstrp =    0.001 MW   - strata poprzeczna mocy czynnej w wezle p
   Qstrp =    0.015 Mvar - strata poprzeczna mocy biernej w wezle p
      Pp =    1.565 MW   - moc czynna doplywajaca do wezla p
      Qp =    0.835 Mvar - moc bierna doplywajaca do wezla p

### czwornik p=3 - k=2 ###
 k = 2 - wezel konca czwornika:
      Uk =   10.407 kV   - napiecie w wezle k
      Pk =    1.565 MW   - moc czynna wyplywajaca z wezla k
      Qk =    0.835 Mvar - moc bierna wyplywajaca z wezla k
   Pstrk =    0.000 MW   - strata poprzeczna mocy czynnej w wezle k
   Qstrk =   -0.006 Mvar - strata poprzeczna mocy biernej w wezle k
 galaz podluzna 3 - 2
      Ua =    0.073 kV   - strata podluzna   napiecia
      Ub =   -0.003 kV   - strata poprzeczna napiecia
    Pstr =    0.011 MW   - strata podluzna mocy czynnej
    Qstr =    0.005 Mvar - strata podluzna mocy biernej
 p = 3 - wezel poczatku czwornika:
      Up =   10.480 kV   - napiecie w wezle p
 rozchyl =   -0.016 st   - rozchyl katowy napiec
   Pstrp =    0.000 MW   - strata poprzeczna mocy czynnej w wezle p
   Qstrp =   -0.006 Mvar - strata poprzeczna mocy biernej w wezle p
      Pp =    1.576 MW   - moc czynna doplywajaca do wezla p
      Qp =    0.828 Mvar - moc bierna doplywajaca do wezla p

### czwornik p=4 - k=3 ###
 k = 3 - wezel konca czwornika:
      Uk =   10.480 kV   - napiecie w wezle k
      Pk =    1.576 MW   - moc czynna wyplywajaca z wezla k
      Qk =    0.828 Mvar - moc bierna wyplywajaca z wezla k
   Pstrk =    0.000 MW   - strata poprzeczna mocy czynnej w wezle k
   Qstrk =   -0.000 Mvar - strata poprzeczna mocy biernej w wezle k
 galaz podluzna 4 - 3
      Ua =    0.239 kV   - strata podluzna   napiecia
      Ub =    0.052 kV   - strata poprzeczna napiecia
    Pstr =    0.032 MW   - strata podluzna mocy czynnej
    Qstr =    0.027 Mvar - strata podluzna mocy biernej
 p = 4 - wezel poczatku czwornika:
      Up =   10.719 kV   - napiecie w wezle p
 rozchyl =    0.281 st   - rozchyl katowy napiec
   Pstrp =    0.000 MW   - strata poprzeczna mocy czynnej w wezle p
   Qstrp =   -0.000 Mvar - strata poprzeczna mocy biernej w wezle p
      Pp =    1.608 MW   - moc czynna doplywajaca do wezla p
      Qp =    0.854 Mvar - moc bierna doplywajaca do wezla p

### czwornik p=5 - k=4 ###
 k = 4 - wezel konca czwornika:
      Uk =   10.719 kV   - napiecie w wezle k
      Pk =   -7.049 MW   - moc czynna wyplywajaca z wezla k
      Qk =   -5.801 Mvar - moc bierna wyplywajaca z wezla k
   Pstrk =    0.016 MW   - strata poprzeczna mocy czynnej w wezle k
   Qstrk =    0.192 Mvar - strata poprzeczna mocy biernej w wezle k
 galaz podluzna 5 - 4
      Ua =   -0.195 kV   - strata podluzna   napiecia
      Ub =   -0.218 kV   - strata poprzeczna napiecia
    Pstr =    0.013 MW   - strata podluzna mocy czynnej
    Qstr =    0.245 Mvar - strata podluzna mocy biernej
 p = 5 - wezel poczatku czwornika:
      Up =   10.527 kV   - napiecie w wezle p
 rozchyl =   -1.189 st   - rozchyl katowy napiec
   Pstrp =    0.015 MW   - strata poprzeczna mocy czynnej w wezle p
   Qstrp =    0.185 Mvar - strata poprzeczna mocy biernej w wezle p
      Pp =   -7.005 MW   - moc czynna doplywajaca do wezla p
      Qp =   -5.179 Mvar - moc bierna doplywajaca do wezla p

 Koniec analizy lancucha czwornikow 


 Straty i sprawnosc przesylu
    PSEE= -7.005 MW,     QSEE= -5.179 Mvar  - moc doplywajaca z SEE
 PstrSEE=  0.065 MW,  QstrSEE=  0.380 Mvar  - straty podluzne
PstrSEEp=  0.034 MW, QstrSEEp=  0.393 Mvar  - straty poprzeczne
PstrSUMA=  0.099 MW, QstrSUMA=  0.773 Mvar  - straty sumaryczne
    PSEE= -7.005 MW - moc czynna doplywajaca z SEE
PstrSUMA=  0.099 MW - moc calkowite straty przesylowe ukladu
   PGSEE=  9.208 MW - sumaryczna gen.  mocy czynnej w ukladzie
   PLSEE=  9.109 MW - sumaryczny pobor mocy czynnej w ukladzie
     eta=   98.9%

Wyniki obliczen - napiecia i moce wezlowe
nr UNSobl      U    dU   kat    Pd     Qd     Pg     Qg   Pwez   Qwez
 -    kV     kV     %    st     MW   Mvar     MW   Mvar     MW   Mvar
  1    10  10.09 0.912 0.000  1.553  0.703      0      0  1.553  0.703
  2    10  10.41 4.074 2.909      0      0      0      0      0      0
  3    10  10.48 4.800 2.892      0      0      0      0      0      0
  4    10  10.72 7.194 3.173  0.551  0.251  9.208  6.906 -8.657 -6.655
  5    10  10.53 5.271 1.984  7.005  5.179      0      0  7.005  5.179

 Nap. na koncu ukladu    Ukonc =  10.0912 kV 
 Nap. na poczatku ukladu Upocz =  10.5271 kV 