function [fd,Up,Ukp,Pp,Qp,dUp,etaP,Pstrk,Qstrk,Pstr,Qstr,Pstrp,Qstrp]=...
    czwornik(fd,p,k,Uk,Ukk,Pk,Qk,R,X,G,B,UN)
U=Uk; % napiecie na koncu
G=G*1e-6; B=B*1e-6;
Pstrk=0.5*G*U^2; Qstrk=-0.5*B*U^2; %straty poprzeczne w wezle k
P=Pk+Pstrk; Q=Qk+Qstrk; % moc plynaca przze R,X
Ua=(P*R+Q*X)/U; Ub=(P*X-Q*R)/U; % podluzna i poprzeczna strata napiecia
Up=sqrt((U+Ua)^2+Ub^2); % napiecie na poczatku
dUp=(Up-UN)*100/UN; % procentowe odchylenie napiecia na poczatku 
rozchyl=atan(Ub/(U+Ua))*180/pi; %rozchyl katowy
Ukp=Ukk+ rozchyl; %kat na poczatku
Pstr=R*(P^2+Q^2)/U^2; Qstr=X*(P^2+Q^2)/U^2; %straty podluzne
Pstrp=0.5*G*Up^2; Qstrp=-0.5*B*Up^2; %straty poprzeczne w wezle p
Pp=P+Pstr+Pstrp; Qp=Q+Qstr+Qstrp;
etaP=Pk/Pp*100; % procentowa sprawnosc przesylu mocy czynnej
fprintf(fd,'\n\n### czwornik p=%d - k=%d ###',p,k);
fprintf(fd,'\n k = %d - wezel konca czwornika:',k);
fprintf(fd,...
'\n      Uk = %8.3f kV   - napiecie w wezle k', Uk);
fprintf(fd,...
'\n      Pk = %8.3f MW   - moc czynna wyplywajaca z wezla k',Pk);
fprintf(fd,...
'\n      Qk = %8.3f Mvar - moc bierna wyplywajaca z wezla k',Qk);
fprintf(fd,...
'\n   Pstrk = %8.3f MW   - strata poprzeczna mocy czynnej w wezle k',Pstrk);
fprintf(fd,...
'\n   Qstrk = %8.3f Mvar - strata poprzeczna mocy biernej w wezle k',Qstrk);
fprintf(fd,'\n galaz podluzna %d - %d',p,k);
fprintf(fd,'\n      Ua = %8.3f kV   - strata podluzna   napiecia',Ua);
fprintf(fd,'\n      Ub = %8.3f kV   - strata poprzeczna napiecia',Ub);
fprintf(fd,'\n    Pstr = %8.3f MW   - strata podluzna mocy czynnej',Pstr);
fprintf(fd,'\n    Qstr = %8.3f Mvar - strata podluzna mocy biernej',Qstr);
fprintf(fd,'\n p = %d - wezel poczatku czwornika:',p);
fprintf(fd,'\n      Up = %8.3f kV   - napiecie w wezle p', Up);
fprintf(fd,'\n rozchyl = %8.3f st   - rozchyl katowy napiec',rozchyl);
fprintf(fd,...
'\n   Pstrp = %8.3f MW   - strata poprzeczna mocy czynnej w wezle p',Pstrp);
fprintf(fd,...
'\n   Qstrp = %8.3f Mvar - strata poprzeczna mocy biernej w wezle p',Qstrp);
fprintf(fd,'\n      Pp = %8.3f MW   - moc czynna doplywajaca do wezla p',Pp);
fprintf(fd,'\n      Qp = %8.3f Mvar - moc bierna doplywajaca do wezla p',Qp);
end 