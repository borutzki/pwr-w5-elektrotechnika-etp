
O:\OneDrive - Politechnika Wroclawska\studia\Systemy elektroenergetyczne 2\lab\see2cw7\az\Wyniki\az2izwOUT_2020-4-6_12h34.m - z3f zasilane z niezaleznych zr.: SEE,G,M ***
 Data:  2020- 4- 6  godz. 12, 34min, 35s

 Metoda niezaleznych zrodel zasilajacych zwarcie
 Impedancje zwarciowe galezi zrodlo - punkt zwarcia 3-fazowego
 ZkSEE = RkSEE+jXkSEE = ( 0.019 + j 0.400) om - imp. zw. pol. z SEE
   ZkG = RkG   +jXkG  = ( 0.117 + j 1.672) om - imp. zw. pol. z GS
   ZkM = RkM   +jXkM  = ( 6.844 + j16.705) om - imp. zw. pol. z M
 Unk =  10.0 kV - znamionowe napiecie sieci w punkcie zwarcia
 Prady zwarciowe poczatkowe
 c =  1.1 
  IkSEE = 15.846 kA ( 79.3%) - prad zw. poczatkowy od SEE
    IkG =  3.789 kA ( 19.0%) - prad zw. poczatkowy od GS
    IkM =  0.352 kA (  1.8%) - prad zw. poczatkowy od M
     Ik = 19.987 kA (100.0%) - prad zw. poczatkowy sumaryczny
 Moce zwarciowe
  SkSEE =    274 MVA - moc zwarciowa od SEE
    SkG =     66 MVA - moc zwarciowa od  GS
    SkM =      6 MVA - moc zwarciowa od   M
     Sk =    346 MVA - moc zwarciowa sumaryczna

 Metoda Thevenina - imp. widziana z miejsca zwarcia
 1/Zkk = 1/ZSEE + 1/ZG + 1/ZM
 Zkk = Rkk +jXkk = ( 0.018 + j 0.318) om 
 Ik =    19.967 kA  - prad zwarciowy poczatkowy
 Sk =     345.8 MVA - moc zwarciowa
