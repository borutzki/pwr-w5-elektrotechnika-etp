
c:\az\Wyniki\az2izwOUT_2018-1-24_9h46.m - z3f zasilane z niezaleznych zr.: SEE,GS,M ***
 Data:  2018- 1-24  godz.  9, 46min,  4s