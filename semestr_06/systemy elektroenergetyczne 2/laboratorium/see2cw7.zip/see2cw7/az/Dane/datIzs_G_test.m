function [c,zrodlo,In,m,Unk,Rk,Xk,tzw,psi]=datIzs_G
zrodlo='G'; % zwarcie zasilane z gen. synchr.
Sn = 11;   % MVA - moc znamionowa zrodla
m=[];      % moc znamionowa silnika na pare biegunow
Unk=10;    % kV - napiecie znamionowe sieci w miejscu zwarcia
In=Sn/sqrt(3)/Unk; % kA - prad znamionowy zrodla
Rk=0.119; % om - rezystancja obwodu zw. przy Unk
Xk=1.706; % om - reaktancja  obwodu zw. przy Unk
tzw=0.24;  % s - czas trwania zwarcia
psi=0;     % stopnie - kat poczatkowy sem
c=1.1; % maksymalny prad zw.
end
