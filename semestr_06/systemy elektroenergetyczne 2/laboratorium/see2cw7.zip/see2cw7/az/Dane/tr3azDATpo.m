function [Sn,UnG,UnGs,UNSobl,straGS,straGD,straSD,...
    poluzw,winf,tN] = tr3azDATpo
%Dane do obl. par. zast. zwarciowych transf. 3-uzw.
UNSobl=110.0; % kV
winf=1e8; % nieskonczonosc
% dane znamionowe wspolne dla par uzwojen
Sn=16; UnG=115; UnGs=110; tN=1.0;
% dane znamionowe dla poszczegolnych par uzwojen
straGS={
%trans.  wezp    wezk      PcuGS  ukGS
%12s     12s     12s         MW    % 
'T1' 'GPZ110kV' 'GPZ20kV' 0.04874 11.51};
straGD={
%trans.  wezp    wezk     PcuGD   ukGD
%12s     12s     12s       MW       % 
'T1' 'GPZ110kV' 'GPZ10kV' 0.049435 18.67};
straSD={
%trans.  wezp    wezk     PcuSD  ukSD
%12s     12s     12s       MW     %
'T1' 'GPZ20kV' 'GPZ10kV' 0.0489  6.3};
% polaczenia uzwojen
% G - gorne nap.    S - srodkowe nap.    D - dolne nap.
% G-S-D:
polG='YN'; polS='d';  polD='yn'; YN_d_yn=[polG '-' polS '-' polD];
polG='YN'; polS='d';  polD='y';  YN_d_y =[polG '-' polS '-' polD];
polG='YN'; polS='d';  polD='d';  YN_d_d =[polG '-' polS '-' polD];
% wybor rodzaju polaczen uzwojen
%poluzw=YN_d_yn;
%poluzw=YN_d_y;
poluzw=YN_d_d;
end % koniec tr3azDAT
