function  [nazwa,Un,Ipoj,s_rozstr] = z1fsndatGPZ10kV
% prad doziemny pojemnosciowy w wezle GPZ10kV
nazwa='GPZ10kV'; 
Un=10; % kV, napiecie znamionowe sieci
Ipoj = 20.8; % A, pomierzony prad pojemnosciowy doziemny w wezle
s_rozstr=10; % s - procentowe roztrojenie cewki
return;



