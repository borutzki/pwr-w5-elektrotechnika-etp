function [nazwa,Un,Ipoj,s_rozstr]=datz1fSNpo
nazwa='GPZ10kV'; 
Un=10;%kV, nap. znam. sieci SN
Ipoj=100;%A - pomierzony prad doziemny pojemnosciowy w GPZ
s_rozstr=-10;%s - procentowe rozstrojenie cewki
end
