function az2Izns(fd,nazwa,Unk,Rkk1,Xkk1,Rkk0,Xkk0,drukIz)
%Analiza zwarc w wybranym wezle:
% - obliczenia numeryczne pr. i nap. w ukl. 012 oraz ABC
% - wykresy wektorowe pr. i nap. w ukl. 012 oraz ABC
t0=clock; % czas rozpoczecia obliczen
rok=int2str(t0(1));miesiac=int2str(t0(2));dzien=int2str(t0(3));
godz=int2str(t0(4));mins=int2str(t0(5));secs=int2str(t0(6));
czas=['_' rok '-' miesiac '-' dzien '_' godz 'h' mins];
wykresy=0;
if nargin < 6
  wykresy=1;
  wdold=cd;
  [fname,sciezka]=uigetfile('datIzns*.m',...
  'Wybierz plik danych do analizy numerycznej i graficznej zwarcia:');
  fprintf('\n... wybrano: %s%s.m',sciezka,fname);
  eval(['cd(''',sciezka,''')']);
  % czytanie wybranego pliku
  zwdat=strtok(fname,'.');
  [nazwa,Unk,Rkk1,Xkk1,Rkk0,Xkk0,drukIz]=feval(zwdat);
  eval(['cd(''',wdold,''')']);% powrot do przeczytaniu
  fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
  Unfk=Unk/sqrt(3); % nap. znam. fazowe sieci w miejscu zwarcia
  sciezka0=pwd; cd([sciezka0 '\Wyniki']); sciezka1=pwd;
  plikWy= strcat([sciezka1 '\az2Izns',czas,'.m']);
  fd=fopen(plikWy,'wt');  % plik z przeczytanymi danymi do obliczen
  cd ..
  fprintf(fd,...
'\n*** %s - analiza pr. i nap. zwarc w wezle ***',plikWy);
   fprintf(...
'\n*** %s - analiza pr. i nap. zwarc w wezle ***',plikWy);
  fprintf(fd,...
'\n Data: %5d-%2d-%2d  godz. %2d, %2dmin, %2.0fs',clock);
end
if drukIz  
winf=1e8; cinf='inf'; % nieskonczonosc
j=sqrt(-1); a=exp(j*2*pi/3); % operatory obrotu wektorow pradow i napiec
S    =[1    1     1;
       1    a     a^2; 
       1    a^2   a  ]/3;
invS =[1    1     1;
       1    a^2   a; 
       1    a     a^2  ];
Zkk1=Rkk1+j*Xkk1; Zkk0=Rkk0+j*Xkk0;
p3=sqrt(3); % pierwiastek kwadratowy z liczby 3
% USTALANIE wsp. zwarciowego c 
c=1.1; cnN=1; if Unk<1 c=cnN; end
Unfk=Unk/sqrt(3);
E1=c*Unfk; % sem Thevenina zastepcza
I1=c*Unk/p3/Zkk1; % PRAD zwarciowy ZESPOLONY
Izk3f=I1;
Ik=c*Unk/p3/abs(Zkk1); Ikk=Ik; % PRAD zwarciowy POCZATKOWY
Sk=p3*Unk*Ik;
knazwa=nazwa;
fprintf(fd,'\n\n');
fprintf(fd,...
'\n ******************************************************');
fprintf(fd,'\n ***  %-12s - miejsce zwarcia ***',knazwa);
fprintf(fd,...
'\n ******************************************************');
fprintf(fd,...
'\n Unk = %7.3g kV - nap. znam. sieci  w miejscu zwarcia',Unk);
fprintf(fd,...
'\nUnfk = %7.3f kV - nap. znam. fazowe w miejscu zwarcia',Unfk);
fprintf(fd,'\n   c = %7.2f    - wsp. obliczen zwarciowych',c);
fprintf(fd,...
'\n  E1 = %7.3f kV - sem. Thevenina zastepcza E1=c*Unfk',E1);
if Rkk1>9999 | Xkk1>9999
  fprintf(fd,...
  '\nRkk1 = %7s     , Xkk1 = %7s      - imp. zwar. skl.1'...
  ,cinf,cinf);
else
  fprintf(fd,...
  '\nRkk1 = %7.3f om, Xkk1 = %7.3f om - imp. zwar. skl.1'...
  ,Rkk1,Xkk1);
end
if Rkk0>999. | Xkk0>999.
  fprintf(fd,...
  '\nRkk0 = %7s     , Xkk0 = %7s      - imp. zwar. skl.0'...
  ,cinf,cinf);
else
  fprintf(fd,...
  '\nXkk0 = %7.3f om, Xkk0 = %7.3f om - imp. zwar. skl.0'...
  ,Rkk0,Xkk0);
end
fprintf(fd,...
'\n Prad poczatkowy zwarcia 3-fazowego     Ik = %9.4g kA',Ik');
fprintf(fd,...
'\n MOC ZWARCIOWA zwarcia   3-fazowego     Sk = %9.1f MVA',Sk');
Ik2=c*Unk/abs(2*Zkk1); if Ik2<1e-3 Ik2=0; end
Iek2e=p3*c*Unk/abs(Zkk1+2*Zkk0); if Iek2e<1e-3 Iek2e=0; end
IBk2ez=c*Unk*(1+a^2+Zkk0/Zkk1)/(Zkk1+2*Zkk0);
IBk2e=abs(IBk2ez); if IBk2e<1e-3 IBk2e=0; end
ICk2ez=c*Unk*(1+a+Zkk0/Zkk1)/(Zkk1+2*Zkk0);
ICk2e=abs(ICk2ez); if ICk2e<1e-3 ICk2e=0; end
Ik1=c*p3*Unk/abs(2*Zkk1+Zkk0); if Ik1<1e-3 Ik1=0; end
Sk1=sqrt(3)*Unk*Ik1;
r0x1=Rkk0/Xkk1; x0x1=Xkk0/Xkk1;
pizol=0; if r0x1> 1e3 | x0x1 >1e3 pizol=1; end
fprintf(fd,...
'\n Zwarcie 2-fazowe                      Ik2 = %9.4g kA',Ik2');
fprintf(fd,...
'\n ------------------------------------------------------');
fprintf(fd,...
'\n Zwarcie 2-fazowe f.B i C do ziemi   Iek2e = %9.4g kA',Iek2e');
fprintf(fd,...
'\n Zwarcie 2-fazowe f.B i C do ziemi   IBk2e = %9.4g kA',IBk2e');
fprintf(fd,...
'\n Zwarcie 2-fazowe f.B i C do ziemi   ICk2e = %9.4g kA',ICk2e');
fprintf(fd,...
'\n ------------------------------------------------------');
    %
fprintf(fd,...
'\n Zwarcie 1-fazowe f.A do ziemi         Ik1 = %9.4g kA',Ik1');
fprintf(fd,...
'\n MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 = %9.1f MVA',Sk1');
fprintf(fd,'\n Warunki skutecznosci uziemienia');
fprintf(fd,...
'\n 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV');
fprintf(fd,...
'\n 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV');
if r0x1>999.
fprintf(fd,...
'\n Warunki skutecznosci uziemienia: R0/X1 = %5s  ',cinf);
else
fprintf(fd,...
'\n Warunki skutecznosci uziemienia: R0/X1 = %5.2f',r0x1);    
end
if Unk == 110 & (r0x1>1)   fprintf(fd,' niespelnione'); end
if Unk  > 110 & (r0x1>0.5) fprintf(fd,' niespelnione'); end
if x0x1>999. fprintf(fd,'PN izolowany'); pizol=1;end
if x0x1>999.
fprintf(fd,'\n                       X0/X1 = %5s  ',cinf);
else
fprintf(fd,'\n                       X0/X1 = %5.2f',x0x1);    
end
if Unk == 110 & (x0x1<1 | x0x1>3)
 fprintf(fd,' niespelnione'); end
if Unk  > 110 & (x0x1<1 | x0x1>2)
 fprintf(fd,' niespelnione'); end
if x0x1>1e5 fprintf(fd,'PN izolowany'); pizol=1;end
fprintf(fd,...
'\n ------------------------------------------------------');
% sem Thevenina rowna sem fazowej zrodla zastepczego
zw=0; % przed zwarciem
    E = c*Unk/sqrt(3);
    UABC=[E; a^2*E; a*E];
    UA=UABC(1); UB=UABC(2); UC=UABC(3);
    mUA=abs(UA); kUA=angle(UA); kUAst=kUA*180/pi;
    wUA=num2str(mUA,4);
    mUB=abs(UB); kUB=angle(UB); kUBst=kUB*180/pi;
    wUB=num2str(mUB,4);
    mUC=abs(UC); kUC=angle(UC); kUCst=kUC*180/pi;
    wUC=num2str(mUC,4);
    if wykresy
     napABC =[' UA=' wUA 'kV, ' 'UB=' wUB 'kV, ' 'UC=' wUC 'kV'];
     opisUABC=napABC; 
     tytul=['Nap. fazowe przed zwarciem:' opisUABC];
     compass(UA,'k-'); hold on; compass(UB,'r--'); compass(UC,'b-.');
     legend('UA','UB','UC'); title(tytul); 
     saveas(gcf,['UABC_',int2str(zw)],'emf'); pause(2); close;
    end % if wykresy
    % impedancje w ukladzie 012
    Z0=Zkk0; Z1=Zkk1; Z2=Z1;
    nap012= ' U0,U1,U2, kV';       nap=' UA,UB,UC, kV';
    prad012=' I0,I1,I2, kA';      prad=' IA,IB,IC, kA';
    zw1fz='Zwarcie 1fz - faza A do ziemi: ';
    zw2f ='Zwarcie 2f  - faza B z C: ';
    zw2fz='Zwarcie 2fz - faza B i C z ziemia: ';
fprintf(fd,...
 '\nAnaliza pradow i napiec w ukladzie 012 oraz ABC');
zw=0;
while zw<3 % po zwarciu
 zw=zw+1; I1=[]; I2=[]; I0=[]; U0=[]; U1=[]; U2=[];
 if zw == 1
  % zwarcie 1-fazowe w ukladzie 012
   I1=E/(Z1+Z2+Z0); I2=I1;     I0=I1; % prady 012
   U1=E-Z1*I1;  U2=-Z2*I2; U0=-Z0*I0; % napiecia 012
 end % zw==1
 if zw == 2
  % zwarcie 2-fazowe w ukladzie 012
   I1=E/(Z1+Z2); I2=-I1;    I0=0;
   U1=E-Z1*I1;   U2=-Z2*I2; U0=-Z0*I0;
 end % zw==2
 if zw == 3
  % zwarcie 2-fazowe  z ziemia w ukladzie 012
    Z=Z1+Z2*Z0/(Z2+Z0);
    I1=E/Z;
    I2=-Z0*I1/(Z2+Z0); I0=-I1-I2;
    U1=E-Z1*I1; U2=-Z2*I2; U0=-Z0*I0;    % napiecia 012
 end % zw==3
 if abs(I0)<1e-5 I0=0; end
 if abs(I1)<1e-5 I1=0; end
 if abs(I2)<1e-5 I2=0; end
  I012=[I0; I1; I2]; 
 if abs(U0)<1e-5 U0=0; end
 if abs(U1)<1e-5 U1=0; end
 if abs(U2)<1e-5 U2=0; end 
  U012=[U0; U1; U2];
 IABC=invS*I012;        UABC=invS*U012;
 % skl. symetryczne 012 
 mI1=abs(I1); kI1=angle(I1); kI1st=kI1*180/pi;
 if mI1<1e-8 mI1=0; I1=0; end
 wI1=num2str(mI1,4);
 mI2=abs(I2); kI2=angle(I2); kI2st=kI2*180/pi; 
 if mI2<1e-8 mI2=0; I2=0; end
 wI2=num2str(mI2,4);
 mI0=abs(I0); kI0=angle(I0); kI0st=kI0*180/pi;
 if mI0<1e-8 mI0=0; I0=0; end
 wI0=num2str(mI0,4);
 mU1=abs(U1); kU1=angle(U1); kU1st=kU1*180/pi;
 if mU1<1e-8 mU1=0; U1=0; end
 wU1=num2str(mU1,4);
 mU2=abs(U2); kU2=angle(U2); kU2st=kU2*180/pi;
 if mU2<1e-8 mU2=0; U2=0; end
 wU2=num2str(mU2,4);
 mU0=abs(U0); kU0=angle(U0); kU0st=kU0*180/pi;
 if mU0<1e-8 mU0=0; U0=0; end
 wU0=num2str(mU0,4);
 %WIELKOSCI FAZOWE               
  IA=IABC(1); IB=IABC(2); IC=IABC(3);
  UA=UABC(1); UB=UABC(2); UC=UABC(3);
  mIA=abs(IA); kIA=angle(IA); kIAst=kIA*180/pi;
  if mIA<1e-8 mIA=0; IA=0; end 
  wIA=num2str(mIA,4);
  mIB=abs(IB); kIB=angle(IB); kIBst=kIB*180/pi;
  if mIB<1e-8 mIB=0; IB=0; end 
  wIB=num2str(mIB,4);
  mIC=abs(IC); kIC=angle(IC); kICst=kIC*180/pi;
  if mIC<1e-8 mIC=0; IC=0; end 
  wIC=num2str(mIC,4);
  mUA=abs(UA); kUA=angle(UA); kUAst=kUA*180/pi;
  if mUA<1e-8 mUA=0; UA=0; end 
  wUA=num2str(mUA,4);
  mUB=abs(UB); kUB=angle(UB); kUBst=kUB*180/pi;
  if mUB<1e-8 mUB=0; UB=0; end 
  wUB=num2str(mUB,4);
  mUC=abs(UC); kUC=angle(UC); kUCst=kUC*180/pi;
  if mUC<1e-8 mUC=0; UC=0; end 
  wUC=num2str(mUC,4);
  % ukl. 012 -> ABC
  I012=[I0; I1; I2];     U012=[U0; U1; U2];
  IABC=invS*I012;        UABC=invS*U012;
  nap012 =['U1=' wU1 'kV, ' 'U2=' wU2 'kV, ' 'U0=' wU0 'kV'];
  napABC =['UA=' wUA 'kV, ' 'UB=' wUB 'kV, ' 'UC=' wUC 'kV'];
  prad012=['I1=' wI1 'kA, ' 'I2=' wI2 'kA, ' 'I0=' wI0 'kA'];
  pradABC=['IA=' wIA 'kA, ' 'IB=' wIB 'kA, ' 'IC=' wIC 'kA'];
  opis1='ZWARCIE 1-fazowe';
  opis2='ZWARCIE 2-fazowe';
  opis3='ZWARCIE 2-fazowe z ziemia';  opis=[];
  if zw == 1 opis=opis1; end
  if zw == 2 opis=opis2; end
  if zw == 3 opis=opis3; end
  if wykresy
    opisU012=[]; opisUABC=[];   opisUABCo=[];
    opisI012=[]; opisIABC=[];
    if zw == 1
        opisU012=[zw1fz nap012];  opisI012=[zw1fz prad012];
        opisUABC=[zw1fz napABC];  opisIABC=[zw1fz pradABC];
    end
    if zw == 2
        opisU012=[zw2f nap012];  opisI012=[zw2f prad012];
        opisUABC=[zw2f napABC];  opisIABC=[zw2f pradABC];
    end
    if zw == 3
        opisU012=[zw2fz nap012];  opisI012=[zw2fz prad012];
        opisUABC=[zw2fz napABC];  opisIABC=[zw2fz pradABC];
    end
    %wykresy wektorow pradow
    compass(I1,'k-'); hold on;
    compass(I2,'r--'); compass(I0,'b-.');
    legend('I1','I2','I0');    
    title(opisI012);
    saveas(gcf,['I012_',int2str(zw)],'emf'); pause(2);close;
    if mIA>mIB
    compass(IA,'k-'); hold on;
    compass(IB,'r--'); compass(IC,'b-.');
    legend('IA','IB','IC');    
    else
    compass(IB,'k-'); hold on;
    compass(IC,'r--'); compass(IA,'b-.');
    legend('IB','IC','IA');    
    end
    title(opisIABC);
    saveas(gcf,['IABC_',int2str(zw)],'emf'); pause(2);close;
    % wykresy wektorow napiec
    compass(U1,'k-'); hold on;
    compass(U2,'r--'); compass(U0,'b-.');
    legend('U1','U2','U0');    
    title(opisU012); 
    saveas(gcf,['U012_',int2str(zw)],'emf'); pause(2);close;
    if mUA>mUB
    compass(UA,'k-'); hold on;
    compass(UB,'r--'); compass(UC,'b-.');
    legend('UA','UB','UC');    
    else
    compass(UB,'k-'); hold on;
    compass(UC,'r--'); compass(UA,'b-.');
    legend('UB','UC','UA');    
    end
    title(opisUABC); 
    saveas(gcf,['UABC_',int2str(zw)],'emf'); pause(2);close;
  end % if wykresy
       fprintf(fd,...
'\n ------------------------------------------------------');
   fprintf(fd,'\n *** %s *** ',opis);
   fprintf(fd,...
'\n ------------------------------------------------------');
   fprintf(fd,'\nPrady - uklad 012');
   if mI0<1e-3 mI0=0; end
   if mI1<1e-3 mI1=0; end
   if mI1<1e-3 mI2=0; end
   fprintf(fd,...
'\nModuly: mI1=%7.3g kA, mI2=%7.3g kA, mI0=%7.3g kA',...
     mI1,  mI2,  mI0);
   fprintf(fd,...
'\nKaty:   kI1=%7.1f st, kI2=%7.1f st, kI0=%7.1f st',...
     kI1st,kI2st,kI0st);
   fprintf(fd,'\nNapiecia - uklad 012');
   if mU0<1e-3 mU0=0; end
   if mU1<1e-3 mU1=0; end
   if mU2<1e-3 mU2=0; end
   fprintf(fd,...
'\nModuly: mU1=%7.3g kV, mU2=%7.3g kV, mU0=%7.3g kV',...
     mU1,  mU2,  mU0);   fprintf(fd,...
'\nKaty:   kU1=%7.1f st, kU2=%7.1f st, kU0=%7.1f st',...
     kU1st,kU2st,kU0st);
   fprintf(fd,'\nPrady - uklad ABC');
   if mIA<1e-3 mIA=0; end
   if mIB<1e-3 mIB=0; end
   if mIC<1e-3 mIC=0; end
   if mIA>mIB & mIA> mIC 
   fprintf(fd,...
'\nModuly: mIA=%7.3g kA, mIB=%7.3g kA, mIC=%7.3g kA',...
     mIA,  mIB,  mIC);
   fprintf(fd,...
'\nKaty:   kIA=%7.1f st, kIB=%7.1f st, kIC=%7.1f st',...
     kIAst,kIBst,kICst);
   else
   fprintf(fd,...
'\nModuly: mIB=%7.3g kA, mIC=%7.3g kA, mIA=%7.3g kA',...
     mIB,  mIC,  mIA);
   fprintf(fd,...
'\nKaty:   kIA=%7.1f st, kIB=%7.1f st, kIC=%7.1f st',...
     kIAst,kIBst,kICst);
   end
   fprintf(fd,'\nNapiecia - uklad ABC');
   if mUA<1e-3 mUA=0; end
   if mUB<1e-3 mUB=0; end
   if mUC<1e-3 mUC=0; end
   fprintf(fd,...
'\nModuly: mUA=%7.3g kV, mUB=%7.3g kV, mUC=%7.3g kV',...
     mUA,  mUB,  mUC);
   fprintf(fd,...
'\nKaty:   kUA=%7.1f st, kUB=%7.1f st, kUC=%7.1f st',...
     kUAst,kUBst,kUCst);
end %while zw<=3
end %if drukIz
if wykresy fclose(fd); end
end %koniec az2Izns()
 