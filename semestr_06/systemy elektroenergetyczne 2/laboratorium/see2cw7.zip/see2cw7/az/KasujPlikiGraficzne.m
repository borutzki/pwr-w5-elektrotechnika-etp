function KasujPlikiGraficzne
fprintf('\n\n Kasowanie plikow *.emf?');
fprintf('\n 1- TAK, 0 - NIE');
fprintf('\n... podaj: 1 lub 0 \n');
emf=input(' ');
if emf
delete *.emf
fprintf('\n\n ... skasowano wszystkie pliki graficzne *.emf ...');
fprintf('\n ... w katalogu: %s ...\n\n',pwd);
end
end


