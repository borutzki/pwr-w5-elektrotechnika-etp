function [c,ZSEEk,ZGk,ZMk,Unk,psi,tz]=dataz2izw_cw7
% dane do wyznaczanie pradow zwarciowych met. niezaleznych zrodel
% SEE + G + M
j=sqrt(-1);
ZSEEk=0.01892+j*0.400329;   % om - impedancja pol. z systemem
ZGk = 0.117+j*1.672;  % om - imp. pol. z generatorem synchr.
ZMk = 6.8442+j*16.7049; % om - imp. pol. z silnikiem ind.
Unk = 10; % kV - napiecie znamionowe sieci w miejscu zwarcia
psi = 90; % stopnie - kat poczatkowy sem Thevenina
tz = 0.1; % s - czas trwania zwarcia
c  = 1.1; % prad zwarciowy maksymalny
end


