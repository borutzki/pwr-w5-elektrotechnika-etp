function [Sng,Ung,Usee,xdp,Xgs,Tm,P,Q]=gseeDAT;
  % dane do kryterium rownych pol
  Sng=11.51; %MVA
  Ung=10.5; %kV
  Usee=10; %kV na poziomie nap. 10 kV
  xdp=0.2451;
  Xgs=0.2814; %oreaktancja pol. GS z SEE, hm na pzoiomie nap. 10 kV
  P=8; %MW
  Q=6; %Mvar
  Tm=8.51; %s
  return
  
    