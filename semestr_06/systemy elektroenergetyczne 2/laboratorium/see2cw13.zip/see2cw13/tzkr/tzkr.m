function tzkr
% kryterium rownych pol
wdold=cd; winf=1e8;
[fname,sciezka]=uigetfile('gseeDAT*.m',...
  'Wybierz plik danych zgodny z wymaganiami programu ogran.m - domyslnie gseedat*.m');
eval(['cd(''',sciezka,''')']);
% czytanie pliku w formacie cwiczenia
zwdat=strtok(fname,'.');
% czytanie danych z pliku zwdat
[Sng,Ung,Usee,xdp,Xgs,Tm,P,Q]=feval(zwdat);
Uns=Usee;
%
fd = fopen('tzkrOUT.m','wt');
%Przeliczenie na jednostki wzgledne
Zb=Ung^2/Sng;
Us=Usee/Ung;
Xgs=Xgs/Zb;
P=P/Sng; Q=Q/Sng;
Pg=P;
%
% ANALIZA DLA 2 zmiennych stanu x = [d w] 
% d - przyrost kata wirnika  w - predkosc katowa wirnika
% poczatek analizy
X=Xgs + xdp; R=0;
Pm=Pg;
Ua=(P*R+Q*X)/Us;
Ub=(P*X-Q*R)/Us;
Eprim=sqrt( (Us+Ua)^2+Ub^2);
Pm=Pg;
sind=Pm*X/(Eprim*Us);
d0=asin(sind); % kat wirnika w stanie ustalonym wynikajacy z Pm = Pe
d0st=d0*180/pi;
%
K1=Eprim*Us/X*cos(d0);
Ped = K1;
ws=100*pi; % predkosc katowa synchroniczna
wm=sqrt(K1*ws/Tm); % pulsacja wlasnych kolysan wirnika
fm=wm/2/pi; % czestotliwosc wlasnych klysan wirnika
%
Dpu=0; % wspolczynnik tlumienia kolysan wirnika
psi=Dpu/2/wm/Tm; % standadryzowany wspolczynnik tlumienia kolysan
fprintf(fd,'\n Parametry wejsciowe ukladu; GENERATOR - SYSTEM');
fprintf(fd,'\n   Sng = %8.2f MVA',Sng);
fprintf(fd,'\n   Ung = %8.2f kV',Ung);
fprintf(fd,'\n   Uns = %8.2f kV',Uns);
fprintf(fd,'\n   xdp = %8.4f pu',xdp);
fprintf(fd,'\n Eprim = %8.4f pu',Eprim);
fprintf(fd,'\n    Us = %8.4f pu',Us);
fprintf(fd,'\n   Xgs = %8.4f pu',Xgs);
fprintf(fd,'\n    Pm = %8.4f pu',Pm); 
fprintf(fd,'\n    Tm = %8.2f s ',Tm);
fprintf(fd,'\n   Dpu = %8.2f pu',Dpu);
fprintf(    '\n Parametry wejsciowe ukladu; GENERATOR - SYSTEM');
fprintf(    '\n   Sng = %8.2f MVA',Sng);
fprintf(    '\n   Ung = %8.2f kV',Ung);
fprintf(    '\n   Uns = %8.2f kV',Uns);
fprintf(    '\n   xdp = %8.2f pu',xdp);
fprintf(    '\n Eprim = %8.4f pu',Eprim);
fprintf(    '\n    Us = %8.4f pu',Us);
fprintf(    '\n   Xgs = %8.4f pu',Xgs);
fprintf(    '\n    Pm = %8.4f pu',Pm); 
fprintf(    '\n    Tm = %8.2f s ',Tm);
fprintf(    '\n   Dpu = %8.2f pu',Dpu);

fprintf(fd,'\n Wyniki analizy kolysan wirnika GENERATORA');
d0st=d0*180/pi;
fprintf(fd,'\n Kat poczatkowy wirnika          d0 = %8.2f st',d0st);
fprintf(fd,'\n Moc synchronizujaca             K1 = %8.4f pu',K1);
fprintf(fd,'\n Pulsacja kolysan wirnika        wm = %8.2f rad/s',wm);
fprintf(fd,'\n Czestotliwosc kolysan wirnika   fm = %8.2f Hz',fm);
fprintf(fd,'\n Wspolczynnik tlumienia kolysan psi = %8.4f pu',psi);

fprintf(    '\n Wyniki analizy kolysan wirnika GENERATORA');
fprintf(    '\n Kat poczatkowy wirnika          d0 = %8.2f st',d0st);
fprintf(    '\n Moc synchronizujaca             K1 = %8.4f pu',K1);
fprintf(    '\n Pulsacja kolysan wirnika        wm = %8.2f rad/s',wm);
fprintf(    '\n Czestotliwosc kolysan wirnika   fm = %8.2f Hz',fm);
fprintf(    '\n Wspolczynnik tlumienia kolysan psi = %8.4f pu',psi);
%
%
X=Xgs+xdp;
Pmax=Eprim*Us/X;
kp=(Pmax-Pm)/Pmax; kpprocent=kp*100;
PmaxMW=Pmax*Sng;
PmMW=Pm*Sng;
%
%dane
fprintf(fd,'\n ------------- rownowaga statyczna -----------------------');
fprintf(fd,'\n Kat wirnika  dla Pe = Pm:                d0 = %8.4f rad  = %8.1f st',d0,d0st);
fprintf(fd,'\n Moc mechaniczna constans:                Pm = %8.2f MW',PmMW);
fprintf(fd,'\n Moc elektryczna maksymalna:            Pmax = %8.2f MW',PmaxMW);
fprintf(fd,'\n Wspolczynnik zapasu rownowagi:           kp = %8.2f  %',kpprocent);
fprintf(fd,'\n =========================================================\n');
%
fprintf(   '\n ------------- rownowaga statyczna -----------------------');
fprintf(   '\n Kat wirnika  dla Pe = Pm:                d0 = %8.4f rad  = %8.1f st',d0,d0st);
fprintf(   '\n Moc mechaniczna constans:                Pm = %8.2f MW',PmMW);
fprintf(   '\n Moc elektryczna maksymalna:            Pmax = %8.2f MW',PmaxMW);
fprintf(   '\n Wspolczynnik zapasu rownowagi:           kp = %8.2f  %',kpprocent);
fprintf(   '\n =========================================================\n');

%
%Pe=Eprim*Us/X*sind
%sind=Pm*X/(Eprim*Us);
cosd1=cos(pi-d0)-2*d0*sind+pi*sind;
d1=acos(cosd1); d1st=d1*180/pi;
%
tz=sqrt(2*(d1-d0)*Tm/(100*pi*Pm) );
%
fprintf(fd,'\n ------------- rownowaga dynamiczna -----------------------');
fprintf(fd,'\n Kat wirnika przed zwarciem:              d0 = %8.4f rad  =  %8.1f st',d0, d0st);
fprintf(fd,'\n Kat graniczny wirnika po zwarciu:        d1 = %8.4f rad  =  %8.1 st',d1, d1st);
fprintf(fd,'\n KRYTYCZNY CZAS TRWANIA ZWARCIA:        tzkr = %8.3f  s',tz);
fprintf(fd,'\n =========================================================\n');
%
fprintf(   '\n ------------- rownowaga dynamiczna -----------------------');
fprintf(   '\n Kat wirnika przed zwarciem:              d0 = %8.4f rad  =  %8.1f st',d0, d0st);
fprintf(   '\n Kat graniczny wirnika po zwarciu:        d1 = %8.4f rad  =  %8.1 st',d1, d1st);
fprintf(   '\n KRYTYCZNY CZAS TRWANIA ZWARCIA:        tzkr = %8.3f  s',tz);
fprintf(   '\n =========================================================\n');
%
% wykres

dk=0:0.01:pi;
[ndk,mdk]=size(dk);
dkst=dk*(180/pi);
Pdk=Eprim*Us/X*sin(dk);
PdkMW=Pdk*Sng;
%ndk
%mdk
ddk0=(d1st-d0st)/10;
dgrst=180-d0st;
ddk1=(dgrst-d1st)/10;
for i=1:mdk
    Pdk0MW(i)=Pm*Sng;
    xdk0(i)=d0st; ype0(i)=1/mdk*i*PmMW;
    xdk01(i)=d0st+ddk0;   ype01(i)=1/mdk*i*PmMW;
    xdk02(i)=d0st+ddk0*2; ype02(i)=1/mdk*i*PmMW;
    xdk03(i)=d0st+ddk0*3; ype03(i)=1/mdk*i*PmMW;
    xdk04(i)=d0st+ddk0*4; ype04(i)=1/mdk*i*PmMW;
    xdk05(i)=d0st+ddk0*5; ype05(i)=1/mdk*i*PmMW;
    xdk06(i)=d0st+ddk0*6; ype06(i)=1/mdk*i*PmMW;
    xdk07(i)=d0st+ddk0*7; ype07(i)=1/mdk*i*PmMW;
    xdk08(i)=d0st+ddk0*8; ype08(i)=1/mdk*i*PmMW;
    xdk09(i)=d0st+ddk0*9; ype09(i)=1/mdk*i*PmMW;
    xdk1(i)=d1st; ype1(i)=1/mdk*i*PmaxMW;

end

plot(dkst,PdkMW,'r-',dkst,Pdk0MW,'r-',xdk0,ype0,'b-',xdk1,ype1,'g-');
hold on;
plot(xdk01,ype01,'g-',xdk02,ype02,'g-',xdk03,ype03,'g-',xdk04,ype04,'g-');
plot(xdk05,ype05,'g-',xdk06,ype06,'g-',xdk07,ype07,'g-',xdk08,ype08,'g-');
plot(xdk09,ype09,'g-');
text(d0st+ddk0,PmMW/2,'PRZYSPIESZANIE');
text(d1st+ddk1,PmMW*1.2,'HAMOWANIE');
xlabel(' kat[st]'); ylabel(' P[MW]');
title('Kryterium r�wnych pol - krytyczny czas zwarcia');
disp('Dalej? ENTER');pause;
close;
%
fclose('all');
return

