
 Parametry wejsciowe ukladu; GENERATOR - SYSTEM
   Sng =    11.51 MVA
   Ung =    10.50 kV
   Uns =    10.00 kV
   xdp =   0.2451 pu
 Eprim =   0.6625 pu
    Us =   0.9524 pu
   Xgs =   0.0727 pu
    Pm =   0.0000 pu
    Tm =     8.51 s 
   Dpu =     0.00 pu
 Wyniki analizy kolysan wirnika GENERATORA
 Kat poczatkowy wirnika          d0 =     0.00 st
 Moc synchronizujaca             K1 =   1.9852 pu
 Pulsacja kolysan wirnika        wm =     8.56 rad/s
 Czestotliwosc kolysan wirnika   fm =     1.36 Hz
 Wspolczynnik tlumienia kolysan psi =   0.0000 pu
 ------------- rownowaga statyczna -----------------------
 Kat wirnika  dla Pe = Pm:                d0 =   0.0000 rad  =      0.0 st
 Moc mechaniczna constans:                Pm =     0.00 MW
 Moc elektryczna maksymalna:            Pmax =    22.85 MW
 Wspolczynnik zapasu rownowagi:           kp =   100.00  
 =========================================================

 ------------- rownowaga dynamiczna -----------------------
 Kat wirnika przed zwarciem:              d0 =   0.0000 rad  =       0.0 st
 Kat graniczny wirnika po zwarciu:        d1 =   3.1416 rad  =  
 KRYTYCZNY CZAS TRWANIA ZWARCIA:        tzkr =      Inf  s
 =========================================================
