function [par,poluzw]=tr3uzw
% dane transformatora 2-uzwojeniowego
Sn=16; %MVA - moc znamionowa
UnG=115; %kV - nap. znamionowe g�rne
UnS=22; %kV - nap. znamionowe srodkowe
UnD=11; % kV - nap. znamionowe dolne
p=10; % % - zmiany nap. po stronie UnG w -/+% wskutek regulacji przekladni
streg=12; % - liczba stopni regulacyjnych +/-
UnGs = 110; % - nap. znamionowe sieciowe g�rne
UnDs =20; % kV -nap. znamionowe sieciowe srodkowe; 
UnSs =10; % kV -nap. znamionowe sieciowe dolne; 
PcuGS=0.04874; % MW - straty obciazeniowe G-S (gora - srodek)
PcuGD=0.049435; % MW - straty obciazeniowe G-D (gora - dol)
PcuSD=0.04888; % MW - straty obciazeniowe S-D (srodek - dol)
ukGS=11.51; % - napiecie zwarcia G-S (gora - srodek) w procentach
ukGD=18.67; % - napiecie zwarcia G-D (gora - dol) w procentach
ukSD=6.3; % - napiecie zwarcia S-D (srodek - dol) w procentach
Pfe=0.01929; % MW - straty w zelazie
Io=0.5; % - prad jalowy w %
% XomiXT - pomija sie w obliczeniach zwarciowych;
% Polaczenia uzwojen wg kolejnosci:
% poczatek               koniec
% G - gorne nap.    S - srodkowe nap.    D - dolne nap.
%  G-S-D:
% YN-d-yn
polG='YN'; polS='d';  polD='yn'; YN_d_yn=[polG '-' polS '-' polD];
%poluzw=YN_d_yn;
% YN-d-y
polG='YN'; polS='d';  polD='y';  YN_d_y =[polG '-' polS '-' polD];
%poluzw=YN_d_y;
% YN-d-d
polG='YN'; polS='d';  polD='d';  YN_d_d =[polG '-' polS '-' polD];
poluzw=YN_d_d;
% par, poluzw - parametry wyjsciowe
%    1   2   3   4  5   6    7    8    9    10     11    12   13   14   15  16  17   
par=[Sn UnG UnD UnS p streg UnGs UnDs UnSs PcuGD PcuGS PcuSD ukGD ukGS ukSD Pfe Io];
% poluzw - polaczen uzwojen
return