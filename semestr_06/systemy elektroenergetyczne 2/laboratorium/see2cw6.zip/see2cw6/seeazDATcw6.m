function [see,UNSobl,winf] = seeazDATtest
%UNSobl - nap. znam. sieci wybrane na nap. obliczeniowe
%UNQ - kV, napiecie znam. systemu zewnetrznego SEE
%SkQ - MVA, moc zwarciowa systemu zewnetrznego SEE
%c - wsp. obl. zwarciowych
%R0X1, X0X1 - wsp. skut. uziemienia PN dla systemu SEE
%tN - przekladnia transf.:siec UNSobl -> system zewnetrzny
%tN=tN1*tN2*... - sieci promieniowe
%tN=UNSobl/UNQ  - tylko sieci oczkowe
UNSobl=10.0; %kV
winf=1e8; % nieskonczonosc
see={
%SiecZasil    wezel   UnQ   SkQ   c  R0X1 X0X1  tn
%12s          12s      kV   MVA   -     -    -   -
'SEE2'  'WezSEE2'     110  2010 1.1   0.0  1.0 11/115
};
end % koniec seeazDAT

