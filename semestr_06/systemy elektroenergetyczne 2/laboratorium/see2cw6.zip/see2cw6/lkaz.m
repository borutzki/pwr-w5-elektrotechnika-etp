function lkaz
% parametry zastepcze zwarciowe linii nap. lub kabowej
j=sqrt(-1);
 sciezka0=pwd; cd([sciezka0 '\Dane']); sciezka1=pwd;
 plikWe= strcat([sciezka1 '\slin_lk.m']);
 fd=fopen(plikWe,'wt');  % plik z przeczytanymi danymi do obliczen
 cd ..
fprintf(fd,'\n%%PARAMETRY ZASTEPCZE ZWARCIOWE LINII ');
% czytanie danych z m-pliku
cdold=cd;
[plik,sciezka]=...
uigetfile('lkazDAT*.m','Wybierz plik z danymi linii');
fprintf('\n... wybrano: %s%s.m',sciezka,plik);
eval(['cd(''',sciezka,''')']); dane=strtok(plik,'.');
[slin,UNSobl,winf] = eval(dane);
eval(['cd(''',cdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
sp12='123456789012';       % ustala dlugosc maksymalna nazwy na 12 znakow
[nl,n]=size(slin);
if nl
   nazlin=strvcat( sp12,char(slin(:,1)));
   nazlin=nazlin(2:end,:);  
   nazwp =strvcat( sp12,char(slin(:,2))); 
   nazwp=nazwp(2:end,:);
   nazwk =strvcat( sp12,char(slin(:,3)));
   nazwk=nazwk(2:end,:); 
   linie=[cell2mat(slin(:,4:end)) ];
else    % brak linii
   nazlin=[]; linie=[];
end %if nl
if ~isempty(linie)
fprintf(fd,'\n%%Par. zast. zwarciowe nap. znam. linii UNS');
fprintf(fd,...
'\n%%UNSobl - nap. znam. sieci wybrane na nap. obliczeniowe');
fprintf(fd,'\n%%tN - przekl. transf.: siec UNSobl -> linia UNS');
fprintf(fd,'\n%%tN=tN1*tN2*... - siec promieniowa');
fprintf(fd,'\n%%tN=UNSobl/UNS -  tylko siec oczkowa');
fprintf(fd,'\nUNSobl=%g; %%kV - nap. obliczeniowe ',UNSobl);
fprintf(fd,'\nwinf=%.0e; %% nieskonczonosc ',winf);
fprintf(fd,'\n slin={');
fprintf(fd,...
'\n%%linia       Od         Do        ');
fprintf(fd,'UNS     R1     X1     R0     X0   tN');
fprintf(fd,...
 '\n%%max12s     max12s     max12s     ');
fprintf(fd,'kV     om     om     om     om   -');
 for i=1:nl
  UNS=linie(i,1);
  r=linie(i,2); x=linie(i,3); L=linie(i,4);
  R0R1=linie(i,5); X0X1=linie(i,6); tn=linie(i,7);
  R1=r*L; X1=x*L; R0=R1*R0R1; X0=X1*X0X1;
  naz1=nazlin(i,:); naz2=nazwp(i,:); naz3=nazwk(i,:);
  naz1=deblank(naz1); naz2=deblank(naz2); naz3=deblank(naz3);
  fprintf(fd,...
 '\n''%-8s'' ''%-8s'' ''%-8s'' ',naz1,naz2,naz3);
 fprintf(fd,...
 '%3.3g %6.3g %6.4g %6.3g %6.3g %6.5g',...
 UNS,R1,X1,R0,X0,tn);
 end %for i=1:nl
   fprintf(fd,'\n };');
 else
     fprintf(fd,'\n%% brak linii napowietrznych lub kablowych!');
end % ~isempty(linie)
fclose(fd);
fprintf('\n\n ... slin{} zapisano w lkazOUT.m');
end % koniec lkaz()
