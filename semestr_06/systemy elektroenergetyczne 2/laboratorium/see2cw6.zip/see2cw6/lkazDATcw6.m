function [slin,UNSobl,winf] = lkazDATcw6
% Dane do obl. par. zast. zwarciowych linii nap. kablowych
% UNSobl - nap. znam. sieci wybrane na nap. obliczeniowe
% UNS - nap. znam. sieci, do ktorej jest przylaczona linia
%tN - przekladnia transf.: siec UNSob -> linia UNS
%tN=tN1*tN2*... - sieci promieniowe
%tN=UNSobl/UNS  - tylko sieci oczkowe
% r, rezystancja jednostkowa om/km
% x, reaktancja jednostkowa om/km
% L, km dlugosc linii
% R0R1 = R0/R1, jesli nieznane, to R0R1=1.00+0.15/r
% X0X1 = X0/X1, jesli nieznane, to X0/X1= 2.5
% X0/X1= 1 dla kabli 1-zylowych
UNSobl=10; % kV 
winf=1e+08; % nieskonczonosc 
slin={
%Linia  Od        Do     UNS    r      x      L R0R1  X0X1  tn
%max12s max12s    max12s  kV  om/km  om/km   km  -     -    -
 'L'   'GPZ10kV' 'odczep' 10  0.44   0.370  2.51 1.341  3.5   1.0 
 'K'   'odczep'  'RO'     10  0.255  0.122  1.51 1.0   1.0   1.0 
};
end % koniec lkazDAT
