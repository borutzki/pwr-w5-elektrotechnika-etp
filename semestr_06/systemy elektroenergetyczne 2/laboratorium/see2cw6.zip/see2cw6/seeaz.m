function seeaz
% parametry zastepcze zwarciowe systemu zewnetrznego
j=sqrt(-1);
 sciezka0=pwd; cd([sciezka0 '\Dane']); sciezka1=pwd;
 plikWe= strcat([sciezka1 '\sgen_see.m']);
 fd=fopen(plikWe,'wt');  % plik z przeczytanymi danymi do obliczen
 cd ..
fprintf(fd,'\n%%PARAMETRY ZASTEPCZE ZWARCIOWE SYSTEMU ZEWNETRZNEGO');
% czytanie danych z m-pliku
cdold=cd;
[plik,sciezka]=...
    uigetfile('seeazDAT*.m','Wybierz plik z danymi zewnetrznego SEE');
fprintf('\n... wybrano: %s%s.m',sciezka,plik);
eval(['cd(''',sciezka,''')']); dane=strtok(plik,'.');
[see,UNSobl,winf] = eval(dane);
eval(['cd(''',cdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
sp12='123456789012';       % ustala dlugosc maksymalna nazwy na 12 znakow
[ng,n]=size(see);
if ng
   nazgen =strvcat( sp12,char(see(:,1)));  nazgen=nazgen(2:end,:);  
   nazwgs =strvcat( sp12,char(see(:,2)));  nazwgs=nazwgs(2:end,:);
   gen=[cell2mat(see(:,3:end)) ];   % end
else    % brak gen
   nazgen=[]; gen=[];
end %if nl
if ~isempty(gen)
fprintf(fd,'\n%%Par. zast. na nap.znam. SEE, UNS=UNQ');
fprintf(fd,'\n%%UNSobl - nap. znam. obliczeniowe');
fprintf(fd,'\n%%tN - przekl. transf.:siec UNSobl -> siec UNS');
fprintf(fd,'\n%%tN=tN1*tN2*... - siec promieniowa');
fprintf(fd,'\n%%tN=UNSobl/UNS - tylko sieci oczkowe');
fprintf(fd,'\nUNSobl=%4.3g; ',UNSobl);
fprintf(fd,'\nwinf=%.0e; %% nieskonczonosc ',winf);
fprintf(fd,'\nsgen={');
fprintf(fd,...
'\n%%SEE        Od         Do        ');
fprintf(fd,'UNS     R1     X1     R0     X0   tN');
fprintf(fd,...
 '\n%%max12s     max12s     max12s     ');
fprintf(fd,'kV     om     om     om     om   -');
for i=1:ng
  UnQ=gen(i,1); SkQ=gen(i,2); c=gen(i,3);
  R0X1=gen(i,4); X0X1=gen(i,5); tn=gen(i,6);
  ZQ=c*UnQ^2/SkQ;  RQ=0; XQ=ZQ;
  if UnQ<35 XQ=0.995*ZQ; RQ=0.1*XQ; end % dla sieci UnQ<35 kV
  R1=RQ; X1=XQ; R0=R0X1*X1; X0=X0X1*X1;
  naz1=nazgen(i,:); naz2=nazwgs(i,:);
  drukzr(fd,naz1,naz2,UnQ,R1,X1,R0,X0,tn,winf);
 end
   fprintf(fd,'\n };');
else
     fprintf(fd,'\n%% brak zewnetrznych SEE!');
end % ~isempty(gen)
fclose(fd);
fprintf('\n\n sgen{} zapisano w seeazOUT.m');
end % koniec seeaz()
 