function [Sn,UnP,UnK,p,streg,UnPs,UnKs,Pcu,uk,Pfe,Io,poluzw,XomiXT]=tr2uzwdat
% dane transformatora 2-uzwojeniowego
Sn=10; %MVA - moc znamionowa
UnP=115; %kV - nap. znamionowe transformatora g�rne
UnK=22; %kV - nap. znamionowe transformatora dolne
p=10; % % - zmiany nap. po stronie UnH w -/+% wskutek regulacji przekladni
streg=8; % - liczba stopni regulacyjnych +/-
UnPs = 110; % - nap. znamionowe sieciowe g�rne
UnKs =20; % kV -nap. znamionowe sieciowe dolne; 
Pcu=0.0791; % MW - straty obciazeniowe 
uk=11.5; % - napiecie zwarcia w %
Pfe=0.0129; % MW - straty w zelazie
Io=0.77; % - prad jalowy w %
XomiXT=5;
% Polaczenia uzwojen wg kolejnosci:
% P - poczatek           K - koniec
YNyn='YNyn';YNd='YNd'; YNy='YNy'; Yy='Yy'; % - polaczenia uzwojen P-K;
            Dyn='Dyn'; Yyn='Yyn';          % - polaczenia uzwojen P-K;
%poluzw='YNyn'; 
%poluzw='YNy'; 
%poluzw='Yyn'; 
%poluzw='Yy'; 
poluzw='YNd';
%poluzw='Dyn';
return