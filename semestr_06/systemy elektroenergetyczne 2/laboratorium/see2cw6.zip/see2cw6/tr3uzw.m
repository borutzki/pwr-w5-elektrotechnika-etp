function tr3uzw
% paramtery zastepcze transf. 3-uzw. z reg. przekladni
fd=fopen('tr3uzwOUT.m','wt');
fprintf(fd,'\n====================================================================');
fprintf(fd,'\n partransf() - OBLICZANIE PARAMETROW TRANSFORMATORA 3-uzwojeniowego ');
fprintf(fd,'\n Data: %5d-%2d-%2d  godz. %2d, %2dmin, %2.0fs',clock);
fprintf(fd,'\n====================================================================\n');
fprintf(   '\n====================================================================');
fprintf(   '\n partransf() - OBLICZANIE PARAMETROW TRANSFORMATORA 3-uzwojeniowego ');
fprintf(   '\n Data: %5d-%2d-%2d  godz. %2d, %2dmin, %2.0fs',clock);
fprintf(   '\n====================================================================\n');
% czytanie danych z m-pliku
cdold=cd;
[plik,sciezka]=uigetfile('tr3uzwdat*.m','Wybierz m-plik z danymi');
eval(['cd(''',sciezka,''')']); dane=strtok(plik,'.');
[par,poluzw]=feval(dane);
fprintf(fd,'Przeczytano dane z m-pliku: %s',dane) ;
eval(['cd(''',cdold,''')']);   % powrot do katalogu z programem
%przeczytane dane
%     1   2   3   4  5   6    7    8    9    10     11    12   13   14   15  16  17   
%par=[Sn UnG UnD UnS p streg UnGs UnDs UnSs PcuGD PcuGS PcuSD ukGD ukGS ukSD Pfe Io];
Sn=par(1); UnG=par(2);  UnD=par(3);  UnS=par(4);
p=par(5); streg=par(6);
          UnGs=par(7); UnDs=par(8); UnSs=par(9);
PcuGD=par(10); PcuGS=par(11); PcuSD=par(12);
ukGD=par(13); ukGS=par(14); ukSD =par(15);
Pfe=par(16);  Io=par(17);
poluzw
% regulacja przekladni przy zadanym napieciu po stronie UnSs
tnGS=UnG/UnS; tnsGS=UnGs/UnSs; t0GS=tnGS/tnsGS;
dtGS=0.01*p/streg; tminGS=t0GS-streg*dtGS; tmaxGS=t0GS+streg*dtGS;
% regulacja przekladni przy zadanym napieciu po stronie UnDs
tnGD=UnG/UnD; tnsGD=UnGs/UnDs; t0GD=tnGD/tnsGD;
dtGD=0.01*p/streg; tminGD=t0GD-streg*dtGD; tmaxGD=t0GD+streg*dtGD;
% napiecie zwarciowe na rezystancji par uzwojen
uRGD=PcuGD/Sn*100; uRGS=PcuGS/Sn*100; uRSD=PcuSD/Sn*100;
%przeliczenie napiec zwarcia z par uzwojen na uzwojenie zastepcze G, S, D
uRGD=PcuGD/Sn*100;          uRGS=PcuGS/Sn*100;          uRSD=PcuSD/Sn*100;
uXGD=sqrt(ukGD^2-uRGD^2);   uXGS=sqrt(ukGS^2-uRGS^2);   uXSD=sqrt(ukSD^2-uRSD^2);
% parametry zastepcze par uzwojen  na strone wyzszego napiecia Un=UnG
Un=UnG; Zn=Un^2/Sn;
RGS=uRGS/100*Zn; XGS=uXGS/100*Zn;       ZGS=RGS+j*XGS;
RGD=uRGD/100*Zn; XGD=uXGD/100*Zn;       ZGD=RGD+j*XGD;
RSD=uRSD/100*Zn; XSD=uXSD/100*Zn;       ZSD=RSD+j*XSD;
%przeliczenie napiec zwarcia z par uzwojen na uzwojenie zastepcze G, S, D
ZG=(ZGS+ZGD-ZSD)/2; RG=real(ZG); XG=imag(ZG);
ZS=(ZGS+ZSD-ZGD)/2; RS=real(ZS); XS=imag(ZS);
ZD=(ZGD+ZSD-ZGS)/2; RD=real(ZD); XD=imag(ZD);
G=Pfe/Un^2*1e6; B=-Io/100/Zn*1e6;
fprintf(fd,'\n\n Dane transformatora 3-uzwojeniowego');
fprintf(fd,'\n Sn=%7.1f MVA; UnG=%8.3f kV,    p=%8.3f%%, streg=%d',Sn,UnG,p,streg);
fprintf(fd,'\n                 UnS=%8.3f kV,  UnD=%8.3f kV',UnS,UnD);
fprintf(fd,'\n                UnGs=%8.3f kV, UnSs=%8.3f kV, UnDs=%8.3f kV',UnGs,UnSs,UnDs);
fprintf(fd,'\n PcuGD=%8.5f MW,  ukGD=%8.2f%%, uRGD=%8.2f%%, uXGD=%8.2f%%',PcuGD,ukGD,uRGD,uXGD);
fprintf(fd,'\n PcuGS=%8.5f MW,  ukGS=%8.2f%%, uRGS=%8.2f%%, uXGS=%8.2f%%',PcuGS,ukGS,uRGS,uXGS);
fprintf(fd,'\n PcuSD=%8.5f MW,  ukSD=%8.2f%%, uRSD=%8.2f%%, uXSD=%8.2f%%',PcuSD,ukSD,uRSD,uXSD);
fprintf(fd,'\n   Pfe=%8.5f MW,    Io=%5.2f%%',Pfe,Io);
fprintf(fd,'\n Rezystancje i reaktancje par uzwojen:');
fprintf(fd,'\n   RGD=%8.5f om,  XGD=%8.2f om',RGD,XGD);
fprintf(fd,'\n   RGS=%8.5f om,  XGS=%8.2f om',RGS,XGS);
fprintf(fd,'\n   RSD=%8.5f om,  XSD=%8.2f om',RSD,XSD);
fprintf(fd,'\n Rezystancje i reaktancje ga��zi gwiazdy:');
fprintf(fd,'\n    RG=%8.5f om,    XG=%8.5f om',RG,XG);
fprintf(fd,'\n    RD=%8.5f om,    XD=%8.5f om',RD,XD);
fprintf(fd,'\n    RS=%8.5f om,    XS=%8.5f om',RS,XS);
fprintf(fd,'\n Konduktancja i susceptancja poprzeczna:');
fprintf(fd,'\n     G=%6.2f mikroS,   B=%6.2f mikroS',G,B);
fprintf(fd,'\n\n Regulacja przekladni pary uzwojen G-S');
fprintf(fd,'\n tnGS=%8.5f, tnsGS=%8.5f',tnGS,tnsGS);
fprintf(fd,'\n t0GS=%8.5f,  dtGS=%8.5f, tminGS=%8.5f, tmaxGS=%8.5f',t0GS,dtGS,tminGS,tmaxGS);
fprintf(fd,'\n Regulacja przekladni pary uzwojen G-D');
fprintf(fd,'\n tnGD=%8.5f, tnsGD=%8.5f',tnGD,tnsGD);
fprintf(fd,'\n t0GD=%8.5f,  dtGD=%8.5f, tminGD=%8.5f, tmaxGD=%8.5f',t0GD,dtGD,tminGD,tmaxGD);


fprintf(   '\n\n Dane transformatora 3-uzwojeniowego');
fprintf(   '\n Sn=%7.1f MVA; UnG=%8.3f kV,    p=%8.3f%%, streg=%d',Sn,UnG,p,streg);
fprintf(   '\n                 UnS=%8.3f kV,  UnD=%8.3f kV',UnS,UnD);
fprintf(   '\n                UnGs=%8.3f kV, UnSs=%8.3f kV, UnDs=%8.3f kV',UnGs,UnSs,UnDs);
fprintf(   '\n PcuGD=%8.5f MW,  ukGD=%8.2f%%, uRGD=%8.2f%%, uXGD=%8.2f%%',PcuGD,ukGD,uRGD,uXGD);
fprintf(   '\n PcuGS=%8.5f MW,  ukGS=%8.2f%%, uRGS=%8.2f%%, uXGS=%8.2f%%',PcuGS,ukGS,uRGS,uXGS);
fprintf(   '\n PcuSD=%8.5f MW,  ukSD=%8.2f%%, uRSD=%8.2f%%, uXSD=%8.2f%%',PcuSD,ukSD,uRSD,uXSD);
fprintf(   '\n   Pfe=%8.5f MW,    Io=%5.2f%%',Pfe,Io);
fprintf(   '\n Rezystancje i reaktancje par uzwojen:');
fprintf(   '\n   RGD=%8.5f om,  XGD=%8.2f om',RGD,XGD);
fprintf(   '\n   RGS=%8.5f om,  XGS=%8.2f om',RGS,XGS);
fprintf(   '\n   RSD=%8.5f om,  XSD=%8.2f om',RSD,XSD);
fprintf(   '\n Rezystancje i reaktancje ga��zi gwiazdy:');
fprintf(   '\n    RG=%8.5f om,    XG=%8.5f om',RG,XG);
fprintf(   '\n    RD=%8.5f om,    XD=%8.5f om',RD,XD);
fprintf(   '\n    RS=%8.5f om,    XS=%8.5f om',RS,XS);
fprintf(   '\n Konduktancja i susceptancja poprzeczna:');
fprintf(   '\n     G=%6.2f mikroS,   B=%6.2f mikroS',G,B);
fprintf(   '\n\n Regulacja przekladni pary uzwojen G-S');
fprintf(   '\n tnGS=%8.5f, tnsGS=%8.5f',tnGS,tnsGS);
fprintf(   '\n t0GS=%8.5f,  dtGS=%8.5f, tminGS=%8.5f, tmaxGS=%8.5f',t0GS,dtGS,tminGS,tmaxGS);
fprintf(   '\n Regulacja przekladni pary uzwojen G-D');
fprintf(   '\n tnGD=%8.5f, tnsGD=%8.5f',tnGD,tnsGD);
fprintf(   '\n t0GD=%8.5f,  dtGD=%8.5f, tminGD=%8.5f, tmaxGD=%8.5f',t0GD,dtGD,tminGD,tmaxGD);


fprintf(fd,'\n =================================================================');
fprintf(fd,'\n\n Parametry zastepcze zwarciowe transf. 3-uzw w ukl. 012');
fprintf(fd,'\n %s - polaczenie uzwojen GS-GD-SD: ',poluzw);
fprintf(   '\n =================================================================');
fprintf(   '\n\n Parametry zastepcze zwarciowe transf. 3-uzw w ukl. 012');
fprintf(   '\n  Polaczenie uzwojen G-S-D: %s ',poluzw);
% napiecie zwarciowe na rezystancji par uzwojen
KTGD=0.95*1.1/(1+0.6*uXGD/100);
KTGS=0.95*1.1/(1+0.6*uXGS/100);
KTSD=0.95*1.1/(1+0.6*uXSD/100);

% parametry zastepcze par uzwojen  na strone wyzszego napiecia Un=UnG
ZGS=RGS+j*XGS; ZGSK=ZGS*KTGS;       RGSK=real(ZGSK); XGSK=imag(ZGSK);
ZGD=RGD+j*XGD; ZGDK=ZGD*KTGD;       RGDK=real(ZGDK); XGDK=imag(ZGDK);
ZSD=RSD+j*XSD; ZSDK=ZSD*KTSD;       RSDK=real(ZSDK); XSDK=imag(ZSDK);

%przeliczenie napiec zwarcia z par uzwojen na uzwojenie zastepcze G, S, D
ZGK=(ZGSK+ZGDK-ZSDK)/2; RGK=real(ZGK); XGK=imag(ZGK);
ZSK=(ZGSK+ZSDK-ZGDK)/2; RSK=real(ZSK); XSK=imag(ZSK);
ZDK=(ZGDK+ZSDK-ZGSK)/2; RDK=real(ZDK); XDK=imag(ZDK);
fprintf(fd,'\n Wsp. korekcji wg IEC:');
fprintf(fd,'\n   KTGD=%13.4f,     KTGS=%13.4f,    KTSD=%13.4f',KTGD,KTGS,KTSD);
fprintf(fd,'\n Rezystancje i reaktancje par uzwojen po korekcji:');
fprintf(fd,'\n   RGDK=%13.4f om,  XGDK=%13.4f om',RGDK,XGDK);
fprintf(fd,'\n   RGSK=%13.4f om,  XGSK=%13.4f om',RGSK,XGSK);
fprintf(fd,'\n   RSDK=%13.4f om,  XSDK=%13.4f om',RSDK,XSDK);
fprintf(fd,'\n Rezystancje i reaktancje ga��zi gwiazdy:');
fprintf(fd,'\n    RGK=%13.4f om,   XGK=%13.4f om',RGK,XGK);
fprintf(fd,'\n    RDK=%13.4f om,   XDK=%13.4f om',RDK,XDK);
fprintf(fd,'\n    RSK=%13.4f om,   XSK=%13.4f om',RSK,XSK);

fprintf(   '\n Wsp. korekcji wg IEC:');
fprintf(   '\n   KTGD=%13.4f,     KTGS=%13.4f,    KTSD=%13.4f',KTGD,KTGS,KTSD);
fprintf(   '\n Rezystancje i reaktancje par uzwojen po korekcji:');
fprintf(   '\n   RGDK=%13.4f om,  XGDK=%13.4f om',RGDK,XGDK);
fprintf(   '\n   RGSK=%13.4f om,  XGSK=%13.4f om',RGSK,XGSK);
fprintf(   '\n   RSDK=%13.4f om,  XSDK=%13.4f om',RSDK,XSDK);
fprintf(   '\n Rezystancje i reaktancje ga��zi gwiazdy:');
fprintf(   '\n    RGK=%13.4f om,   XGK=%13.4f om',RGK,XGK);
fprintf(   '\n    RDK=%13.4f om,   XDK=%13.4f om',RDK,XDK);
fprintf(   '\n    RSK=%13.4f om,   XSK=%13.4f om',RSK,XSK);
% Polaczenia uzwojen wg kolejnosci:
% poczatek               koniec
% G - gorne nap.    S - srodkowe nap.    D - dolne nap.
%  G-S-D:
% YN-d-yn
polG='YN'; polS='d';  polD='yn'; YN_d_yn=[polG '-' polS '-' polD];
% YN-d-y
polG='YN'; polS='d';  polD='y';  YN_d_y =[polG '-' polS '-' polD];
% YN-d-d
polG='YN'; polS='d';  polD='d';  YN_d_d =[polG '-' polS '-' polD];
% rezrwacja tablic
ZA1=[];ZB1=[];ZC1=[];ZE1=[];
ZA0=[];ZB0=[];ZC0=[];ZE0=[];
%                 G-S-D
if strcmp(poluzw,YN_d_yn) [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=fun_YN_d_yn(ZGK,ZSK,ZDK);   end
%                 G-S-D
if strcmp(poluzw,YN_d_y)  [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=fun_YN_d_y(ZGK,ZSK,ZDK);   end
%                 G-S-D
if strcmp(poluzw,YN_d_d)  [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=fun_YN_d_d(ZGK,ZSK,ZDK);   end

% zastepcze impedancje zwarciowe dla grup pol uzw.
fprintf(fd,'\n\n Gwiazda 4-ramienna do obliczen komputerowych');
fprintf(fd,'\n\n skl. 1 - tr3uzw');
fprintf(fd,'\n RA1=%13.3f om,    XA1=%13.3f om', real(ZA1),imag(ZA1) );
fprintf(fd,'\n RB1=%13.3f om,    XB1=%13.3f om', real(ZB1),imag(ZB1) );
fprintf(fd,'\n RC1=%13.3f om,    XC1=%13.3f om', real(ZC1),imag(ZC1) );
fprintf(fd,'\n RE1=%13.3f om,    XE1=%13.3f om', real(ZE1),imag(ZE1) );
fprintf(fd,'\n\n skl. 0 - tr3uzw - pol. uzw. G-S-D: %s',poluzw);
fprintf(fd,'\n RA0=%13.3f om,    XA0=%13.3f om', real(ZA0),imag(ZA0) );
fprintf(fd,'\n RB0=%13.3f om,    XB0=%13.3f om', real(ZB0),imag(ZB0) );
fprintf(fd,'\n RC0=%13.3f om,    XC0=%13.3f om', real(ZC0),imag(ZC0) );
fprintf(fd,'\n RE0=%13.3f om,    XE0=%13.3f om', real(ZE0),imag(ZE0) );

fprintf(   '\n\n Gwiazda 4-ramienna do obliczen komputerowych');
fprintf(   '\n\n skl. 1 - tr3uzw');
fprintf(   '\n RA1=%13.3f om,    XA1=%13.3f om', real(ZA1),imag(ZA1) );
fprintf(   '\n RB1=%13.3f om,    XB1=%13.3f om', real(ZB1),imag(ZB1) );
fprintf(   '\n RC1=%13.3f om,    XC1=%13.3f om', real(ZC1),imag(ZC1) );
fprintf(   '\n RE1=%13.3f om,    XE1=%13.3f om', real(ZE1),imag(ZE1) );
fprintf(   '\n\n skl. 0 - tr3uzw - pol. uzw. G-S-D: %s',poluzw);
fprintf(   '\n RA0=%13.3f om,    XA0=%13.3f om', real(ZA0),imag(ZA0) );
fprintf(   '\n RB0=%13.3f om,    XB0=%13.3f om', real(ZB0),imag(ZB0) );
fprintf(   '\n RC0=%13.3f om,    XC0=%13.3f om', real(ZC0),imag(ZC0) );
fprintf(   '\n RE0=%13.3f om,    XE0=%13.3f om', real(ZE0),imag(ZE0) );



fclose(fd);
return


function [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=fun_YN_d_yn(ZG,ZS,ZD)
%   G-S-D: YN-d-yn  -    skl. 0
%              
% A(G-gora)    *T           B(D-dol)
% o--ZA0=ZG----o--ZB0=ZD---o
%              | -
%              |    - 
%           ZE0=ZS   ZC0=inf
%              |       --- o C(C-srodek)
%              o
%           E-ZIEMIA
j=sqrt(-1); inf = 1e8;
ZA1=ZG;     ZB1=ZD;    ZE1=inf;   ZC1=ZS;      % skl. 1
ZA0=ZG;     ZB0=ZD;    ZE0=ZS;    ZC0=inf;     % skl. 0
return

function [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=fun_YN_d_y(ZG,ZS,ZD)
%   G-S-D: YN-d-y  -    skl. 0
%              
% A(G-gora)    *T           B(D-dol)
% o--ZA0=ZG----o--ZB0=inf   o
%              | -
%              |    - 
%           ZE0=ZS   ZC0=inf
%              |       --- o C(C-srodek)
%              o
%            E-ZIEMIA
j=sqrt(-1); inf = 1e8;
ZA1=ZG;     ZB1=ZD;    ZE1=inf;   ZC1=ZS;      % skl. 1
ZA0=ZG;     ZB0=inf;   ZE0=ZS;    ZC0=inf;     % skl. 0
return


function [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=fun_YN_d_d(ZG,ZS,ZD)
%   G-S-D: YN-d-d  -    skl. 0
%              
% A(G-gora)    *T           B(D-dol)
% o--ZA0=ZG----o--ZB0=inf   o
%              | -
%              |    - 
%  ZE0=ZD*ZS/(ZD+ZS)  ZC0=inf
%              |       --- o C(C-srodek)
%              o
%            E-ZIEMIA
j=sqrt(-1); inf = 1e8;
ZA1=ZG;     ZB1=ZD;    ZE1=inf;              ZC1=ZS;      % skl. 1
ZA0=ZG;     ZB0=inf;   ZE0=ZD*ZS/(ZD+ZS);    ZC0=inf;     % skl. 0
return
