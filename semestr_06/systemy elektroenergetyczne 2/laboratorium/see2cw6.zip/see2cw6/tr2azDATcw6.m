function [stra,UNSobl,winf]=tr2azDATcw6
%Dane do obl. par. zast. zwarciowych transf. 2-uzw.
%UNSobl - nap. znam. sieci wybrane na nap. obliczeniowe
%tN - przekladnia transf.: siec UNSobl -> transf. UNPS
%tN=tN1*tN2*... - sieci promieniowej
%tN=UNSobl/UNPS - tylko sieci oczkowe
%SN, MVA  - moc znamionowa
%UNP, kV  - nap. znam. transf. w wezle poczatkowym P
%UNPS, kV - nap. znam. sieci   w wezle poczatkowym P
%Pcu, MW  - straty obciazeniowe 
%uk, %    - napiecie zwarcia w %
%Xomi=X0mi/XT - krotnosc reaktancji magnesowania dla skl. 1
%Polaczenia uzwojen wg kolejnosci:
%P - poczatek   K - koniec
%poluzw='YNyn'; 
%poluzw='YNy'; 
%poluzw='Yyn'; 
%poluzw='Yy'; 
%poluzw='YNd';
%poluzw='Dyn';
%poluzw='Yd';
UNSobl=10.0; % kV
winf=1e8; % nieskonczonosc
stra={
% nazwg  nazwP    nazwK poluzw  SN  UNP UNPS    Pcu   uk   X0mi  tN
% max12s max12s   max12s    s  MVA   kV   kV     MW    %     -   -  
'T1'   'GPZ110'  'GPZ10'  'YNd' 40  115  110   0.256 11.51  5   11/115
'T2'   'RO'      'silnik' 'Dyn' 2   10.5  10   0.01151  6.51    6   1 
};
end %koniec tr2azDAT
