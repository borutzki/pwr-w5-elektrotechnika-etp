function tr2uzw
% paramtery zastepcze transf. 2-uzw. z reg. przekladni
% P---Tr2uzw---K 
% P - wezel poczatkowy transformatora
% K - wezel koncowy    transformatora
% Parametry zastepcze obliczamy na nap. znam. transf. po stronie wezla P
j=sqrt(-1);
fd=fopen('tr2uzwOUT.m','wt');
fprintf(fd,'\n====================================================================');
fprintf(fd,'\n partransf() - OBLICZANIE PARAMTROW TRANSFORMATORA 2-uzwojeniowego) ');
fprintf(fd,'\n Data: %5d-%2d-%2d  godz. %2d, %2dmin, %2.0fs',clock);
fprintf(fd,'\n====================================================================');
fprintf(   '\n====================================================================');
fprintf(   '\n partransf() - OBLICZANIE PARAMTROW TRANSFORMATORA 2-uzwojeniowego  ');
fprintf(   '\n Data: %5d-%2d-%2d  godz. %2d, %2dmin, %2.0fs',clock);
fprintf(   '\n====================================================================');
% czytanie danych z m-pliku
cdold=cd;
[plik,sciezka]=uigetfile('tr2uzwdat*.m','Wybierz m-plik z danymi transf. 2-uzw.');
eval(['cd(''',sciezka,''')']); dane=strtok(plik,'.');
[Sn,UnP,UnK,p,streg,UnPs,UnKs,Pcu,uk,Pfe,Io,poluzw,XomiXT]=feval(dane);
fprintf(fd,'\nPrzeczytano dane z m-pliku: %s',dane) ;
fprintf(   '\nPrzeczytano dane z m-pliku: %s',dane) ;
eval(['cd(''',cdold,''')']);   % powrot do katalogu z programem
% regulacja przekladni
tn=UnP/UnK; tns=UnPs/UnKs; t0=tn/tns;
dt=0.01*p/streg; tmin=t0-streg*dt; tmax=t0+streg*dt;
% parametry zastepcze na nap. znam. transf. od strony wezla P
% Un=UnP
Un=UnP; Zn=Un^2/Sn; uR=Pcu/Sn*100; uX=sqrt(uk^2-uR^2);
KT=0.95*1.1/(1+0.6*uX/100);
RT=Pcu/Sn*Zn; XT=uX/100*Zn; GT=Pfe/Un^2*1e6; BT=-Io/100/Zn*1e6;
ZT=RT+j*XT; Xomi=XomiXT*XT;
fprintf(fd,'\n\n Dane transformatora 2-uzwojeniowego');
fprintf(fd,'\n Sn=%.1f MVA; UnP=%.2f kV, p=%.2f%%, streg=%d, UnK=%.2f kV',...
    Sn,UnP,p,streg,UnK);
fprintf(fd,'\n Pcu=%8.5f MW, uk=%8.2f%%,  uR=%5.2f%%,  uX=%7.2f%%',Pcu,uk,uR,uX);
fprintf(fd,'\n Pfe=%8.5f MW, Io=%8.2f%%',Pfe,Io);
fprintf(fd,'\n =================================================================');
fprintf(fd,'\n\n Parametry zastepcze do obliczania Rozplywu Mocy');
fprintf(fd,'\n RT=%8.5f om,     XT=%8.5f om',RT,XT);
fprintf(fd,'\n GT=%8.5f mikroS, BT=%8.5f mikroS',GT,BT);
fprintf(fd,'\n\n Regulacja przekladni w obliczaniu Rozplywu Mocy');
fprintf(fd,'\n tn=UnP/UnK=%8.5f, tns=UnPs/UnKs=%8.5f',tn,tns);
fprintf(fd,'\n t0=tn/tns =%8.5f, dt =%8.5f, tmin=%8.5f, tmax=%8.5f',t0,dt,tmin,tmax);
fprintf(fd,'\n\n Dane transformatora');
fprintf(   '\n Sn=%8.1f MVA; UnP=%.2f kV, p=%.2f%%, streg=%d, UnK=%.2f kV',...
    Sn,UnP,p,streg,UnK);
fprintf(   '\n Pcu=%8.5f MW, uk=%8.2f%%,  uR=%5.2f%%,  uX=%7.2f%%',Pcu,uk,uR,uX);
fprintf(   '\n Pfe=%8.5f MW, Io=%8.2f%%',Pfe,Io);
fprintf(   '\n =================================================================');
fprintf(   '\n\n Parametry zastepcze do obliczania Rozplywu Mocy');
fprintf(   '\n RT=%8.5f om,     XT=%8.5f om',RT,XT);
fprintf(   '\n GT=%8.5f mikroS, BT=%8.5f mikroS',GT,BT);
fprintf(   '\n\n Regulacja przekladni w obliczaniu Rozplywu Mocy');
fprintf(   '\n tn=UnP/UnK=%8.5f, tns=UnPs/UnKs=%8.5f',tn,tns);
fprintf(   '\n t0=tn/tns =%8.5f, dt =%8.5f, tmin=%8.5f, tmax=%8.5f',t0,dt,tmin,tmax);
fprintf(fd,'\n =================================================================');
fprintf(fd,'\n\n Parametry zastepcze zwarciowe transf. 2-uzw w ukl. 012');
fprintf(fd,'\n %s - polaczenie uzwojen',poluzw);
fprintf(fd,'\n XomiXT =%g, Xomi=%g',XomiXT,Xomi);
fprintf(   '\n =================================================================');
fprintf(   '\n\n Parametry zastepcze zwarciowe transf. 2-uzw w ukl. 012');
fprintf(   '\n %s - polaczenie uzwojen',poluzw);
% Polaczenia uzwojen wg kolejnosci:
% poczatek               koniec
% P - gorne nap.         K - dolne napiecie
 YNyn='YNyn'; YNd='YNd'; YNy='YNy'; Yy='Yy'; % - polaczenia uzwojen P-K;
              Dyn='Dyn'; Yyn='Yyn';          % - polaczenia uzwojen P-K; 
% poczatek               koniec
% K - dolne nap.         K - gorne napiecie
% ynYN='ynYN'; Dyn='Dyn'; yYN='yYN'; yY='yY';% - polaczenia uzwojen K-P;

ZTK=ZT*KT; Xomi=KT*Xomi; % uwzglednmienie korekty wg IEC
RTK=real(ZTK); XTK=imag(ZTK);
if strcmp(poluzw,YNyn) [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]=funYNyn(ZTK,Xomi);   end
if strcmp(poluzw,YNy)  [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]= funYNy(ZTK,Xomi);   end
if strcmp(poluzw,Yyn)  [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]= funYyn(ZKT,Xomi);   end
if strcmp(poluzw,YNd)  [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]= funYNd(ZTK,Xomi);   end
if strcmp(poluzw,Dyn)  [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]= funDyn(ZTK,Xomi);   end
if strcmp(poluzw,Yy)   [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]=  funYy(ZTK,Xomi);   end
% zastepcze impedancje zwarciowe dla grup pol uzw.
fprintf(fd,'\n Wsp. korekcji wg IEC:                    KT=%13.4f',KT);
fprintf(fd,'\n Rezystancje i reaktancje uzwojen po korekcji:');
fprintf(fd,'\n RTK=%13.4f om,                   XTK=%13.4f om',RTK,XTK);
fprintf(fd,'\nXomi=%13.4f om',Xomi);
fprintf(fd,'\n\n Gwiazda do zwarciowych obliczen komputerowych: A,B,E-ziemia');
fprintf(fd,'\n\n skl. 1 - tr2uzw');
fprintf(fd,'\n RA1=%13.3f om,                   XA1=%13.3f om', real(ZA1),imag(ZA1) );
fprintf(fd,'\n RB1=%13.3f om,                   XB1=%13.3f om', real(ZB1),imag(ZB1) );
fprintf(fd,'\n RE1=%13.3f om,                   XE1=%13.3f om', real(ZE1),imag(ZE1) );
fprintf(fd,'\n\n skl. 0 - tr3uzw - pol. uzw. G-D: %s',poluzw);
fprintf(fd,'\n RA0=%13.3f om,                   XA0=%13.3f om', real(ZA0),imag(ZA0) );
fprintf(fd,'\n RB0=%13.3f om,                   XB0=%13.3f om', real(ZB0),imag(ZB0) );
fprintf(fd,'\n RE0=%13.3f om,                   XE0=%13.3f om', real(ZE0),imag(ZE0) );
fprintf(fd,'\n =================================================================');
fprintf(   '\n Wsp. korekcji wg IEC:                    KT=%13.4f',KT);
fprintf(   '\n Rezystancje i reaktancje uzwojen po korekcji:');
fprintf(   '\n RTK=%13.4f om,                   XTK=%13.4f om',RTK,XTK);
fprintf(   '\nXomi=%13.4f om',Xomi);
fprintf(   '\n\n Gwiazda do zwarciowych obliczen komputerowych: A,B,E-ziemia');
fprintf(   '\n\n skl. 1 - tr2uzw');
fprintf(   '\n RA1=%13.3f om,                   XA1=%13.3f om', real(ZA1),imag(ZA1) );
fprintf(   '\n RB1=%13.3f om,                   XB1=%13.3f om', real(ZB1),imag(ZB1) );
fprintf(   '\n RE1=%13.3f om,                   XE1=%13.3f om', real(ZE1),imag(ZE1) );
fprintf(   '\n\n skl. 0 - tr2uzw - pol. uzw. G-D: %s',poluzw);
fprintf(   '\n RA0=%13.3f om,                   XA0=%13.3f om', real(ZA0),imag(ZA0) );
fprintf(   '\n RB0=%13.3f om,                   XB0=%13.3f om', real(ZB0),imag(ZB0) );
fprintf(   '\n RE0=%13.3f om,                   XE0=%13.3f om', real(ZE0),imag(ZE0) );
fprintf(   '\n =================================================================');
fprintf(   '\n\n Koniec obl. par. zast. tr2uzw - wyniki tr2uzwOUT.m');
fclose(fd);
return


function [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]=funYNyn(ZT,Xomi)
%        YNyn - skl. 0
% P           *T           K
% o--ZA0=ZT/2--o--ZB=ZT/2--o
%              |
%            ZE=jXomi
%              |
%              o
%            ZIEMIA
j=sqrt(-1); inf = 1e8;
ZA1=ZT/2;   ZB1=ZT/2;    ZE1=inf;      % skl. 1
ZA0=ZT/2;   ZB0=ZT/2;    ZE0=j*Xomi;   % skl. 0
return

function [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]=funYNy(ZT,Xomi)
%        Yy - skl. 0
% P           *T           K
% o--ZA0=ZT/2--o--ZB=inf   o
%              |
%            ZE=jXomi
%              |
%              o
%            ZIEMIA
j=sqrt(-1);  inf=1e8;
ZA1=ZT/2;    ZB1=ZT/2;    ZE1=inf;       % skl. 1
ZA0=ZT/2;    ZB0=inf;     ZE0=j*Xomi;    % skl. 0
return

function [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]=funYyn(ZT,Xomi)
%        Yy - skl. 0
% P           *T           K
% o -ZA0=inf---o--ZB=ZT/2--o
%              |
%            ZE=jXomi
%              |
%              o
%            ZIEMIA
j=sqrt(-1);  inf=1e8;
ZA1=ZT/2;    ZB1=ZT/2;    ZE1=inf;       % skl. 1
ZA0=inf;     ZB0=ZT/2;    ZE0=j*Xomi;    % skl. 0
return




function [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]=funYy(ZT,Xomi)
%        Yy - skl. 0
% P           *T           K
% o--ZA0=ZT/2--o--ZB=inf   o
%              |
%            ZE=jXomi
%              |
%              o
%            ZIEMIA
j=sqrt(-1);  inf=1e8;
ZA1=ZT/2;    ZB1=ZT/2;    ZE1=inf;       % skl. 1
ZA0=inf;     ZB0=inf;     ZE0=j*Xomi;    % skl. 0
return

function [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]=funYNd(ZT,Xomi)
%        YNd - skl. 0
% P           *T              K
% o--ZA0=ZT/2--o--ZT/2---    o     ZB0=inf
%              |         |
%            jXomi       |         ZE0=ZT/2*jXomi/(ZT/2+jXomi)
%              |         |
%              o---------o
%            ZIEMIA   ZIEMIA
j=sqrt(-1);  inf=1e8;
ZA1=ZT/2;    ZB1=ZT/2;    ZE1=inf;                               % skl. 1
ZA0=ZT/2;    ZB0=inf;     ZE0=( (ZT/2)*j*Xomi )/( ZT/2+j*Xomi ); % skl. 0
return


function [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]=funDyn(ZT,Xomi)
%        YNd - skl. 0
% P  ZA0=inf   *T              K
% o  -----ZT/2--o--ZB0=ZT/2----o     ZB0=inf
%   |           |         
%   |         jXomi  ZE0=ZT/2*jXomi/(ZT/2+jXomi)
%   |           |         
%    -----------o
%            ZIEMIA   ZIEMIA
j=sqrt(-1);  inf=1e8;
ZA1=ZT/2;    ZB1=ZT/2;    ZE1=inf;                               % skl. 1
ZA0=inf;     ZB0=ZT/2;    ZE0=( (ZT/2)*j*Xomi )/( ZT/2+j*Xomi ); % skl. 0
return
