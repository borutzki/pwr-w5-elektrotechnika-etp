function tr2az
% par. zast. zwarciowe transf. 2-uzw.
j=sqrt(-1);
sciezka0=pwd; cd([sciezka0 '\Dane']); sciezka1=pwd;
plikWe= strcat([sciezka1 '\str_tr2.m']);
fd=fopen(plikWe,'wt');% plik na dane
cd ..
fprintf(fd,'\n%% PAR. ZAST. ZWARCIOWE transf. 2-uzw.');
% czytanie danych z m-pliku
cdold=cd;
[plik,sciezka]=...
 uigetfile('tr2azDAT*.m','Wybierz plik danych tr. 2-uzw.');
fprintf('\n... wybrano: %s%s.m',sciezka,plik);
eval(['cd(''',sciezka,''')']); dane=strtok(plik,'.');
[stra,UNSobl,winf] = eval(dane);
eval(['cd(''',cdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
[nt,n]=size(stra);
if nt
   naztr =stra(:,1); nazwp =stra(:,2); nazwk =stra(:,3);
   pol=stra(:,4);   tre=[cell2mat(stra(:,5:end)) ];
else    % brak tranf.
naztr=[]; tre=[];
end %if nt
% Polaczenia uzwojen wg kolejnosci:
% P - gorne nap.         K - dolne napiecie
 YNyn=strcat('YN','yn');
 YNd =strcat('YN','d');
 YNy =strcat('YN','y');
 Yy  =strcat('Y','y');
 Dyn =strcat('D','yn');
 Yyn =strcat('Y','yn'); 
 Yd  =strcat('Y','d');
if ~isempty(tre)
fprintf(fd,'\n%%Par. zast. na nap. znam. transf. UNP');
fprintf(fd,'\n%%UNSobl - nap. znam. sieci jako nap. obliczeniowe');
fprintf(fd,'\n%%tN - przekl. transf.: siec UNSobl -> transf. UNS');
fprintf(fd,'\n%%tN=tN1*tN2*... - siec promieniowa');
fprintf(fd,'\n%%tN=UNSobl/UNS  - tylko siec oczkowa');
fprintf(fd,'\nUNSobl=%4.3g; %% kV',UNSobl);
fprintf(fd,'\nwinf=%.0e; %% nieskonczonosc ',winf);
fprintf(fd,'\n stra={');
fprintf(fd,'\n%%transf      Od         Do        ');
fprintf(fd,'UNS     R1     X1     R0     X0   tN');
fprintf(fd,...
 '\n%%max12s     max12s     max12s     ');
fprintf(fd,'kV     om     om     om     om   -');
for i=1:nt
  Sn=tre(i,1); UnP=tre(i,2); UnPs=tre(i,3);
  Pcu=tre(i,4); uk=tre(i,5); X0miXT=tre(i,6);
  tn=tre(i,7);
  % par. zast. na nap. znam. transf. od strony wezla P
  Un=UnP; Zn=Un^2/Sn; uR=Pcu/Sn*100; uX=sqrt(uk^2-uR^2); 
  RT=Pcu/Sn*Zn; XT=uX/100*Zn; 
  KT=0.95*1.1/(1+0.6*uX/100); 
  ZT=RT+j*XT; X0mi=X0miXT*XT;
  ZTK=ZT*KT; X0mi=KT*X0mi; % uwzglednienie korekty wg IEC
  ZA1=[]; ZB1=[]; ZE1=[];    ZA0=[]; ZB0=[]; ZE0=[];
  nazwo=[]; naztrA=[]; naztrB=[]; naztrE=[];
  poluzw=pol(i,:); % aktualna grupa polaczen
  if strcmp(poluzw,YNyn)
   [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]= funYNyn(ZTK,X0mi,winf);end
  if strcmp(poluzw,YNy)
   [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]= funYNy(ZTK,X0mi,winf); end
  if strcmp(poluzw,Yyn)
   [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]= funYyn(ZKT,X0mi,winf); end
  if strcmp(poluzw,YNd)
   [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]= funYNd(ZTK,X0mi,winf); end
  if strcmp(poluzw,Dyn)
   [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]= funDyn(ZTK,X0mi,winf); end
  if strcmp(poluzw,Yy)
   [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]= funYy(ZTK,X0mi,winf);  end
  if strcmp(poluzw,Yd)
   [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]= funYd(ZTK,X0mi,winf); end
  if ~isempty(ZA1)
        RA1=real(ZA1); XA1=imag(ZA1);
        RB1=real(ZB1); XB1=imag(ZB1);
        RE1=real(ZE1); XE1=imag(ZE1);
        RA0=real(ZA0); XA0=imag(ZA0);
        RB0=real(ZB0); XB0=imag(ZB0);
        RE0=real(ZE0); XE0=imag(ZE0);
        ntr=char(naztr(i,:)); ntrP=char(nazwp(i,:));
        ntrK=char(nazwk(i,:));
        nazwo=strcat('*',deblank(ntr)); ziemia='ZIEMIA';
        naztrA=strcat(deblank(ntr),'A');
        naztrB=strcat(deblank(ntr),'B');
        naztrE=strcat(deblank(ntr),'E');
        fprintf(fd,'\n %% %s - polaczenie uzwojen P-K: ',char(poluzw) );
        naz1=[]; naz2=[]; naz3=[]; 
        naz1=naztrA; naz2=ntrP; naz3=nazwo;
        R1=RA1; X1=XA1;
        R0=RA0; X0=XA0;
        druktr(fd,naz1,naz2,naz3,UnPs,R1,X1,R0,X0,tn,winf); 
        naz1=[]; naz2=[]; naz3=[];        
        naz1=naztrB; naz2=nazwo; naz3=ntrK;
        R1=RB1; X1=XB1;
        R0=RB0; X0=XB0;
        druktr(fd,naz1,naz2,naz3,UnPs,R1,X1,R0,X0,tn,winf);  
        naz1=[]; naz2=[]; naz3=[];       
        naz1=naztrE; naz2=nazwo; naz3=ziemia;
        R1=RE1; X1=XE1;
        R0=RE0; X0=XE0;
        druktr(fd,naz1,naz2,naz3,UnPs,R1,X1,R0,X0,tn,winf);             
     else
        fprintf(fd,'\n %s %s %s - bledne dane grupy polaczen',...
             naztr(i,:),nawzp(i,:),nazwk(i,:) );
     end % if ~isempty(ZA1)
   end %for i=1:nt
   fprintf(fd,'\n };');
 else
     fprintf(fd,'\n%% brak transf. 2-uzw.!');
end % ~isempty(tre)
fclose(fd);
fprintf('\n\n...str{} zapisano w pliku tr2azOUT.m\n');
end % koniec tr2az()
function [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]=funYNyn(ZT,X0mi,winf)
%        YNyn - skl. 0
% P           *T           K
% o--ZA0=ZT/2--o--ZB=ZT/2--o
%              |
%            ZE=jX0mi
%              |
%              o
%            ZIEMIA
j=sqrt(-1);
ZA1=ZT/2;   ZB1=ZT/2;    ZE1=winf;     % skl. 1
ZA0=ZT/2;   ZB0=ZT/2;    ZE0=j*X0mi;   % skl. 0
end % koniec funYNyn()
function [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]=funYNy(ZT,X0mi,winf)
%        Yy - skl. 0
% P           *T           K
% o--ZA0=ZT/2--o--ZB=winf   o
%              |
%            ZE=jX0mi
%              |
%              o
%            ZIEMIA
j=sqrt(-1);
ZA1=ZT/2;    ZB1=ZT/2;     ZE1=winf;      % skl. 1
ZA0=ZT/2;    ZB0=winf;     ZE0=j*X0mi;    % skl. 0
end % koniec funYNy()
function [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]=funYyn(ZT,X0mi,winf)
%        Yy - skl. 0
% P           *T           K
% o -ZA0=winf---o--ZB=ZT/2--o
%              |
%            ZE=jX0mi
%              |
%              o
%            ZIEMIA
j=sqrt(-1);
ZA1=ZT/2;    ZB1=ZT/2;     ZE1=winf;       % skl. 1
ZA0=winf;     ZB0=ZT/2;    ZE0=j*X0mi;    % skl. 0
end % koniec funYyn()
function [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]=funYy(ZT,X0mi,winf)
%        Yy - skl. 0
% P           *T           K
% o--ZA0=ZT/2--o--ZB=winf   o
%              |
%            ZE=jX0mi
%              |
%              o
%            ZIEMIA
j=sqrt(-1);
ZA1=ZT/2;    ZB1=ZT/2;     ZE1=winf;       % skl. 1
ZA0=winf;     ZB0=winf;     ZE0=j*X0mi;    % skl. 0
end % funYy()
function [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]=funYNd(ZT,X0mi,winf)
%        YNd - skl. 0
% P           *T              K
% o--ZA0=ZT/2--o--ZT/2---    o     ZB0=winf
%              |         |
%            jX0mi       |         ZE0=ZT/2*jX0mi/(ZT/2+jX0mi)
%              |         |
%              o---------o
%            ZIEMIA   ZIEMIA
j=sqrt(-1);
ZA1=ZT/2;    ZB1=ZT/2;     ZE1=winf;                              % skl. 1
ZA0=ZT/2;    ZB0=winf;     ZE0=( (ZT/2)*j*X0mi )/( ZT/2+j*X0mi ); % skl. 0
end %koniec funYNd
function [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]=funDyn(ZT,X0mi,winf)
%        YNd - skl. 0
% P  ZA0=winf   *T              K
% o  -----ZT/2--o--ZB0=ZT/2----o     ZB0=winf
%   |           |         
%   |         jX0mi  ZE0=ZT/2*jX0mi/(ZT/2+jX0mi)
%   |           |         
%    -----------o
%            ZIEMIA   ZIEMIA
j=sqrt(-1);
ZA1=ZT/2;    ZB1=ZT/2;     ZE1=winf;                              % skl. 1
ZA0=winf;     ZB0=ZT/2;    ZE0=( (ZT/2)*j*X0mi )/( ZT/2+j*X0mi ); % skl. 0
end %koniec funDyn()
function [ZA1,ZB1,ZE1,ZA0,ZB0,ZE0]=funYd(ZT,X0mi,winf)
%        YNd - skl. 0
% P           *T              K
% o  ZA0=winf--o--ZT/2---    o     ZB0=winf
%              |         |
%            jX0mi       |         ZE0=ZT/2*jX0mi/(ZT/2+jX0mi)
%              |         |
%              o---------o
%            ZIEMIA   ZIEMIA
j=sqrt(-1);
ZA1=ZT/2;    ZB1=ZT/2;     ZE1=winf;                              % skl. 1
ZA0=winf;    ZB0=winf;     ZE0=( (ZT/2)*j*X0mi )/( ZT/2+j*X0mi ); % skl. 0
end %koniec funYd

