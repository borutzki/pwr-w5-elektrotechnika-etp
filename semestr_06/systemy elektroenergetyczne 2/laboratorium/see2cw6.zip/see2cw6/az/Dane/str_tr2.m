
% PAR. ZAST. ZWARCIOWE transf. 2-uzw.
%Par. zast. na nap. znam. transf. UNP
%UNSobl - nap. znam. sieci jako nap. obliczeniowe
%tN - przekl. transf.: siec UNSobl -> transf. UNS
%tN=tN1*tN2*... - siec promieniowa
%tN=UNSobl/UNS  - tylko siec oczkowa
UNSobl=  10; % kV
winf=1e+08; % nieskonczonosc 
 stra={
%transf      Od         Do        UNS     R1     X1     R0     X0   tN
%max12s     max12s     max12s     kV     om     om     om     om   -
 % YNd - polaczenie uzwojen P-K: 
'T1A     ' 'GPZ110  ' '*T1     ' 110  1.034  18.57  1.034  18.57 0.095652
'T1B     ' '*T1     ' 'GPZ10   ' 110  1.034  18.57   winf   winf 0.095652
'T1E     ' '*T1     ' 'ZIEMIA  ' 110   winf   winf 0.8583  16.92 0.095652
 % Dyn - polaczenie uzwojen P-K: 
'T2A     ' 'RO      ' '*T2     '  10 0.1596  1.798   winf   winf      1
'T2B     ' '*T2     ' 'silnik  '  10 0.1596  1.798 0.1596  1.798      1
'T2E     ' '*T2     ' 'ZIEMIA  '  10   winf   winf 0.1358   1.66      1
 };