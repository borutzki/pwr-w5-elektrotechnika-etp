
%PAR. ZAST. ZWARCIOWE SILNIKOW ASYNCHRONICZNYCH
%Par. zast. nap. znam. silnika UNM
%UNSobl - nap. obliczeniowe
%tN - przekl. transf.: siecUNSobl -> siec UNS
%tN=tN1*tN2*...- siec promieniowa
%tN=UNS/UNSobl - tylko sieci oczkowe
UNSobl=  10; % kV
winf=1e+08; % nieskonczonosc 
sgen={
%Silnik     Od         Do         UNS     R1     X1     R0     X0   tN
%max12s     max12s     max12s     kV     om      om     om     om   -
'M       ' 'silnik  ' 'ZIEMIA  ' 0.525 0.0126 0.02999   winf   winf     20
 };