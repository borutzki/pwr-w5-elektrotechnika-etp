
%PARAMETRY ZASTEPCZE ZWARCIOWE LINII 
%Par. zast. zwarciowe nap. znam. linii UNS
%UNSobl - nap. znam. sieci wybrane na nap. obliczeniowe
%tN - przekl. transf.: siec UNSobl -> linia UNS
%tN=tN1*tN2*... - siec promieniowa
%tN=UNSobl/UNS -  tylko siec oczkowa
UNSobl=10; %kV - nap. obliczeniowe 
winf=1e+08; % nieskonczonosc 
 slin={
%linia       Od         Do        UNS     R1     X1     R0     X0   tN
%max12s     max12s     max12s     kV     om     om     om     om   -
'L       ' 'GPZ10kV ' 'odczep  '  10    1.1 0.9287  1.481   3.25      1
'K       ' 'odczep  ' 'RO      '  10  0.385 0.1842 0.3851 0.1842      1
 };