
%PARAMETRY ZASTEPCZE ZWARCIOWE SYSTEMU ZEWNETRZNEGO
%Par. zast. na nap.znam. SEE, UNS=UNQ
%UNSobl - nap. znam. obliczeniowe
%tN - przekl. transf.:siec UNSobl -> siec UNS
%tN=tN1*tN2*... - siec promieniowa
%tN=UNSobl/UNS - tylko sieci oczkowe
UNSobl=  10; 
winf=1e+08; % nieskonczonosc 
sgen={
%SEE        Od         Do        UNS     R1     X1     R0     X0   tN
%max12s     max12s     max12s     kV     om     om     om     om   -
'SEE2    ' 'WezSEE2 ' 'ZIEMIA  ' 110      0  6.622      0  6.622 0.095652
 };