function [sgen,UNSobl,winf] = gsazDATtest
% Dane do obl. parametrow zastepczych zwarciowych GS
% UNSobl - nap. znam. sieci wybrane na nap. obliczeniowe
% UNG - nap. znamionowe GS
% UNS - nap. znam. sieci, do ktorej jest przylaczony GS
% SNG - moc znam. pozorna GS
% cosfin - znam. wsp. mocy GS
% xdb - reaktancja podprzejsciowa GS
% X0X1 - X0/X1 skl. zerowej do zgodnej
% tN - przekladnia transf. miedzy GS i siecia UNSobl
%tN=tN1*tN2*... - sieci promieniowe
%tN=UNSobl/UN   - tylko sieci oczkowe
UNSobl=110.0; %kV poziom napiecia obliczen zwarciowych
winf=1e8; % nieskonczonosc
sgen={
%gen.   wezel     UNG  UNS   SNG cosfin   xdb X0X1  tN
%max12s max12s     kV   kV   MVA    -      pu   -    -
'G1'   'GPZ10kV' 10.5 10.0 11.00  0.80  0.180 winf  115/11
'G2'   'MEW'      6.3  6.0  3.95  0.90  0.133 winf 115/22*21/6.3
};
end


