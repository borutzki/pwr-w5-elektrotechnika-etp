function [sas,UNSobl,winf] = sasazDATtest
%Dane do obl. par. zastepczych zwar. silnikow asynchr.
%UNSobl - nap. znam. sieci wybrane na nap. obliczeniowe
%UNM      % kV - napiecie znamionowe silnika
%UNS      % kV - napiecie znam. sieci z silnikiem
%PNM      % MW - moc znamionowa silnika
%eta      % znamionowa sprawnosc
%cosfin   % znamionowy wspolczynnik mocy
%kr=Ik/IN % wspolczynik pradu rozruchu
%p        % liczba par biegunow
%ns       % liczba silnik�w
%tN - przekl. transf.: siec UNSobl -> siec z silnikiem
%tN=tN1*tN2*...- sieci promieniowe
%tN=UNSobl/UNS - tylko sieci oczkowe
UNSobl=10.0; % kV
winf=1e8; % nieskonczonosc
sas={
%sas wezel   UNM UNS PNM  eta cosfin Ik/IN p ns  tn
%12s max12s   kV  kV MVA   -    -    -    -  -    -
'M' 'silnik' 0.5 0.525 0.2 0.97 0.86   4.0  2  6 115/11*10.5/0.525
};
end
