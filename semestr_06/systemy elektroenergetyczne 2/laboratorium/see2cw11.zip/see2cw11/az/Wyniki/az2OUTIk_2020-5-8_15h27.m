
 ANALIZA ZWARC W SIECI SKUTECZNIE UZIEMIONEJ

*** E:\OneDrive - Politechnika Wroclawska\studia\Systemy elektroenergetyczne 2\lab\see2cw11\az\Wyniki\az2OUTIk_2020-5-8_15h27.m 
- zbiorcze wyniki analizy zwarc 3-f i 1-fz ***

 Data:  2020- 5- 8  o'clock 15h, 27min, 16s
 az: a-analiza z-warc
% - dane par. zwarciowych w m-pliku    na poziomie UNS
% - po przeczytaniu dane przeliczone   na poziom UNSobl
% - m. admitancyjna    Y1,   Y0 w [S]  na poziomie UNSobl
% - imp. zwar. Thev. Zkk1, Zkk0 w [om] na poziomie UNSobl
% - prady zw. 3-f, 2-f, 2-fz, 1-fz     na poziomie UNS 
 Izw3f i Izw1f odniesione do nap. znam. UNS w miejscu zwarcia
   Wez.         UNS    Szw3f    Szw1f    Izw3f    Izw1f  X0X1 R0X1 SkutUz
     -           kV      MVA      MVA       kA       kA   -    -       - 
  WEZ1-220kV    220  16491.7  14294.2    43.28    37.51  1.5  0.0      -     
  WEZ2-220kV    220  16491.7  14294.2    43.28    37.51  1.5  0.0      -     
  WEZ1-110kV    110   2166.5   2225.9    11.37    11.68  0.9  0.0     NIE     
  WEZ2-110kV    110   2166.5   2225.9    11.37    11.68  0.9  0.0     NIE     
          W2    110   1092.4    829.5     5.73     4.35  2.0  0.0      -     
    GPZ110kV    110   1136.3    994.8     5.96     5.22  1.4  0.0      -     
     GPZ10kV     10    246.0      0.0    14.20     0.00  inf  inf PNizol.
          DL     10     76.0      0.0     4.39     0.00  inf  inf PNizol.
          RO     10     41.9      0.0     2.42     0.00  inf  inf PNizol.
      silnik  0.525     25.3     27.2    27.80    29.87  0.8  0.1      nN