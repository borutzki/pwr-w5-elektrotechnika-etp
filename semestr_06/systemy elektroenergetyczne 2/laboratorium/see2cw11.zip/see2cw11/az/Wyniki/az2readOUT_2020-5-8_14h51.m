

 bus[] wg danych wczytanych
              nrwez      UNS         tN
 WEZ1-220kV      1     220.000      0.469  
 WEZ2-220kV      2     220.000      0.469  
 WEZ1-110kV      3     110.000      1.000  
 WEZ2-110kV      4     110.000      1.000  
 W2              5     110.000      1.000  
 GPZ110kV        6     110.000      1.000  
 GPZ10kV         7      10.000     10.455  
 RO              8      10.000     10.455  
 silnik          9       0.525    209.091  
 *T221          10     220.000      0.469  
 *T222          11     220.000      0.469  
 *T1            12     110.000      1.000  
 *T2            13      10.000     10.455  
 ZIEMIA          0       0.000      0.000  

 galezie[] wg danych wczytanych
 nazwg        nazwp        nazwk        wp - wk  UNS     R1     X1     R0     X0      tN
                                         1   2    3       4      5      6      7      8
L110tor1     WEZ1-110kV   GPZ110kV       3   6   110      0   6.04      0   18.1      1
L110tor2     WEZ2-110kV   W2             4   5   110      0   6.04      0   18.1      1
W1           WEZ1-110kV   WEZ2-110kV     3   4   110      0 0.0001      0 0.0001      1
LK           GPZ10kV      RO             7   8    10   1.49   1.11   1.87   3.44   10.5
T221A        WEZ1-220kV   *T221          1  10   220      0     27      0     27  0.469
T221B        *T221        WEZ1-110kV    10   3   220      0     27      0     27  0.469
T221E        *T221        ZIEMIA        10   0   220  1e+15  1e+15      0    281  0.469
T222A        WEZ2-220kV   *T222          2  11   220      0     27      0     27  0.469
T222B        *T222        WEZ2-110kV    11   4   220      0     27      0     27  0.469
T222E        *T222        ZIEMIA        11   0   220  1e+15  1e+15      0    281  0.469
T1A          GPZ110kV     *T1            6  12   110  0.998   28.1  0.998   28.1      1
T1B          *T1          GPZ10kV       12   7   110  0.998   28.1  1e+15  1e+15      1
T1E          *T1          ZIEMIA        12   0   110  1e+15  1e+15  0.833   25.6      1
T2A          RO           *T2            8  13    10   0.16    1.8  1e+15  1e+15   10.5
T2B          *T2          silnik        13   9    10   0.16    1.8   0.16    1.8   10.5
T2E          *T2          ZIEMIA        13   0    10  1e+15  1e+15  0.136   1.67   10.5
SkQ1         WEZ1-220kV   ZIEMIA         1   0   220      0   3.33      0   4.99  0.469
SkQ2         WEZ2-220kV   ZIEMIA         2   0   220      0   3.33      0   4.99  0.469
GS           GPZ10kV      ZIEMIA         7   0    10  0.251   1.67  1e+15  1e+15   10.5
MAS          silnik       ZIEMIA         9   0 0.525 0.0048  0.032  1e+15  1e+15    209
 galezie[] po przeliczeniu na UNSobl=   110 kV
 nazwg        nazwp        nazwk        wp - wk  UNS     R1     X1     R0     X0      tN
                                         1   2    3       4      5      6      7      8
L110tor1     WEZ1-110kV   GPZ110kV       3   6   110      0   6.04      0   18.1      1
L110tor2     WEZ2-110kV   W2             4   5   110      0   6.04      0   18.1      1
W1           WEZ1-110kV   WEZ2-110kV     3   4   110      0 0.0001      0 0.0001      1
LK           GPZ10kV      RO             7   8    10    163    122    204    375   10.5
T221A        WEZ1-220kV   *T221          1  10   220      0   5.94      0   5.94  0.469
T221B        *T221        WEZ1-110kV    10   3   220      0   5.94      0   5.94  0.469
T221E        *T221        ZIEMIA        10   0   220 2.2e+14 2.2e+14      0     62  0.469
T222A        WEZ2-220kV   *T222          2  11   220      0   5.94      0   5.94  0.469
T222B        *T222        WEZ2-110kV    11   4   220      0   5.94      0   5.94  0.469
T222E        *T222        ZIEMIA        11   0   220 2.2e+14 2.2e+14      0     62  0.469
T1A          GPZ110kV     *T1            6  12   110  0.998   28.1  0.998   28.1      1
T1B          *T1          GPZ10kV       12   7   110  0.998   28.1  1e+15  1e+15      1
T1E          *T1          ZIEMIA        12   0   110  1e+15  1e+15  0.833   25.6      1
T2A          RO           *T2            8  13    10   17.5    197 1.09e+17 1.09e+17   10.5
T2B          *T2          silnik        13   9    10   17.5    197   17.5    197   10.5
T2E          *T2          ZIEMIA        13   0    10 1.09e+17 1.09e+17   14.9    182   10.5
SkQ1         WEZ1-220kV   ZIEMIA         1   0   220      0  0.733      0    1.1  0.469
SkQ2         WEZ2-220kV   ZIEMIA         2   0   220      0  0.733      0    1.1  0.469
GS           GPZ10kV      ZIEMIA         7   0    10   27.4    183 1.09e+17 1.09e+17   10.5
MAS          silnik       ZIEMIA         9   0 0.525    210 1.4e+03 4.37e+19 4.37e+19    209