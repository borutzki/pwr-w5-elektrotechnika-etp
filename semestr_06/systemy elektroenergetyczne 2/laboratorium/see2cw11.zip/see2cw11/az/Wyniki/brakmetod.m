
 ANALIZA ZWARC W SIECI SKUTECZNIE UZIEMIONEJ

*** E:\OneDrive - Politechnika Wroclawska\studia\Systemy elektroenergetyczne 2\lab\see2cw11\az\Wyniki\az2OUTIk_2020-5-8_13h53.m 
- zbiorcze wyniki analizy zwarc 3-f i 1-fz ***

 Data:  2020- 5- 8  o'clock 13h, 53min, 29s
 az: a-analiza z-warc
% - dane par. zwarciowych w m-pliku    na poziomie UNS
% - po przeczytaniu dane przeliczone   na poziom UNSobl
% - m. admitancyjna    Y1,   Y0 w [S]  na poziomie UNSobl
% - imp. zwar. Thev. Zkk1, Zkk0 w [om] na poziomie UNSobl
% - prady zw. 3-f, 2-f, 2-fz, 1-fz     na poziomie UNS 
 Izw3f i Izw1f odniesione do nap. znam. UNS w miejscu zwarcia
   Wez.         UNS    Szw3f    Szw1f    Izw3f    Izw1f  X0X1 R0X1 SkutUz
     -           kV      MVA      MVA       kA       kA   -    -       - 
  WEZ1-220kV    220  16493.0  14304.4    43.28    37.54  1.5  0.0      -     
  WEZ2-220kV    220  16493.0  14304.4    43.28    37.54  1.5  0.0      -     
  WEZ1-110kV    110   2172.5   2262.1    11.40    11.87  0.9  0.0     NIE     
  WEZ2-110kV    110   2172.5   2262.1    11.40    11.87  0.9  0.0     NIE     
          W2    110   1490.6   1399.0     7.82     7.34  1.2  0.0      -     
    GPZ110kV    110   1490.6   1399.0     7.82     7.34  1.2  0.0      -     
     GPZ10kV     10    329.0      0.0    18.99     0.00  inf  inf PNizol.
          RO     10     57.8      0.0     3.34     0.00  inf  inf PNizol.
      silnik  0.525     28.9     29.9    31.76    32.86  0.9  0.1      nN