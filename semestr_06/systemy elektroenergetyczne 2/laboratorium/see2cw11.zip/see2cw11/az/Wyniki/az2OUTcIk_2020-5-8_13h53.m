
 ANALIZA ZWARC W SIECI SKUTECZNIE UZIEMIONEJ

*** E:\OneDrive - Politechnika Wroclawska\studia\Systemy elektroenergetyczne 2\lab\see2cw11\az\Wyniki\az2OUTcIk_2020-5-8_13h53.m 
- analiza zwarc w ukl. 012 oraz ABC ***

 Data:  2020- 5- 8  o'clock 13h, 53min, 29s
 az: a-analiza z-warc
% - dane par. zwarciowych w m-pliku    na poziomie UNS
% - po przeczytaniu dane przeliczone   na poziom UNSobl
% - m. admitancyjna    Y1,   Y0 w [S]  na poziomie UNSobl
% - imp. zwar. Thev. Zkk1, Zkk0 w [om] na poziomie UNSobl
% - prady zw. 3-f, 2-f, 2-fz, 1-fz     na poziomie UNS 


 ******************************************************
 ***  WEZ1-220kV   - miejsce zwarcia ***
 ******************************************************
 Unk =     220 kV - nap. znam. sieci  w miejscu zwarcia
Unfk = 127.017 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 = 139.719 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.000 om, Xkk1 =   3.228 om - imp. zwar. skl.1
Xkk0 =   0.001 om, Xkk0 =   4.710 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     43.28 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =   16493.0 MVA
 Zwarcie 2-fazowe                      Ik2 =     37.48 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     33.14 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     40.98 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     40.98 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     37.54 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =   14304.4 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.00
                       X0/X1 =  1.46
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   12.5 kA, mI2=   12.5 kA, mI0=   12.5 kA
Katy:   kI1=  -90.0 st, kI2=  -90.0 st, kI0=  -90.0 st
Napiecia - uklad 012
Moduly: mU1=   99.3 kV, mU2=   40.4 kV, mU0=   58.9 kV
Katy:   kU1=   -0.0 st, kU2= -180.0 st, kU0=  180.0 st
Prady - uklad ABC
Moduly: mIA=   37.5 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -90.0 st, kIB=    9.5 st, kIC=    9.5 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=    150 kV, mUC=    150 kV
Katy:   kUA=   90.0 st, kUB= -126.2 st, kUC=  126.2 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   21.6 kA, mI2=   21.6 kA, mI0=      0 kA
Katy:   kI1=  -90.0 st, kI2=   90.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   69.9 kV, mU2=   69.9 kV, mU0=      0 kV
Katy:   kU1=   -0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   37.5 kA, mIC=   37.5 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -180.0 st, kIC=    0.0 st
Napiecia - uklad ABC
Moduly: mUA=    140 kV, mUB=   69.9 kV, mUC=   69.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   27.2 kA, mI2=   16.1 kA, mI0=     11 kA
Katy:   kI1=  -90.0 st, kI2=   90.0 st, kI0=   90.0 st
Napiecia - uklad 012
Moduly: mU1=     52 kV, mU2=     52 kV, mU0=     52 kV
Katy:   kU1=   -0.0 st, kU2=   -0.0 st, kU0=   -0.0 st
Prady - uklad ABC
Moduly: mIB=     41 kA, mIC=     41 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  156.2 st, kIC=   23.9 st
Napiecia - uklad ABC
Moduly: mUA=    156 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=   -0.0 st, kUB=   90.0 st, kUC=   90.0 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: WEZ1-220kV   
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ1-220kV    43.28 kA (100.0%)   0.00   3.23   0.00 -43.28j
     od: *T221          1.29 kA (  3.0%)   0.00  26.97   0.00  -1.29j
 od zr.: WEZ1-220kV    41.99 kA ( 97.0%)   0.00   3.33   0.00 -41.99j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: WEZ1-220kV   
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ1-220kV    12.51 kA (100.0%)   0.00   4.71   0.00 -12.51j
     od: *T221          0.71 kA (  5.6%)   0.00  26.97   0.00  -0.71j
 od zr.: WEZ1-220kV    11.81 kA ( 94.4%)   0.00   4.99  -0.00 -11.81j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00  -0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  WEZ2-220kV   - miejsce zwarcia ***
 ******************************************************
 Unk =     220 kV - nap. znam. sieci  w miejscu zwarcia
Unfk = 127.017 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 = 139.719 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.000 om, Xkk1 =   3.228 om - imp. zwar. skl.1
Xkk0 =   0.001 om, Xkk0 =   4.710 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     43.28 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =   16493.0 MVA
 Zwarcie 2-fazowe                      Ik2 =     37.48 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     33.14 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     40.98 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     40.98 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     37.54 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =   14304.4 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.00
                       X0/X1 =  1.46
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   12.5 kA, mI2=   12.5 kA, mI0=   12.5 kA
Katy:   kI1=  -90.0 st, kI2=  -90.0 st, kI0=  -90.0 st
Napiecia - uklad 012
Moduly: mU1=   99.3 kV, mU2=   40.4 kV, mU0=   58.9 kV
Katy:   kU1=   -0.0 st, kU2= -180.0 st, kU0=  180.0 st
Prady - uklad ABC
Moduly: mIA=   37.5 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -90.0 st, kIB=   26.6 st, kIC=   26.6 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=    150 kV, mUC=    150 kV
Katy:   kUA=  180.0 st, kUB= -126.2 st, kUC=  126.2 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   21.6 kA, mI2=   21.6 kA, mI0=      0 kA
Katy:   kI1=  -90.0 st, kI2=   90.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   69.9 kV, mU2=   69.9 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   37.5 kA, mIC=   37.5 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -180.0 st, kIC=    0.0 st
Napiecia - uklad ABC
Moduly: mUA=    140 kV, mUB=   69.9 kV, mUC=   69.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   27.2 kA, mI2=   16.1 kA, mI0=     11 kA
Katy:   kI1=  -90.0 st, kI2=   90.0 st, kI0=   90.0 st
Napiecia - uklad 012
Moduly: mU1=     52 kV, mU2=     52 kV, mU0=     52 kV
Katy:   kU1=   -0.0 st, kU2=   -0.0 st, kU0=   -0.0 st
Prady - uklad ABC
Moduly: mIB=     41 kA, mIC=     41 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  156.2 st, kIC=   23.9 st
Napiecia - uklad ABC
Moduly: mUA=    156 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=   -0.0 st, kUB=   58.0 st, kUC=   50.2 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: WEZ2-220kV   
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ2-220kV    43.28 kA (100.0%)   0.00   3.23   0.00 -43.28j
     od: *T222          1.29 kA (  3.0%)   0.00  26.97   0.00  -1.29j
 od zr.: WEZ2-220kV    41.99 kA ( 97.0%)   0.00   3.33   0.00 -41.99j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: WEZ2-220kV   
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ2-220kV    12.51 kA (100.0%)   0.00   4.71   0.00 -12.51j
     od: *T222          0.71 kA (  5.6%)   0.00  26.97   0.00  -0.71j
 od zr.: WEZ2-220kV    11.81 kA ( 94.4%)   0.00   4.99  -0.00 -11.81j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00  -0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  WEZ1-110kV   - miejsce zwarcia ***
 ******************************************************
 Unk =     110 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =  63.509 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =  69.859 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.024 om, Xkk1 =   6.126 om - imp. zwar. skl.1
Xkk0 =   0.027 om, Xkk0 =   5.399 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =      11.4 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =    2172.5 MVA
 Zwarcie 2-fazowe                      Ik2 =     9.875 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     12.38 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     11.66 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     11.65 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     11.87 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =    2262.1 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.00
                       X0/X1 =  0.88 niespelnione
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   3.96 kA, mI2=   3.96 kA, mI0=   3.96 kA
Katy:   kI1=  -89.8 st, kI2=  -89.8 st, kI0=  -89.8 st
Napiecia - uklad 012
Moduly: mU1=   45.6 kV, mU2=   24.2 kV, mU0=   21.4 kV
Katy:   kU1=   -0.0 st, kU2= -180.0 st, kU0=  180.0 st
Prady - uklad ABC
Moduly: mIA=   11.9 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -89.8 st, kIB=   26.6 st, kIC=   26.6 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=   68.4 kV, mUC=   68.5 kV
Katy:   kUA=   90.0 st, kUB= -117.9 st, kUC=  117.9 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=    5.7 kA, mI2=    5.7 kA, mI0=      0 kA
Katy:   kI1=  -89.8 st, kI2=   90.2 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   34.9 kV, mU2=   34.9 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   9.88 kA, mIC=   9.88 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -179.8 st, kIC=    0.2 st
Napiecia - uklad ABC
Moduly: mUA=   69.9 kV, mUB=   34.9 kV, mUC=   34.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   7.77 kA, mI2=   3.64 kA, mI0=   4.13 kA
Katy:   kI1=  -89.8 st, kI2=   90.2 st, kI0=   90.3 st
Napiecia - uklad 012
Moduly: mU1=   22.3 kV, mU2=   22.3 kV, mU0=   22.3 kV
Katy:   kU1=   -0.0 st, kU2=   -0.0 st, kU0=   -0.0 st
Prady - uklad ABC
Moduly: mIB=   11.7 kA, mIC=   11.7 kA, mIA=      0 kA
Katy:   kIA=  -90.2 st, kIB=  148.1 st, kIC=   32.3 st
Napiecia - uklad ABC
Moduly: mUA=   66.9 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=   -0.0 st, kUB=  180.0 st, kUC=  132.0 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: WEZ1-110kV   
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ1-110kV    11.40 kA (100.0%)   0.02   6.13   0.04 -11.40j
     od: WEZ2-110kV     5.70 kA ( 50.0%)   0.00   0.00   0.02  -5.70j
     od: GPZ110kV       0.17 kA (  1.5%)   0.00   6.04   0.02  -0.17j
     od: *T221          5.54 kA ( 48.5%)   0.00   5.94   0.00  -5.54j
 od zr.: WEZ1-110kV     0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: WEZ1-110kV   
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ1-110kV     3.96 kA (100.0%)   0.03   5.40   0.02  -3.96j
     od: WEZ2-110kV     1.98 kA ( 50.0%)   0.00   0.00   0.01  -1.98j
     od: GPZ110kV       0.24 kA (  6.0%)   0.00  18.12   0.01  -0.24j
     od: *T221          1.74 kA ( 44.0%)   0.00   5.94  -0.00  -1.74j
 od zr.: WEZ1-110kV     0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00  -0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  WEZ2-110kV   - miejsce zwarcia ***
 ******************************************************
 Unk =     110 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =  63.509 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =  69.859 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.024 om, Xkk1 =   6.126 om - imp. zwar. skl.1
Xkk0 =   0.027 om, Xkk0 =   5.399 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =      11.4 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =    2172.5 MVA
 Zwarcie 2-fazowe                      Ik2 =     9.875 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     12.38 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     11.66 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     11.65 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     11.87 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =    2262.1 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.00
                       X0/X1 =  0.88 niespelnione
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   3.96 kA, mI2=   3.96 kA, mI0=   3.96 kA
Katy:   kI1=  -89.8 st, kI2=  -89.8 st, kI0=  -89.8 st
Napiecia - uklad 012
Moduly: mU1=   45.6 kV, mU2=   24.2 kV, mU0=   21.4 kV
Katy:   kU1=   -0.0 st, kU2= -180.0 st, kU0=  180.0 st
Prady - uklad ABC
Moduly: mIA=   11.9 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -89.8 st, kIB=   26.6 st, kIC=   26.6 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=   68.4 kV, mUC=   68.5 kV
Katy:   kUA=    0.4 st, kUB= -117.9 st, kUC=  117.9 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=    5.7 kA, mI2=    5.7 kA, mI0=      0 kA
Katy:   kI1=  -89.8 st, kI2=   90.2 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   34.9 kV, mU2=   34.9 kV, mU0=      0 kV
Katy:   kU1=   -0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   9.88 kA, mIC=   9.88 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -179.8 st, kIC=    0.2 st
Napiecia - uklad ABC
Moduly: mUA=   69.9 kV, mUB=   34.9 kV, mUC=   34.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   7.77 kA, mI2=   3.64 kA, mI0=   4.13 kA
Katy:   kI1=  -89.8 st, kI2=   90.2 st, kI0=   90.3 st
Napiecia - uklad 012
Moduly: mU1=   22.3 kV, mU2=   22.3 kV, mU0=   22.3 kV
Katy:   kU1=   -0.0 st, kU2=   -0.0 st, kU0=   -0.0 st
Prady - uklad ABC
Moduly: mIB=   11.7 kA, mIC=   11.7 kA, mIA=      0 kA
Katy:   kIA=  180.0 st, kIB=  148.1 st, kIC=   32.3 st
Napiecia - uklad ABC
Moduly: mUA=   66.9 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=   -0.0 st, kUB=  146.3 st, kUC=  116.6 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: WEZ2-110kV   
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ2-110kV    11.40 kA (100.0%)   0.02   6.13   0.04 -11.40j
     od: WEZ1-110kV     5.70 kA ( 50.0%)   0.00   0.00   0.02  -5.70j
     od: W2             0.17 kA (  1.5%)   0.00   6.04   0.02  -0.17j
     od: *T222          5.54 kA ( 48.5%)   0.00   5.94   0.00  -5.54j
 od zr.: WEZ2-110kV     0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: WEZ2-110kV   
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ2-110kV     3.96 kA (100.0%)   0.03   5.40   0.02  -3.96j
     od: WEZ1-110kV     1.98 kA ( 50.0%)   0.00   0.00   0.01  -1.98j
     od: W2             0.24 kA (  6.0%)   0.00  18.12   0.01  -0.24j
     od: *T222          1.74 kA ( 44.0%)   0.00   5.94  -0.00  -1.74j
 od zr.: WEZ2-110kV     0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00  -0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  W2           - miejsce zwarcia ***
 ******************************************************
 Unk =     110 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =  63.509 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =  69.859 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.053 om, Xkk1 =   8.929 om - imp. zwar. skl.1
Xkk0 =   0.168 om, Xkk0 =  10.682 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     7.824 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =    1490.6 MVA
 Zwarcie 2-fazowe                      Ik2 =     6.776 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     6.918 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     7.629 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     7.586 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     7.343 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =    1399.0 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.02
                       X0/X1 =  1.20
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   2.45 kA, mI2=   2.45 kA, mI0=   2.45 kA
Katy:   kI1=  -89.5 st, kI2=  -89.5 st, kI0=  -89.5 st
Napiecia - uklad 012
Moduly: mU1=     48 kV, mU2=   21.9 kV, mU0=   26.1 kV
Katy:   kU1=   -0.1 st, kU2= -179.8 st, kU0=  179.6 st
Prady - uklad ABC
Moduly: mIA=   7.34 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -89.5 st, kIB=   14.0 st, kIC=   14.0 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=   71.9 kV, mUC=   72.3 kV
Katy:   kUA=    0.4 st, kUB= -123.1 st, kUC=  122.9 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   3.91 kA, mI2=   3.91 kA, mI0=      0 kA
Katy:   kI1=  -89.7 st, kI2=   90.3 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   34.9 kV, mU2=   34.9 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=   -0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   6.78 kA, mIC=   6.78 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -179.7 st, kIC=    0.3 st
Napiecia - uklad ABC
Moduly: mUA=   69.9 kV, mUB=   34.9 kV, mUC=   34.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   5.06 kA, mI2=   2.76 kA, mI0=   2.31 kA
Katy:   kI1=  -89.6 st, kI2=   90.2 st, kI0=   90.7 st
Napiecia - uklad 012
Moduly: mU1=   24.6 kV, mU2=   24.6 kV, mU0=   24.6 kV
Katy:   kU1=   -0.2 st, kU2=   -0.2 st, kU0=   -0.2 st
Prady - uklad ABC
Moduly: mIB=   7.63 kA, mIC=   7.59 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  153.4 st, kIC=   27.5 st
Napiecia - uklad ABC
Moduly: mUA=   73.9 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=   -0.2 st, kUB=   71.6 st, kUC=   45.0 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: W2           
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: W2             7.82 kA (100.0%)   0.05   8.93   0.05  -7.82j
     od: WEZ2-110kV     3.74 kA ( 47.9%)   0.00   6.04   0.00  -3.74j
     od: GPZ110kV       4.08 kA ( 52.1%)   0.00   0.00   0.05  -4.08j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: W2           
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: W2             2.45 kA (100.0%)   0.17  10.68   0.02  -2.45j
     od: WEZ2-110kV     0.86 kA ( 35.2%)   0.00  18.12  -0.01  -0.86j
     od: GPZ110kV       1.59 kA ( 64.8%)   0.00   0.00   0.03  -1.59j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00   0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  GPZ110kV     - miejsce zwarcia ***
 ******************************************************
 Unk =     110 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =  63.509 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =  69.859 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.053 om, Xkk1 =   8.929 om - imp. zwar. skl.1
Xkk0 =   0.168 om, Xkk0 =  10.682 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     7.824 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =    1490.6 MVA
 Zwarcie 2-fazowe                      Ik2 =     6.776 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     6.918 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     7.629 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     7.586 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     7.343 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =    1399.0 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.02
                       X0/X1 =  1.20
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   2.45 kA, mI2=   2.45 kA, mI0=   2.45 kA
Katy:   kI1=  -89.5 st, kI2=  -89.5 st, kI0=  -89.5 st
Napiecia - uklad 012
Moduly: mU1=     48 kV, mU2=   21.9 kV, mU0=   26.1 kV
Katy:   kU1=   -0.1 st, kU2= -179.8 st, kU0=  179.6 st
Prady - uklad ABC
Moduly: mIA=   7.34 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -89.5 st, kIB=   14.0 st, kIC=   14.0 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=   71.9 kV, mUC=   72.3 kV
Katy:   kUA=   90.0 st, kUB= -123.1 st, kUC=  122.9 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   3.91 kA, mI2=   3.91 kA, mI0=      0 kA
Katy:   kI1=  -89.7 st, kI2=   90.3 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   34.9 kV, mU2=   34.9 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   6.78 kA, mIC=   6.78 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -179.7 st, kIC=    0.3 st
Napiecia - uklad ABC
Moduly: mUA=   69.9 kV, mUB=   34.9 kV, mUC=   34.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   5.06 kA, mI2=   2.76 kA, mI0=   2.31 kA
Katy:   kI1=  -89.6 st, kI2=   90.2 st, kI0=   90.7 st
Napiecia - uklad 012
Moduly: mU1=   24.6 kV, mU2=   24.6 kV, mU0=   24.6 kV
Katy:   kU1=   -0.2 st, kU2=   -0.2 st, kU0=   -0.2 st
Prady - uklad ABC
Moduly: mIB=   7.63 kA, mIC=   7.59 kA, mIA=      0 kA
Katy:   kIA=  180.0 st, kIB=  153.4 st, kIC=   27.5 st
Napiecia - uklad ABC
Moduly: mUA=   73.9 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=   -0.2 st, kUB=   99.5 st, kUC=  180.0 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: GPZ110kV     
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: GPZ110kV       7.82 kA (100.0%)   0.05   8.93   0.05  -7.82j
     od: WEZ1-110kV     3.74 kA ( 47.9%)   0.00   6.04   0.00  -3.74j
     od: W2             3.74 kA ( 47.9%)   0.00   0.00   0.00  -3.74j
     od: *T1            0.34 kA (  4.3%)   1.03  18.60   0.05  -0.34j
 od zr.: GPZ110kV       0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: GPZ110kV     
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: GPZ110kV       2.45 kA (100.0%)   0.17  10.68   0.02  -2.45j
     od: WEZ1-110kV     0.86 kA ( 35.2%)   0.00  18.12  -0.01  -0.86j
     od: W2             0.86 kA ( 35.2%)   0.00   0.00  -0.01  -0.86j
     od: *T1            0.73 kA ( 29.7%)   1.03  18.60   0.03  -0.73j
 od zr.: GPZ110kV       0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00  -0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  GPZ10kV      - miejsce zwarcia ***
 ******************************************************
 Unk =      10 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =   5.774 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =   6.351 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.023 om, Xkk1 =   0.334 om - imp. zwar. skl.1
Rkk0 =     inf     , Xkk0 =     inf      - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     18.99 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =     329.0 MVA
 Zwarcie 2-fazowe                      Ik2 =     16.45 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =         0 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     16.45 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     16.45 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =         0 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =       0.0 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =   inf  PN izolowany
                       X0/X1 =   inf  PN izolowany
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=      0 kA, mI2=      0 kA, mI0=      0 kA
Katy:   kI1=    0.0 st, kI2=    0.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   6.35 kV, mU2=      0 kV, mU0=   6.35 kV
Katy:   kU1=   -0.0 st, kU2=    0.0 st, kU0=  180.0 st
Prady - uklad ABC
Moduly: mIB=      0 kA, mIC=      0 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=    0.0 st, kIC=    0.0 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=     11 kV, mUC=     11 kV
Katy:   kUA=   40.9 st, kUB= -150.0 st, kUC=  150.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=    9.5 kA, mI2=    9.5 kA, mI0=      0 kA
Katy:   kI1=  -86.1 st, kI2=   93.9 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   3.18 kV, mU2=   3.18 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   16.4 kA, mIC=   16.4 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -176.1 st, kIC=    3.9 st
Napiecia - uklad ABC
Moduly: mUA=   6.35 kV, mUB=   3.18 kV, mUC=   3.18 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=    9.5 kA, mI2=    9.5 kA, mI0=      0 kA
Katy:   kI1=  -86.1 st, kI2=   93.9 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   3.18 kV, mU2=   3.18 kV, mU0=   3.16 kV
Katy:   kU1=   -0.0 st, kU2=   -0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   16.4 kA, mIC=   16.4 kA, mIA=      0 kA
Katy:   kIA=  -45.0 st, kIB= -176.1 st, kIC=    3.9 st
Napiecia - uklad ABC
Moduly: mUA=   9.51 kV, mUB= 0.0196 kV, mUC= 0.0196 kV
Katy:   kUA=    0.0 st, kUB=  179.4 st, kUC=  179.4 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: GPZ10kV      
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: GPZ10kV       18.99 kA (100.0%)   0.02   0.33   1.29 -18.95j
     od: RO             0.35 kA (  1.9%)   1.49   1.11   0.07  -0.35j
     od: *T1           14.90 kA ( 78.5%)   0.01   0.17   0.66 -14.89j
 od zr.: GPZ10kV        3.76 kA ( 19.8%)   0.25   1.67   0.56  -3.71j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00   0.00j
 -------------------------------------------------------------------
 ... izolowany punkt neutralny w tym wezle ...


 ******************************************************
 ***  RO           - miejsce zwarcia ***
 ******************************************************
 Unk =      10 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =   5.774 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =   6.351 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   1.274 om, Xkk1 =   1.413 om - imp. zwar. skl.1
Rkk0 =     inf     , Xkk0 =     inf      - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     3.339 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =      57.8 MVA
 Zwarcie 2-fazowe                      Ik2 =     2.891 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =         0 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     2.891 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     2.891 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =         0 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =       0.0 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =   inf  PN izolowany
                       X0/X1 =   inf  PN izolowany
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=      0 kA, mI2=      0 kA, mI0=      0 kA
Katy:   kI1=    0.0 st, kI2=    0.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   6.35 kV, mU2=      0 kV, mU0=   6.35 kV
Katy:   kU1=   -0.0 st, kU2=    0.0 st, kU0=  180.0 st
Prady - uklad ABC
Moduly: mIB=      0 kA, mIC=      0 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=    0.0 st, kIC=    0.0 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=     11 kV, mUC=     11 kV
Katy:   kUA=    2.9 st, kUB= -150.0 st, kUC=  150.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   1.67 kA, mI2=   1.67 kA, mI0=      0 kA
Katy:   kI1=  -48.0 st, kI2=  132.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   3.18 kV, mU2=   3.18 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   2.89 kA, mIC=   2.89 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -138.0 st, kIC=   42.0 st
Napiecia - uklad ABC
Moduly: mUA=   6.35 kV, mUB=   3.18 kV, mUC=   3.18 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   1.67 kA, mI2=   1.67 kA, mI0=      0 kA
Katy:   kI1=  -48.0 st, kI2=  132.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   3.18 kV, mU2=   3.18 kV, mU0=   3.17 kV
Katy:   kU1=   -0.0 st, kU2=   -0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   2.89 kA, mIC=   2.89 kA, mIA=      0 kA
Katy:   kIA=  -45.0 st, kIB= -138.0 st, kIC=   42.0 st
Napiecia - uklad ABC
Moduly: mUA=   9.52 kV, mUB=0.00367 kV, mUC=0.00367 kV
Katy:   kUA=    0.0 st, kUB=  176.9 st, kUC=  176.9 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: RO           
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: RO             3.34 kA (100.0%)   1.27   1.41   2.24  -2.48j
     od: GPZ10kV        3.03 kA ( 90.7%)   1.49   1.11   2.18  -2.10j
     od: *T2            0.38 kA ( 11.5%)   0.16   1.80   0.05  -0.38j
 od zr.: RO             0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00  -0.00j
 -------------------------------------------------------------------
 ... izolowany punkt neutralny w tym wezle ...


 ******************************************************
 ***  silnik       - miejsce zwarcia ***
 ******************************************************
 Unk =   0.525 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =   0.303 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.00    - wsp. obliczen zwarciowych
  E1 =   0.303 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.003 om, Xkk1 =   0.009 om - imp. zwar. skl.1
Xkk0 =   0.001 om, Xkk0 =   0.009 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     31.76 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =      28.9 MVA
 Zwarcie 2-fazowe                      Ik2 =      27.5 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     33.89 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     30.35 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     34.15 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     32.86 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =      29.9 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.08
                       X0/X1 =  0.95
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=     11 kA, mI2=     11 kA, mI0=     11 kA
Katy:   kI1=  -77.1 st, kI2=  -77.1 st, kI0=  -77.1 st
Napiecia - uklad 012
Moduly: mU1=  0.199 kV, mU2=  0.105 kV, mU0= 0.0954 kV
Katy:   kU1=    1.9 st, kU2=  176.3 st, kU0= -172.0 st
Prady - uklad ABC
Moduly: mIA=   32.9 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -77.1 st, kIB=   36.9 st, kIC=   32.0 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=  0.316 kV, mUC=  0.281 kV
Katy:   kUA=  170.5 st, kUB= -116.6 st, kUC=  120.3 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   15.9 kA, mI2=   15.9 kA, mI0=      0 kA
Katy:   kI1=  -73.4 st, kI2=  106.6 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=  0.152 kV, mU2=  0.152 kV, mU0=      0 kV
Katy:   kU1=   -0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   27.5 kA, mIC=   27.5 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -163.4 st, kIC=   16.6 st
Napiecia - uklad ABC
Moduly: mUA=  0.303 kV, mUB=  0.152 kV, mUC=  0.152 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   21.5 kA, mI2=   10.3 kA, mI0=   11.3 kA
Katy:   kI1=  -75.4 st, kI2=  110.7 st, kI0=   99.0 st
Napiecia - uklad 012
Moduly: mU1= 0.0984 kV, mU2= 0.0984 kV, mU0= 0.0984 kV
Katy:   kU1=    4.1 st, kU2=    4.1 st, kU0=    4.1 st
Prady - uklad ABC
Moduly: mIB=   30.3 kA, mIC=   34.1 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  163.0 st, kIC=   46.0 st
Napiecia - uklad ABC
Moduly: mUA=  0.295 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=    4.1 st, kUB=  110.6 st, kUC=  180.0 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: silnik       
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: silnik        31.76 kA (100.0%)   0.00   0.01   9.05 -30.44j
     od: *T2           22.52 kA ( 70.9%)   0.00   0.00   7.66 -21.18j
 od zr.: silnik         9.37 kA ( 29.5%)   0.00   0.03   1.39  -9.26j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: silnik       
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: silnik        10.95 kA (100.0%)   0.00   0.01   2.45 -10.68j
     od: *T2           10.95 kA (100.0%)   0.00   0.00   2.45 -10.68j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00  -0.00j
 -------------------------------------------------------------------