
 ANALIZA ZWARC W SIECI SKUTECZNIE UZIEMIONEJ

*** E:\OneDrive - Politechnika Wroclawska\studia\Systemy elektroenergetyczne 2\lab\see2cw11\az\Wyniki\az2OUTcIk_2020-5-8_14h36.m 
- analiza zwarc w ukl. 012 oraz ABC ***

 Data:  2020- 5- 8  o'clock 14h, 36min, 43s
 az: a-analiza z-warc
% - dane par. zwarciowych w m-pliku    na poziomie UNS
% - po przeczytaniu dane przeliczone   na poziom UNSobl
% - m. admitancyjna    Y1,   Y0 w [S]  na poziomie UNSobl
% - imp. zwar. Thev. Zkk1, Zkk0 w [om] na poziomie UNSobl
% - prady zw. 3-f, 2-f, 2-fz, 1-fz     na poziomie UNS 


 ******************************************************
 ***  WEZ1-220kV   - miejsce zwarcia ***
 ******************************************************
 Unk =     220 kV - nap. znam. sieci  w miejscu zwarcia
Unfk = 127.017 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 = 139.719 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.000 om, Xkk1 =   3.228 om - imp. zwar. skl.1
Xkk0 =   0.001 om, Xkk0 =   4.713 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     43.28 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =   16492.8 MVA
 Zwarcie 2-fazowe                      Ik2 =     37.48 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     33.12 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     40.98 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     40.98 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     37.53 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =   14300.1 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.00
                       X0/X1 =  1.46
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   12.5 kA, mI2=   12.5 kA, mI0=   12.5 kA
Katy:   kI1=  -90.0 st, kI2=  -90.0 st, kI0=  -90.0 st
Napiecia - uklad 012
Moduly: mU1=   99.3 kV, mU2=   40.4 kV, mU0=     59 kV
Katy:   kU1=   -0.0 st, kU2= -180.0 st, kU0=  180.0 st
Prady - uklad ABC
Moduly: mIA=   37.5 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -90.0 st, kIB=   18.4 st, kIC=   18.4 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=    150 kV, mUC=    150 kV
Katy:   kUA=    0.0 st, kUB= -126.2 st, kUC=  126.2 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   21.6 kA, mI2=   21.6 kA, mI0=      0 kA
Katy:   kI1=  -90.0 st, kI2=   90.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   69.9 kV, mU2=   69.9 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   37.5 kA, mIC=   37.5 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -180.0 st, kIC=    0.0 st
Napiecia - uklad ABC
Moduly: mUA=    140 kV, mUB=   69.9 kV, mUC=   69.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   27.2 kA, mI2=   16.1 kA, mI0=     11 kA
Katy:   kI1=  -90.0 st, kI2=   90.0 st, kI0=   90.0 st
Napiecia - uklad 012
Moduly: mU1=     52 kV, mU2=     52 kV, mU0=     52 kV
Katy:   kU1=   -0.0 st, kU2=   -0.0 st, kU0=   -0.0 st
Prady - uklad ABC
Moduly: mIB=     41 kA, mIC=     41 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  156.2 st, kIC=   23.8 st
Napiecia - uklad ABC
Moduly: mUA=    156 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=   -0.0 st, kUB=  128.7 st, kUC=  166.0 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: WEZ1-220kV   
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ1-220kV    43.28 kA (100.0%)   0.00   3.23   0.00 -43.28j
     od: *T221          1.29 kA (  3.0%)   0.00  26.97   0.00  -1.29j
 od zr.: WEZ1-220kV    41.99 kA ( 97.0%)   0.00   3.33   0.00 -41.99j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00  -0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: WEZ1-220kV   
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ1-220kV    12.51 kA (100.0%)   0.00   4.71   0.00 -12.51j
     od: *T221          0.70 kA (  5.6%)   0.00  26.97   0.00  -0.70j
 od zr.: WEZ1-220kV    11.81 kA ( 94.4%)   0.00   4.99  -0.00 -11.81j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00  -0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  WEZ2-220kV   - miejsce zwarcia ***
 ******************************************************
 Unk =     220 kV - nap. znam. sieci  w miejscu zwarcia
Unfk = 127.017 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 = 139.719 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.000 om, Xkk1 =   3.228 om - imp. zwar. skl.1
Xkk0 =   0.001 om, Xkk0 =   4.713 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     43.28 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =   16492.8 MVA
 Zwarcie 2-fazowe                      Ik2 =     37.48 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     33.12 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     40.98 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     40.98 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     37.53 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =   14300.1 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.00
                       X0/X1 =  1.46
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   12.5 kA, mI2=   12.5 kA, mI0=   12.5 kA
Katy:   kI1=  -90.0 st, kI2=  -90.0 st, kI0=  -90.0 st
Napiecia - uklad 012
Moduly: mU1=   99.3 kV, mU2=   40.4 kV, mU0=     59 kV
Katy:   kU1=   -0.0 st, kU2= -180.0 st, kU0=  180.0 st
Prady - uklad ABC
Moduly: mIA=   37.5 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -90.0 st, kIB=   18.4 st, kIC=   18.4 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=    150 kV, mUC=    150 kV
Katy:   kUA=   90.0 st, kUB= -126.2 st, kUC=  126.2 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   21.6 kA, mI2=   21.6 kA, mI0=      0 kA
Katy:   kI1=  -90.0 st, kI2=   90.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   69.9 kV, mU2=   69.9 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   37.5 kA, mIC=   37.5 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -180.0 st, kIC=    0.0 st
Napiecia - uklad ABC
Moduly: mUA=    140 kV, mUB=   69.9 kV, mUC=   69.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   27.2 kA, mI2=   16.1 kA, mI0=     11 kA
Katy:   kI1=  -90.0 st, kI2=   90.0 st, kI0=   90.0 st
Napiecia - uklad 012
Moduly: mU1=     52 kV, mU2=     52 kV, mU0=     52 kV
Katy:   kU1=   -0.0 st, kU2=   -0.0 st, kU0=   -0.0 st
Prady - uklad ABC
Moduly: mIB=     41 kA, mIC=     41 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  156.2 st, kIC=   23.8 st
Napiecia - uklad ABC
Moduly: mUA=    156 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=   -0.0 st, kUB=  161.6 st, kUC=  126.9 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: WEZ2-220kV   
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ2-220kV    43.28 kA (100.0%)   0.00   3.23   0.00 -43.28j
     od: *T222          1.29 kA (  3.0%)   0.00  26.97   0.00  -1.29j
 od zr.: WEZ2-220kV    41.99 kA ( 97.0%)   0.00   3.33   0.00 -41.99j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: WEZ2-220kV   
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ2-220kV    12.51 kA (100.0%)   0.00   4.71   0.00 -12.51j
     od: *T222          0.70 kA (  5.6%)   0.00  26.97   0.00  -0.70j
 od zr.: WEZ2-220kV    11.81 kA ( 94.4%)   0.00   4.99  -0.00 -11.81j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00  -0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  WEZ1-110kV   - miejsce zwarcia ***
 ******************************************************
 Unk =     110 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =  63.509 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =  69.859 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.023 om, Xkk1 =   6.129 om - imp. zwar. skl.1
Xkk0 =   0.020 om, Xkk0 =   5.509 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =      11.4 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =    2171.7 MVA
 Zwarcie 2-fazowe                      Ik2 =     9.871 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     12.22 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     11.61 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     11.61 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =      11.8 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =    2247.4 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.00
                       X0/X1 =  0.90 niespelnione
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   3.93 kA, mI2=   3.93 kA, mI0=   3.93 kA
Katy:   kI1=  -89.8 st, kI2=  -89.8 st, kI0=  -89.8 st
Napiecia - uklad 012
Moduly: mU1=   45.8 kV, mU2=   24.1 kV, mU0=   21.7 kV
Katy:   kU1=    0.0 st, kU2=  180.0 st, kU0= -180.0 st
Prady - uklad ABC
Moduly: mIA=   11.8 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -89.8 st, kIB=   18.4 st, kIC=   18.4 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=   68.7 kV, mUC=   68.7 kV
Katy:   kUA= -179.9 st, kUB= -118.2 st, kUC=  118.2 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=    5.7 kA, mI2=    5.7 kA, mI0=      0 kA
Katy:   kI1=  -89.8 st, kI2=   90.2 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   34.9 kV, mU2=   34.9 kV, mU0=      0 kV
Katy:   kU1=   -0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   9.87 kA, mIC=   9.87 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -179.8 st, kIC=    0.2 st
Napiecia - uklad ABC
Moduly: mUA=   69.9 kV, mUB=   34.9 kV, mUC=   34.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   7.74 kA, mI2=   3.66 kA, mI0=   4.07 kA
Katy:   kI1=  -89.8 st, kI2=   90.2 st, kI0=   90.2 st
Napiecia - uklad 012
Moduly: mU1=   22.4 kV, mU2=   22.4 kV, mU0=   22.4 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   11.6 kA, mIC=   11.6 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  148.5 st, kIC=   32.0 st
Napiecia - uklad ABC
Moduly: mUA=   67.3 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=    0.0 st, kUB= -164.1 st, kUC=  139.4 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: WEZ1-110kV   
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ1-110kV    11.40 kA (100.0%)   0.02   6.13   0.04 -11.40j
     od: WEZ2-110kV     5.54 kA ( 48.6%)   0.00   0.00   0.00  -5.54j
     od: GPZ110kV       0.33 kA (  2.9%)   0.00   6.04   0.04  -0.33j
     od: *T221          5.54 kA ( 48.6%)   0.00   5.94   0.00  -5.54j
 od zr.: WEZ1-110kV     0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: WEZ1-110kV   
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ1-110kV     3.93 kA (100.0%)   0.02   5.51   0.01  -3.93j
     od: WEZ2-110kV     1.77 kA ( 44.9%)   0.00   0.00   0.00  -1.77j
     od: GPZ110kV       0.40 kA ( 10.2%)   0.00  18.12   0.01  -0.40j
     od: *T221          1.77 kA ( 44.9%)   0.00   5.94   0.00  -1.77j
 od zr.: WEZ1-110kV     0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00  -0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  WEZ2-110kV   - miejsce zwarcia ***
 ******************************************************
 Unk =     110 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =  63.509 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =  69.859 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.023 om, Xkk1 =   6.129 om - imp. zwar. skl.1
Xkk0 =   0.020 om, Xkk0 =   5.509 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =      11.4 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =    2171.7 MVA
 Zwarcie 2-fazowe                      Ik2 =     9.871 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     12.22 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     11.61 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     11.61 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =      11.8 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =    2247.4 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.00
                       X0/X1 =  0.90 niespelnione
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   3.93 kA, mI2=   3.93 kA, mI0=   3.93 kA
Katy:   kI1=  -89.8 st, kI2=  -89.8 st, kI0=  -89.8 st
Napiecia - uklad 012
Moduly: mU1=   45.8 kV, mU2=   24.1 kV, mU0=   21.7 kV
Katy:   kU1=    0.0 st, kU2=  180.0 st, kU0= -180.0 st
Prady - uklad ABC
Moduly: mIA=   11.8 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -89.8 st, kIB=   18.4 st, kIC=   18.4 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=   68.7 kV, mUC=   68.7 kV
Katy:   kUA=  180.0 st, kUB= -118.2 st, kUC=  118.2 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=    5.7 kA, mI2=    5.7 kA, mI0=      0 kA
Katy:   kI1=  -89.8 st, kI2=   90.2 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   34.9 kV, mU2=   34.9 kV, mU0=      0 kV
Katy:   kU1=   -0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   9.87 kA, mIC=   9.87 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -179.8 st, kIC=    0.2 st
Napiecia - uklad ABC
Moduly: mUA=   69.9 kV, mUB=   34.9 kV, mUC=   34.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   7.74 kA, mI2=   3.66 kA, mI0=   4.07 kA
Katy:   kI1=  -89.8 st, kI2=   90.2 st, kI0=   90.2 st
Napiecia - uklad 012
Moduly: mU1=   22.4 kV, mU2=   22.4 kV, mU0=   22.4 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   11.6 kA, mIC=   11.6 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  148.5 st, kIC=   32.0 st
Napiecia - uklad ABC
Moduly: mUA=   67.3 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=    0.0 st, kUB= -161.6 st, kUC=  129.8 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: WEZ2-110kV   
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ2-110kV    11.40 kA (100.0%)   0.02   6.13   0.04 -11.40j
     od: WEZ1-110kV     5.86 kA ( 51.4%)   0.00   0.00   0.04  -5.86j
     od: W2             0.00 kA (  0.0%)   0.00   6.04   0.00   0.00j
     od: *T222          5.54 kA ( 48.6%)   0.00   5.94   0.00  -5.54j
 od zr.: WEZ2-110kV     0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: WEZ2-110kV   
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ2-110kV     3.93 kA (100.0%)   0.02   5.51   0.01  -3.93j
     od: WEZ1-110kV     2.17 kA ( 55.1%)   0.00   0.00   0.01  -2.17j
     od: W2             0.00 kA (  0.0%)   0.00  18.12   0.00   0.00j
     od: *T222          1.77 kA ( 44.9%)   0.00   5.94   0.00  -1.77j
 od zr.: WEZ2-110kV     0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00   0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  W2           - miejsce zwarcia ***
 ******************************************************
 Unk =     110 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =  63.509 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =  69.859 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.023 om, Xkk1 =  12.169 om - imp. zwar. skl.1
Xkk0 =   0.020 om, Xkk0 =  23.629 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     5.741 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =    1093.8 MVA
 Zwarcie 2-fazowe                      Ik2 =     4.972 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     3.527 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     5.274 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     5.277 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     4.369 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =     832.4 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.00
                       X0/X1 =  1.94
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   1.46 kA, mI2=   1.46 kA, mI0=   1.46 kA
Katy:   kI1=  -89.9 st, kI2=  -89.9 st, kI0=  -89.9 st
Napiecia - uklad 012
Moduly: mU1=   52.1 kV, mU2=   17.7 kV, mU0=   34.4 kV
Katy:   kU1=    0.0 st, kU2=  180.0 st, kU0= -180.0 st
Prady - uklad ABC
Moduly: mIA=   4.37 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -89.9 st, kIB=   26.6 st, kIC=   26.6 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=   79.6 kV, mUC=   79.5 kV
Katy:   kUA=   90.0 st, kUB= -130.5 st, kUC=  130.5 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   2.87 kA, mI2=   2.87 kA, mI0=      0 kA
Katy:   kI1=  -89.9 st, kI2=   90.1 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   34.9 kV, mU2=   34.9 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   4.97 kA, mIC=   4.97 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -179.9 st, kIC=    0.1 st
Napiecia - uklad ABC
Moduly: mUA=   69.9 kV, mUB=   34.9 kV, mUC=   34.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   3.46 kA, mI2=   2.28 kA, mI0=   1.18 kA
Katy:   kI1=  -89.9 st, kI2=   90.1 st, kI0=   90.1 st
Napiecia - uklad 012
Moduly: mU1=   27.8 kV, mU2=   27.8 kV, mU0=   27.8 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   5.27 kA, mIC=   5.28 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  160.6 st, kIC=   19.6 st
Napiecia - uklad ABC
Moduly: mUA=   83.3 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=    0.0 st, kUB=   71.6 st, kUC=   71.6 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: W2           
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: W2             5.74 kA (100.0%)   0.02  12.17   0.01  -5.74j
     od: WEZ2-110kV     5.74 kA (100.0%)   0.00   6.04   0.01  -5.74j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: W2           
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: W2             1.46 kA (100.0%)   0.02  23.63   0.00  -1.46j
     od: WEZ2-110kV     1.46 kA (100.0%)   0.00  18.12   0.00  -1.46j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00   0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  GPZ110kV     - miejsce zwarcia ***
 ******************************************************
 Unk =     110 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =  63.509 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =  69.859 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.090 om, Xkk1 =  11.657 om - imp. zwar. skl.1
Xkk0 =   0.310 om, Xkk0 =  14.485 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     5.993 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =    1141.8 MVA
 Zwarcie 2-fazowe                      Ik2 =      5.19 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     5.158 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     5.818 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     5.773 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     5.544 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =    1056.3 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.03
                       X0/X1 =  1.24
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   1.85 kA, mI2=   1.85 kA, mI0=   1.85 kA
Katy:   kI1=  -89.3 st, kI2=  -89.3 st, kI0=  -89.3 st
Napiecia - uklad 012
Moduly: mU1=   48.3 kV, mU2=   21.5 kV, mU0=   26.8 kV
Katy:   kU1=   -0.1 st, kU2= -179.7 st, kU0=  179.5 st
Prady - uklad ABC
Moduly: mIA=   5.54 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -89.3 st, kIB=   18.4 st, kIC=   18.4 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=   72.3 kV, mUC=   72.9 kV
Katy:   kUA= -178.7 st, kUB= -123.7 st, kUC=  123.4 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=      3 kA, mI2=      3 kA, mI0=      0 kA
Katy:   kI1=  -89.6 st, kI2=   90.4 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   34.9 kV, mU2=   34.9 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   5.19 kA, mIC=   5.19 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -179.6 st, kIC=    0.4 st
Napiecia - uklad ABC
Moduly: mUA=   69.9 kV, mUB=   34.9 kV, mUC=   34.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   3.86 kA, mI2=   2.14 kA, mI0=   1.72 kA
Katy:   kI1=  -89.4 st, kI2=   90.2 st, kI0=   91.0 st
Napiecia - uklad 012
Moduly: mU1=   24.9 kV, mU2=   24.9 kV, mU0=   24.9 kV
Katy:   kU1=   -0.2 st, kU2=   -0.2 st, kU0=   -0.2 st
Prady - uklad ABC
Moduly: mIB=   5.82 kA, mIC=   5.77 kA, mIA=      0 kA
Katy:   kIA=  180.0 st, kIB=  154.1 st, kIC=   27.0 st
Napiecia - uklad ABC
Moduly: mUA=   74.7 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=   -0.2 st, kUB= -166.0 st, kUC=  128.7 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: GPZ110kV     
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: GPZ110kV       5.99 kA (100.0%)   0.09  11.66   0.05  -5.99j
     od: WEZ1-110kV     5.66 kA ( 94.4%)   0.00   6.04   0.00  -5.66j
     od: *T1            0.34 kA (  5.7%)   1.03  18.60   0.05  -0.34j
 od zr.: GPZ110kV       0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: GPZ110kV     
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: GPZ110kV       1.85 kA (100.0%)   0.31  14.48   0.02  -1.85j
     od: WEZ1-110kV     1.10 kA ( 59.7%)   0.00  18.12  -0.01  -1.10j
     od: *T1            0.74 kA ( 40.3%)   1.03  18.60   0.03  -0.74j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00  -0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  GPZ10kV      - miejsce zwarcia ***
 ******************************************************
 Unk =      10 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =   5.774 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =   6.351 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.024 om, Xkk1 =   0.350 om - imp. zwar. skl.1
Rkk0 =     inf     , Xkk0 =     inf      - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     18.09 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =     313.3 MVA
 Zwarcie 2-fazowe                      Ik2 =     15.66 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =         0 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     15.66 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     15.66 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =         0 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =       0.0 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =   inf  PN izolowany
                       X0/X1 =   inf  PN izolowany
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=      0 kA, mI2=      0 kA, mI0=      0 kA
Katy:   kI1=    0.0 st, kI2=    0.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   6.35 kV, mU2=      0 kV, mU0=   6.35 kV
Katy:   kU1=   -0.0 st, kU2=    0.0 st, kU0=  180.0 st
Prady - uklad ABC
Moduly: mIB=      0 kA, mIC=      0 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=    0.0 st, kIC=    0.0 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=     11 kV, mUC=     11 kV
Katy:   kUA=   40.8 st, kUB= -150.0 st, kUC=  150.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   9.04 kA, mI2=   9.04 kA, mI0=      0 kA
Katy:   kI1=  -86.1 st, kI2=   93.9 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   3.18 kV, mU2=   3.18 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   15.7 kA, mIC=   15.7 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -176.1 st, kIC=    3.9 st
Napiecia - uklad ABC
Moduly: mUA=   6.35 kV, mUB=   3.18 kV, mUC=   3.18 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   9.04 kA, mI2=   9.04 kA, mI0=      0 kA
Katy:   kI1=  -86.1 st, kI2=   93.9 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   3.18 kV, mU2=   3.18 kV, mU0=   3.18 kV
Katy:   kU1=   -0.0 st, kU2=   -0.0 st, kU0=   -0.2 st
Prady - uklad ABC
Moduly: mIB=   15.7 kA, mIC=   15.7 kA, mIA=      0 kA
Katy:   kIA=  -45.2 st, kIB= -176.1 st, kIC=    3.9 st
Napiecia - uklad ABC
Moduly: mUA=   9.53 kV, mUB=0.00965 kV, mUC=0.00965 kV
Katy:   kUA=   -0.1 st, kUB=  -72.7 st, kUC=  -72.7 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: GPZ10kV      
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: GPZ10kV       18.09 kA (100.0%)   0.02   0.35   1.22 -18.05j
     od: RO             0.35 kA (  2.0%)   1.49   1.11   0.07  -0.35j
     od: *T1           14.00 kA ( 77.4%)   0.01   0.17   0.58 -13.98j
 od zr.: GPZ10kV        3.76 kA ( 20.8%)   0.25   1.67   0.56  -3.71j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00   0.00j
 -------------------------------------------------------------------
 ... izolowany punkt neutralny w tym wezle ...


 ******************************************************
 ***  RO           - miejsce zwarcia ***
 ******************************************************
 Unk =      10 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =   5.774 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =   6.351 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   1.272 om, Xkk1 =   1.427 om - imp. zwar. skl.1
Rkk0 =     inf     , Xkk0 =     inf      - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     3.322 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =      57.5 MVA
 Zwarcie 2-fazowe                      Ik2 =     2.877 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =         0 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     2.877 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     2.877 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =         0 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =       0.0 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =   inf  PN izolowany
                       X0/X1 =   inf  PN izolowany
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=      0 kA, mI2=      0 kA, mI0=      0 kA
Katy:   kI1=    0.0 st, kI2=    0.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   6.35 kV, mU2=      0 kV, mU0=   6.35 kV
Katy:   kU1=   -0.0 st, kU2=    0.0 st, kU0=  180.0 st
Prady - uklad ABC
Moduly: mIB=      0 kA, mIC=      0 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=    0.0 st, kIC=    0.0 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=     11 kV, mUC=     11 kV
Katy:   kUA=    3.2 st, kUB= -150.0 st, kUC=  150.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   1.66 kA, mI2=   1.66 kA, mI0=      0 kA
Katy:   kI1=  -48.3 st, kI2=  131.7 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   3.18 kV, mU2=   3.18 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   2.88 kA, mIC=   2.88 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -138.3 st, kIC=   41.7 st
Napiecia - uklad ABC
Moduly: mUA=   6.35 kV, mUB=   3.18 kV, mUC=   3.18 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   1.66 kA, mI2=   1.66 kA, mI0=      0 kA
Katy:   kI1=  -48.3 st, kI2=  131.7 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   3.18 kV, mU2=   3.18 kV, mU0=   3.18 kV
Katy:   kU1=   -0.0 st, kU2=   -0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   2.88 kA, mIC=   2.88 kA, mIA=      0 kA
Katy:   kIA=  -45.0 st, kIB= -138.3 st, kIC=   41.7 st
Napiecia - uklad ABC
Moduly: mUA=   9.53 kV, mUB=0.00492 kV, mUC=0.00492 kV
Katy:   kUA=    0.0 st, kUB=    8.8 st, kUC=    8.8 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: RO           
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: RO             3.32 kA (100.0%)   1.27   1.43   2.21  -2.48j
     od: GPZ10kV        3.01 kA ( 90.7%)   1.49   1.11   2.16  -2.10j
     od: *T2            0.38 kA ( 11.5%)   0.16   1.80   0.05  -0.38j
 od zr.: RO             0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00   0.00j
 -------------------------------------------------------------------
 ... izolowany punkt neutralny w tym wezle ...


 ******************************************************
 ***  silnik       - miejsce zwarcia ***
 ******************************************************
 Unk =   0.525 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =   0.303 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.00    - wsp. obliczen zwarciowych
  E1 =   0.303 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.003 om, Xkk1 =   0.009 om - imp. zwar. skl.1
Xkk0 =   0.001 om, Xkk0 =   0.009 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     31.69 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =      28.8 MVA
 Zwarcie 2-fazowe                      Ik2 =     27.44 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     33.86 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =      30.3 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     34.08 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     32.81 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =      29.8 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.08
                       X0/X1 =  0.95
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   10.9 kA, mI2=   10.9 kA, mI0=   10.9 kA
Katy:   kI1=  -77.1 st, kI2=  -77.1 st, kI0=  -77.1 st
Napiecia - uklad 012
Moduly: mU1=  0.199 kV, mU2=  0.105 kV, mU0= 0.0952 kV
Katy:   kU1=    1.9 st, kU2=  176.4 st, kU0= -172.0 st
Prady - uklad ABC
Moduly: mIA=   32.8 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -77.1 st, kIB=   26.6 st, kIC=   32.0 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=  0.316 kV, mUC=  0.281 kV
Katy:   kUA=  148.0 st, kUB= -116.6 st, kUC=  120.2 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   15.8 kA, mI2=   15.8 kA, mI0=      0 kA
Katy:   kI1=  -73.5 st, kI2=  106.5 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=  0.152 kV, mU2=  0.152 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   27.4 kA, mIC=   27.4 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -163.5 st, kIC=   16.5 st
Napiecia - uklad ABC
Moduly: mUA=  0.303 kV, mUB=  0.152 kV, mUC=  0.152 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   21.5 kA, mI2=   10.3 kA, mI0=   11.3 kA
Katy:   kI1=  -75.5 st, kI2=  110.6 st, kI0=   99.0 st
Napiecia - uklad 012
Moduly: mU1= 0.0983 kV, mU2= 0.0983 kV, mU0= 0.0983 kV
Katy:   kU1=    4.1 st, kU2=    4.1 st, kU0=    4.1 st
Prady - uklad ABC
Moduly: mIB=   30.3 kA, mIC=   34.1 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  162.9 st, kIC=   46.0 st
Napiecia - uklad ABC
Moduly: mUA=  0.295 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=    4.1 st, kUB=   63.4 st, kUC=   14.0 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: silnik       
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: silnik        31.69 kA (100.0%)   0.00   0.01   9.01 -30.38j
     od: *T2           22.45 kA ( 70.8%)   0.00   0.00   7.62 -21.12j
 od zr.: silnik         9.37 kA ( 29.6%)   0.00   0.03   1.39  -9.26j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00  -0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: silnik       
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: silnik        10.94 kA (100.0%)   0.00   0.01   2.44 -10.66j
     od: *T2           10.94 kA (100.0%)   0.00   0.00   2.44 -10.66j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00  -0.00j
 -------------------------------------------------------------------