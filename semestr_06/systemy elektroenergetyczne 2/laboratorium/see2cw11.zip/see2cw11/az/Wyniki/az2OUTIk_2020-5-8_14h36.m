
 ANALIZA ZWARC W SIECI SKUTECZNIE UZIEMIONEJ

*** E:\OneDrive - Politechnika Wroclawska\studia\Systemy elektroenergetyczne 2\lab\see2cw11\az\Wyniki\az2OUTIk_2020-5-8_14h36.m 
- zbiorcze wyniki analizy zwarc 3-f i 1-fz ***

 Data:  2020- 5- 8  o'clock 14h, 36min, 43s
 az: a-analiza z-warc
% - dane par. zwarciowych w m-pliku    na poziomie UNS
% - po przeczytaniu dane przeliczone   na poziom UNSobl
% - m. admitancyjna    Y1,   Y0 w [S]  na poziomie UNSobl
% - imp. zwar. Thev. Zkk1, Zkk0 w [om] na poziomie UNSobl
% - prady zw. 3-f, 2-f, 2-fz, 1-fz     na poziomie UNS 
 Izw3f i Izw1f odniesione do nap. znam. UNS w miejscu zwarcia
   Wez.         UNS    Szw3f    Szw1f    Izw3f    Izw1f  X0X1 R0X1 SkutUz
     -           kV      MVA      MVA       kA       kA   -    -       - 
  WEZ1-220kV    220  16492.8  14300.1    43.28    37.53  1.5  0.0      -     
  WEZ2-220kV    220  16492.8  14300.1    43.28    37.53  1.5  0.0      -     
  WEZ1-110kV    110   2171.7   2247.4    11.40    11.80  0.9  0.0     NIE     
  WEZ2-110kV    110   2171.7   2247.4    11.40    11.80  0.9  0.0     NIE     
          W2    110   1093.8    832.4     5.74     4.37  1.9  0.0      -     
    GPZ110kV    110   1141.8   1056.3     5.99     5.54  1.2  0.0      -     
     GPZ10kV     10    313.3      0.0    18.09     0.00  inf  inf PNizol.
          RO     10     57.5      0.0     3.32     0.00  inf  inf PNizol.
      silnik  0.525     28.8     29.8    31.69    32.81  0.9  0.1      nN