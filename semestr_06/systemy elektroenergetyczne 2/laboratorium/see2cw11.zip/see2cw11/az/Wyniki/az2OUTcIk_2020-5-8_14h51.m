
 ANALIZA ZWARC W SIECI SKUTECZNIE UZIEMIONEJ

*** E:\OneDrive - Politechnika Wroclawska\studia\Systemy elektroenergetyczne 2\lab\see2cw11\az\Wyniki\az2OUTcIk_2020-5-8_14h51.m 
- analiza zwarc w ukl. 012 oraz ABC ***

 Data:  2020- 5- 8  o'clock 14h, 51min, 41s
 az: a-analiza z-warc
% - dane par. zwarciowych w m-pliku    na poziomie UNS
% - po przeczytaniu dane przeliczone   na poziom UNSobl
% - m. admitancyjna    Y1,   Y0 w [S]  na poziomie UNSobl
% - imp. zwar. Thev. Zkk1, Zkk0 w [om] na poziomie UNSobl
% - prady zw. 3-f, 2-f, 2-fz, 1-fz     na poziomie UNS 


 ******************************************************
 ***  WEZ1-220kV   - miejsce zwarcia ***
 ******************************************************
 Unk =     220 kV - nap. znam. sieci  w miejscu zwarcia
Unfk = 127.017 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 = 139.719 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.000 om, Xkk1 =   3.228 om - imp. zwar. skl.1
Xkk0 =   0.000 om, Xkk0 =   4.717 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     43.28 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =   16491.7 MVA
 Zwarcie 2-fazowe                      Ik2 =     37.48 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =      33.1 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     40.97 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     40.97 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     37.51 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =   14294.2 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.00
                       X0/X1 =  1.46
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   12.5 kA, mI2=   12.5 kA, mI0=   12.5 kA
Katy:   kI1=  -90.0 st, kI2=  -90.0 st, kI0=  -90.0 st
Napiecia - uklad 012
Moduly: mU1=   99.4 kV, mU2=   40.4 kV, mU0=     59 kV
Katy:   kU1=    0.0 st, kU2=  180.0 st, kU0= -180.0 st
Prady - uklad ABC
Moduly: mIA=   37.5 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -90.0 st, kIB=    9.5 st, kIC=    9.5 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=    150 kV, mUC=    150 kV
Katy:   kUA=   -0.0 st, kUB= -126.2 st, kUC=  126.2 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   21.6 kA, mI2=   21.6 kA, mI0=      0 kA
Katy:   kI1=  -90.0 st, kI2=   90.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   69.9 kV, mU2=   69.9 kV, mU0=      0 kV
Katy:   kU1=   -0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   37.5 kA, mIC=   37.5 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -180.0 st, kIC=    0.0 st
Napiecia - uklad ABC
Moduly: mUA=    140 kV, mUB=   69.9 kV, mUC=   69.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   27.2 kA, mI2=   16.1 kA, mI0=     11 kA
Katy:   kI1=  -90.0 st, kI2=   90.0 st, kI0=   90.0 st
Napiecia - uklad 012
Moduly: mU1=     52 kV, mU2=     52 kV, mU0=     52 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=     41 kA, mIC=     41 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  156.2 st, kIC=   23.8 st
Napiecia - uklad ABC
Moduly: mUA=    156 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=    0.0 st, kUB=   26.6 st, kUC=   71.6 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: WEZ1-220kV   
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ1-220kV    43.28 kA (100.0%)   0.00   3.23   0.00 -43.28j
     od: *T221          1.29 kA (  3.0%)   0.00  26.97   0.00  -1.29j
 od zr.: WEZ1-220kV    41.99 kA ( 97.0%)   0.00   3.33   0.00 -41.99j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: WEZ1-220kV   
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ1-220kV    12.50 kA (100.0%)   0.00   4.72   0.00 -12.50j
     od: *T221          0.69 kA (  5.5%)   0.00  26.97   0.00  -0.69j
 od zr.: WEZ1-220kV    11.82 kA ( 94.5%)   0.00   4.99   0.00 -11.82j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00   0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  WEZ2-220kV   - miejsce zwarcia ***
 ******************************************************
 Unk =     220 kV - nap. znam. sieci  w miejscu zwarcia
Unfk = 127.017 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 = 139.719 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.000 om, Xkk1 =   3.228 om - imp. zwar. skl.1
Xkk0 =   0.000 om, Xkk0 =   4.717 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     43.28 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =   16491.7 MVA
 Zwarcie 2-fazowe                      Ik2 =     37.48 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =      33.1 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     40.97 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     40.97 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     37.51 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =   14294.2 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.00
                       X0/X1 =  1.46
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   12.5 kA, mI2=   12.5 kA, mI0=   12.5 kA
Katy:   kI1=  -90.0 st, kI2=  -90.0 st, kI0=  -90.0 st
Napiecia - uklad 012
Moduly: mU1=   99.4 kV, mU2=   40.4 kV, mU0=     59 kV
Katy:   kU1=    0.0 st, kU2=  180.0 st, kU0= -180.0 st
Prady - uklad ABC
Moduly: mIA=   37.5 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -90.0 st, kIB=   26.6 st, kIC=   26.6 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=    150 kV, mUC=    150 kV
Katy:   kUA=    0.0 st, kUB= -126.2 st, kUC=  126.2 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   21.6 kA, mI2=   21.6 kA, mI0=      0 kA
Katy:   kI1=  -90.0 st, kI2=   90.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   69.9 kV, mU2=   69.9 kV, mU0=      0 kV
Katy:   kU1=   -0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   37.5 kA, mIC=   37.5 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -180.0 st, kIC=    0.0 st
Napiecia - uklad ABC
Moduly: mUA=    140 kV, mUB=   69.9 kV, mUC=   69.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   27.2 kA, mI2=   16.1 kA, mI0=     11 kA
Katy:   kI1=  -90.0 st, kI2=   90.0 st, kI0=   90.0 st
Napiecia - uklad 012
Moduly: mU1=     52 kV, mU2=     52 kV, mU0=     52 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=     41 kA, mIC=     41 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  156.2 st, kIC=   23.8 st
Napiecia - uklad ABC
Moduly: mUA=    156 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=    0.0 st, kUB=   82.9 st, kUC=   76.0 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: WEZ2-220kV   
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ2-220kV    43.28 kA (100.0%)   0.00   3.23   0.00 -43.28j
     od: *T222          1.29 kA (  3.0%)   0.00  26.97   0.00  -1.29j
 od zr.: WEZ2-220kV    41.99 kA ( 97.0%)   0.00   3.33   0.00 -41.99j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: WEZ2-220kV   
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ2-220kV    12.50 kA (100.0%)   0.00   4.72   0.00 -12.50j
     od: *T222          0.69 kA (  5.5%)   0.00  26.97   0.00  -0.69j
 od zr.: WEZ2-220kV    11.82 kA ( 94.5%)   0.00   4.99   0.00 -11.82j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00   0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  WEZ1-110kV   - miejsce zwarcia ***
 ******************************************************
 Unk =     110 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =  63.509 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =  69.859 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.020 om, Xkk1 =   6.143 om - imp. zwar. skl.1
Xkk0 =   0.011 om, Xkk0 =   5.652 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     11.37 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =    2166.7 MVA
 Zwarcie 2-fazowe                      Ik2 =     9.848 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     12.01 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     11.53 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     11.54 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     11.68 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =    2226.0 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.00
                       X0/X1 =  0.92 niespelnione
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   3.89 kA, mI2=   3.89 kA, mI0=   3.89 kA
Katy:   kI1=  -89.8 st, kI2=  -89.8 st, kI0=  -89.8 st
Napiecia - uklad 012
Moduly: mU1=   45.9 kV, mU2=   23.9 kV, mU0=     22 kV
Katy:   kU1=    0.0 st, kU2=  180.0 st, kU0= -180.0 st
Prady - uklad ABC
Moduly: mIA=   11.7 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -89.8 st, kIB=   18.4 st, kIC=   18.4 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=   68.9 kV, mUC=   68.9 kV
Katy:   kUA=  -90.0 st, kUB= -118.6 st, kUC=  118.6 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   5.69 kA, mI2=   5.69 kA, mI0=      0 kA
Katy:   kI1=  -89.8 st, kI2=   90.2 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   34.9 kV, mU2=   34.9 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   9.85 kA, mIC=   9.85 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -179.8 st, kIC=    0.2 st
Napiecia - uklad ABC
Moduly: mUA=   69.9 kV, mUB=   34.9 kV, mUC=   34.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   7.69 kA, mI2=   3.68 kA, mI0=      4 kA
Katy:   kI1=  -89.8 st, kI2=   90.2 st, kI0=   90.1 st
Napiecia - uklad 012
Moduly: mU1=   22.6 kV, mU2=   22.6 kV, mU0=   22.6 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   11.5 kA, mIC=   11.5 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  148.8 st, kIC=   31.6 st
Napiecia - uklad ABC
Moduly: mUA=   67.9 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=    0.0 st, kUB=   80.5 st, kUC=   80.5 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: WEZ1-110kV   
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ1-110kV    11.37 kA (100.0%)   0.02   6.14   0.04 -11.37j
     od: WEZ2-110kV     5.54 kA ( 48.7%)   0.00   0.00   0.00  -5.54j
     od: GPZ110kV       0.30 kA (  2.7%)   0.00   6.04   0.04  -0.30j
     od: *T221          5.54 kA ( 48.7%)   0.00   5.94   0.00  -5.54j
 od zr.: WEZ1-110kV     0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: WEZ1-110kV   
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ1-110kV     3.89 kA (100.0%)   0.01   5.65   0.01  -3.89j
     od: WEZ2-110kV     1.79 kA ( 46.1%)   0.00   0.00   0.00  -1.79j
     od: GPZ110kV       0.31 kA (  7.9%)   0.00  18.12   0.01  -0.31j
     od: *T221          1.79 kA ( 46.1%)   0.00   5.94   0.00  -1.79j
 od zr.: WEZ1-110kV     0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00  -0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  WEZ2-110kV   - miejsce zwarcia ***
 ******************************************************
 Unk =     110 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =  63.509 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =  69.859 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.020 om, Xkk1 =   6.143 om - imp. zwar. skl.1
Xkk0 =   0.011 om, Xkk0 =   5.652 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     11.37 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =    2166.7 MVA
 Zwarcie 2-fazowe                      Ik2 =     9.848 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     12.01 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     11.53 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     11.54 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     11.68 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =    2226.0 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.00
                       X0/X1 =  0.92 niespelnione
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   3.89 kA, mI2=   3.89 kA, mI0=   3.89 kA
Katy:   kI1=  -89.8 st, kI2=  -89.8 st, kI0=  -89.8 st
Napiecia - uklad 012
Moduly: mU1=   45.9 kV, mU2=   23.9 kV, mU0=     22 kV
Katy:   kU1=    0.0 st, kU2=  180.0 st, kU0= -180.0 st
Prady - uklad ABC
Moduly: mIA=   11.7 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -89.8 st, kIB=   18.4 st, kIC=   18.4 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=   68.9 kV, mUC=   68.9 kV
Katy:   kUA=  -90.0 st, kUB= -118.6 st, kUC=  118.6 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   5.69 kA, mI2=   5.69 kA, mI0=      0 kA
Katy:   kI1=  -89.8 st, kI2=   90.2 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   34.9 kV, mU2=   34.9 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   9.85 kA, mIC=   9.85 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -179.8 st, kIC=    0.2 st
Napiecia - uklad ABC
Moduly: mUA=   69.9 kV, mUB=   34.9 kV, mUC=   34.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   7.69 kA, mI2=   3.68 kA, mI0=      4 kA
Katy:   kI1=  -89.8 st, kI2=   90.2 st, kI0=   90.1 st
Napiecia - uklad 012
Moduly: mU1=   22.6 kV, mU2=   22.6 kV, mU0=   22.6 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   11.5 kA, mIC=   11.5 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  148.8 st, kIC=   31.6 st
Napiecia - uklad ABC
Moduly: mUA=   67.9 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  135.0 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: WEZ2-110kV   
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ2-110kV    11.37 kA (100.0%)   0.02   6.14   0.04 -11.37j
     od: WEZ1-110kV     5.84 kA ( 51.3%)   0.00   0.00   0.04  -5.84j
     od: W2             0.00 kA (  0.0%)   0.00   6.04   0.00   0.00j
     od: *T222          5.54 kA ( 48.7%)   0.00   5.94   0.00  -5.54j
 od zr.: WEZ2-110kV     0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: WEZ2-110kV   
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: WEZ2-110kV     3.89 kA (100.0%)   0.01   5.65   0.01  -3.89j
     od: WEZ1-110kV     2.10 kA ( 53.9%)   0.00   0.00   0.01  -2.10j
     od: W2             0.00 kA (  0.0%)   0.00  18.12   0.00   0.00j
     od: *T222          1.79 kA ( 46.1%)   0.00   5.94   0.00  -1.79j
 od zr.: WEZ2-110kV     0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00   0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  W2           - miejsce zwarcia ***
 ******************************************************
 Unk =     110 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =  63.509 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =  69.859 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.020 om, Xkk1 =  12.183 om - imp. zwar. skl.1
Xkk0 =   0.011 om, Xkk0 =  23.772 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     5.734 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =    1092.5 MVA
 Zwarcie 2-fazowe                      Ik2 =     4.966 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     3.509 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     5.265 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     5.268 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     4.354 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =     829.5 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.00
                       X0/X1 =  1.95
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   1.45 kA, mI2=   1.45 kA, mI0=   1.45 kA
Katy:   kI1=  -89.9 st, kI2=  -89.9 st, kI0=  -89.9 st
Napiecia - uklad 012
Moduly: mU1=   52.2 kV, mU2=   17.7 kV, mU0=   34.5 kV
Katy:   kU1=    0.0 st, kU2=  180.0 st, kU0= -180.0 st
Prady - uklad ABC
Moduly: mIA=   4.35 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -89.9 st, kIB=   14.0 st, kIC=   14.0 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=   79.6 kV, mUC=   79.6 kV
Katy:   kUA= -179.9 st, kUB= -130.5 st, kUC=  130.6 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   2.87 kA, mI2=   2.87 kA, mI0=      0 kA
Katy:   kI1=  -89.9 st, kI2=   90.1 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   34.9 kV, mU2=   34.9 kV, mU0=      0 kV
Katy:   kU1=   -0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   4.97 kA, mIC=   4.97 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -179.9 st, kIC=    0.1 st
Napiecia - uklad ABC
Moduly: mUA=   69.9 kV, mUB=   34.9 kV, mUC=   34.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   3.45 kA, mI2=   2.28 kA, mI0=   1.17 kA
Katy:   kI1=  -89.9 st, kI2=   90.1 st, kI0=   90.0 st
Napiecia - uklad 012
Moduly: mU1=   27.8 kV, mU2=   27.8 kV, mU0=   27.8 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   5.27 kA, mIC=   5.27 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  160.6 st, kIC=   19.5 st
Napiecia - uklad ABC
Moduly: mUA=   83.4 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=    0.0 st, kUB=   90.0 st, kUC=   90.0 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: W2           
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: W2             5.73 kA (100.0%)   0.02  12.18   0.01  -5.73j
     od: WEZ2-110kV     5.73 kA (100.0%)   0.00   6.04   0.01  -5.73j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: W2           
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: W2             1.45 kA (100.0%)   0.01  23.77   0.00  -1.45j
     od: WEZ2-110kV     1.45 kA (100.0%)   0.00  18.12   0.00  -1.45j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00   0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  GPZ110kV     - miejsce zwarcia ***
 ******************************************************
 Unk =     110 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =  63.509 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =  69.859 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.076 om, Xkk1 =  11.711 om - imp. zwar. skl.1
Xkk0 =   0.177 om, Xkk0 =  16.713 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     5.965 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =    1136.5 MVA
 Zwarcie 2-fazowe                      Ik2 =     5.166 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     4.643 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =      5.67 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     5.657 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     5.222 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =     994.9 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.02
                       X0/X1 =  1.43
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   1.74 kA, mI2=   1.74 kA, mI0=   1.74 kA
Katy:   kI1=  -89.5 st, kI2=  -89.5 st, kI0=  -89.5 st
Napiecia - uklad 012
Moduly: mU1=   49.5 kV, mU2=   20.4 kV, mU0=   29.1 kV
Katy:   kU1=   -0.0 st, kU2= -179.9 st, kU0=  179.9 st
Prady - uklad ABC
Moduly: mIA=   5.22 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -89.5 st, kIB=   26.6 st, kIC=   26.6 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=   74.5 kV, mUC=   74.7 kV
Katy:   kUA= -179.1 st, kUB= -125.8 st, kUC=  125.8 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   2.98 kA, mI2=   2.98 kA, mI0=      0 kA
Katy:   kI1=  -89.6 st, kI2=   90.4 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   34.9 kV, mU2=   34.9 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   5.17 kA, mIC=   5.17 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -179.6 st, kIC=    0.4 st
Napiecia - uklad ABC
Moduly: mUA=   69.9 kV, mUB=   34.9 kV, mUC=   34.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   3.76 kA, mI2=   2.21 kA, mI0=   1.55 kA
Katy:   kI1=  -89.6 st, kI2=   90.3 st, kI0=   90.5 st
Napiecia - uklad 012
Moduly: mU1=   25.9 kV, mU2=   25.9 kV, mU0=   25.9 kV
Katy:   kU1=   -0.1 st, kU2=   -0.1 st, kU0=   -0.1 st
Prady - uklad ABC
Moduly: mIB=   5.67 kA, mIC=   5.66 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  156.2 st, kIC=   24.6 st
Napiecia - uklad ABC
Moduly: mUA=   77.6 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=   -0.1 st, kUB=  164.1 st, kUC=  139.4 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: GPZ110kV     
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: GPZ110kV       5.97 kA (100.0%)   0.08  11.71   0.04  -5.97j
     od: WEZ1-110kV     5.66 kA ( 94.8%)   0.00   6.04   0.00  -5.66j
     od: *T1            0.31 kA (  5.2%)   1.00  28.06   0.04  -0.31j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: GPZ110kV     
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: GPZ110kV       1.74 kA (100.0%)   0.18  16.71   0.01  -1.74j
     od: WEZ1-110kV     1.20 kA ( 68.9%)   0.00  18.12  -0.00  -1.20j
     od: *T1            0.54 kA ( 31.1%)   1.00  28.06   0.02  -0.54j
 od zr.: GPZ110kV       0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00   0.00j
 -------------------------------------------------------------------


 ******************************************************
 ***  GPZ10kV      - miejsce zwarcia ***
 ******************************************************
 Unk =      10 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =   5.774 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =   6.351 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.029 om, Xkk1 =   0.446 om - imp. zwar. skl.1
Rkk0 =     inf     , Xkk0 =     inf      - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     14.22 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =     246.3 MVA
 Zwarcie 2-fazowe                      Ik2 =     12.31 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =         0 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     12.31 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     12.31 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =         0 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =       0.0 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =   inf  PN izolowany
                       X0/X1 =   inf  PN izolowany
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=      0 kA, mI2=      0 kA, mI0=      0 kA
Katy:   kI1=    0.0 st, kI2=    0.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   6.35 kV, mU2=      0 kV, mU0=   6.35 kV
Katy:   kU1=   -0.0 st, kU2=    0.0 st, kU0=  180.0 st
Prady - uklad ABC
Moduly: mIB=      0 kA, mIC=      0 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=    0.0 st, kIC=    0.0 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=     11 kV, mUC=     11 kV
Katy:   kUA=   41.0 st, kUB= -150.0 st, kUC=  150.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   7.11 kA, mI2=   7.11 kA, mI0=      0 kA
Katy:   kI1=  -86.3 st, kI2=   93.7 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   3.18 kV, mU2=   3.18 kV, mU0=      0 kV
Katy:   kU1=   -0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   12.3 kA, mIC=   12.3 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -176.3 st, kIC=    3.7 st
Napiecia - uklad ABC
Moduly: mUA=   6.35 kV, mUB=   3.18 kV, mUC=   3.18 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   7.11 kA, mI2=   7.11 kA, mI0=      0 kA
Katy:   kI1=  -86.3 st, kI2=   93.7 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   3.18 kV, mU2=   3.18 kV, mU0=   3.16 kV
Katy:   kU1=   -0.0 st, kU2=   -0.0 st, kU0=    0.1 st
Prady - uklad ABC
Moduly: mIB=   12.3 kA, mIC=   12.3 kA, mIA=      0 kA
Katy:   kIA=  -44.9 st, kIB= -176.3 st, kIC=    3.7 st
Napiecia - uklad ABC
Moduly: mUA=   9.51 kV, mUB= 0.0149 kV, mUC= 0.0149 kV
Katy:   kUA=    0.0 st, kUB=  155.4 st, kUC=  155.4 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: GPZ10kV      
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: GPZ10kV       14.22 kA (100.0%)   0.03   0.45   0.93 -14.19j
     od: RO             0.35 kA (  2.5%)   1.49   1.11   0.07  -0.35j
     od: *T1           10.13 kA ( 71.3%)   0.01   0.26   0.30 -10.13j
 od zr.: GPZ10kV        3.76 kA ( 26.4%)   0.25   1.67   0.56  -3.71j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00  -0.00j
 -------------------------------------------------------------------
 ... izolowany punkt neutralny w tym wezle ...


 ******************************************************
 ***  RO           - miejsce zwarcia ***
 ******************************************************
 Unk =      10 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =   5.774 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =   6.351 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   1.265 om, Xkk1 =   1.508 om - imp. zwar. skl.1
Rkk0 =     inf     , Xkk0 =     inf      - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     3.226 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =      55.9 MVA
 Zwarcie 2-fazowe                      Ik2 =     2.794 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =         0 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     2.794 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     2.794 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =         0 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =       0.0 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =   inf  PN izolowany
                       X0/X1 =   inf  PN izolowany
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=      0 kA, mI2=      0 kA, mI0=      0 kA
Katy:   kI1=    0.0 st, kI2=    0.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   6.35 kV, mU2=      0 kV, mU0=   6.35 kV
Katy:   kU1=   -0.0 st, kU2=    0.0 st, kU0=  180.0 st
Prady - uklad ABC
Moduly: mIB=      0 kA, mIC=      0 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=    0.0 st, kIC=    0.0 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=     11 kV, mUC=     11 kV
Katy:   kUA=    5.0 st, kUB= -150.0 st, kUC=  150.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   1.61 kA, mI2=   1.61 kA, mI0=      0 kA
Katy:   kI1=  -50.0 st, kI2=  130.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   3.18 kV, mU2=   3.18 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   2.79 kA, mIC=   2.79 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -140.0 st, kIC=   40.0 st
Napiecia - uklad ABC
Moduly: mUA=   6.35 kV, mUB=   3.18 kV, mUC=   3.18 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   1.61 kA, mI2=   1.61 kA, mI0=      0 kA
Katy:   kI1=  -50.0 st, kI2=  130.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   3.18 kV, mU2=   3.18 kV, mU0=   3.17 kV
Katy:   kU1=   -0.0 st, kU2=   -0.0 st, kU0=   -0.0 st
Prady - uklad ABC
Moduly: mIB=   2.79 kA, mIC=   2.79 kA, mIA=      0 kA
Katy:   kIA=  -45.1 st, kIB= -140.0 st, kIC=   40.0 st
Napiecia - uklad ABC
Moduly: mUA=   9.53 kV, mUB=0.00167 kV, mUC=0.00167 kV
Katy:   kUA=   -0.0 st, kUB= -132.0 st, kUC= -132.0 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: RO           
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: RO             3.23 kA (100.0%)   1.27   1.51   2.07  -2.47j
     od: GPZ10kV        2.91 kA ( 90.2%)   1.49   1.11   2.02  -2.09j
     od: *T2            0.38 kA ( 11.9%)   0.16   1.80   0.05  -0.38j
 od zr.: RO             0.00 kA (  0.0%)    inf    inf   0.00   0.00j
... kontrolna suma pradow galeziowych w wezle, sumaI =  -0.00   0.00j
 -------------------------------------------------------------------
 ... izolowany punkt neutralny w tym wezle ...


 ******************************************************
 ***  silnik       - miejsce zwarcia ***
 ******************************************************
 Unk =   0.525 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =   0.303 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.00    - wsp. obliczen zwarciowych
  E1 =   0.303 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.003 om, Xkk1 =   0.009 om - imp. zwar. skl.1
Xkk0 =   0.001 om, Xkk0 =   0.009 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     31.31 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =      28.5 MVA
 Zwarcie 2-fazowe                      Ik2 =     27.11 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     33.71 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     30.04 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =      33.7 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     32.53 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =      29.6 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.08
                       X0/X1 =  0.93
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   10.8 kA, mI2=   10.8 kA, mI0=   10.8 kA
Katy:   kI1=  -77.3 st, kI2=  -77.3 st, kI0=  -77.3 st
Napiecia - uklad 012
Moduly: mU1=  0.198 kV, mU2=  0.105 kV, mU0= 0.0944 kV
Katy:   kU1=    1.9 st, kU2=  176.5 st, kU0= -172.1 st
Prady - uklad ABC
Moduly: mIA=   32.5 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -77.3 st, kIB=   26.6 st, kIC=   20.6 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=  0.315 kV, mUC=  0.281 kV
Katy:   kUA=   90.0 st, kUB= -116.5 st, kUC=  120.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   15.7 kA, mI2=   15.7 kA, mI0=      0 kA
Katy:   kI1=  -73.7 st, kI2=  106.3 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=  0.152 kV, mU2=  0.152 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=   -0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   27.1 kA, mIC=   27.1 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -163.7 st, kIC=   16.3 st
Napiecia - uklad ABC
Moduly: mUA=  0.303 kV, mUB=  0.152 kV, mUC=  0.152 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   21.2 kA, mI2=   10.1 kA, mI0=   11.2 kA
Katy:   kI1=  -75.7 st, kI2=  110.3 st, kI0=   98.9 st
Napiecia - uklad 012
Moduly: mU1= 0.0979 kV, mU2= 0.0979 kV, mU0= 0.0979 kV
Katy:   kU1=    4.1 st, kU2=    4.1 st, kU0=    4.1 st
Prady - uklad ABC
Moduly: mIB=     30 kA, mIC=   33.7 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  162.4 st, kIC=   46.0 st
Napiecia - uklad ABC
Moduly: mUA=  0.294 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=    4.1 st, kUB=   90.0 st, kUC=    0.0 st
 --------------------------------------------------------------------
 Rozplyw pradow I1 w miejscu zwarcia 3-f: silnik       
 --------------------------------------------------------------------
 --------------------------------------------------------------------
 Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA
 --------------------------------------------------------------------
Zwarcie: silnik        31.31 kA (100.0%)   0.00   0.01   8.76 -30.05j
     od: *T2           22.06 kA ( 70.5%)   0.00   0.00   7.37 -20.79j
 od zr.: silnik         9.37 kA ( 29.9%)   0.00   0.03   1.39  -9.26j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00   0.00j
 -------------------------------------------------------------------
 --------------------------------------------------------------------
 Rozplyw pradow I0 w miejscu zwarcia 1-fz: silnik       
 Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA
 --------------------------------------------------------------------
Zwarcie: silnik        10.84 kA (100.0%)   0.00   0.01   2.39 -10.58j
     od: *T2           10.84 kA (100.0%)   0.00   0.00   2.39 -10.58j
... kontrolna suma pradow galeziowych w wezle, sumaI =   0.00  -0.00j
 -------------------------------------------------------------------