function az2suz
% Funkcja analizy zwarc symetrycznych i niesymetrycznych
% w sieciach skutecznie uziemionych:
% - czyta dane zwarciowe sici z pliku wybranego w oknie dialogowym
% - tworzy macierz admitancyjna zwarciowa  Y1, Y0
% - wyznacza impedancje zwarciowe wezlow Thevenina Zkk1, Zkk0
% - oblicza prady i moce zwarc 3-f, 2-f, 2fz, 1-fz
t0=clock; % czas rozpoczecia obliczen
rok=int2str(t0(1));miesiac=int2str(t0(2));dzien=int2str(t0(3));
godz=int2str(t0(4));mins=int2str(t0(5));secs=int2str(t0(6));
czas=['_' rok '-' miesiac '-' dzien '_' godz 'h' mins];
sciezka0=pwd; cd([sciezka0 '\Wyniki']); sciezka1=pwd;
plikIk= strcat([sciezka1 '\az2OUTIk',czas,'.m']);
plikcIk= strcat([sciezka1 '\az2OUTcIk',czas,'.m']);
fd=fopen(plikIk,'wt');% plik na prady zw 3-f i 1-f
fdzns=fopen(plikcIk,'wt');% plik na wyniki w ukl. 012 oraz ABC
cd ..
fprintf(fd,'\n ANALIZA ZWARC W SIECI SKUTECZNIE UZIEMIONEJ\n');
fprintf(fd,...
'\n*** %s \n- zbiorcze wyniki analizy zwarc 3-f i 1-fz ***\n',...
plikIk);
fprintf(fdzns,'\n ANALIZA ZWARC W SIECI SKUTECZNIE UZIEMIONEJ\n');
fprintf(fdzns,...
'\n*** %s \n- analiza zwarc w ukl. 012 oraz ABC ***\n',plikcIk);
fprintf(fd,...
'\n Data: %5d-%2d-%2d  o''clock %2dh, %2dmin, %2.0fs',t0);
fprintf(fdzns,...
'\n Data: %5d-%2d-%2d  o''clock %2dh, %2dmin, %2.0fs',t0);
fprintf(fd,   '\n az: a-analiza z-warc');
fprintf(fd,...
'\n%% - dane par. zwarciowych w m-pliku    na poziomie UNS');
fprintf(fd,...
'\n%% - po przeczytaniu dane przeliczone   na poziom UNSobl');
fprintf(fd,...
'\n%% - m. admitancyjna    Y1,   Y0 w [S]  na poziomie UNSobl');
fprintf(fd,...
'\n%% - imp. zwar. Thev. Zkk1, Zkk0 w [om] na poziomie UNSobl');
fprintf(fd,...
'\n%% - prady zw. 3-f, 2-f, 2-fz, 1-fz     na poziomie UNS ');
fprintf(fdzns,   '\n az: a-analiza z-warc');
fprintf(fdzns,...
'\n%% - dane par. zwarciowych w m-pliku    na poziomie UNS');
fprintf(fdzns,...
'\n%% - po przeczytaniu dane przeliczone   na poziom UNSobl');
fprintf(fdzns,...
'\n%% - m. admitancyjna    Y1,   Y0 w [S]  na poziomie UNSobl');
fprintf(fdzns,...
'\n%% - imp. zwar. Thev. Zkk1, Zkk0 w [om] na poziomie UNSobl');
fprintf(fdzns,...
'\n%% - prady zw. 3-f, 2-f, 2-fz, 1-fz     na poziomie UNS ');
% czytanie danych do obl. zwarciowych z tablic komorkowych
[nazwez,wezly,nazgal,gal,UNSobl,winf]=az2read;
fprintf('\n ... przeczytano dane do analizy zwarc ...');
j=sqrt(-1); % operator liczby zespolonej
% wstepna obrobka danych
[n,mw]=size(wezly); % wymiary tablicy danych wezlowych
[nbr,mbr]=size(gal);% wymiary tablicy danych galeziowych
wp=gal(:,1);   wk=gal(:,2); % poczatki i konce galezi
rgal1=gal(:,4); xgal1=gal(:,5); % R1,X1 galezi
zgal1=rgal1+j*xgal1; ygal1=1./zgal1;
ggal1=real(ygal1); bgal1=imag(ygal1); % G1,B1 galezi
rgal0=gal(:,6); xgal0=gal(:,7); % R0,X0 galezi
zgal0=rgal0+j*xgal0; ygal0=1./zgal0;
ggal0=real(ygal0); bgal0=imag(ygal0); % G0,B0 galezi
% macierz admitancji zwarciowych dla skl. 1
[Y1]=az2mYs(fd,UNSobl,n,nbr,wp,wk,ggal1,bgal1);
% macierz admitancji zwarciowych dla skl. 0
[Y0]=az2mYs(fd,UNSobl,n,nbr,wp,wk,ggal0,bgal0);
fprintf('\n ... wyznaczono m. admitancji dla skl. 1 oraz 0 ...');
% Analiza zwarc 3-f, 2-f, 2-fz, 1-fz 
iwezIz=0;
for k=1:n
  knazwa=nazwez(k,:);   UNS=wezly(k,2);
  tN=wezly(k,3); tN2=tN^2;
  %wektor impedancji dla k-tego wezla - skl. 1 na poziomie UNS
  vec1=zeros(n,1); vec1(k,1)=1; % 1 na pozycji wezla ze zwarciem
  zveck1=Y1\vec1/tN2; yveck1=Y1(:,k)*tN2; % kolumna m. Z1 i Y1
  %wektor impedancji dla k-tego wezla - skl. 0 na poziomie UNS
  vec0=zeros(n,1); vec0(k,1)=1; 
  zveck0=Y0\vec0/tN2; yveck0=Y0(:,k)*tN2; % kolumna m. Z0 i Y0
  % obliczanie zwarc w wezle: k, knazwa
  drukIz=1; % sterowanie wydrukiem w ukl. 012 oraz ABC
  % funkcja az2Iz() analizuje zwarcie w ukl. 012 oraz ABC
  [Szw3f,Szw1f,Izw3f,Izw1f,R0X1,X0X1,cIzw,drukIz]=...
  az2Iz(fdzns,nazwez,k,knazwa,UNS,zveck1,yveck1,zveck0,yveck0);
  if drukIz % zapamietanie zbiorczych wynikow analizy
   iwezIz=iwezIz+1; 
   nazwezIz(iwezIz,:)=knazwa; %nazwa k-tego wezla
   tabIz(iwezIz,1)=UNS;  %nap. znam. sieci w k-tym wezle 
   tabIz(iwezIz,2)=Szw3f;%moc zwarciowa zwarcia 3-f
   tabIz(iwezIz,3)=Szw1f;%moc zwarciowa zwarcia 1-fz
   tabIz(iwezIz,4)=Izw3f;%prad zwarciowy poczatkowy zwarcia 3-f
   tabIz(iwezIz,5)=Izw1f;%prad zwarciowy poczatkowy zwarcia 1-f 
   tabIz(iwezIz,6)=X0X1; %wsp. skut. uziemienia PN
   tabIz(iwezIz,7)=R0X1; %wsp. skut. uziemienia PN
   tabIz(iwezIz,8)=cIzw; %wsp. obliczen zwarciowych
  end %if drukIz
end %for k=1:n
%
% druk wynikow do sprawdzania skutecznosci zerowania
fprintf(fd,...
'\n Izw3f i Izw1f odniesione do nap. znam. UNS w miejscu zwarcia');
fprintf(fd,...
'\n   Wez.         UNS    Szw3f    Szw1f    Izw3f    Izw1f  X0X1 R0X1 SkutUz');
fprintf(fd,...
'\n     -           kV      MVA      MVA       kA       kA   -    -       - ');
fprintf(...
'\n Izw3f i Izw1f odniesione do nap. znam. UNS w miejscu zwarcia');
fprintf(...
'\n   Wez.         UNS    Szw3f    Szw1f    Izw3f    Izw1f  X0X1 R0X1 SkutUz');
fprintf(...
'\n     -           kV      MVA      MVA       kA       kA   -    -       - ');
nwezrozp=size(tabIz,1);
for iwezrozp=1:iwezIz
 knazwa=nazwezIz(iwezrozp,:);  nazwak=deblank(knazwa);
 Unk=   tabIz(iwezrozp,1); % nap. znam. sieci 
 Szw3f= tabIz(iwezrozp,2);   Szw1f= tabIz(iwezrozp,3);
 Izw3f= tabIz(iwezrozp,4);  Izw1f= tabIz(iwezrozp,5);
 X0X1 = tabIz(iwezrozp,6);  R0X1 = tabIz(iwezrozp,7);
 PNuziem=1; if X0X1>1e3 PNuziem=0; end
 PNizol=' inf';  ZNinf=' PNizol.';
 if PNuziem
  fprintf(fd,'\n%12s %6.4g %8.1f %8.1f %8.2f %8.2f %4.1f %4.1f',...
                 nazwak,Unk,Szw3f,Szw1f,Izw3f,Izw1f,X0X1,R0X1');
  fprintf(   '\n%12s %6.4g %8.1f %8.1f %8.2f %8.2f %4.1f %4.1f',...
                 nazwak,Unk,Szw3f,Szw1f,Izw3f,Izw1f,X0X1,R0X1');
  tak='      -     ';  nie='     NIE     '; 
  odp=tak;
  if Unk==400  & (X0X1<1.0 | X0X1>2.0) odp=nie; end  
  if Unk==220  & (X0X1<1.0 | X0X1>2.0) odp=nie; end
  if Unk==110  & (X0X1<1.0 | X0X1>3.0) odp=nie; end 
  if Unk<110   & Unk>1  odp='    SN'; end
  if Unk<1  odp='    nN'; end
  fprintf(fd,'%8s',odp); 
  fprintf(   '%8s',odp); 
 else
   fprintf(fd,'\n%12s %6.4g %8.1f %8.1f %8.2f %8.2f %4s %4s',...
                 nazwak,Unk,Szw3f,Szw1f,Izw3f,Izw1f, PNizol, PNizol');
  fprintf(   '\n%12s %6.4g %8.1f %8.1f %8.2f %8.2f %4s %4s',...
                 nazwak,Unk,Szw3f,Szw1f,Izw3f,Izw1f, PNizol, PNizol');
  odp=ZNinf;
  fprintf(fd,'%8s',odp); 
  fprintf(   '%8s',odp); 
 end %PNuziem
end % for i=1:nwezrozp
fprintf('\n\nWyniki analizy zwarc zapisano w plikach tekstowych:'); 
fprintf('\n\n%-25s - rozplyw pradow w wezle',plikcIk);
fprintf('\n\n%-25s - prady i moce zw. 3-f i 1-f, skutUzPN',plikIk);
fclose('all');
end % koniec az2suz.m

