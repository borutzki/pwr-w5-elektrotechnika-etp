function az2Iki(fd,k,knazwa,Zkks,Izw,Is,yvecks,zvecks,nazwez)
nw=length(yvecks); cinf='inf';
udzial=100; Rkk=real(Zkks); Xkk=imag(Zkks); 
if abs(Xkk)>99999.
    Izw=0; Is=0;
fprintf(fd,...
'\nZwarcie: %12s %6.2f kA (%5.1f%%) %6s %6s %6.2f %6.2fj',...
    knazwa,Izw,udzial,cinf,cinf,real(Is),imag(Is) );
else
fprintf(fd,...
'\nZwarcie: %12s %6.2f kA (%5.1f%%) %6.2f %6.2f %6.2f %6.2fj',...
        knazwa,Izw,udzial,Rkk,Xkk,real(Is),imag(Is) );    
end
Ika=real(Is); Ikb=imag(Is);
yGk=full(yvecks(k)); sumI=-Is;
for i=1:nw
  yiks=full(yvecks(i));  my=abs(yiks);
  if my & abs(i-k)
    nazi=nazwez(i,:); yGk=yGk+yiks;
    Ziks=zvecks(i,1);  Zgal=-1/yiks; Rgal=real(Zgal);
    Iiks=(Ziks-Zkks)*Is*(yiks);
    mIiks=abs(Iiks); udzial=0;
    if mIiks>1e-4 udzial=mIiks/Izw*100; end
    Xgal=imag(Zgal);
    if abs(Rgal)>99999. | abs(Xgal)>99999.
      Iiks=0; mIiks=0; udzial=0;
      fprintf(fd,...
'\n     od: %12s %6.2f kA (%5.1f%%) %6s %6s %6.2f %6.2fj',...
                nazi,mIiks,udzial,cinf,cinf,real(Iiks),imag(Iiks));           
    else
      fprintf(fd,...
'\n     od: %12s %6.2f kA (%5.1f%%) %6.2f %6.2f %6.2f %6.2fj',...
      nazi,mIiks,udzial,Rgal,Xgal,real(Iiks),imag(Iiks));
    end
  sumI=sumI+Iiks;
  end  % if my & abs(i-k)
end %for ii=1:nw
myGk=abs(yGk); IGk=Zkks*Is*yGk;  mIGk=abs(IGk); 
udzial=0; if Izw>1e-5 udzial=mIGk/Izw*100; end
if abs(yGk)
  Zgen=1/yGk; Rgen=real(Zgen);  Xgen=imag(Zgen);
  if abs(Rgen)>99999. | abs(Xgen)>99999.
   IGk=0; mIGk=0; udzial=0;
   fprintf(fd,...
'\n od zr.: %12s %6.2f kA (%5.1f%%) %6s %6s %6.2f %6.2fj',...
        knazwa,mIGk,udzial,cinf,cinf,real(IGk),imag(IGk) );
  else
   fprintf(fd,...
'\n od zr.: %12s %6.2f kA (%5.1f%%) %6.2f %6.2f %6.2f %6.2fj',...
        knazwa,mIGk,udzial,Rgen,Xgen,real(IGk),imag(IGk) );
  end
  sumI=sumI+IGk;
end % if abs(yGk)
fprintf(fd,...
'\n... kontrolna suma pradow galeziowych w wezle');
fprintf(fd,...
', sumaI = %6.2f %6.2fj',real(sumI),imag(sumI));
fprintf(fd,...
'\n -------------------------------------------------------------------');
end % koniec az2Iki

