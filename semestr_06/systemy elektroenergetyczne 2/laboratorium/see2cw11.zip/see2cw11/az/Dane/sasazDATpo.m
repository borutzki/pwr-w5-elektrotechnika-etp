function [sas,UNSobl,winf] = sasazDATpo
UNSobl=110.0; % kV
winf=1e8; % nieskonczonosc
sas={
%silnik wezel    UNM  UNS  PNM  eta cosfin Ik/IN p ns   tn
%max12s max12s    kV   kV  MVA    -    -    -    -  -    -
'M'    'ROnN'  0.525  0.5  0.2  0.97 0.86   4.0  2  6 115/11*10.5/0.525
};
end
