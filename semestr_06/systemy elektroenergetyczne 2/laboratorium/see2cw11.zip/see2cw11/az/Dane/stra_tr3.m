
% PARAMETRY ZASTEPCZE tranf. 3-uzw.
%Dane znam. transf. 3-uzw. z pliku: tr3azDAT_YNynd
%Par. zast. na nap. znam. transf. UNG
%UNSobl - nap. znam. sieci jako nap. obliczeniowe
%tN - przekl. transf.: siec UNSobl -> transf. UNS
%tN=tN1*tN2*... - siec promieniowa
%tN=UNSobl/UNS  - tylko siec oczkowa
UNSobl= 110; % kV
winf=1e+08; % nieskonczonosc 
 stra={
% R1,X1,R0,X0 - skl. 012
% UNS=UNGs - nap. znam. sieci UNS dla wez. UNG
%transf      Od         Do        UNS     R1     X1     R0     X0   tN
%max12s     max12s     max12s     kV     om     om     om     om   -
 % YN-yn-d - polaczenie uzwojen G-S-D: 
'T1A     ' 'GPZ110kV' '*T1     ' 110   1.16   92.8   1.16   92.8      1
'T1B     ' '*T1     ' 'GPZ20kV ' 110   1.24  52.21   winf   winf      1
'T1C     ' '*T1     ' 'GPZ10kV ' 110    1.3 0.1701    1.3   0.17      1
'T1E     ' '*T1     ' 'ZIEMIA  ' 110   winf   winf   1.24   52.2      1
 };