function [stra,UNSobl,winf]=tr2azDATpo
%Polaczenia uzwojen wg kolejnosci:
%P - poczatek   K - koniec
%poluzw='YNyn'; 
%poluzw='YNy'; 
%poluzw='Yyn'; 
%poluzw='Yy'; 
%poluzw='YNd';
%poluzw='Dyn';
UNSobl=110.0; % kV
winf=1e8; % nieskonczonosc
stra={
% nazwg  nazwP     nazwK poluzw  SN   UNP UNPS    Pcu   uk X0mi  tN
% max12s max12s    max12s    s  MVA    kV   kV     MW    %   -    -  
 'T2'   'ROSN'    'ROnN'  'Dyn'  2.  10.5   10  0.011  6.0   6  115/11 
 'TB'   'GPZ20kV' 'MEW'   'YNd'  4.  21     20  0.032  7.0   5  115/22 
};
end %koniec tr2azDAT
