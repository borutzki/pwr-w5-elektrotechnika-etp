function [sbus,sgal,UNSobl,winf]=dataz2suzTEST
%W obl. zwar. par. zast. beda przeliczane na nap. UNSobl
%UNSobl - nap. znam. sieci wybrane na nap. obliczeniowe
UNSobl=110.0; % kV
winf=1e15; % nieskonczonosc
% DANE WEZLOWE
%tN - przekl. transf.: siec UNSobl -> wezel UNS
%tN=tN1*tN2*... - siec promieniowa
%tN=UNSobl/UNS - w przypadku sieci oczkowych
% Wezel - max 12 znakowa nazwa wezla sieci
% UNS	- napiecie znamionowe sieci w danym wezle
% Nalezy podac wezly srodkowe gwiazdy dodane dla transf., poprzedzone *
% Ostatnim wezlem musi byc wezel odniesienia ZIEMIA, o zerowym potencjale
 sbus={
%wezel        UNS      tn
%max12s        kV      -
 'GPZ110kV'  110    1.0;
 'GPZ20kV'    20    115/22; 
 'GPZ10kV'    10    115/11; 
 'MEW'         6    115/22*21/6.3;
 'XLK'        10    115/11; 
 'ROSN'       10    115/11;
 'ROnN'       0.5   115/11*10.5/0.525;
 '*T1'       110      1;
 '*T2'        10    115/11;
 '*TB'        20    115/22;
 'ZIEMIA'       0      0;
};
%  DANE ZRODEL
%Parametry zastepcze obliczono przy UN - nap. znam. zrodla
%W obl. zwar. par. zast. beda przeliczone na nap. UNSobl
%tN - przekl. transf.: sieci ze zrodlem - siec o nap. UNSobl
%tN=tN1*tN2*... - siec promieniowa wielonapieciowa
%tN=UNS/UNSobl - w przypadku sieci oczkowych
% Zrodlo - max 12-znakowa nazwa zrodla,
% Wezel  - max 12-znakowa nazwa wezla sieci, z przylaczonym zrodlem
% R1,X1  - rezystancja i reaktancja skl. 1
% R0,X0  - rezystancja i reaktancja skl. 0
% R1,X1,R0,X0 - skl. symetryczna zgodna i zerowa
sgen={
%Zrodlo    WezZr     ZIEMIA     UNS      R1      X1     R0     X0   tN
%max12s   max12s     max12s     kV       om      om     om     om    -
'SEE'    'GPZ110kV' 'ZIEMIA  ' 110        0   8.873      0  8.873    1
'G1'     'GPZ10kV ' 'ZIEMIA  '  10   0.1194   1.706   winf   winf  10.45
'G2'     'MEW'      'ZIEMIA  '  6   0.09263   1.323   winf   winf  17.42
'M '     'ROnN'     'ZIEMIA  '  0.5 0.01855 0.04417   winf   winf  209.1
};
 % DANE LINII
%Parametry zastepcze obliczono przy UNS - nap. znam. linii
% Galaz - max 12-znakowa nazwa linii,
% Od    - max 12-znakowa nazwa wezla poczatku linii
% Do    - max 12-znakowa nazwa wezla konca linii
%tN - przekl. transf.: linia - siec o nap. UNSobl
%tN=tN1*tN2*... - siec promieniowa wielonapieciowa
%tN=UNS/UNSobl - w przypadku sieci oczkowych
% R1,X1,R0,X0 - skl. symetryczna zgodna i zerowa
slin={
%Linia    Od         Do       UNS    R1     X1     R0     X0   tN
%max12s   max12s     max12s    kV    om     om     om     om   -
'L     ' 'GPZ10kV ' 'XLK   '   10  0.88   0.74   1.18   2.59 10.45
'K     ' 'XLK     ' 'ROSN  '   10  0.255  0.122  0.255 0.122 10.45
};
 % DANE TRANSFORMATOROW
%Parametry zastepcze przeliczono na UNP - nap. znam. transf.
% Galaz - max 12-znakowa nazwa galezi transformatora,
% Od    - max 12-znakowa nazwa wezla pocz. galezi transf., moze byc z *
% Od    - max 12-znakowa nazwa wezla konc. galezi transf., moze byc z *
%tN - przekl. transf.: transf. - siec o nap. UNSobl
%tN=tN1*tN2*... - siec promieniowa wielonapieciowa
%tN=UNS/UNSobl - w przypadku sieci oczkowych
% R1,X1,R0,X0 - skl. symetryczna zgodna i zerowa
% UNS - napiecie znam. sieci po stronie wezla poczatkowego transf.
stra={
%Transf.    Od         Do         UNS     R1     X1     R0     X0   tN
%max12s     max12s     max12s      kV     om     om     om     om   -
 % Dyn - polaczenie uzwojen P-K: 
'T2A     ' 'ROSN    ' '*T2     '   10 0.1529  1.661   winf   winf  10.45
'T2B     ' '*T2     ' 'ROnN    '   10 0.1529  1.661 0.1529  1.661  10.45
'T2E     ' '*T2     ' 'ZIEMIA  '   10   winf   winf 0.1303  1.534  10.45
 % YNd - polaczenie uzwojen P-K: 
'TBA     ' 'GPZ20kV ' '*TB     '   20 0.4424  3.846 0.4424  3.846  5.227
'TBB     ' '*TB     ' 'MEW     '   20 0.4424  3.846   winf   winf  5.227
'TBE     ' '*TB     ' 'ZIEMIA  '   20   winf   winf 0.3656    3.5  5.227
 % YN-d-d - polaczenie uzwojen G-S-D: 
'T1A     ' 'GPZ110kV' '*T1     '  110  1.159   92.8  1.159   92.8      1
'T1B     ' '*T1     ' 'GPZ20kV '  110  1.241  52.21   winf   winf      1
'T1C     ' '*T1     ' 'GPZ10kV '  110  1.303 0.1701   winf   winf      1
'T1E     ' '*T1     ' 'ZIEMIA  '  110   winf   winf  1.293 0.2015      1
 };
sgal=[slin; stra; sgen];
end % koniec azDAT()

