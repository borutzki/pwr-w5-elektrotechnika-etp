function tr3az
% parametry zastepcze tranf. 3-uzw.
j=sqrt(-1);
sciezka0=pwd; cd([sciezka0 '\Dane']); sciezka1=pwd;
plikWe= strcat([sciezka1 '\str_tr3.m']);
fd=fopen(plikWe,'wt');% plik na dane
cd ..
fprintf(fd,'\n%% PARAMETRY ZASTEPCZE tranf. 3-uzw.');
% czytanie danych z m-pliku
cdold=cd;
[plik,sciezka]=...
uigetfile('tr3azDAT*.m','Wybierz plik dla transf. 3-uzw.');
fprintf('\n... wybrano: %s%s.m',sciezka,plik);
eval(['cd(''',sciezka,''')']); dane=strtok(plik,'.');
[Sn,UnG,UnGs,UNSobl,straGS,straGD,straSD,...
    poluzw,winf,tN]=feval(dane);
fprintf(fd,'\n%%Dane znam. transf. 3-uzw. z pliku: %s',dane) ;
fprintf(   '\n%%Dane znam. transf. 3-uzw. z pliku: %s',dane) ;
eval(['cd(''',cdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
Un=UnG;% par. zast. tr. 3-uzw. przeliczone na nap. gorne Un=UnG
Zn=Un^2/Sn; % impedancja znamionowa
[RGSK,XGSK,naztr,nazwpGS,nazwkGS]= atrp(Sn,Un,straGS);
[RGDK,XGDK,naztr,nazwpGD,nazwkGD]= atrp(Sn,Un,straGD);
[RSDK,XSDK,naztr,nazwpSD,nazwkSD]= atrp(Sn,Un,straSD);
ZGSK=RGSK+j*XGSK;
ZGDK=RGDK+j*XGDK;
ZSDK=RSDK+j*XSDK;
%przeliczenie napiec zwarcia z par uzwojen na uzw. G, S, D
ZGK=(ZGSK+ZGDK-ZSDK)/2; RGK=real(ZGK); XGK=imag(ZGK);
ZSK=(ZGSK+ZSDK-ZGDK)/2; RSK=real(ZSK); XSK=imag(ZSK);
ZDK=(ZGDK+ZSDK-ZGSK)/2; RDK=real(ZDK); XDK=imag(ZDK);
% Polaczenia uzwojen wg kolejnosci:
% G - gorne nap.    S - srodkowe nap.    D - dolne nap.
% G-S-D:
% YN-yn-d 
polG='YN';polS='yn';polD='d';YN_yn_d=[polG '-' polS '-' polD];
% YN-d-yn 
polG='YN';polS='d';polD='yn';YN_d_yn=[polG '-' polS '-' polD];
% YN-d-y
polG='YN';polS='d';polD='y'; YN_d_y =[polG '-' polS '-' polD];
% YN-d-d
polG='YN';polS='d';polD='d'; YN_d_d =[polG '-' polS '-' polD];
% inne polaczenia uzwojen *************************************
% Y-y-d ************************************
polG='Y';polS='y';polD='d';Y_y_d=[polG '-' polS '-' polD];
% Y-d-d ******************************
polG='Y';polS='d';polD='d';Y_d_d=[polG '-' polS '-' polD];
% koniec innych polaczen **************************************
% rezerwacja tablic
ZA1=[];ZB1=[];ZC1=[];ZE1=[];
ZA0=[];ZB0=[];ZC0=[];ZE0=[];
%                 G-S-D
if strcmp(poluzw,YN_yn_d)
    [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=...
        fun_YN_yn_d(ZGK,ZSK,ZDK,winf);
end
%                 G-S-D
if strcmp(poluzw,YN_d_yn)
    [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=...
        fun_YN_d_yn(ZGK,ZSK,ZDK,winf);
end
%                 G-S-D
if strcmp(poluzw,YN_d_y)
    [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=...
        fun_YN_d_y(ZGK,ZSK,ZDK,winf); 
end
%                 G-S-D
if strcmp(poluzw,YN_d_d)
    [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=...
        fun_YN_d_d(ZGK,ZSK,ZDK,winf);
end
% inne polaczenia uzwojen Y-y-d ************************************
% polG='Y';polS='y';polD='d'; Y_y_d=[polG '-' polS '-' polD];
%                 G-S-D
if strcmp(poluzw,Y_y_d)
    [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=...
        fun_YN_yn_d(ZGK,ZSK,ZDK,winf);
end
% inne polaczenia uzwojen Y-d-d ******************************
%polG='Y';polS='d';polD='d'; Y_d_d=[polG '-' polS '-' polD];
%                 G-S-D
if strcmp(poluzw,Y_d_d)
    [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=...
        fun_YN_d_d(ZGK,ZSK,ZDK,winf);
end
% koniec innych polaczen **************************************
%
% zastepcze impedancje zwarciowe dla grup poluzw
fprintf(fd,'\n%%Par. zast. na nap. znam. transf. UNG');
fprintf(fd,'\n%%UNSobl - nap. znam. sieci jako nap. obliczeniowe');
fprintf(fd,'\n%%tN - przekl. transf.: siec UNSobl -> transf. UNS');
fprintf(fd,'\n%%tN=tN1*tN2*... - siec promieniowa');
fprintf(fd,'\n%%tN=UNSobl/UNS  - tylko siec oczkowa');
fprintf(fd,'\nUNSobl=%4.3g; %% kV',UNSobl);
fprintf(fd,'\nwinf=%.0e; %% nieskonczonosc ',winf);
fprintf(fd,'\n stra={');
fprintf(fd,'\n%% R1,X1,R0,X0 - skl. 012');
fprintf(fd,...
'\n%% UNS=UNGs - nap. znam. sieci UNS dla wez. UNG');
fprintf(fd,'\n%%transf      Od         Do        ');
fprintf(fd,'UNS     R1     X1     R0     X0   tN');
fprintf(fd,...
'\n%%max12s     max12s     max12s     ');
fprintf(fd,'kV     om     om     om     om   -');
fprintf(fd,'\n %% %s - polaczenie uzwojen G-S-D: ',poluzw);
if ~isempty(ZA1)
   nazwo=[]; naztrA=[]; naztrB=[]; naztrE=[];
   RA1=real(ZA1); XA1=imag(ZA1);
   RB1=real(ZB1); XB1=imag(ZB1); RC1=real(ZC1); XC1=imag(ZC1);
   RE1=real(ZE1); XE1=imag(ZE1);
   RA0=real(ZA0); XA0=imag(ZA0); 
   RB0=real(ZB0); XB0=imag(ZB0); RC0=real(ZC0); XC0=imag(ZC0);
   RE0=real(ZE0); XE0=imag(ZE0);
   ntr=char(naztr(:)); ntrA=char(nazwpGS(:));
   ntrB=char(nazwkGS(:));ntrC=char(nazwkGD(:));
   nazwo=strcat('*',deblank(ntr)); ziemia='ZIEMIA';
   naztrA=strcat(deblank(ntr),'A');
   naztrB=strcat(deblank(ntr),'B');
   naztrC=strcat(deblank(ntr),'C');
   naztrE=strcat(deblank(ntr),'E'); 
   naz1=[]; naz2=[]; naz3=[]; 
   naz1=naztrA; naz2=ntrA; naz3=nazwo;  
   R1=RA1; X1=XA1; R0=RA0; X0=XA0;
        druktr(fd,naz1,naz2,naz3,UnGs,R1,X1,R0,X0,tN,winf); 
   naz1=[]; naz2=[]; naz3=[]; 
   naz1=naztrB; naz2=nazwo; naz3=ntrB; 
   R1=RB1; X1=XB1; R0=RB0; X0=XB0;
        druktr(fd,naz1,naz2,naz3,UnGs,R1,X1,R0,X0,tN,winf);  
   naz1=[]; naz2=[]; naz3=[]; 
   naz1=naztrC; naz2=nazwo; naz3=ntrC; 
   R1=RC1; X1=XC1; R0=RC0; X0=XC0;
        druktr(fd,naz1,naz2,naz3,UnGs,R1,X1,R0,X0,tN,winf);  
   naz1=[]; naz2=[]; naz3=[]; 
   naz1=naztrE; naz2=nazwo; naz3=ziemia;
   R1=RE1; X1=XE1; R0=RE0; X0=XE0;
        druktr(fd,naz1,naz2,naz3,UnGs,R1,X1,R0,X0,tN,winf);             
else
   fprintf(fd,...
   '\n\n %s %s %s - bledne dane grupy polaczen',...
   naztr,nazwp,nazwk );
end % if ~isempty(ZA1)
   fprintf(fd,'\n };');
fclose(fd);
fprintf('\n\n stra{} zapisano w m-pliku: %s',plikWe);
end
function [RK,XK,naztr,nazwp,nazwk]=atrp(Sn,Un,stra)
[nt,n]=size(stra);
if nt
   naztr =stra(:,1);     nazwp =stra(:,2);   nazwk =stra(:,3); 
   tre=[cell2mat(stra(:,4:end)) ];   % end
else    % brak tranf.
   tre=[];
end %if nt
if ~isempty(tre)
     Zn=Un^2/Sn;
     Pcu=tre(1); uk=tre(2);
     uR=Pcu/Sn*100; uX=sqrt(uk^2-uR^2); 
     R=Pcu/Sn*Zn; X=uX/100*Zn;
     % wsp. korekcji par uwzojen
     KT=0.95*1.1/(1+0.6*uX/100);
     RK=R*KT; XK=X*KT;
 else
     fprintf(fd,'\brak danych dla pary uzwojen!');
end % ~isempty(tre)
end % koniec tr3az()

function [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=fun_YN_yn_d(ZG,ZS,ZD,winf)
%   G-S-D: YN-yn-d  -    skl. 0
%              
% A(G-gora)    *T           B(D-dol)
% o--ZA0=ZG----o--ZB0=inf  o
%              | -
%              |    - 
%           ZE0=ZD   ZC0=ZS
%              |       --- o C(C-srodek)
%              o
%           E-ZIEMIA
j=sqrt(-1);
ZA1=ZG;     ZB1=ZD;    ZE1=winf;   ZC1=ZS;     % skl. 1
ZA0=ZG;     ZB0=winf;  ZE0=ZD;     ZC0=ZS;     % skl. 0
end % koniec fun_YN_yn_d()
function [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=fun_YN_d_yn(ZG,ZS,ZD,winf)
%   G-S-D: YN-d-yn  -    skl. 0
%              
% A(G-gora)    *T           B(D-dol)
% o--ZA0=ZG----o--ZB0=ZD---o
%              | -
%              |    - 
%           ZE0=ZS   ZC0=winf
%              |       --- o C(C-srodek)
%              o
%           E-ZIEMIA
j=sqrt(-1);
ZA1=ZG;     ZB1=ZD;    ZE1=winf;   ZC1=ZS;      % skl. 1
ZA0=ZG;     ZB0=ZD;    ZE0=ZS;    ZC0=winf;     % skl. 0
end % koniec fun_YN_d_yn()
function [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=fun_YN_d_y(ZG,ZS,ZD,winf)
%   G-S-D: YN-d-y  -    skl. 0
%              
% A(G-gora)    *T           B(D-dol)
% o--ZA0=ZG----o--ZB0=winf   o
%              | -
%              |    - 
%           ZE0=ZS   ZC0=winf
%              |       --- o C(C-srodek)
%              o
%            E-ZIEMIA
j=sqrt(-1);
ZA1=ZG;     ZB1=ZD;     ZE1=winf;   ZC1=ZS;      % skl. 1
ZA0=ZG;     ZB0=winf;   ZE0=ZS;    ZC0=winf;     % skl. 0
end % koniec fun_YN_d_y()
function [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=fun_YN_d_d(ZG,ZS,ZD,winf)
%   G-S-D: YN-d-d  -    skl. 0
%              
% A(G-gora)    *T           B(D-dol)
% o--ZA0=ZG----o--ZB0=winf   o
%              | -
%              |    - 
%  ZE0=ZD*ZS/(ZD+ZS)  ZC0=winf
%              |       --- o C(C-srodek)
%              o
%            E-ZIEMIA
j=sqrt(-1);
ZA1=ZG;     ZB1=ZD;     ZE1=winf;             ZC1=ZS;       % skl. 1
ZA0=ZG;     ZB0=winf;   ZE0=ZD*ZS/(ZD+ZS);    ZC0=winf;     % skl. 0
end %koniec fun_YN_d_d()
%
% inne polaczenie uzwojen Y-y-d ************************************
% polG='Y';polS='y';polD='d';Y_y_d=[polG '-' polS '-' polD];
%                 G-S-D
%if strcmp(poluzw,Y_y_d)
%    [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=...
%        fun_YN_yn_d(ZGK,ZSK,ZDK,winf);
%end
function [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=fun_Y_y_d(ZG,ZS,ZD,winf)
%   G-S-D: YN-yn-d  -    skl. 0
%              
% A(G-gora)    *T           B(D-dol)
% o  ZA0=inf----o--ZB0=inf  o
%              | -
%              |    - 
%           ZE0=ZD   ZC0=inf
%              |            o C(C-srodek)
%              o
%           E-ZIEMIA
j=sqrt(-1);
ZA1=ZG;     ZB1=ZD;    ZE1=winf;   ZC1=ZS;     % skl. 1
ZA0=inf;    ZB0=winf;  ZE0=ZD;     ZC0=inf;    % skl. 0
end
% inne polaczenia uzwojen Y-d-d ******************************
%polG='Y';polS='d';polD='d'; Y_d_d=[polG '-' polS '-' polD];
%                 G-S-D
%if strcmp(poluzw,Y_d_d)
%    [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=...
%        fun_YN_d_d(ZGK,ZSK,ZDK,winf);
%end
function [ZA1,ZB1,ZC1,ZE1,ZA0,ZB0,ZC0,ZE0]=fun_Y_d_d(ZG,ZS,ZD,winf)
%   G-S-D: YN-d-d  -    skl. 0
%              
% A(G-gora)    *T           B(D-dol)
% o  ZA0=inf---o--ZB0=winf   o
%              | -
%              |    - 
%  ZE0=ZD*ZS/(ZD+ZS)  ZC0=winf
%              |             o C(C-srodek)
%              o
%            E-ZIEMIA
j=sqrt(-1);
ZA1=ZG;     ZB1=ZD;     ZE1=winf;             ZC1=ZS;       % skl. 1
ZA0=winf;     ZB0=winf;   ZE0=ZD*ZS/(ZD+ZS);    ZC0=winf;   % skl. 0
end
% KONIEC innych polaczen uzwojen


