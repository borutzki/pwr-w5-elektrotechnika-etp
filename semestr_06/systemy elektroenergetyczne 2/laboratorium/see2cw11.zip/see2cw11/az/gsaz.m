function gsaz
% parametry zastepcze zwarciowe generatorow synchronicznych
j=sqrt(-1);
 sciezka0=pwd; cd([sciezka0 '\Dane']); sciezka1=pwd;
 plikWe= strcat([sciezka1 '\sgen_gs.m']);
 fd=fopen(plikWe,'wt');  % plik z przeczytanymi danymi do obliczen
 cd ..
fprintf(fd,'\n%%PARAMETRY ZASTEPCZE ZWARCIOWE GEN. SYNCHR.');
% czytanie danych z m-pliku
cdold=cd;
[plik,sciezka]=...
uigetfile('gsazDAT*.m','Wybierz plik z danymi generatora');
fprintf('\n... wybrano: %s%s.m',sciezka,plik);
eval(['cd(''',sciezka,''')']); dane=strtok(plik,'.');
[sgen, UNSobl,winf] = eval(dane);
eval(['cd(''',cdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
sp12='123456789012';% nazwa max 12 znakow
[ng,n]=size(sgen);
if ng
   nazgen =strvcat( sp12,char(sgen(:,1)));
   nazgen=nazgen(2:end,:);  
   nazwgs =strvcat( sp12,char(sgen(:,2)));
   nazwgs=nazwgs(2:end,:);
   gen=[cell2mat(sgen(:,3:end)) ];   % end
else    % brak gen
   nazgen=[]; gen=[];
end %if ng
if ~isempty(gen)
 fprintf(fd,'\n%%Parametry zastepcze GS na nap. znam. UNG');
 fprintf(fd,'\n%%UNSobl - nap. znam. obliczeniowe');
 fprintf(fd,'\n%%tN - przekl. transf.:siec UNSobl -> siec UNS');
 fprintf(fd,'\n%%tN=tN1*tN2*... - siec promieniowa');
 fprintf(fd,'\n%%tN=UNSobl/UNS  - tylko sieci oczkowe');
 fprintf(fd,'\nUNSobl=%4.3g;%% kV ',UNSobl);
 fprintf(fd,'\nwinf=%.0e;%% nieskonczonosc ',winf);
 fprintf(fd,'\nsgen={');
 fprintf(fd,...
'\n%%Gen        Od         Do        UNS     ');
fprintf(fd,'R1     X1     R0    X0  tN');
 fprintf(fd,...
'\n%%max12s     max12s     max12s     kV     ');
fprintf(fd,'om     om     om    om   -');
 for i=1:ng
 Ung=gen(i,1); Uns=gen(i,2);
 Sng=gen(i,3); cosfin=gen(i,4); xdb=gen(i,5);
 X0X1=gen(i,6); tn=gen(i,7);
 ZnG=Ung^2/Sng; % impedancja znamionowa GS
 sinfin=sqrt(1-cosfin^2);
 XG=xdb*ZnG; % reaktancja podprzejsciowa w omach
 cmax=1.1; if Ung<1 cmax=1; end
 KG=Uns/Ung*cmax/(1+xdb*sinfin); % wsp. korekcji
 Rgk=0; XGk=XG*KG; % reaktancja po korekcji
 if Ung>1&Sng>=100 RGk=0.05*XGk;end%dla UnG>1kV, SnG>100MVA
 if Ung>1&Sng<100 RGk=0.07*XGk; end%dla UnG>1kV, SnG<100MVA
 if Ung<=1 RGk=0.15*XGk; end % dla UnG<1kV
 R1=RGk; X1=XGk; R0=R1*X0X1; X0=X1*X0X1;
 if X0X1==winf R0=winf; X0=winf; end
 naz1=deblank(nazgen(i,:)); naz2=deblank(nazwgs(i,:));
 drukzr(fd,naz1,naz2,Uns,R1,X1,R0,X0,tn,winf); end
  fprintf(fd,'\n };');
 else
    fprintf(fd,'\n brak gen. synchronicznych!');
end % ~isempty(gen)
fclose(fd);
fprintf('\n\n sgen{} zapisano w m-pliku: %s',plikWe');
end % koniec gsaz()
