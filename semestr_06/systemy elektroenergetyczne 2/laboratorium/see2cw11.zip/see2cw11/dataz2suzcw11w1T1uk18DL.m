function [sbus,sgal,UNSobl,winf]=dataz2suzcw11w1T1uk18
% cw. 11 - ograniczanie pradow zwarciowyxch
% T221 - YNyn, T221 - YNyn, T1 - YNd, T2 - Dyn
%W obl. zwar. par. zast. beda przeliczane na nap. UNSobl
%UNSobl - nap. znam. sieci wybrane na nap. obliczeniowe
% zwarcia bez SILNIKA INDUKCYJNEGO
UNSobl=110.0; % kV
winf=1e15; % nieskonczonosc
% DANE WEZLOWE
%tN - przekl. transf.: siec UNSobl -> wezel UNS
%tN=tN1*tN2*... - siec promieniowa
%tN=UNSobl/UNS - w przypadku sieci oczkowych
% Wezel - max 12 znakowa nazwa wezla sieci
% UNS	- napiecie znamionowe sieci w danym wezle
% Nalezy podac wezly srodkowe gwiazdy dodane dla transf., poprzedzone *
% Ostatnim wezlem musi byc wezel odniesienia ZIEMIA, o zerowym potencjale
 sbus={
%wezel            UNS      tn
%max12s            kV      -
 'WEZ1-220kV  '   220    115/245;
 'WEZ2-220kV  '   220    115/245;
 'WEZ1-110kV  '   110    1.0;
 'WEZ2-110kV  '   110    1.0;
 'W2'             110    1.0; 
 'GPZ110kV    '   110    1.0;
 'GPZ10kV     '    10    115/11;
 'DL'              10    115/11; % DL - wezel dlawika
 'RO'              10    115/11;
 'silnik'       0.525      115/11*10.5/0.525;
 '*T221       '   220    115/245;
 '*T222       '   220    115/245;
 '*T1         '   110    1.0;
 '*T2         '    10    115/11; 
 'ZIEMIA      '     0    0.0;
};
%  DANE ZRODEL
%Parametry zastepcze obliczono przy UN - nap. znam. zrodla
%W obl. zwar. par. zast. beda przeliczone na nap. UNSobl
%tN - przekl. transf.: sieci ze zrodlem - siec o nap. UNSobl
%tN=tN1*tN2*... - siec promieniowa wielonapieciowa
%tN=UNS/UNSobl - w przypadku sieci oczkowych
% Zrodlo - max 12-znakowa nazwa zrodla,
% Wezel  - max 12-znakowa nazwa wezla sieci, z przylaczonym zrodlem
% R1,X1  - rezystancja i reaktancja skl. 1
% R0,X0  - rezystancja i reaktancja skl. 0
% R1,X1,R0,X0 - skl. symetryczna zgodna i zerowa
sgen={
%Zrodlo    WezZr     ZIEMIA    UNS  R1     X1     R0      X0   tN
%max12s   max12s     max12s     kV  om     om     om      om    -
'SkQ1' 'WEZ1-220kV'  'ZIEMIA'  220  0      3.3275 0  4.99125  115/245
'SkQ2' 'WEZ2-220kV'  'ZIEMIA'  220  0      3.3275 0  4.99125  115/245
'GS'   'GPZ10kV'     'ZIEMIA'   10  0.251 1.672 winf  winf  115/11
'MAS'  'silnik'      'ZIEMIA' 0.525 0.0048 0.032 winf  winf 115/11*10.5/0.525
};
 % DANE LINII
%Parametry zastepcze obliczono przy UNS - nap. znam. linii
% Galaz - max 12-znakowa nazwa linii,
% Od    - max 12-znakowa nazwa wezla poczatku linii
% Do    - max 12-znakowa nazwa wezla konca linii
%tN - przekl. transf.: linia - siec o nap. UNSobl
%tN=tN1*tN2*... - siec promieniowa wielonapieciowa
%tN=UNS/UNSobl - w przypadku sieci oczkowych
% R1,X1,R0,X0 - skl. symetryczna zgodna i zerowa
 slin={
%linia       Od         Do            UNS  R1     X1    R0    X0   tN
%max12s     max12s     max12s          kV  om     om    om    om   -
'L110tor1'  'WEZ1-110kV' 'GPZ110kV'   110   0   6.04      0  18.12    1.0 
'L110tor2'  'WEZ2-110kV' 'W2'         110   0   6.04      0  18.12    1.0 
'W1'        'WEZ1-110kV' 'WEZ2-110kV' 110   0  0.0001    0  0.0001  1.0
%'W2'        'W2'         'GPZ110kV'   110   0  0.0001    0  0.0001  1.0
'DL'        'GPZ10kV'    'DL'          10   0   1.115    0  1.115 115/11;%dlawik 
'LK'        'DL'    'RO'          10 1.489 1.113 1.866 3.435 115/11 
 };
 % DANE TRANSFORMATOROW
%Parametry zastepcze przeliczono na UNP - nap. znam. transf.
% Galaz - max 12-znakowa nazwa galezi transformatora,
% Od    - max 12-znakowa nazwa wezla pocz. galezi transf., moze byc z *
% Od    - max 12-znakowa nazwa wezla konc. galezi transf., moze byc z *
%tN - przekl. transf.: transf. - siec o nap. UNSobl
%tN=tN1*tN2*... - siec promieniowa wielonapieciowa
%tN=UNS/UNSobl - w przypadku sieci oczkowych
% R1,X1,R0,X0 - skl. symetryczna zgodna i zerowa
% UNS - napiecie znam. sieci po stronie wezla poczatkowego transf.
 stra={
%transf      Od         Do        UNS     R1     X1     R0     X0   tN
%max12s     max12s     max12s     kV     om     om     om     om   -
 % YNyn - polaczenie uzwojen P-K: 
'T221A   ' 'WEZ1-220kV' '*T221   ' 220      0  26.975      0  26.975 115/245
'T221B   ' '*T221   ' 'WEZ1-110kV' 220      0  26.975      0  26.975 115/245
'T221E   ' '*T221   ' 'ZIEMIA  '   220   winf   winf      0  281.367 115/245
 % YNyn - polaczenie uzwojen P-K: 
'T222A   ' 'WEZ2-220kV' '*T222   ' 220      0  26.975      0  26.975 115/245
'T222B   ' '*T222   ' 'WEZ2-110kV' 220      0  26.975      0  26.975 115/245
'T222E   ' '*T222   ' 'ZIEMIA  '   220   winf   winf      0  281.367 115/245
'T1A     ' 'GPZ110kV' '*T1     '   110  0.998  28.064  0.998  28.064      1
'T1B     ' '*T1     ' 'GPZ10kV '   110  0.998  28.064  winf  winf      1
'T1E     ' '*T1     ' 'ZIEMIA  '   110   winf   winf 0.833  25.6481      1
 % Dyn - polaczenie uzwojen P-K: 
'T2A     ' 'RO      ' '*T2     '    10 0.160  1.805   winf   winf 115/11
'T2B     ' '*T2     ' 'silnik  '    10 0.160  1.805 0.160  1.805 115/11
'T2E     ' '*T2     ' 'ZIEMIA  '    10   winf   winf 0.136  1.666 115/11
 };
sgal=[slin; stra; sgen];
end % koniec dataz*
