function [stra,UNSobl,winf]=tr2azDATcw11T
%Dane do obl. par. zast. zwarciowych transf. 2-uzw.
%UNSobl - nap. znam. sieci wybrane na nap. obliczeniowe
%tN - przekladnia transf.: siec UNSobl -> transf. UNPS
%tN=tN1*tN2*... - sieci promieniowej
%tN=UNSobl/UNPS - tylko sieci oczkowe
%SN, MVA  - moc znamionowa
%UNP, kV  - nap. znam. transf. w wezle poczatkowym P
%UNPS, kV - nap. znam. sieci   w wezle poczatkowym P
%Pcu, MW  - straty obciazeniowe 
%uk, %    - napiecie zwarcia w %
%Xomi=X0mi/XT - krotnosc reaktancji magnesowania dla skl. 1
%Polaczenia uzwojen wg kolejnosci:
%P - poczatek   K - koniec
%poluzw='YNyn'; 
%poluzw='YNy'; 
%poluzw='Yyn'; 
%poluzw='Yy'; 
%poluzw='YNd';
%poluzw='Dyn';
%poluzw='Yd';
UNSobl=110.0; % kV
winf=1e8; % nieskonczonosc
stra={
% nazwg  nazwP       nazwK      poluzw   SN  UNP UNPS  Pcu  uk X0mi  tN
% max12s max12s      max12s       s     MVA   kV   kV   MW   %   -   -  
'T221' 'WEZ1-220kV' 'WEZ1-110kV' 'YNyn' 160  245  220   0   15   5 115/245
'T222' 'WEZ2-220kV' 'WEZ2-110kV' 'YNyn' 160  245  220   0   15   5 115/245
'T1'   'GPZ110kV'   'GPZ10kV'    'YNd'   40  115  110 0.245 11.4 5    1
'T2'   'RO'         'silnik'     'Dyn'    2  10.5  10 0.011  6   6 115/11
};
end %koniec tr2azDAT

