

 bus[] wg danych wczytanych
              nrwez      UNS         tN
 GPZ110kV        1     110.000      0.096  
 GPZ10kV         2      10.000      1.000  
 RO              3      10.000      1.000  
 silnik          4       0.525     20.000  
 *T1             5     110.000      0.096  
 *T2             6      10.000      1.000  
 ZIEMIA          0       0.000      0.000  

 galezie[] wg danych wczytanych
 nazwg        nazwp        nazwk        wp - wk  UNS     R1     X1     R0     X0      tN
                                         1   2    3       4      5      6      7      8
LK           GPZ10kV      RO             2   3    10   1.49   1.11   1.87   3.43      1
T1-A         GPZ110kV     *T1            1   5   110   1.03   18.6   1.03   18.6 0.0957
T1-B         GPZ10kV      *T1            2   5   110   1.03   18.6  1e+08  1e+08 0.0957
T1-E         *T1          ZIEMIA         5   0   110  1e+08  1e+08  0.858   16.9 0.0957
T2-A         RO           *T2            3   6    10   0.16    1.8  1e+08  1e+08      1
T2-B         silnik       *T2            4   6    10   0.16    1.8  0.153   1.66      1
T2-E         *T2          ZIEMIA         6   0    10  1e+08  1e+08  0.136   1.66      1
GS           GPZ10kV      ZIEMIA         2   0    10  0.117   1.67  1e+08  1e+08      1
MAS          silnik       ZIEMIA         4   0 0.525 0.0126   0.03  1e+08  1e+08     20
SEE          GPZ110kV     ZIEMIA         1   0   110      0   6.62      0   6.62 0.0957
 galezie[] po przeliczeniu na UNSobl=    10 kV
 nazwg        nazwp        nazwk        wp - wk  UNS     R1     X1     R0     X0      tN
                                         1   2    3       4      5      6      7      8
LK           GPZ10kV      RO             2   3    10   1.49   1.11   1.87   3.43      1
T1-A         GPZ110kV     *T1            1   5   110 0.00946   0.17 0.00946   0.17 0.0957
T1-B         GPZ10kV      *T1            2   5   110 0.00946   0.17 9.15e+05 9.15e+05 0.0957
T1-E         *T1          ZIEMIA         5   0   110 9.15e+05 9.15e+05 0.00785  0.155 0.0957
T2-A         RO           *T2            3   6    10   0.16    1.8  1e+08  1e+08      1
T2-B         silnik       *T2            4   6    10   0.16    1.8  0.153   1.66      1
T2-E         *T2          ZIEMIA         6   0    10  1e+08  1e+08  0.136   1.66      1
GS           GPZ10kV      ZIEMIA         2   0    10  0.117   1.67  1e+08  1e+08      1
MAS          silnik       ZIEMIA         4   0 0.525   5.04     12  4e+10  4e+10     20
SEE          GPZ110kV     ZIEMIA         1   0   110      0 0.0606      0 0.0606 0.0957