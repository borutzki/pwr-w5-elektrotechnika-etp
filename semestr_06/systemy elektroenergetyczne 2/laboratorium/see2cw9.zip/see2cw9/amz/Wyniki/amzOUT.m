

 macierz Y1 poziomie napiecia UNSobl=10kV
 wezel: GPZ110kV    
 Y1(GPZ110kV    ,GPZ110kV    ) = (  0.3267 +j-22.3727)S
 Y1(GPZ110kV    ,GPZ10kV     ) = (  0.0000 +j  0.0000)S
 Y1(GPZ110kV    ,RO          ) = (  0.0000 +j  0.0000)S
 Y1(GPZ110kV    ,silnik      ) = (  0.0000 +j  0.0000)S
 Y1(GPZ110kV    ,*T1         ) = ( -0.3267 +j  5.8675)S
 Y1(GPZ110kV    ,*T2         ) = (  0.0000 +j  0.0000)S
 wezel: GPZ10kV     
 Y1(GPZ10kV     ,GPZ110kV    ) = (  0.0000 +j  0.0000)S
 Y1(GPZ10kV     ,GPZ10kV     ) = (  0.7996 +j -6.7858)S
 Y1(GPZ10kV     ,RO          ) = ( -0.4312 +j  0.3232)S
 Y1(GPZ10kV     ,silnik      ) = (  0.0000 +j  0.0000)S
 Y1(GPZ10kV     ,*T1         ) = ( -0.3267 +j  5.8675)S
 Y1(GPZ10kV     ,*T2         ) = (  0.0000 +j  0.0000)S
 wezel: RO          
 Y1(RO          ,GPZ110kV    ) = (  0.0000 +j  0.0000)S
 Y1(RO          ,GPZ10kV     ) = ( -0.4312 +j  0.3232)S
 Y1(RO          ,RO          ) = (  0.4802 +j -0.8750)S
 Y1(RO          ,silnik      ) = (  0.0000 +j  0.0000)S
 Y1(RO          ,*T1         ) = (  0.0000 +j  0.0000)S
 Y1(RO          ,*T2         ) = ( -0.0490 +j  0.5518)S
 wezel: silnik      
 Y1(silnik      ,GPZ110kV    ) = (  0.0000 +j  0.0000)S
 Y1(silnik      ,GPZ10kV     ) = (  0.0000 +j  0.0000)S
 Y1(silnik      ,RO          ) = (  0.0000 +j  0.0000)S
 Y1(silnik      ,silnik      ) = (  0.0788 +j -0.6227)S
 Y1(silnik      ,*T1         ) = (  0.0000 +j  0.0000)S
 Y1(silnik      ,*T2         ) = ( -0.0490 +j  0.5518)S
 wezel: *T1         
 Y1(*T1         ,GPZ110kV    ) = ( -0.3267 +j  5.8675)S
 Y1(*T1         ,GPZ10kV     ) = ( -0.3267 +j  5.8675)S
 Y1(*T1         ,RO          ) = (  0.0000 +j  0.0000)S
 Y1(*T1         ,silnik      ) = (  0.0000 +j  0.0000)S
 Y1(*T1         ,*T1         ) = (  0.6534 +j-11.7350)S
 Y1(*T1         ,*T2         ) = (  0.0000 +j  0.0000)S
 wezel: *T2         
 Y1(*T2         ,GPZ110kV    ) = (  0.0000 +j  0.0000)S
 Y1(*T2         ,GPZ10kV     ) = (  0.0000 +j  0.0000)S
 Y1(*T2         ,RO          ) = ( -0.0490 +j  0.5518)S
 Y1(*T2         ,silnik      ) = ( -0.0490 +j  0.5518)S
 Y1(*T2         ,*T1         ) = (  0.0000 +j  0.0000)S
 Y1(*T2         ,*T2         ) = (  0.0980 +j -1.1037)S

 macierz Y0 poziomie napiecia UNSobl=10kV
 wezel: GPZ110kV    
 Y0(GPZ110kV    ,GPZ110kV    ) = (  0.3267 +j-22.3727)S
 Y0(GPZ110kV    ,GPZ10kV     ) = (  0.0000 +j  0.0000)S
 Y0(GPZ110kV    ,RO          ) = (  0.0000 +j  0.0000)S
 Y0(GPZ110kV    ,silnik      ) = (  0.0000 +j  0.0000)S
 Y0(GPZ110kV    ,*T1         ) = ( -0.3267 +j  5.8675)S
 Y0(GPZ110kV    ,*T2         ) = (  0.0000 +j  0.0000)S
 wezel: GPZ10kV     
 Y0(GPZ10kV     ,GPZ110kV    ) = (  0.0000 +j  0.0000)S
 Y0(GPZ10kV     ,GPZ10kV     ) = (  0.1222 +j -0.2248)S
 Y0(GPZ10kV     ,RO          ) = ( -0.1222 +j  0.2248)S
 Y0(GPZ10kV     ,silnik      ) = (  0.0000 +j  0.0000)S
 Y0(GPZ10kV     ,*T1         ) = ( -0.0000 +j  0.0000)S
 Y0(GPZ10kV     ,*T2         ) = (  0.0000 +j  0.0000)S
 wezel: RO          
 Y0(RO          ,GPZ110kV    ) = (  0.0000 +j  0.0000)S
 Y0(RO          ,GPZ10kV     ) = ( -0.1222 +j  0.2248)S
 Y0(RO          ,RO          ) = (  0.1222 +j -0.2248)S
 Y0(RO          ,silnik      ) = (  0.0000 +j  0.0000)S
 Y0(RO          ,*T1         ) = (  0.0000 +j  0.0000)S
 Y0(RO          ,*T2         ) = ( -0.0000 +j  0.0000)S
 wezel: silnik      
 Y0(silnik      ,GPZ110kV    ) = (  0.0000 +j  0.0000)S
 Y0(silnik      ,GPZ10kV     ) = (  0.0000 +j  0.0000)S
 Y0(silnik      ,RO          ) = (  0.0000 +j  0.0000)S
 Y0(silnik      ,silnik      ) = (  0.0550 +j -0.5970)S
 Y0(silnik      ,*T1         ) = (  0.0000 +j  0.0000)S
 Y0(silnik      ,*T2         ) = ( -0.0550 +j  0.5970)S
 wezel: *T1         
 Y0(*T1         ,GPZ110kV    ) = ( -0.3267 +j  5.8675)S
 Y0(*T1         ,GPZ10kV     ) = ( -0.0000 +j  0.0000)S
 Y0(*T1         ,RO          ) = (  0.0000 +j  0.0000)S
 Y0(*T1         ,silnik      ) = (  0.0000 +j  0.0000)S
 Y0(*T1         ,*T1         ) = (  0.6535 +j-12.3106)S
 Y0(*T1         ,*T2         ) = (  0.0000 +j  0.0000)S
 wezel: *T2         
 Y0(*T2         ,GPZ110kV    ) = (  0.0000 +j  0.0000)S
 Y0(*T2         ,GPZ10kV     ) = (  0.0000 +j  0.0000)S
 Y0(*T2         ,RO          ) = ( -0.0000 +j  0.0000)S
 Y0(*T2         ,silnik      ) = ( -0.0550 +j  0.5970)S
 Y0(*T2         ,*T1         ) = (  0.0000 +j  0.0000)S
 Y0(*T2         ,*T2         ) = (  0.1039 +j -1.1954)S

 macierz Z1 poziomie napiecia UNSobl=10kV
 wezel: GPZ110kV    
 Z1(GPZ110kV    ,GPZ110kV    ) = (  0.0002 +j  0.0587)om
 Z1(GPZ110kV    ,GPZ10kV     ) = (  0.0005 +j  0.0481)om
 Z1(GPZ110kV    ,RO          ) = ( -0.0021 +j  0.0439)om
 Z1(GPZ110kV    ,silnik      ) = (  0.0007 +j  0.0346)om
 Z1(GPZ110kV    ,*T1         ) = (  0.0003 +j  0.0534)om
 Z1(GPZ110kV    ,*T2         ) = ( -0.0007 +j  0.0393)om
 wezel: GPZ10kV     
 Z1(GPZ10kV     ,GPZ110kV    ) = (  0.0005 +j  0.0481)om
 Z1(GPZ10kV     ,GPZ10kV     ) = (  0.0183 +j  0.3176)om
 Z1(GPZ10kV     ,RO          ) = ( -0.0001 +j  0.2905)om
 Z1(GPZ10kV     ,silnik      ) = (  0.0152 +j  0.2288)om
 Z1(GPZ10kV     ,*T1         ) = (  0.0094 +j  0.1828)om
 Z1(GPZ10kV     ,*T2         ) = (  0.0075 +j  0.2597)om
 wezel: RO          
 Z1(RO          ,GPZ110kV    ) = ( -0.0021 +j  0.0439)om
 Z1(RO          ,GPZ10kV     ) = ( -0.0001 +j  0.2905)om
 Z1(RO          ,RO          ) = (  1.2799 +j  1.3579)om
 Z1(RO          ,silnik      ) = (  1.0792 +j  1.0020)om
 Z1(RO          ,*T1         ) = ( -0.0011 +j  0.1672)om
 Z1(RO          ,*T2         ) = (  1.1795 +j  1.1800)om
 wezel: silnik      
 Z1(silnik      ,GPZ110kV    ) = (  0.0007 +j  0.0346)om
 Z1(silnik      ,GPZ10kV     ) = (  0.0152 +j  0.2288)om
 Z1(silnik      ,RO          ) = (  1.0792 +j  1.0020)om
 Z1(silnik      ,silnik      ) = (  1.3430 +j  3.5471)om
 Z1(silnik      ,*T1         ) = (  0.0079 +j  0.1317)om
 Z1(silnik      ,*T2         ) = (  1.2111 +j  2.2745)om
 wezel: *T1         
 Z1(*T1         ,GPZ110kV    ) = (  0.0003 +j  0.0534)om
 Z1(*T1         ,GPZ10kV     ) = (  0.0094 +j  0.1828)om
 Z1(*T1         ,RO          ) = ( -0.0011 +j  0.1672)om
 Z1(*T1         ,silnik      ) = (  0.0079 +j  0.1317)om
 Z1(*T1         ,*T1         ) = (  0.0096 +j  0.2031)om
 Z1(*T1         ,*T2         ) = (  0.0034 +j  0.1495)om
 wezel: *T2         
 Z1(*T2         ,GPZ110kV    ) = ( -0.0007 +j  0.0393)om
 Z1(*T2         ,GPZ10kV     ) = (  0.0075 +j  0.2597)om
 Z1(*T2         ,RO          ) = (  1.1795 +j  1.1800)om
 Z1(*T2         ,silnik      ) = (  1.2111 +j  2.2745)om
 Z1(*T2         ,*T1         ) = (  0.0034 +j  0.1495)om
 Z1(*T2         ,*T2         ) = (  1.2751 +j  2.6263)om

 macierz Z0 poziomie napiecia UNSobl=10kV
 wezel: GPZ110kV    
 Z0(GPZ110kV    ,GPZ110kV    ) = (  0.0004 +j  0.0511)om
 Z0(GPZ110kV    ,GPZ10kV     ) = (  0.0001 +j  0.0239)om
 Z0(GPZ110kV    ,RO          ) = (  0.0001 +j  0.0239)om
 Z0(GPZ110kV    ,silnik      ) = ( -0.0000 +j  0.0000)om
 Z0(GPZ110kV    ,*T1         ) = (  0.0001 +j  0.0243)om
 Z0(GPZ110kV    ,*T2         ) = ( -0.0000 +j  0.0000)om
 wezel: GPZ10kV     
 Z0(GPZ10kV     ,GPZ110kV    ) = (  0.0001 +j  0.0239)om
 Z0(GPZ10kV     ,GPZ10kV     ) = (     inf   +j      inf)om
 Z0(GPZ10kV     ,RO          ) = (     inf   +j      inf)om
 Z0(GPZ10kV     ,silnik      ) = (  0.0012 +j  0.0149)om
 Z0(GPZ10kV     ,*T1         ) = (  0.0043 +j  0.0909)om
 Z0(GPZ10kV     ,*T2         ) = (  0.0012 +j  0.0149)om
 wezel: RO          
 Z0(RO          ,GPZ110kV    ) = (  0.0001 +j  0.0239)om
 Z0(RO          ,GPZ10kV     ) = (     inf   +j      inf)om
 Z0(RO          ,RO          ) = (     inf   +j      inf)om
 Z0(RO          ,silnik      ) = (  0.0012 +j  0.0149)om
 Z0(RO          ,*T1         ) = (  0.0043 +j  0.0909)om
 Z0(RO          ,*T2         ) = (  0.0012 +j  0.0149)om
 wezel: silnik      
 Z0(silnik      ,GPZ110kV    ) = ( -0.0000 +j  0.0000)om
 Z0(silnik      ,GPZ10kV     ) = (  0.0012 +j  0.0149)om
 Z0(silnik      ,RO          ) = (  0.0012 +j  0.0149)om
 Z0(silnik      ,silnik      ) = (  0.2888 +j  3.3210)om
 Z0(silnik      ,*T1         ) = ( -0.0000 +j  0.0000)om
 Z0(silnik      ,*T2         ) = (  0.1358 +j  1.6600)om
 wezel: *T1         
 Z0(*T1         ,GPZ110kV    ) = (  0.0001 +j  0.0243)om
 Z0(*T1         ,GPZ10kV     ) = (  0.0043 +j  0.0909)om
 Z0(*T1         ,RO          ) = (  0.0043 +j  0.0909)om
 Z0(*T1         ,silnik      ) = ( -0.0000 +j  0.0000)om
 Z0(*T1         ,*T1         ) = (  0.0043 +j  0.0926)om
 Z0(*T1         ,*T2         ) = ( -0.0000 +j  0.0000)om
 wezel: *T2         
 Z0(*T2         ,GPZ110kV    ) = ( -0.0000 +j  0.0000)om
 Z0(*T2         ,GPZ10kV     ) = (  0.0012 +j  0.0149)om
 Z0(*T2         ,RO          ) = (  0.0012 +j  0.0149)om
 Z0(*T2         ,silnik      ) = (  0.1358 +j  1.6600)om
 Z0(*T2         ,*T1         ) = ( -0.0000 +j  0.0000)om
 Z0(*T2         ,*T2         ) = (  0.1358 +j  1.6600)om