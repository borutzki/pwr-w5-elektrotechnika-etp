function [nazwez,wezly,nazgal,galezie,UNSobl,winf]=az2read
% az2read() czyta dane do analiz zwarciowych
t0=clock; % czas rozpoczecia obliczen
rok=int2str(t0(1));miesiac=int2str(t0(2));dzien=int2str(t0(3));
godz=int2str(t0(4));mins=int2str(t0(5));secs=int2str(t0(6));
czas=['_' rok '-' miesiac '-' dzien '_' godz 'h' mins];
wdold=cd; winf=1e8;
[fname,sciezka]=uigetfile('dataz2*.m',...
  'Wybierz plik danych zgodny z wymaganiami programu az():   ');
fprintf('\n... wybrano dane: %s%s.m',sciezka,fname);
eval(['cd(''',sciezka,''')']);
zwdat=strtok(fname,'.');
[sbus,sgal,UNSobl,winf]=feval(zwdat);% wybrany plik danych
eval(['cd(''',wdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
 sciezka0=pwd; cd([sciezka0 '\Wyniki']); sciezka1=pwd;
 plikWe= strcat([sciezka1 '\az2readOUT',czas,'.m']);
 fd=fopen(plikWe,'wt');  % plik z przeczytanymi danymi do obliczen
 cd ..
% DANE WEZLOW
% sbus={
%        nazwa           UNS    tN
%      'GPZ110kV    '  110.0    115/11]};
sp12='123456789012';  % maksymalnaie nazwa ma 12 znakow
% sbus{} do znakowej nazwez[] oraz numerycznej bus[]
[nw,mw]=size(sbus); nazwez=strvcat(sp12, char(sbus(:,1))); 
nazwez=nazwez(2:end,:); 
bus=[[1:nw]' cell2mat(sbus(:,2:end))]; %dane numeryczne  
bus(nw,1)=0; % wezel modniesienia ma numer 0
[nbus,mbus]=size(bus); 
fprintf(fd,'\n\n bus[] wg danych wczytanych'); 
fprintf(fd,'\n              nrwez      UNS         tN');
for i=1:nbus
 fprintf(fd,'\n %-12s %4d   %9.3f  %9.3f  %9.3f',...
     nazwez(i,:),bus(i,1),bus(i,2),bus(i,3) );  
end
wezly=bus(1:nw-1,:);% dane tylko dla niezaleznych wezlow sieci
% sgal{} do znakowej nazgal[] oraz numerycznej galezie[]
% sgal={
%Galaz   Od      Do     UNS    R1   X1     R0      X0    tN
%max12s  max12s  max12s  kV    om   om     om      om     -
%   1      2      3      4      5    6      7       8     9
%'L'   'GPZ10kV' 'XLK'  10  0.880  0.740  1.180  2.590  1.0000};
% sgal{} - przeczytane
[nl,n]=size(sgal);
if nl   % brak galezi
  nazgal=strvcat( sp12,char(sgal(:,1)));  nazgal=nazgal(2:end,:);  
  nazwp =strvcat( sp12,char(sgal(:,2)));  nazwp=nazwp(2:end,:);
  nazwk =strvcat( sp12,char(sgal(:,3)));  nazwk=nazwk(2:end,:); 
  galezie=[zeros(nl,2) cell2mat(sgal(:,4:end))];%dane numeryczne
  strvcatnazwp0=deblank(strvcat(nazwp));
  strvcatnazwk0=deblank(strvcat(nazwk));
  for ii=1:nw
    nazw0=deblank(nazwez(ii,:));
    wp = strmatch(nazw0,strvcatnazwp0,'exact');
    if ~isempty(wp)    galezie(wp,1)=ii;      end
    wk = strmatch(nazw0,strvcatnazwk0,'exact');
    if ~isempty(wk)    galezie(wk,2)=ii;       end
   end % for ii=1:nw
   prawid=galezie(:,1) .* galezie(:,2);
   nrgalezie=find(prawid ==0);
   if ~isempty(nrgalezie)
      for ii=1:length(nrgalezie)
       fprintf(fd,...
       '\n galaz nr=%3d - >%s<  ma bledne nazwy wezlow',...
           nrgalezie(ii),nazgal(nrgalezie(ii),:));
       fprintf(...
       '\n galaz nr=%3d - >%s<  ma bledne nazwy wezlow',...
           nrgalezie(ii),nazgal(nrgalezie(ii),:));
      end     
      blad=1;   %blad w nazwach galezi
      return;   % powrot do arm()
   end  %if ~isempty(nrgalezie)
else
   nazgal=[]; galezie=[];
end
% KONTROLNY WYDRUK tabeli galezie wg sgal{} i nadanych nr wezlow
[ngalezie,mgalezie]=size(galezie);sp=' ';
fprintf(fd,'\n\n galezie[] wg danych wczytanych');    
fprintf(fd,'\n nazwg        nazwp        nazwk        wp - wk');
fprintf(fd,'  UNS     R1     X1     R0     X0      tN');
fprintf(fd,'\n                                         1   2'); 
fprintf(fd,'    3       4      5      6      7      8');
brama=1; WP=galezie(:,1); WK=galezie(:,2);
zWP=[]; zWP=find(WP(:,1)==nw); if ~isempty(zWP) WP(zWP,1)=0; end
zWK=[]; zWK=find(WK(:,1)==nw); if ~isempty(zWK) WK(zWK,1)=0; end
galezie(:,1)=WP; galezie(:,2)=WK;
for k=1:ngalezie
 wp=WP(k); wk=WK(k); wp0=[];
 if ~wp
   wp=nw; WP(k)=wp; wp0=k;%wykrywanie blednych nazw
   BladDanych=1;     end
 if ~wk wk=nw; WK(k)=wk; end
   nazg=nazgal(k,:); nazp=nazwez(wp,:); nazk=nazwez(wk,:);
   fprintf(fd,...
'\n%-8s %-8s %-8s %3d %3d %5.3g %6.3g %6.3g %6.3g %6.3g %6.3g',...
            nazg,nazp, nazk,  galezie(k,1:8));
 if ~isempty(wp0)
  fprintf(fd,...
'\n ... galaz: nr=%d %s !ma bledne nazwy wezlow!',k,nazg);
 end
end %for k=1:ngalezie
% Przeliczenie impedancji na napiecie obliczeniowe UNSobl
tn=galezie(:,8); tn2=tn.^(2); 
for i=4:7  galezie(:,i)=galezie(:,i).*tn2;  end
fprintf(fd,...
'\n galezie[] po przeliczeniu na UNSobl=%6.3g kV',UNSobl);    
fprintf(fd,'\n nazwg        nazwp        nazwk        wp - wk');
fprintf(fd,'  UNS     R1     X1     R0     X0      tN');
fprintf(fd,'\n                                         1   2'); 
fprintf(fd,'    3       4      5      6      7      8');
brama=1; WP=galezie(:,1); WK=galezie(:,2);
for k=1:ngalezie
 wp=WP(k); wk=WK(k);
 if ~wp wp=nw; WP(k)=wp;  end
 if ~wk wk=nw; WK(k)=wk; end
   nazg=nazgal(k,:); nazp=nazwez(wp,:); nazk=nazwez(wk,:);
   fprintf(fd,...
'\n%-8s %-8s %-8s %3d %3d %5.3g %6.3g %6.3g %6.3g %6.3g %6.3g',...
           nazg,nazp, nazk,  galezie(k,1:8));
end %for k=1:ngalezie
fclose(fd);
end % koniec az2read

