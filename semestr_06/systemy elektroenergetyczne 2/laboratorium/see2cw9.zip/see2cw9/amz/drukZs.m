function drukZs(fd,n,Zs,skl,nazwez,UNSobl)
sUNSobl=num2str(UNSobl,3);
opis=['macierz Z' skl ' poziomie napiecia UNSobl=' sUNSobl 'kV'];
fprintf(fd,'\n\n %s',opis);
fprintf(   '\n\n %s',opis);
Rs=real(Zs); Xs=imag(Zs); winf='inf';
for i=1:n
   fprintf(fd,'\n wezel: %s',nazwez(i,:) );
   %fprintf(   '\n wezel: %s',nazwez(i,:) );
   for k=1:n
    format=1;  if Xs(i,k)>1e5 format=0; end
    if format
        fprintf(fd,'\n Z%s(%8s,%8s) = (%8.4f +j%8.4f)om',...
            skl,nazwez(i,:),nazwez(k,:),Rs(i,k),Xs(i,k) );
        %fprintf(   '\n Z%s(%8s,%8s) = (%8.4f +j%8.4f)om',...
        %    skl,nazwez(i,:),nazwez(k,:),Rs(i,k),Xs(i,k) );
    else
        fprintf(fd,'\n Z%s(%8s,%8s) = (%8s   +j %8s)om',...
            skl,nazwez(i,:),nazwez(k,:),winf,winf);
        %fprintf(   '\n Z%s(%8s,%8s) = (%8s   +j %8s)om',...
        %    skl,nazwez(i,:),nazwez(k,:),winf,winf);
    end %if format
   end %for k=1:n
end %for i=1:n
end