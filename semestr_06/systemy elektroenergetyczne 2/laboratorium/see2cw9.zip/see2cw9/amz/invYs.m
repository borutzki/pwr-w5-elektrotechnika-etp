%skrypt invYs
j=sqrt(-1);
n=6; Y1=zeros(n,n); Y0=zeros(n,n);
Y1(1,1)=0.3184-j*18.2384; Y1(1,5)=-0.3184+j*5.9204; Y1(5,1)=Y1(1,5);
Y1(2,2)=0.7967-j*6.8255;  Y1(2,3)=-0.387+j*0.296;   Y1(3,2)=Y1(2,3);
                          Y1(2,5)=-0.3184+j*5.9204; Y1(5,2)=Y1(2,5);
Y1(3,3)=0.4699-j*0.9058;  Y1(3,6)=-0.083+j*0.6098;  Y1(6,3)=Y1(3,6);
Y1(4,4)=0.0914-j*0.6661;  Y1(4,6)=-0.083+j*0.6098;  Y1(6,4)=Y1(4,6);
Y1(5,5)=0.6368-j*11.84;
Y1(6,6)=0.1659-j*1.2197;
fprintf('\n Macierz admitancyjna zwarciowa dla skl. 1\n');
Y1
Z1=inv(Y1);
fprintf('\n Macierz impedancyjna zwarciowa dla skl. 1\n');
Z1