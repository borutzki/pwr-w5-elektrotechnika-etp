function drukYs(fd,n,Ys,skl,nazwez,UNSobl)
sUNSobl=num2str(UNSobl,3);
opis=['macierz Y' skl ' poziomie napiecia UNSobl=' sUNSobl 'kV'];
fprintf(fd,'\n\n %s',opis);
fprintf(   '\n\n %s',opis);
Gs=real(Ys); Bs=imag(Ys); winf='inf';
for i=1:n
   fprintf(fd,'\n wezel: %s',nazwez(i,:) );
   %fprintf(   '\n wezel: %s',nazwez(i,:) );
   for k=1:n
    format=1;  if Bs(i,k)>1e5 format=0; end
    if format
        fprintf(fd,'\n Y%s(%8s,%8s) = (%8.4f +j%8.4f)S',...
            skl,nazwez(i,:),nazwez(k,:),Gs(i,k),Bs(i,k) );
        %fprintf(   '\n Y%s(%8s,%8s) = (%8.4f +j%8.4f)S',...
        %    skl,nazwez(i,:),nazwez(k,:),Gs(i,k),Bs(i,k) );
    else
        fprintf(fd,'\n Y%s(%8s,%8s) = (%8s   +j %8s)S',...
            skl,nazwez(i,:),nazwez(k,:),winf,winf);
        %fprintf(   '\n Y%s(%8s,%8s) = (%8s   +j %8s)S',...
        %    skl,nazwez(i,:),nazwez(k,:),winf,winf);
    end %if format
   end %for k=1:n
end %for i=1:n
end