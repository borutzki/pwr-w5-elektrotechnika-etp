function amz
% analiza macierzy zwarciowych
% w sieciach skutecznie uziemionych:
% - czyta dane zwarciowe sici z pliku wybranego w oknie dialogowym
% - tworzy macierz admitancyjna zwarciowa  Y1, Y0
% - wyznacza impedancje zwarciowe wezlow Thevenina Zkk1, Zkk0
t0=clock; % czas rozpoczecia obliczen
sciezka0=pwd; cd([sciezka0 '\Wyniki']); sciezka1=pwd;
plikWy= strcat([sciezka1 '\amzOUT.m']);
fd=fopen(plikWy,'wt');  % plik z przeczytanymi danymi do obliczen
 cd ..
wdold=cd;
% czytanie danych do obl. zwarciowych z tablic komorkowych
[nazwez,wezly,nazgal,gal,UNSobl,winf]=az2read;
fprintf('\n ... przeczytano dane do analizy macierzy zwarciowych ...');
eval(['cd(''',wdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
j=sqrt(-1); % operator liczby zespolonej
% wstepna obrobka danych
[n,mw]=size(wezly); % wymiary tablicy danych wezlowych
[nbr,mbr]=size(gal);% wymiary tablicy danych galeziowych
wp=gal(:,1);   wk=gal(:,2); % poczatki i konce galezi
rgal1=gal(:,4); xgal1=gal(:,5); % R1,X1 galezi
zgal1=rgal1+j*xgal1; ygal1=1./zgal1;
ggal1=real(ygal1); bgal1=imag(ygal1); % G1,B1 galezi
rgal0=gal(:,6); xgal0=gal(:,7); % R0,X0 galezi
zgal0=rgal0+j*xgal0; ygal0=1./zgal0;
ggal0=real(ygal0); bgal0=imag(ygal0); % G0,B0 galezi
% macierz admitancji zwarciowych dla skl. 1
[Y1]=az2mYs(fd,UNSobl,n,nbr,wp,wk,ggal1,bgal1);
skl='1'; macY1=full(Y1);
drukYs(fd,n,macY1,skl,nazwez,UNSobl);
% macierz admitancji zwarciowych dla skl. 0
[Y0]=az2mYs(fd,UNSobl,n,nbr,wp,wk,ggal0,bgal0);
skl='0'; macY0=full(Y0);
drukYs(fd,n,macY0,skl,nazwez,UNSobl);
% Wyznaczanie macierzy impedancji zwarciowych
macZ1=[]; macZ0=[];
for k=1:n
 % knazwa=nazwez(k,:);   UNS=wezly(k,2);
 % tN=wezly(k,3); tN2=tN^2;
  %wektor impedancji dla k-tego wezla - skl. 1 na poziomie UNS
  vec1=zeros(n,1); vec1(k,1)=1; % 1 na pozycji wezla ze zwarciem
  zveck1=Y1\vec1; yveck1=Y1(:,k); % kolumna m. Z1 i Y1
  macZ1=[macZ1 zveck1];
  %wektor impedancji dla k-tego wezla - skl. 0 na poziomie UNS
  vec0=zeros(n,1); vec0(k,1)=1; 
  zveck0=Y0\vec0; yveck0=Y0(:,k); % kolumna m. Z0 i Y0
  macZ0=[macZ0 zveck0];
end %for k=1:n
skl='1';
drukZs(fd,n,macZ1,skl,nazwez,UNSobl);
skl='0';
drukZs(fd,n,macZ0,skl,nazwez,UNSobl);
fprintf('\n\nWyniki analizy macierzy zwarciowych w m-pliku: %s',plikWy); 
fclose('all');
end % koniec az2suz.m

