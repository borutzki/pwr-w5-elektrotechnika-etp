function [sbus,sgal,UNSobl,winf]=dataz2cw9
% T1 - YNd
% T2 - Dyn
%W obl. zwar. par. zast. beda przeliczane na nap. UNSobl
%UNSobl - nap. znam. sieci wybrane na nap. obliczeniowe
UNSobl=10.0; % kV
winf=1e8; % nieskonczonosc
% DANE WEZLOWE
%tN - przekl. transf.: siec UNSobl -> wezel UNS
%tN=tN1*tN2*... - siec promieniowa
%tN=UNSobl/UNS - w przypadku sieci oczkowych
% Wezel - max 12 znakowa nazwa wezla sieci
% UNS	- napiecie znamionowe sieci w danym wezle
% Nalezy podac wezly srodkowe gwiazdy dodane dla transf., poprzedzone *
% Ostatnim wezlem musi byc wezel odniesienia ZIEMIA, o zerowym potencjale
 sbus={
%wezel        UNS      tn
%max12s        kV      - 
 'GPZ110kV'   110    11/115
 'GPZ10kV'     10      1.0;
 'RO'          10      1.0;
 'silnik'     0.525   10.5/0.525;
 '*T1'        110    11/115;
 '*T2'         10      1.0;
 'ZIEMIA'       0      0.0;
};
%  DANE ZRODEL
%Parametry zastepcze obliczono przy UN - nap. znam. zrodla
%W obl. zwar. par. zast. beda przeliczone na nap. UNSobl
%tN - przekl. transf.: sieci ze zrodlem - siec o nap. UNSobl
%tN=tN1*tN2*... - siec promieniowa wielonapieciowa
%tN=UNS/UNSobl - w przypadku sieci oczkowych
% Zrodlo - max 12-znakowa nazwa zrodla,
% Wezel  - max 12-znakowa nazwa wezla sieci, z przylaczonym zrodlem
% R1,X1  - rezystancja i reaktancja skl. 1
% R0,X0  - rezystancja i reaktancja skl. 0
% R1,X1,R0,X0 - skl. symetryczna zgodna i zerowa
sgen={
%Zrodlo    WezZr     ZIEMIA     UNS      R1    X1     R0     X0   tN
%max12s   max12s     max12s      kV      om    om     om     om    -
 'GS'    'GPZ10kV'  'ZIEMIA'     10   0.117  1.672  winf   winf    1.0;
 'MAS'    'silnik'  'ZIEMIA'  0.525   0.0126 0.02999  winf   winf 10.5/0.525;
 'SEE'  'GPZ110kV'  'ZIEMIA'    110   0      6.622  0     6.622  11/115;
};
 % DANE LINII
%Parametry zastepcze obliczono przy UNS - nap. znam. linii
% Galaz - max 12-znakowa nazwa linii,
% Od    - max 12-znakowa nazwa wezla poczatku linii
% Do    - max 12-znakowa nazwa wezla konca linii
%tN - przekl. transf.: linia - siec o nap. UNSobl
%tN=tN1*tN2*... - siec promieniowa wielonapieciowa
%tN=UNS/UNSobl - w przypadku sieci oczkowych
% R1,X1,R0,X0 - skl. symetryczna zgodna i zerowa
 slin={
%linia       Od       Do   UNS     R1     X1     R0     X0   tN
%max12s  max12s    max12s   kV     om     om     om     om   -
 'LK'  'GPZ10kV'   'RO'     10  1.485  1.1129   1.8661 3.4342 1.0; 
};
 % DANE TRANSFORMATOROW
%Parametry zastepcze przeliczono na UNP - nap. znam. transf.
% Galaz - max 12-znakowa nazwa galezi transformatora,
% Od    - max 12-znakowa nazwa wezla pocz. galezi transf., moze byc z *
% Od    - max 12-znakowa nazwa wezla konc. galezi transf., moze byc z *
%tN - przekl. transf.: transf. - siec o nap. UNSobl
%tN=tN1*tN2*... - siec promieniowa wielonapieciowa
%tN=UNS/UNSobl - w przypadku sieci oczkowych
% R1,X1,R0,X0 - skl. symetryczna zgodna i zerowa
% UNS - napiecie znam. sieci po stronie wezla poczatkowego transf.
 stra={
%transf      Od         Do    UNS      R1     X1     R0     X0   tN
%max12s    max12s     max12s   kV      om     om     om     om   -
 % YNd - polaczenie uzwojen P-K: 
'T1-A'  'GPZ110kV'    '*T1'   110   1.034 18.570  1.034 18.570 11/115;
'T1-B'  'GPZ10kV'     '*T1'   110   1.034 18.570   winf	  winf 11/115;
'T1-E'  '*T1'      'ZIEMIA'   110    winf   winf 0.8583	16.920 11/115;
 % Dyn - polaczenie uzwojen P-K: 
'T2-A'  'RO'         '*T2'     10   0.1596  1.798   winf   winf    1.0;
'T2-B'  'silnik'     '*T2'     10   0.1596  1.798   0.153  1.661    1.0;
'T2-E'  '*T2'     'ZIEMIA'     10    winf   winf    0.1358 1.660   1.0;
};
sgal=[slin; stra; sgen];
end % koniec dataz2*
