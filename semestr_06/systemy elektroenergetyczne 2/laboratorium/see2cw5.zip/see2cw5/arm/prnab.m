function pr=prnab(Ex,Dx,xa,xb)
% Prawdopodbienstwo zmiennej losowej normalnej w przedziale:  xa <= X < xb  
% wart. oczek.        - Ex 
% odchyl. standardowe - Dx 
% dolna wartosc       - xa 
% gorna wartosc       - xb 
% Standaryzacja zmiennej losowej dla gornej i dolnej wartosci,
% Wywolanie funkcji erf(t)
% erf(t)=2/sqrt(pi)*calka(od 0 do t)[exp(-t^2]dt
% F(t)=0.5+0.5*erf(t/sqrt(2)) dla t >= 0
% F(t)=0.5-0.5*erf(t/sqrt(2)) dla t <  0
% Obliczenie wartosci dystrybuanty dla gornej wartosci xb
tb=(xb-Ex)/Dx;
Fb=0.5*(1+sign(tb)*erf( abs(tb)/sqrt(2) ));
% Obliczenie wartosci dystrybuanty dla dolnej wartosci xa
ta=(xa-Ex)/Dx;
Fa=0.5*(1+sign(ta)*erf( abs(ta)/sqrt(2) ));
% Prawdopodobienstwo  pr=P{xa <= X < xb } 
pr=(Fb-Fa);
end %prnab()

