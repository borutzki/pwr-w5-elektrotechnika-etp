function a2opisGalWyl(fd,tabgalwyl,nazgal,nazwez,WPK,UNBUS,TMK);
if isempty(tabgalwyl)
  return;
else
 nwylgal=size(tabgalwyl,1);
 zn1='transformator';
 zn2='linia        ';
 zn3='LACZNIK      ';
 fprintf(fd,'\n\n GALEZIE wylaczone:');
 fprintf(fd,...
 '\nNrg  Galaz        Od wezla     Do wezla     element          UN');
 fprintf(   '\n\n GALEZIE wylaczone:');
 fprintf(...
 '\n Lp  Galaz        Od wezla     Do wezla     element          UN');
 for iwylgal=1:nwylgal
   kwyl=tabgalwyl(iwylgal,1); zn='             ';
   iwyl=real(WPK(kwyl)); jwyl=imag(WPK(kwyl)); tm=real(TMK(kwyl));
   nazkwyl=nazgal(kwyl,:); 
   naziwyl=nazwez(iwyl,:); nazjwyl=nazwez(jwyl,:);
   UN=UNBUS(iwyl,1); zn=zn3;
   if ~tm zn=zn2; end
   if  tm zn=zn1; end
   if nazkwyl(1)=='!' ; zn=zn3; end
   fprintf(fd,'\n%4d %-12s %-12s %-12s %9s %5.1f kV',...
       iwylgal, nazkwyl, naziwyl, nazjwyl,zn,UN );
    fprintf(  '\n%4d %-12s %-12s %-12s %9s %5.1f kV',...
       iwylgal, nazkwyl, naziwyl, nazjwyl,zn,UN );
 end
end
end % koniec a2opisGalWyl()


