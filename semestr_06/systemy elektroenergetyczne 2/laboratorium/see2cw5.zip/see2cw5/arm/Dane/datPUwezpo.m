function [tabPU]=datPUwezpo 
% krzywe nosowe P-U maksymalnie dla 20 wezlow
% Przyklad obliczeniowy
tabPU={
%armDATpo.m
%'FW411';  'ELW422';  'ELC412'; 
% 'ODB111'; 'ODB131'; 'ODB121';
'ODB131';  'ODB111';  'ODB121';
 };
end

 
