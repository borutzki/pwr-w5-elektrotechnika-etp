function  [sbus,slin,stra,Sbase]=armDATburda
% DANE WEZLOWE
 Sbase =   100; % moc bazowa w MVA
% nazwa - max 12 znakow
% typ - sposob udzialu wezla w regulacji napiecia:
%   1 - PQ  - odbiorczy,  wymaga P,Q
%   2 - PU  - generacyjny bez ograniczen Q, wymaga Pg,Ug
%   3 - Pdelta - wez. bilansujacy, wymaga U oraz Uk=0
%   4 - izolowany - nie bierze udzialu w obliczeniach
%   5 - PQ - odb. z reg. przekl. transf., wymaga U
%   6 - PU - generacyjny z ogr. Q, wymaga Pg oraz Qmin, Qmax
%   7 - PU - z ogr. Qmin, Qmax, przy czym Q=Qmin - typ=7
%   8 - PU - z ogr. Qmin, Qmax, przy czym Q=Qmax - typ=8
% Un   - napiecie znamionowe sieci, kV
% Uzad - zadana wartosc napiecia w pu, w wezlach typu 2,3,5,6
% Uk   - wartosc kata nap. w stopniach
%    Pd(+), MW    - moc czynna odb., Pd(-) - doplywajaca do wez.
%    Qd(+), Mvar  - moc bierna odb. (bierna indukcyjna)
%    Qd(-) - moc bierna doplywajaca (bierna pojemnosciowa)
%    Pg(+), MW    - moc czynna generowana w wezle
%    Pg(-) - moc czynna gen. z ujemnym znakiem (odbierana)
%    Qg(+), Mvar  - moc bierna gen. indukcyjna
%    Qg(-), Mvar  - moc bierna gen. pojemnosciowa
%    Gsh(+) - P jako konduktancja w mikroS
%    Bsh(+) - Q jako susceptancja pojemnosciowa w mikS
%    Bsh(-) - Q jako susceptancja indukcyjna w mikS
%    Qgmin, Mvar  - minimalna  moc bierna generowana w wezle
%    Qgmax, Mvar  - maksymalna moc bierna generowana w wezle
%    Qk - moc bierna kompensatora w Mvar, przy UN: (-)poj, (+)ind
%    Pgm, MW - minimalna gen. moc czynna
%    Pgm, MW - minimalna gen. moc czynna
 sbus={
% nazwa typ Un Uzad Uk Pd   Qd   Pg   Qg  Gsh Bsh Qgmin Qgmax  Qk Pgm  PgM
% max12s -  kV   pu s  MW Mvar   MW Mvar mikS mikS Mvar Mvar Mvar  MW   MW
%    1   2   3    4 5   6    7    8    9  10  11    12    13  14  15   16 
'SEE400' 3 400 1.00 0   0    0    0    0   0   0     0     0   0   0    0
'FW411'  1 400 1.00 0   0    0 1000    0   0   0     0     0 -200  0 1000
'ELW422' 6 400 1.10 0   0    0 1200    0   0   0  -400   800   0 800 1240
'ELC412' 6 400 1.08 0   0    0 1000    0   0   0  -400   800   0 1000 1040
'ODB111' 5 110 1.00 0 200  100    0    0   0   0     0     0   0   0    0
'ODB131' 1 110 1.00 0 400  100    0    0   0   0     0     0  -10  0    0  
'ODB121' 1 110 1.00 0  50   20    0    0 100  40     0     0    0  0    0
};
%
% DANE LINII - linie, wylaczniki
% Linia   - nazwa linii do 12 znakow
% WezPocz - nazwa wezla poczatku linii do 12 znakow
% WezKonc - nazwa wezla konca    linii do 12 znakow
% R,X - rezystancja i reaktancja podluzna linii w omach
% G,B  - konduktancja i susceptancja poprzeczna w mikroSimensach
% B>0  - susceptancja pojemnosciowa
% Imax - dopuszczalne obciazenie termiczne linii w A
% st: 1 - zal., 0 - wyl.
% lkm - dlugosc w km, Smm2 - przekroj w mm2
 slin={
%Galaz  WezPocz  WezKonc   R   X    G   B  Imax  stlkm  Smm2
%max12s max12s   max12s   om  om mikS mikS    A  -  km   mm2
%  1        2        3     4   5    6    7    8  9  10    11
'L401' 'FW411'  'SEE400'   9  99    0  990 2500  1 300   350;
'L402' 'ELW422' 'ELC412'  15 165    0 1650 2500  1 500   350;
'L403' 'ELC412' 'SEE400'   2  20    0  150 2500  1  50   350;
'L404' 'ELC412' 'SEE400'   2  20    0  150 2500  1  50   350;
'L111' 'ODB111' 'ODB121'   5  20    0  140  350  0  50   240;
'L112' 'ODB131' 'ODB121'   4  16    0  112  350  1  40   240;
 };
% DANE TRANSFORMATOROW
% Galaz   - nazwa transformatora do znakow
% WezPocz - nazwa wezla poczatku galezi do 12 znakow
% WezKonc - nazwa wezla konca    galezi do 12 znakow
% Parametry odniesiono do nap. znam. transf. w WezPocz
% R,X - rezystancja i reaktancja podluzna linii w omach
% G,B  - konduktancja i susceptancja poprzeczna w mikroSimensach
% B<0  - susceptancja indukcyjna
% Smax  - maksymalne obciazenie termiczne, Smax=Sn
% Przekladnia znam. transf.  tn = Uwpn/Uwkn,
% Uwpn - nap. znam. WezPocz, Uwkn - nap. znam. WezKonc
% Przekladnia znam. sieciowa tns = Uwpns/Uwkns
% Uwpns - nap. znam. sieci WezPocz, Uwkns - nap. znam. sieci WezKonc
% Przekladnia aktualna tact = Up/Uk,
% Up - nap. aktualne w WezPocz, Uk - nap. aktualne w WezKonc
% Regulowana przekladnia transformatora  t = tact/tns
% tm - modul przekladni transf. na poczatku regulacji
% tk - kat przekladni transf. lub przesuwnika fazowego
% tmin, tmax - minimalna i maksymalna wartosc przekladni
% dt - przyrost przekladni przypadajacy na zaczep
%  st: 1 - zal., 0 - wyl.
 stra={
%Galaz    Od       Do      R       X    G      B Smax    tm  tk   tmin   tmax     dt st
%max12s max12s max12s     om      om mikS   mikS MVA     pu  st     pu     pu     pu  -
% 1        2        3      4       5    6      7   8      9  10     11     12     13 14
'T1' 'SEE400' 'ODB111' 2.540 119.925 1.13  -1.42  250 0.9788  0 0.8788 1.0788 0.0083  1
'T2' 'ELC412' 'ODB131' 1.411  52.901 2.83 -14.17  500 1.0043  0 0.9043 1.1043 0.0125  1
'PF' 'FW411'  'ELW422'     0      12    0      0 2000 1      40      1      1      0  1
 };
end 

