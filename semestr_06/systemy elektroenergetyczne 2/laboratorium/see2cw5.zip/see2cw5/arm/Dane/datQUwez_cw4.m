function [tabQU]=datQUwez_cw4 
% krzywe nosowe Q-U maksymalnie dla 4-ech wezlow
tabQU={
% typQU = 1 - wezel dociazany i wyznaczana krzywa nosowa Q-U  
% typQU = 0 - wezel pasywny, sasiadujacy z wez. dociazanym    
%wezQU   typQU
'GPZ110kV'    0; 
'GPZ10kV'     0; 
'RO'          0;
'odbior'      1; % wez. ze wzrostem Q
};
end
 
