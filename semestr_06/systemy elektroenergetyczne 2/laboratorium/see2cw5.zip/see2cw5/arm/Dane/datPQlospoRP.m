function [datPQzakres,rozklad]=datPQlospoRP 
rozklad=1; % prostokatny rozklad prawdopodobienstwa
%rozklad=2; % normalny    rozklad prawdopodobienstwa
datPQzakres={
% zakres losowych zmian mocy wezlowych    
%Wezel   Pgmin Pgmax   Qgmin Qgmax    Pdmin Pdmax   Qdmin Qdmax 
%max12s     MW    MW    Mvar  Mvar       MW    MW    Mvar  Mvar
 'FW411'     0   800       0   100        0   200       0    80;
 'ELW422'    0  1000       0   200        0   200       0    80;
 'ELC412'  720  1200    -100   100      100   300       0   120;
 'ODB111'    0     0       0     0       20   200       8    80;
 'ODB131'    0     0       0     0       30   300      24   120;
 'ODB121'    0     0       0     0       10    50       4    20;
};
end


