function [tabQU]=datQUwezCIGREE 
% krzywe nosowe Q-U maksymalnie dla 4-ech wezlow
tabQU={
% typQU = 1 - wezel dociazany i wyznaczana krzywa nosowa Q-U  
% typQU = 0 - wezel pasywny, tylko do krzywej nosowej Q-U    
%wezQU   typQU
'B12112'     0; 
'B09211'     1; % wez. ze wzrostem Q 
'B3L112'     0;
'B4L112'     0; 
};
end
 
