function [datPQzakres,rozklad]=datPQlosCIGRERP 
rozklad=1; % prostokatny rozklad prawdopodobienstwa
%rozklad=2; % normalny    rozklad prawdopodobienstwa
datPQzakres={
% zakres losowych zmian mocy wezlowych    
%Wezel   Pgmin Pgmax   Qgmin Qgmax    Pdmin Pdmax   Qdmin Qdmax 
%max12s     MW    MW    Mvar  Mvar       MW    MW    Mvar  Mvar
 'B05211'  200   250   -120   150        10    14      4     8
 'B06211'  190   200   -150   210        20    30      8    20
 'B07211'  140   160   -100   210        10    20      4    10
 'B08211'    0     0      0     0       200   210     80    90
 'B09211'    0     0      0     0       400   440    180   190     
};
end


