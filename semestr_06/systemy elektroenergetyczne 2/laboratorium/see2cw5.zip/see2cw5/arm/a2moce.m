function [galover]=...
    a2moce(fd,opt,nazgal,nazwap,nazwak,STATUS,TMK,wyniki);
galover=[];
nbr=size(STATUS,1); kol=[1:nbr]';% wg kolejnosci wczytania galezi
if opt==0 % druk
 fprintf(fd,'\n\n                  Moce galeziowe');
 fprintf(fd,'\n Przeplyw mocy w galezi:');
 fprintf(fd,'(p-k) pocaztek-koniec, (k-p) koniec-poczatek  ');
 fprintf(fd,'\n I/Imax - wsp. obc.,  > - I>Imax przeciazenie');
 fprintf(fd,',  wyl - wylaczenie');
 fprintf(fd,...
 '\nNrg galaz        Od           Do             ');
fprintf(fd,'P(p-k) Q(p-k)  P(k-p)  Q(k-p) I/Imax - ');
 fprintf(fd,...
 '\n  -    -         -            -                 ');
fprintf(fd,'MW    Mvar      MW    Mvar    -   - ');
end % if opt==0
overIm='     -'; kgal=0;
for kk=1:nbr
  i=kk;  status=STATUS(i);   overIm='     -';
  ImaxA=wyniki(i,7); cp=wyniki(i,3)*100; ck=wyniki(i,6)*100;
  Smm2=wyniki(i,16); dlug=wyniki(i,15);
  if (Smm2==111 | Smm2==110 | Smm2==101 | Smm2==100)
      Smm2=0; dlug=0; end 
  cover=cp; if ck>cp cover=ck; end
  if cover>100
     kgal=kgal+1;
     galover(kgal,1)=i; galover(kgal,2)=ImaxA;
     galover(kgal,3)=cover;
     galover(kgal,4)=Smm2; galover(kgal,5)=dlug;
  end %if cover>100
  if status==0 overIm='wyl';    end
  if (wyniki(i,3)>= 1.0) overIm='  I>=Idop'; end
  if (wyniki(i,6)>= 1.0) overIm='  I>=Idop'; end
  SmaxGal=wyniki(i,7); tapGal=real(TMK(i)); tkGal=imag(TMK(i));
  if tapGal SmaxGal=SmaxGal*1000; end
 if opt==0 %druk
     if tkGal
       fprintf(fd,'\n ... %g - nastawiony kat przesuwnika fazowego',tkGal);
     end
   fprintf(fd,...
   '\n%3d %-8s %-8s %-8s %7.1f %7.1f %7.1f %7.1f %6.2f ', ...
   kk,nazgal(i,:),nazwap(i,:),nazwak(i,:),...
   wyniki(i,1:2) ,wyniki(i,4:5) ,wyniki(i,6)  );
   if wyniki(i,3)>=1.0 & wyniki(i,6)>=1.0
       fprintf(fd,'>'); end 
   if ~status fprintf(fd,'%s',overIm); end  
 end % if opt==0
end % for kk=1:nbr
if opt==0
fprintf(fd,'\n');
%profil obciazenia pradowego galezi
    tp=clock; % czas rozpoczecia obliczen
    rok=int2str(tp(1)); miesiac=int2str(tp(2));
    dzien=int2str(tp(3));
    godz=int2str(tp(4));mins=int2str(tp(5));
    secs=int2str(tp(6));
    acI=[rok miesiac dzien godz mins];
    nrg=(1:nbr)'; Idop=nrg./nrg; I80=Idop*0.8;
    Im=wyniki(:,3); 
    plot(nrg,Im,'k-',nrg,Idop,'r--',nrg,I80,'b-.',...
    'LineWidth',1.5,...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor','g',...
    'MarkerSize',10);
    grid on; 
    xlabel('nr galezi wg kolejnosci wczytania');
    ylabel('I/Imax');
    title('I/Imax - profil pradowego obciazenia galezi sieci');
    legend(' I/Imax', 'Idop=1','0.8Idop');
    
    axis([1 1.1*nbr 0 2]);
    Iprofil = ['cIprofil_' acI]; 
    saveas(gcf,Iprofil,'emf'); close;
end
end %koniec a2moce()