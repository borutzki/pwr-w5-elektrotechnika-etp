function [wezPQsrm,nowePQsrm,rozklad]=a2srmPQlos(fd,nazwez);
% CZYTANIE losowych zamian mocy wezlowych
wdold=cd;
[fname,sciezka]=...
uigetfile('datPQlos*.m','Wybierz plik dla losowych zmian PQ');
fprintf('\n... wybrano: %s%s.m',sciezka,fname);
eval(['cd(''',sciezka,''')']); datafile=strtok(fname,'.');
[sPQsrm,rozklad]=feval(datafile);% zakresy losowych zmian mocy wez.
eval(['cd(''',wdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
sp12='123456789012';  % ustala dlugosc nazwy na max 12 znakow
[nw,mw]=size(nazwez); nrwez=[1:nw]';
if ~isempty(sPQsrm)
   [nl,n]=size(sPQsrm);
   nazwp =strvcat( sp12,char(sPQsrm(:,1)));  nazwp=nazwp(2:end,:);
   wiersze=[zeros(nl,1) cell2mat(sPQsrm(:,2:end)) ];
   strvcatnazwp0=deblank(strvcat(nazwp));
  [nbrl,mbrl]=size(wiersze); 
   for ii=1:nw
      nazw0=deblank(nazwez(ii,:));
      wp = strmatch(nazw0,strvcatnazwp0,'exact');
      if ~isempty(wp) wiersze(wp,1)=nrwez(ii); end
    end % for ii=1:nw
   wezPQsrm=wiersze(:,1); nowePQsrm=wiersze(:,2:end);
else
   return
end  %if ~isempty(sPQsrm)
iwezPQsrm=[]; iwezPQsrm=find(wezPQsrm~=0); nrwezPQsrm=[];
if ~isempty(iwezPQsrm)
    nrwezPQsrm=wezPQsrm(iwezPQsrm); nrPQsrm=nowePQsrm(iwezPQsrm,:);
end
if ~isempty(nrwezPQsrm)
    wezPQsrm=[]; nowePQsrm=[]; wezPQsrm=nrwezPQsrm;
    nowePQsrm=nrPQsrm;
end
end % koniec a2srmPQlos()