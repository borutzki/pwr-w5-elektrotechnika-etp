function [Vbus,SLBUS,SGBUS,sukces] =...
a2NR(fd,NRBUS,TUNBUS,SGBUS,SLBUS,REF,PU,PQ,Ybus,Vbus,Ureg,...
opt,SGMIN,SGMAX,nazwez);
% met. Newtona - Raphsona w ukladzie napiec wezlowych e,f
TYP=real(TUNBUS); UNBUS=imag(TUNBUS);
n=size(NRBUS,1); % liczba wszystkich wezlow
nPU=size(PU,1); npv=nPU+1; % liczba wezlow typu PU
nREF=size(REF,1); %liczba wezlow bilansujacych
nPQ=size(PQ,1); % liczba wezlow typu PQ
WezIzol=find(TYP(:)==4);
nWezIzol=size(WezIzol,1); % wezly izolowane
Jmatrix=[];  dureg2=[]; % rezerwacja tablicy na m. Jacobiego
PUQ=[PU;PQ]; wPUQ=size(PUQ,1); % tablica nr wezlow PU, PQ
Vbus0=Vbus; Vbusold=Vbus; % zapamietanie napiec przed iteracjami
Um([REF;PU])=Ureg([REF;PU]); % reg. moduly napiec w wezlach PU
Pg=real(SGBUS); Qg=imag(SGBUS); % moce wezlowe generowane
Pd=real(SLBUS); Qd=imag(SLBUS); % moce wezlowe odbierane
Pbus=Pg-Pd; Qbus=Qg-Qd; Sbus=Pbus+j*Qbus;%zespolone moce wezlowe
% wektor kwadratow regulowanych napiec przez gen. synchr.
ureg2=zeros(n,1);if nPU ureg2(PU) = Um(PU).^2;end
% PROCES i t e r a c y j n y realizowany przez while
if opt==0
 fprintf(fd,'\n Proces iteracyjny rozwiazania rownan wezlowych');
 fprintf(fd,...
 '\n IT          w     normaF    Umin   wezUmin         wdetJ');
 fprintf(   '\n Proces iteracyjny rozwiazania rownan wezlowych');
 fprintf(...
 '\n IT          w     normaF    Umin   wezUmin         wdetJ');
end
eps=1e-6; % dokladnosc obliczen dla sieci nN
%eps=1e-5; % dokladnosc obliczen dla sieci SN
%eps=1e-4; % dokladnosc obliczen dla sieci 110 kV
%eps=1e-3; % dokladnosc obliczen dla sieci 400/220/110 kV
iter=0; sukces=1; normF=1e8;
itmax=20; %maksymalna liczba iteracji
while sukces  & (normF > eps) & (iter<itmax)  
 ureg2it=[];
 if nPU  ureg2it = abs(Vbus).^2;  end
 Sit=Vbus.*conj(Ybus*sparse(Vbus));% moce wez. w kolejnej iteracji
 iter = iter + 1;
 % Linearyzacja rownan wezlowych
 %  |dp | = | dPe  dPf  |* |de | , generalnie dy = J dx
 %  |dU2|   | dU2e dU2f |  |df | , ureg2
 %  |dq |   | dQe  dQf  |
 % wektor niezbilansowan dy
 [dy, normF]=...
 normaF(Pbus,Qbus,ureg2,PU,PQ,nPU,nPQ,Sit,ureg2it);
 normFold=normF; % norma niezbilansowan
 %Tworzenie macierzy Jacobiego
 [Jmatrix]=a2Jac(PU,PQ,Ybus,Vbus);   convJ=1; 
 [lastmsg]=lastwarn;   lastwarn(''); 
 dx = Jmatrix\dy; % wektor przyrostow napiec
 %zmiany znaku i wzglednej wartosci wyznacznika mac. Jacobiego
 wdetJ=1;
 if opt==0
  detJ=det(Jmatrix); if iter==1 detJ0=detJ; end
  wdetJ=detJ/detJ0; % wzgledna wartosc jakobianu
 end % if opt==0
 %przerwanie procesu iter. w przypadku osobliwosci m. Jacobiego
 lastmsg=lastwarn;
  if ~isempty(lastmsg)
     lastmsg,lastwarn('');sukces=0; balance=0; break;
  end
  % wyznaczanie wsp. zbieznosci w 
  mis = Vbus.* conj(Ybus * Vbus) - Sbus; % zespolone niezbil. wez.
  a=[real(mis);imag(mis)]; % wektor niezbil. wezlowych
  de = dx(1:wPUQ); df = dx(wPUQ+1:2*wPUQ); % poprawki nap. wez.
  dVbus=Vbus*0;  dVbus(PUQ)=de+j*df; %zespolone poprawki nap.
  dSbus=dVbus.*conj(Ybus*dVbus);  
  b=[real(dSbus); imag(dSbus)]; %nieliniowy skl. szeregu Taylora
  %a4=a'*a; a3=2*b'*a; a2=b'*b-2*a'*a; a1=-2*a'*b; a0=a'*a;
  p0=-2*a'*a; p1=2*(a'*a-2*a'*b); p2=6*a'*b; p3=4*b'*b;
  par=[p3 p2 p1 p0];
  w3=roots(par); % pierwiastki wielomianu 3 stopnia
  ireal=find(imag(w3)==0); wreal=w3(ireal);
  wopt=max(wreal); % optymalny krok
  if abs(wopt)>2    wopt=1;      end
  if abs(wopt)<0.001 wopt=0.001; end
  Vold=Vbus; normFold=normF; % nap. wez. przed poprawkami
  dedf=de+j*df; % zespolone poprawki napieciowe
  % dodanie poprawek napiecowych z optymalna dlugoscia kroku
  Vbus(PUQ)=Vold(PUQ)+wopt*dedf;
  ureg2itpop=[];   if nPU  ureg2itpop = abs(Vbus).^2;  end
  Sitpop=Vbus.*conj(Ybus*sparse(Vbus));% moce wez. po iteracji
  % norma nowego wektora niezbilansowan wez. po poprawkach nap.
  [dy, normF]=...
  normaF(Pbus,Qbus,ureg2,PU,PQ,nPU,nPQ,Sitpop,ureg2itpop);
  [Usort,iUsort]=sort(abs(Vbus(PUQ))); % sortowanie U wez.
  minU=Usort(1); iminU=iUsort(1); % najmniejsze nap. wez.
  iwezU=PUQ(iminU); % nr wezla z min. U
  nrwezU=NRBUS(iwezU); nazwaU=deblank(nazwez(iwezU,:));
  if opt==0
  fprintf(fd,'\n %2d   %8.3g   %8.3g   %5.3f   %-12s %8.4g',...
                iter,wopt,normF,minU,nazwaU,wdetJ );
  fprintf(   '\n %2d   %8.3g   %8.3g   %5.3f   %-12s %8.4g',...
                iter,wopt,normF,minU,nazwaU,wdetJ );
  end
  % czy proces iteracyjny jest rozbiezny?
  if iter==itmax | wdetJ<0 sukces = 0; end
end % KONIEC petli while
if sukces % zbiezny proces iteracyjny
  if opt==0 
   fprintf(fd,'\n a2NR() - sukces=1, ITERACJE ZBIEZNE'); 
   fprintf(   '\n a2NR() - sukces=1, ITERACJE ZBIEZNE'); 
  end
else
  Vbus=Vbus0; % powrot do poprzednich  napiec 
  if opt==0 
    fprintf(fd,'\n a2NR() - sukces=0, ITERACJE ROZBIEZNE'); 
    fprintf(fd,'\n a2NR() - sukces=0, ITERACJE ROZBIEZNE'); 
  end
end % if sukces
% nowe moce wezlowe wynikajace z regulowanych napiec
Sit=Vbus.*conj(Ybus*Vbus);
Pbus = real(Sit); Qbus = imag(Sit); 
% nowe moce w wezle bilansujacym
Pg(REF)=Pbus(REF)+Pd(REF); Qg(REF)=Qbus(REF)+Qd(REF);
%nowe moce bierne generowane w wezlach typu PU
Qg(PU)= Qbus(PU) + Qd(PU);     SGBUS=Pg + j*Qg; 
end %koniec a2NR()
function [dy, normF]=...
normaF(Pbus,Qbus,ureg2,PU,PQ,nPU,nPQ,Sit,ureg2it)
dp=[]; dureg2=[]; dq=[];
dp  = Pbus  - real(Sit); % niezbilansowanie P
if nPU % % niezbilansowanie reg. nap. w wezlach PU
  dureg2 = ureg2  - ureg2it;  end
if nPQ  % niezbilansowanie Q
  dq  = Qbus  - imag(Sit);  end
% wektor niezbilansowan wez.
dy=[dp([PU;PQ]); dureg2(PU); dq(PQ)];
normF=norm(dy);%norma wektora niezbilansowan wezlowych
end
