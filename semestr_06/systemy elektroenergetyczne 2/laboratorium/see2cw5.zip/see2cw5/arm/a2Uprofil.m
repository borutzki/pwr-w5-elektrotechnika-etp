function a2Uprofil(fd,opt,Vbus,TUNBUS,nazwez,OPISrys);
TYP=real(TUNBUS);   UNBUS=imag(TUNBUS); % typy, nap. znam.
Um=abs(Vbus);
n=size(Um,1); nrw=1:n;
vec1=nrw./nrw; U09=0.9*vec1; U11=1.1*vec1;
minU=min(Um); iminU=find(Um(:,1)==minU); iminU1=iminU(1);
nazminU=nazwez(iminU1,:);
UNminU=UNBUS(iminU1); TYPmin=TYP(iminU1);
maxU=max(Um); imaxU=find(Um(:,1)==maxU); imaxU1=imaxU(1);
nazmaxU=nazwez(imaxU1,:);
UNmaxU=UNBUS(imaxU1); TYPmax=TYP(imaxU1);
fprintf(fd,'\nUmin %5.3f w %-8s',minU(1),nazminU);
fprintf(fd,'\nUmax %5.3f w %-8s',maxU(1),nazmaxU);
if opt==0
    tp=clock; % czas rozpoczecia obliczen
    rok=int2str(tp(1)); miesiac=int2str(tp(2));
    dzien=int2str(tp(3));
    godz=int2str(tp(4));mins=int2str(tp(5));
    secs=int2str(tp(6));
    acU=[rok miesiac dzien godz mins];
    hist(Um);
    title('Histogram napiec wezlowych sieci'); grid on;
    xlabel('U[pu]');  ylabel('liczba wezlow');
    Uhist = strcat('cUhist_',acU); 
    saveas(gcf,Uhist,'emf'); close;
    plot(nrw,Um,'k-',nrw,U09,'b-.',nrw,U11,'r--',...
    'LineWidth',1.5,...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor','g',...
    'MarkerSize',10);
    grid on; 
    xlabel('nr wezla wg kolejnosci wczytania');
    ylabel('U[pu]');
    title('U[pu] - profil napiec wezlowych sieci');
    legend(' rozplyw mocy', 'Umin=0.9[pu]', 'Umax=1.1[pu]');
    axis([1 n 0.70 1.3]);
    Uprofil = strcat('cUprofil_',acU); 
    saveas(gcf,Uprofil,'emf'); close;
end
end % koniec a2Uprofil()
