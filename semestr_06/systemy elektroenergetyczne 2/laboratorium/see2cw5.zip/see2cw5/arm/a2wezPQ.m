function [wezPQ,nowePQ]=a2wezPQ(fd,nazwez)
% CZYTANIE nowych mocy wez. z m-pliku
wdold=cd;
[fname,sciezka]=...
uigetfile('datPQwez*.m','Wybierz plik wezlow dla nowych PQ');
fprintf(fd,'\n... wybrano: %s%s.m',sciezka,fname);
fprintf(   '\n... wybrano: %s%s.m',sciezka,fname);
eval(['cd(''',sciezka,''')']); datafile=strtok(fname,'.');
[sPQ]=feval(datafile);% czytanie danych z wybranego pliku
eval(['cd(''',wdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
sp12='123456789012';  %nazwy do 12 znakow
[nw,mw]=size(nazwez); nrwez=[1:nw]';
if ~isempty(sPQ)
   [nl,n]=size(sPQ);
   nazwp =strvcat( sp12,char(sPQ(:,1))); 
   nazwp=nazwp(2:end,:);
   wiersze=[zeros(nl,1) cell2mat(sPQ(:,2:end)) ];
   strvcatnazwp0=deblank(strvcat(nazwp));
   [nbrl,mbrl]=size(wiersze); 
   for ii=1:nw
      nazw0=deblank(nazwez(ii,:));
      wp = strmatch(nazw0,strvcatnazwp0,'exact');
      if ~isempty(wp)  wiersze(wp,1)=nrwez(ii);  end
    end % for ii=1:nw
   wezPQ=wiersze(:,1); nowePQ=wiersze(:,2:end);
else
   return
end  %if ~isempty(sPQ)
iwezPQ=[]; iwezPQ=find(wezPQ~=0);
nrwezPQ=[];
if ~isempty(iwezPQ)
    nrwezPQ=wezPQ(iwezPQ); nrPQ=nowePQ(iwezPQ,:);
end
if ~isempty(nrwezPQ)
    wezPQ=[]; nowePQ=[];
    wezPQ=nrwezPQ; nowePQ=nrPQ;
end
end %a2wezPQ(fd,nazwez)