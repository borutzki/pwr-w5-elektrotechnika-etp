function [nap]=a2nap(fd,opt,nazwez,...
    Sbase,Vbus,Ybus,SGBUS,SLBUS,...
    SGMIN,SGMAX,Sshunt,sumSG,sumSL,sumQKomp,...
    TYP,UNBUS,Um,Ukat,UkV,Pg,Qg,Pd,Qd,Psh,Qsh,QKomp,wlacz,nap);
%WYDRUK nazw, typow, napiec i mocy wezlowych
sumSGMAX=sum(SGBUS(wlacz))*Sbase; % Bilans mocy
QgminRM=imag(SGMIN)*Sbase; QgmaxRM=imag(SGMAX)*Sbase; 
sumQgmin=sum(QgminRM);sumQgmax=sum(QgmaxRM);
%do wydruku moce wez. pomniejszono o moce SHUNT i QKOMP
Sit=Vbus.*conj(Ybus*sparse(Vbus))*Sbase - Sshunt -j*QKomp;
UdopMIN=0.95; UdopMAX=1.1; % min i max dopuszczalne napiecie
if opt==0 
fprintf(fd,...
'\n          Napiecia i moce wezlowe');
fprintf(fd,...
'\nNrw Nazwa      typ     U   kat     U    Pgen    Qgen     ');
fprintf(fd,'Podb    Qodb   Qkomp  tgfi');
fprintf(fd,...
'\n -    -          -    pu    st    kV      MW    Mvar       ');
fprintf(fd,'MW    Mvar    Mvar    -');
end %if opt==0
sp=' ';   kkk=0; sumPunb=0; sumQunb=0; iuogr=0; n=size(Vbus,1);
for kk = 1:n 
  i=kk;  tgfi04='   -'; typ=TYP(i);
  % badanie przekroczen dopuszczalnych poziomow napiec
  if typ~=4
    Unom=UNBUS(i); Uact=Um(i);
    if Uact<UdopMIN | Uact>UdopMAX
     iuogr=iuogr+1; nap(iuogr,1)=i; nap(iuogr,2)=Unom;
     nap(iuogr,3)=UdopMIN; nap(iuogr,4)=UdopMAX; nap(iuogr,5)=Uact;
    end %if Uact<UdopMIN | Uact>UdopMAX
    kkk=kkk+1;
    if opt==0 % wydruk
      fprintf(fd,'\n%3d %-8s %1d %5.3f %5.1f %5.1f',...
          kk, nazwez(i,:),typ,Um(i),Ukat(i),UkV(i) );
      if  abs(Pg(i))>1e-6 | abs(Qg(i))>1e-6
        fprintf(fd, ' %7.1f %7.1f ', Pg(i) ,Qg(i)  );
      else
        fprintf(fd, '     -         - ');
      end
      if  abs(Pd(i))>1e-6 | abs(Qd(i))>1e-6 
        fprintf(fd,' %7.1f %7.1f ', Pd(i) ,Qd(i)  );
      else
        fprintf(fd, '       -       - ');
      end 
      %================== wezlowy bilans mocy =================  
      Pwezbil=Pg(i)-Pd(i)-Psh(i);
      Qwezbil=Qg(i)-Qd(i)-Qsh(i)- QKomp(i);
      pgi=Pg(i); pdi=Pd(i); pshi=Psh(i); 
      qgi=Qg(i); qdi=Qd(i); qshi=Qsh(i); qki=QKomp(i);
      pgenwez=-pgi+pdi+pshi; 
      qgenwez=-qgi+qdi+qshi+qki;
      tgfi=0; if abs(pgenwez)>1e-8 tgfi=qgenwez/pgenwez; end
      Punb=real(Sit(i))- Pwezbil;  Qunb=imag(Sit(i))- Qwezbil;
      %================== WYDRUK wezlowego bilansu MW 
      PGmin=real(SGMIN(i))*Sbase;
      if  abs(QKomp(i))>1e-4
        fprintf(fd,' %6.1f',QKomp(i)  );
      else
        fprintf(fd, '      -');
      end
      if  abs(tgfi)>1e-4 
        fprintf(fd,' %5.1f', tgfi );
      else
        fprintf(fd, ' -');
      end
      sumPunb=sumPunb+Punb; sumQunb=sumQunb+Qunb;
    end % opt==0
   end %if typ~=4
end % for kk = 1:n 
if opt==0 % wydruk
fprintf(fd,...
'\n      %16s        Razem: %7.1f %7.1f %8.1f ',...
      sp,real(sumSG),imag(sumSG),real(sumSL) ); 
fprintf(fd,...
'%7.1f %7.1f     -   ',...
      imag(sumSL),sumQKomp);  
end %if opt==0
end % koniec a2nap()

