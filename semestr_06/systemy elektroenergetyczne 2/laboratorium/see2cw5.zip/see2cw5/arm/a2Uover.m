function a2Uover(fd,opt,Uover,nazwez);
% Identyfikacja wezlow z przekroczeniami Umin lub Umax
if ~isempty(Uover)
 ibus=Uover(:,1);
 Unom=Uover(:,2);
 Umin=Uover(:,3); Umax=Uover(:,4); Uact=Uover(:,5);
 dUdol=Uact-Umin; dUgora=Uact-Umax;
 [Usort,iUsort]=sort(Uact); %  wg malejacych przekroczen
 kbus=ibus(iUsort); 
 [nUover,mUover]=size(Uover);
 fprintf(fd,'\n Nrw Wezel         Un   ');
 fprintf(fd,'Umin   Umax    U   U-Udop  U-Udop');
 fprintf(fd,'\n   -   -           kV     ');
 fprintf(fd,'pu     pu   pu     pu       %%');
 for kk=1:nUover % wydruk wezlow z przekroczeniami
  k=kbus(kk,1);
  i=iUsort(kk,1);
  dUdop=0;
  if dUdol(i) <0 dUdop=dUdol(i);  end
  if dUgora(i)>0 dUdop=dUgora(i); end
  fprintf(fd,...
  '\n%4d %12s %3.0f %6.3f %6.3f %6.3f %6.3f %6.1f%%',...
  k,nazwez(k,:),Unom(i),Umin(i),Umax(i),Uact(i),dUdop,dUdop*100);
  end % for kk=1:nUover
else
  fprintf(fd,'\n ... brak przekroczenia Umin lub Umax');
  fprintf(   '\n ... brak przekroczenia Umin lub Umax');
end %if ~isempty(Uover)
end % koniec a2Uover()
