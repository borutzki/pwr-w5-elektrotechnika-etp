function KasujPlikiGraficzne
fprintf('\n\n Kasowanie plikow *.emf?');
fprintf('\n 1- TAK, 0 - NIE');
fprintf('\n... podaj: 1 lub 0 \n');
emf=input(' ');
if emf
delete *.emf
fprintf('\n\n ... skasowano wszystkie pliki graficzne *.emf ...');
fprintf('\n ... w katalogu: %s ...\n\n',pwd);
end
fprintf('\n\n Kasowanie funkcji a2P_Unos*.m, tworzacej krzywe  P-U?');
fprintf('\n 1- TAK, 0 - NIE');
fprintf('\n... podaj: 1 lub 0 \n');
a2P_Unos=input(' ');
if a2P_Unos
delete a2P_Unos*.m
fprintf('\n\n ... skasowano wszystkie funkcje a2P_Unos*.m ...');
fprintf('\n ... w katalogu: %s ...\n\n',pwd);
end
end

