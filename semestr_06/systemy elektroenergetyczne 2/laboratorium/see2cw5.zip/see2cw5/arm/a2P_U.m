function a2P_U(fdpu,tytul,...
    Sbase,tabPUcload,tabPUnrwez,tabPUnazwa,tabPUnap,...
    tabPUstr,tabPUlad,tabPUgen,tabPUodb,tabPUshunt,tabPUw);
%Zapisywanie punktow krzywych P-U oraz Bilansu Q
fprintf(fdpu,'\n function a2P_Unos');
fprintf(fdpu,'\n tytul= ''%40s''; ',tytul);
fprintf(fdpu,'\n tab=[');
[ntabPU,mtabPU]=size(tabPUnap);
fprintf(fdpu,'\n %%  Lp wzrostPsee nrwez-Upu');
 for itabPU=1:ntabPU
  fprintf(fdpu,'\n %3d %9.3f ',itabPU,tabPUcload(itabPU) );
  for jtabPU=1:mtabPU
   fprintf(fdpu,' %3d %5.3f',...
       tabPUnrwez(itabPU,jtabPU),tabPUnap(itabPU,jtabPU) );
   end
 end
fprintf(fdpu,'\n ];');
fprintf(fdpu,'\n    hold on; ');
fprintf(fdpu,'\n    [rows,cols] = find(tab<=0.9); ');
fprintf(fdpu,'\n    ieta=min(rows);  ');
fprintf(fdpu,'\n    eta=tab(ieta,2); '); 
fprintf(fdpu,'\n    ceta=num2str((eta-1)*100,3); ');
fprintf(fdpu,'\n    text(1.005,0.85,[''eta='' ceta '' %%'']); ');
fprintf(fdpu,'\n    p2=plot(eta,0.9,''ro''); ');
fprintf(fdpu,'\n    linia(1,eta,0.9,0.9); ');
fprintf(fdpu,'\n    linia(eta,eta,0.6,0.9); ');

 fprintf(fdpu,'\n  icload=find(tab(:,3)~=0);');
 fprintf(fdpu,'\n tabPU=tab(icload,:);');
 fprintf(fdpu,'\n cloadmax=max(tabPU(:,2))+0.01;');
 fprintf(fdpu,'\n Umax=1.3;');
 fprintf(fdpu,'\n Umin=0.6;');
 fprintf(fdpu,'\n tabPUnazwa=[');
 for jtabPU=1:mtabPU
    nrwez=tabPUnrwez(1,jtabPU);
    nazwa=tabPUnazwa{jtabPU}; 
    fprintf(fdpu,'\n'); 
    fprintf(fdpu, '''');fprintf(fdpu,'%s',nazwa );
    fprintf(fdpu,'''');
    fprintf(fdpu,'%% nrwez = %4d',nrwez); 
 end
fprintf(fdpu,'\n ];');
fprintf(fdpu,'\n cload=tabPU(:,2);');
fprintf(fdpu,'\n [n,m]=size(tabPU); irys=1;');
fprintf(fdpu,'\n rest=4;k=-5;');
fprintf(fdpu,'\n if (m-2)/2 < 4 rest=(m-2)/2; end');
fprintf(fdpu,'\n  while rest>0  ');
fprintf(fdpu,'\n  k=k+8;    ');
fprintf(fdpu,'\n  if rest>=4 ');
fprintf(fdpu,'\n  for i=1:n ');
fprintf(fdpu,'\n    U1(i)=tabPU(i,k+1);U2(i)=tabPU(i,k+3);');
fprintf(fdpu,'\n    U3(i)=tabPU(i,k+5);U4(i)=tabPU(i,k+7);');
fprintf(fdpu,'\n  end ');
fprintf(fdpu,'\n   nazwa1=tabPUnazwa(irys,  :); ');
fprintf(fdpu,'\n   nazwa2=tabPUnazwa(irys+1,:); ');
fprintf(fdpu,'\n   nazwa3=tabPUnazwa(irys+2,:); ');
fprintf(fdpu,'\n   nazwa4=tabPUnazwa(irys+3,:); ');
fprintf(fdpu,'\n   opis1=[nazwa1];  opis2=[nazwa2]; ');
fprintf(fdpu,'\n   opis3=[nazwa3];  opis4=[nazwa4]; ');
fprintf(fdpu,'\n   p1=plot(cload,U1,''k-'',cload,U2,''b--'',...');
fprintf(fdpu,'\n   cload,U3,''r-.'',cload,U4,''m:'',... ');
fprintf(fdpu,'\n''LineWidth'',1.5,''MarkerEdgeColor'',''k'',...');
fprintf(fdpu,'\n''MarkerFaceColor'',''g'',''MarkerSize'',10);');
fprintf(fdpu,'\n  grid on;');
fprintf(fdpu,'\n   title([''Krzywe P-U : '',tytul]); ');
fprintf(fdpu,'\n   xlabel(''wzrost poboru mocy w SEE'');');
fprintf(fdpu,'\n   ylabel(''Upu'');');
fprintf(fdpu,'\n   axis([1 cloadmax Umin Umax]); ');
fprintf(fdpu,'\n   legend(p1,opis1,opis2,opis3,opis4); ');
fprintf(fdpu,'\n   end ');
fprintf(fdpu,'\n  if rest==3 ');
fprintf(fdpu,'\n    for i=1:n ');
fprintf(fdpu,'\n     U1(i)=tabPU(i,k+1); U2(i)=tabPU(i,k+3);');
fprintf(fdpu,'\n     U3(i)=tabPU(i,k+5);');
fprintf(fdpu,'\n    end ');
fprintf(fdpu,'\n    nazwa1=tabPUnazwa(irys,  :); ');
fprintf(fdpu,'\n    nazwa2=tabPUnazwa(irys+1,:); ');
fprintf(fdpu,'\n    nazwa3=tabPUnazwa(irys+2,:); ');
fprintf(fdpu,'\n    opis1=[nazwa1];  opis2=[nazwa2];');
fprintf(fdpu,'\n    opis3=[nazwa3]; ');
fprintf(fdpu,'\n    p1=plot(cload,U1,''k-'',cload,U2,''b--'',...');
fprintf(fdpu,'\n    cload,U3,''r-.'',...');
fprintf(fdpu,'\n''LineWidth'',1.5,''MarkerEdgeColor'',''k'',...');
fprintf(fdpu,'\n''MarkerFaceColor'',''g'',''MarkerSize'',10);');
fprintf(fdpu,'\n  grid on;');
fprintf(fdpu,'\n    title([''Krzywe P-U : '',tytul]); ');
fprintf(fdpu,'\n    xlabel(''wzrost poboru mocy w SEE'');');
fprintf(fdpu,'\n    ylabel(''Upu'');');
fprintf(fdpu,'\n    axis([1 cloadmax Umin Umax]); ');
fprintf(fdpu,'\n    legend(p1,opis1,opis2,opis3); ');
fprintf(fdpu,'\n  end ');
fprintf(fdpu,'\n  if rest==2 ');
fprintf(fdpu,'\n    for i=1:n U1(i)=tabPU(i,k+1); ');
fprintf(fdpu,'\n    U2(i)=tabPU(i,k+3); end ');
fprintf(fdpu,'\n    nazwa1=tabPUnazwa(irys,  :); ');
fprintf(fdpu,'\n    nazwa2=tabPUnazwa(irys+1,:); ');
fprintf(fdpu,'\n    opis1=[nazwa1];  opis2=[nazwa2]; ');
fprintf(fdpu,'\n    p1=plot(cload,U1,''k-'',cload,U2,''b--'',...');
fprintf(fdpu,'\n''LineWidth'',1.5,''MarkerEdgeColor'',''k'',...');
fprintf(fdpu,'\n''MarkerFaceColor'',''g'',''MarkerSize'',10);');
fprintf(fdpu,'\n  grid on;');
fprintf(fdpu,'\n    title([''Krzywe P-U : '',tytul]); ');
fprintf(fdpu,'\n    xlabel(''wzrost poboru mocy w SEE'');');
fprintf(fdpu,'\n    ylabel(''Upu'');');
fprintf(fdpu,'\n    axis([1 cloadmax Umin Umax]); ');
fprintf(fdpu,'\n    legend(p1,opis1,opis2); ');
fprintf(fdpu,'\n    end ');
fprintf(fdpu,'\n  if rest==1 ');
fprintf(fdpu,'\n    for i=1:n U1(i)=tabPU(i,k+1); end ');
fprintf(fdpu,'\n    nazwa1=tabPUnazwa(irys,  :); ');
fprintf(fdpu,'\n    opis1=[nazwa1]; ');
fprintf(fdpu,'\n    p1=plot(cload,U1,''k-'',...');
fprintf(fdpu,'\n''LineWidth'',1.5,''MarkerEdgeColor'',''k'',...');
fprintf(fdpu,'\n''MarkerFaceColor'',''g'',''MarkerSize'',10);');
fprintf(fdpu,'\n  grid on;');
fprintf(fdpu,'\n    title([''Krzywe P-U : '',tytul]); ');
fprintf(fdpu,'\n    xlabel(''wzrost poboru mocy w SEE'');');
fprintf(fdpu,'\n    ylabel(''Upu'');');
fprintf(fdpu,'\n    axis([1 cloadmax Umin Umax]); ');
fprintf(fdpu,'\n    legend(p1,opis1); ');
fprintf(fdpu,'\n    end ');
fprintf(fdpu,'\n  irys=irys+4; ');
fprintf(fdpu,'\n  rest=(m-2)/2-irys+1; ');
fprintf(fdpu,'\n  tPU=clock; ');
fprintf(fdpu,'\n  rok=int2str(tPU(1)); miesiac=int2str(tPU(2));');
fprintf(fdpu,'\n  dzien=int2str(tPU(3));');
fprintf(fdpu,'\n  godz=int2str(tPU(4));mins=int2str(tPU(5));');
fprintf(fdpu,'\n  secs=int2str(tPU(6));');
fprintf(fdpu,'\n  plikPU=[''cPU'' rok miesiac dzien godz mins secs];');
fprintf(fdpu,'\n  saveas(gcf,plikPU,''emf'');');
fprintf(fdpu,'\n pause(2); close;');
fprintf(fdpu,'\n end %%while');
 cload=tabPUcload;
 Pstr=real(tabPUstr); Qstr=imag(tabPUstr);
 Plad=real(tabPUlad); Qlad=-imag(tabPUlad);
 Sgen=tabPUgen; Sodb=tabPUodb;   Sshunt=tabPUshunt;
 wdetJ=tabPUw;
 Pgen=real(Sgen); Qgen=imag(Sgen);
 Podb=real(Sodb); Qodb=imag(Sodb);
 Pshunt=real(Sshunt); Pshuntpu=Pshunt/Sbase;
 Qshunt=imag(Sshunt); Qshuntpu=Qshunt/Sbase;
[ntabPU,mtabPU]=size(tabPUgen);
fprintf(fdpu,'\ntabQ=[');
fprintf(fdpu,...
'\n%%Lp wzrostPsee   Qstr   Qkomp    Qgen    Qodb  ');
fprintf(fdpu,'\n%%Qshunt    Pstr detJ/detJ0' );
fprintf(fdpu,...
'%% -     -        Mvar    Mvar    Mvar    Mvar    ');
fprintf(fdpu,'%%Mvar      MW     -  ' );
for i=1:ntabPU
fprintf(fdpu,...
'\n %3d %9.5f %7.1f %7.1f %7.1f %7.1f %7.1f %7.1f %7.4f',...
    i,cload(i),Qstr(i),Qlad(i),Qgen(i),Qodb(i),...
       Qshunt(i),Pstr(i),wdetJ(i) );
end
fprintf(fdpu,'\n ];');
fprintf(fdpu,'\n  icload=find(tabQ(:,2)~=0);');
fprintf(fdpu,'\n tabPU=tabQ(icload,:);');
fprintf(fdpu,'\n cload=tabPU(:,2); wdetJ=tabPU(:,9);');
fprintf(fdpu,'\n Qstr=tabPU(:,3);Qlad=tabPU(:,4);Qstrlad=Qstr-Qlad;');
fprintf(fdpu,'\n Qgen=tabPU(:,5);Qodb=tabPU(:,6);');
fprintf(fdpu,'\n Qshunt=tabPU(:,7);Pstr=tabPU(:,8);');
fprintf(fdpu,'\n Qodb=Qodb+Qshunt; %% odbiory Qodb + odbiory Qshunt');
%
fprintf(fdpu,'\n  plot(cload,Qgen,''k-''); grid on; ');
fprintf(fdpu,'\n  title('' Qgen - zmiany wytwarzania''); ');
fprintf(fdpu,'\n  xlabel(''wzrost poboru mocy w SEE''); ');
fprintf(fdpu,'\n  ylabel('' Qgen[Mvar] ''); ');
fprintf(fdpu,'\n  cQgen=[''cQgen'' rok miesiac dzien godz mins];');
fprintf(fdpu,'\n  saveas(gcf,cQgen,''emf''); pause(2); close; ');
%
fprintf(fdpu,'\n  plot(cload,Qodb,''k-''); grid on; ');
fprintf(fdpu,'\n  title('' Qodb - zmiany poboru''); ');
fprintf(fdpu,'\n  xlabel(''wzrost poboru mocy w SEE'');');
fprintf(fdpu,'\n  ylabel('' Qodb[MVar] ''); ');
fprintf(fdpu,'\n  cQodb=[''cQodb'' rok miesiac dzien godz mins];');
fprintf(fdpu,'\n  saveas(gcf,cQodb,''emf''); pause(2); close; ');
%
fprintf(fdpu,'\n  plot(cload,Qlad,''k-''); grid on; ');
fprintf(fdpu,'\n  title('' Qkomp+Qlad - zmiany''); ');
fprintf(fdpu,'\n  xlabel(''wzrost poboru mocy w SEE'');');
fprintf(fdpu,'\n  ylabel('' Qkomp+Qlad,[Mvar] ''); ');
fprintf(fdpu,'\n  cQlad=[''cQlad'' rok miesiac dzien godz mins];');
fprintf(fdpu,'\n  saveas(gcf,cQlad,''emf''); pause(2); close; ');
%
fprintf(fdpu,'\n  plot(cload,Qstr,''k-''); grid on; ');
fprintf(fdpu,'\n  title('' Qstr - zmiany strat Q''); ');
fprintf(fdpu,'\n  xlabel(''wzrost poboru mocy w SEE''); ');
fprintf(fdpu,'\n  ylabel('' Qstr[Mvar] ''); ');
fprintf(fdpu,'\n  cQstr=[''cQstr'' rok miesiac dzien godz mins];');
fprintf(fdpu,'\n  saveas(gcf,cQstr,''emf''); pause(2); close; ');
%
fprintf(fdpu,'\n  plot(cload,Pstr,''k-''); grid on; ');
fprintf(fdpu,'\n  title('' Pstr - zmiany strat P''); ');
fprintf(fdpu,'\n  xlabel(''wzrost poboru mocy w SEE''); ');
fprintf(fdpu,'\n  ylabel('' Pstr[MW] ''); ');
fprintf(fdpu,'\n  cPstr=[''cPstr'' rok miesiac dzien godz mins];');
fprintf(fdpu,'\n  saveas(gcf,cPstr,''emf''); pause(2); close; ');
%
fprintf(fdpu,'\n  plot(cload,wdetJ,''k-''); grid on; ');
fprintf(fdpu,'\n  title('' w=detJ/detJ0 - zmiany jakobianu''); ');
fprintf(fdpu,'\n  xlabel(''wzrost poboru mocy w SEE'');');
fprintf(fdpu,'\n  ylabel('' w[pu] ''); ');
fprintf(fdpu,'\n  cwdetJ=[''cwdetJ'' rok miesiac dzien godz mins];');
fprintf(fdpu,'\n  saveas(gcf,cwdetJ,''emf''); pause(2); close; ');
%
fprintf(fdpu,'\n end');
end


