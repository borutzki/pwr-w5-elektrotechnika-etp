function [SstrKSE,SkompKSE,sumSG,sumSL,sumSH] = ...
a2bilans(fd,Sbase,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,...
STATUS,SMAX,YPP,YPK,YKP,YKK,...
Vbus,Ybus,REF,PU,PQ,opt,nazwez,nazgal,...
SGMIN,SGMAX,UKUZW,QKOMP); 
AREA=1; % analizowany tylko jeden obszar
TYPE=real(TUNBUS);   UNBUS=imag(TUNBUS); % typy i nap. znam.
Um = abs(Vbus);   Ukat = angle(Vbus).*(180/pi);
SLBUS=SLBUS*Sbase; SGBUS=SGBUS*Sbase; Qkomp=QKOMP.*Um.^2;
Qkomp=Qkomp*Sbase;  % kompensacja wezlowa
%odb. staloadmit. + Qkomp
Sshunt=Um.^2.*conj(YSHBUS)*Sbase - j*Qkomp;
wlacz=find( TYPE~=4 & AREA==1);
sumSL=sum(SLBUS(wlacz));sumSG=sum(SGBUS(wlacz));
% moc zespolona generowana w wezle bilansujacym
SGslack=SGBUS(REF);
%generacja SEE bez wezla bilansujacego
sumSG=sumSG-SGslack;
%moc zespolona odbierana w wezle bilansujacym
SLslack=SLBUS(REF);
sumSL=sumSL-SLslack;%odbiory SEE bez wezla bilansujacego
if real(SGslack)<0
    SLslack=SLslack-SGslack;
    SGslack=0+j*0;
end
sumSH=sum(Sshunt(wlacz));%suma odbiorow staloadmitancyjnych
sumQkomp=sum(Qkomp(wlacz));% suma kompensacji wezlowych
% STRATY PRZESYLOWE i POPRZECZNE    
WP=real(WPK(:)); WK=imag(WPK(:)); ngal=size(WP,1);
WPgalUN=zeros(ngal,1); WKgalUN=zeros(ngal,1); 
% zapamietanie nap. znam. wez. pocz. oraz wez. konc.
for i3=1:ngal
  wp=WP(i3);    WPgalUN(i3,1)=UNBUS(wp);
  wk=WK(i3);    WKgalUN(i3,1)=UNBUS(wk);
  galarea=1;    galAREA(i3,1)= galarea;
end
tap=real(TMK);
tr=find(tap(:)~=0 & STATUS~=0 & galAREA==1 );%transf.
nl=find(tap(:)==0 & STATUS(:)~=0 & galAREA==1 );
tap(nl)=1.0;%linie
zer=find(tap==0);  tap(zer)=1.0; 
tap=tap.*exp(j*pi/180*imag(TMK));
 % straty podluzne
straty=STATUS.*...
abs( Vbus(WP)./tap-Vbus(WK) ).^2./conj(ZGAL);
 % straty poprzeczne
lad=STATUS.*...
( abs(Vbus(WP)./tap).^2+abs(Vbus(WK)).^2).*conj(YSHGAL)/2;
% straty poprzeczne (linie - moc ladowania)
dSHT=sum(lad(tr))*Sbase; dSHL=sum(lad(nl))*Sbase;
dST=sum(straty(tr))*Sbase; 
dSL=sum(straty(nl))*Sbase;%straty podluzne
sumSG=sumSG*1; sumSL=sumSL*1;
sumQkomp=sumQkomp*1;
SGslack=SGslack*1; SLslack=SLslack*1;
dSHL=dSHL*1;  sumSH=sumSH*1;
dST=dST*1; dSL=dSL*1; dSHT=dSHT*1;
if opt==0
 fprintf(fd,'\n');
 fprintf(fd,'  \n  BILANS mocy w calym SEE        P,MW     Q,Mvar');
 fprintf(fd,'  \n  Generacja                 %9.2f  %9.2f',...
     real(-sumSG),imag(-sumSG) );
 fprintf(fd,'  \n  Kompensatory              %9.2f  %9.2f',...
     0,sumQkomp );
 fprintf(fd,'  \n  Ladowanie linii           %9.2f  %9.2f',...
     real(dSHL),imag(dSHL) );
 fprintf(fd,'  \n  Wezel BILANSUJACY-gen.    %9.2f  %9.2f',...
     real(-SGslack),imag(-SGslack) );
 fprintf(fd,  '\n  ==============================================');
 fprintf(fd,'  \n  Razem WYTWARZANIE  mocy   %9.2f  %9.2f',...
 real(-sumSG-SGslack+dSHL), imag(-sumSG-SGslack+dSHL)+sumQkomp);
 fprintf(fd,'\n');
 fprintf(fd,'  \n  Odbiory                   %9.2f  %9.2f',...
     real(sumSL),imag(sumSL) );
 fprintf(fd,'  \n  Odbiory Ysh=const         %9.2f  %9.2f',...
     real(sumSH),imag(sumSH) );
 fprintf(fd,'  \n  Straty podluzne transf.   %9.2f  %9.2f',...
     real(dST),imag(dST) );
 fprintf(fd,'  \n  Straty podluzne linii     %9.2f  %9.2f',...
     real(dSL),imag(dSL) );
 fprintf(fd,'  \n  Straty poprz. w transf.   %9.2f  %9.2f',...
     real(dSHT),imag(dSHT) );
 fprintf(fd,'  \n  Wezel BILANSUJACY-odbior  %9.2f  %9.2f',...
     real(SLslack),imag(SLslack) );
 fprintf(fd,'  \n  ==============================================');
 fprintf(fd,'  \n  Razem POBOR  mocy         %9.2f  %9.2f',...
 real(sumSL+sumSH+dSL+dST+dSHT+SLslack),...
 imag(sumSL+sumSH+dSL+dST+dSHT+SLslack) );
 fprintf(fd,'\n');
end % if opt==0
SgenBil=-sumSG-SGslack+sumSL+SLslack+...
    sumSH+dSL+dSHL+dST+dSHT + j*sumQkomp;
PgenBil=real(SgenBil); QgenBil=imag(SgenBil); 
SstrKSE=dSL+dST+dSHT; %  straty podluzne
PstrKSE=real(SstrKSE); QstrKSE=imag(SstrKSE);
%moce ladowania linii + moce kompensatorow
SkompKSE=dSHL+j*sumQkomp; 
PkompKSE=real(SkompKSE); QkompKSE=imag(SkompKSE);
dS=SstrKSE + SkompKSE; %straty podluzne i poprzeczne.
bilPstrKSE=real(dS);            bilQstrKSE=imag(dS);
if opt==0
 fprintf(fd,'  \n  BILANS strat i kompensacji     P,MW    Q,Mvar');
 fprintf(fd,'  \n  Straty podl.+ poprz.      %9.2f  %9.2f',...
     PstrKSE,QstrKSE);
 fprintf(fd,'  \n  Lad.linii+Kompensatory    %9.2f  %9.2f',...
     PkompKSE,QkompKSE);
 fprintf(fd,'  \n  ==============================================');
 fprintf(fd,'  \n  Suma strat i kompensacji  %9.2f  %9.2f',...
     bilPstrKSE,bilQstrKSE);
 fprintf(fd,'\n');
end % if opt==0
end % koniec a2bilans()
