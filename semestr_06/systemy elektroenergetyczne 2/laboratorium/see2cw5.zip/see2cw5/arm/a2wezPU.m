function [wezPU]=a2wezPU(fd,nazwez)
% CZYTANIE nazw wezlow do krzywych P-U z pliku datPUwez*.m
wdold=cd;
[fname,sciezka]=...
uigetfile('datPUwez*.m','Wybierz plik wezlow dla P-U');
fprintf('\n... wybrano: %s%s',sciezka,fname);
eval(['cd(''',sciezka,''')']); datafile=strtok(fname,'.');
[sPU]=feval(datafile);% czytanie danych z wybranego pliku
eval(['cd(''',wdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
sp12='123456789012';  % nazwy do 12 znakow
[nw,mw]=size(nazwez); nrwez=[1:nw]'; wezPU=[];
if ~isempty(sPU)
   [nl,n]=size(sPU);
   nazwp =strvcat( sp12,char(sPU(:,1)));
   nazwp=nazwp(2:end,:);
   wiersze=[zeros(nl,1) cell2mat(sPU(:,2:end)) ];
   strvcatnazwp0=deblank(strvcat(nazwp));
   [nbrl,mbrl]=size(wiersze); 
   for ii=1:nw
      nazw0=deblank(nazwez(ii,:));
      wp = strmatch(nazw0,strvcatnazwp0,'exact');
      if ~isempty(wp) wiersze(wp,1)=nrwez(ii); end
   end % for ii=1:nw
   wezPU=wiersze(:,1);
else
   return
end  %if ~isempty(sPU)
iwezPU=[]; iwezPU=find(wezPU~=0);nrwezPU=[];
if ~isempty(iwezPU)
    nrwezPU=wezPU(iwezPU);
end
if ~isempty(nrwezPU)
    wezPU=[]; wezPU=nrwezPU;
end
end
