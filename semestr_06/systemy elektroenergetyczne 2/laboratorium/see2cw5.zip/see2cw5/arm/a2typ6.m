function  [PU,PQ,TUNBUS,Vbus,SLBUS,SGBUS,sukces,Ureg] =...
a2typ6(fd,nazwez,NRBUS,TUNBUS,SGBUS,SLBUS,REF,PU,PQ,...
           Ybus,Vbus,Ureg,opt,SGMIN,SGMAX,WPK);
% uwzglednienie Qmin, Qmax
j=sqrt(-1);
Vbus0=Vbus;%nap. wez. przed sprawdzaniem Qmin, Qmax
iogr=1; sukces=1;
while iogr 
 zmiana=0; 
 SGBUS0=SGBUS;  TUNBUS0=TUNBUS;   TYP=real(TUNBUS);
 UN=imag(TUNBUS); n=size(TYP,1);
 PU6=find( TYP(:)==6);   nPU6=size(PU6,1);
 if opt==0
  fprintf(fd,'\n... sprawdzenie Qmin<Qg<Qmax ...');
  fprintf(   '\n... sprawdzenie Qmin<Qg<Qmax ...'); end
 if ~isempty(PU6) % istnieja wezly typu 6
  Pg6= real(SGBUS(PU6));  Qg6=imag(SGBUS(PU6)); 
  Qmin6=imag(SGMIN(PU6)); Qmax6=imag(SGMAX(PU6));
  for i=1:nPU6
   PU6i=PU6(i);    nazwa=char(nazwez(PU6i,:));
   if Qg6(i)<Qmin6(i) % zmiana typu 6 na 7
    SGBUS(PU6i)=Pg6(i)+j*Qmin6(i); TYP(PU6i)=7;
    nazwa=char(nazwez(PU6i,:));
    zmiana=1; iogr=iogr+1;
    if opt==0 
     fprintf(fd,...
'\n... Qg<Qmin w %8s, typ=6 na 7, Qg=Qgmin=%5.3g[pu]',...
       nazwa,Qmin6(i) );
       fprintf(    ...
'\n... Qg<Qmin w %8s, typ=6 na 7, Qg=Qgmin=%5.3g[pu]',...
       nazwa,Qmin6(i) );   end
   end %if Qg6(i)<Qmin6(i)
   if Qg6(i)>Qmax6(i) % zmiana typu 6 na 8
    SGBUS(PU6i)=Pg6(i)+j*Qmax6(i); TYP(PU6i)=8;
    nazwa=char(nazwez(PU6i,:));
    zmiana=1; iogr=iogr+1;
    if opt==0
       fprintf(fd,...
'\n...Qg>Qmax w %8s, typ=6 na 8, Qg=Qgmax=%5.3g[pu]',...
       nazwa,Qmax6(i) );
       fprintf(   ...
'\n...Qg>Qmax w %8s, typ=6 na 8, Qg=Qgmax=%5.3g[pu]',...
       nazwa,Qmax6(i) );  end
    end %if Qg6(i)>Qmax6(i)
   end %for i=1:nPU6
   if zmiana % wystapila zmiana typu 6 na 7 i/lub 8
    PU=find( TYP(:)==2|TYP(:)==6 ); % nowa tablica typu 2,6
    PU6=find( TYP(:)==6);  nPU6=size(PU6,1);
    % nowa tablica dla typ=1,5,7,8
    PQ=find(TYP(:)==1|TYP(:)==5|TYP(:)==7|TYP(:)==8);
    nd=size(PQ,1); % liczba wezlow typ=1,5,7,8
    TUNBUS=TYP+j*UN; % zapamietanie nowych typow wezlow
    if opt==0;
      fprintf(fd,...
'\n...a2typ6() - nowy RM po zmianie typ=6 na 7,8');
      fprintf(...
'\n...a2typ6() - nowy RM po zmianie typ=6 na 7,8'); end
      Vbus0=Vbus;
      [Vbus,SLBUS,SGBUS,sukces] =...% po zmianie typow
      a2NR(fd,NRBUS,TUNBUS,SGBUS,SLBUS,...
         REF,PU,PQ,Ybus,Vbus,Ureg,opt,...
            SGMIN,SGMAX,nazwez); 
      if ~sukces
       if opt==0
         fprintf(fd,...
'\n RM rozbiezny po zamianie typ=6 na 7,8.!');
         fprintf(...
'\n RM rozbiezny po zamianie typ=6 na 7,8.!');
       end
      Vbus=Vbus0; % powrot do poprzednich napiec wez.
      iogr=0; 
     end %  if ~sukces
   else 
     iogr=0;
     if opt==0
        fprintf(fd,...
'\nUWAGA! ... brak zmiany typ=6 na 7,8');
        fprintf(...
'\nUWAGA! ... brak zmiany typ=6 na 7,8');    end
     return
   end % if zmiana
 else
   iogr=0;
   [Vbus,SLBUS,SGBUS,sukces] =... 
   a2NR(fd,NRBUS,TUNBUS,SGBUS,SLBUS,...
       REF,PU,PQ,Ybus,Vbus,Ureg,opt,...
         SGMIN,SGMAX,nazwez); 
   if opt==0
     fprintf(fd,...
'\n ...  brak wezlow typ=6 z ogr. Qmin<Qg<Qmax...');
     fprintf(...
'\n ...  brak wezlow typ=6 z ogr. Qmin<Qg<Qmax...');   end
 end %if ~isempty(PU6)
end %while iogr
end % koniec a2typ6()

