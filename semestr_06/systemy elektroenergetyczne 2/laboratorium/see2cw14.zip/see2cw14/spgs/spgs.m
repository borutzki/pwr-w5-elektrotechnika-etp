function spgs
% badanie stabilnosci przejsciowej met. calkowania numerycznego
wdold=cd; winf=1e8;
[fname,sciezka]=uigetfile('gseeDAT*.m',...
  'Wybierz plik danych zgodny z wymaganiami programu ogran.m - domyslnie gseedat*.m');
eval(['cd(''',sciezka,''')']);
% czytanie pliku w formacie cwiczenia
zwdat=strtok(fname,'.');
% czytanie danych z pliku zwdat
[Sng,Ung,Usee,xdp,Xgs,Tm,P,Q]=feval(zwdat);
Uns=Usee;
%
fd = fopen('spgsOUT.m','wt');
%Przeliczenie na jednostki wzgledne
Zb=Ung^2/Sng;
Us=Usee/Ung;
Xgs=Xgs/Zb;
P=P/Sng; Q=Q/Sng;
Pg=P;
%
% ANALIZA DLA 2 zmiennych stanu x = [d w] 
% d - przyrost kata wirnika  w - predkosc katowa wirnika
% poczatek analizy
X=Xgs + xdp; R=0;
Pm=Pg;
Ua=(P*R+Q*X)/Us;
Ub=(P*X-Q*R)/Us;
Eprim=sqrt( (Us+Ua)^2+Ub^2);
Pm=Pg;
sind=Pm*X/(Eprim*Us);
d0=asin(sind); % kat wirnika w stanie ustalonym wynikajacy z Pm = Pe
d0st=d0*180/pi;
%
K1=Eprim*Us/X*cos(d0);
Ped = K1;
ws=100*pi; % predkosc katowa synchroniczna
wm=sqrt(K1*ws/Tm); % pulsacja wlasnych kolysan wirnika
fm=wm/2/pi; % czestotliwosc wlasnych klysan wirnika
%
Dpu=0; % wspolczynnik tlumienia kolysan wirnika
psi=Dpu/2/wm/Tm; % standadryzowany wspolczynnik tlumienia kolysan
fprintf(fd,'\n Parametry wejsciowe ukladu; GENERATOR - SYSTEM');
fprintf(fd,'\n   Sng = %8.2f MVA',Sng);
fprintf(fd,'\n   Ung = %8.2f kV',Ung);
fprintf(fd,'\n   Uns = %8.2f kV',Uns);
fprintf(fd,'\n   xdp = %8.2f pu',xdp);
fprintf(fd,'\n Eprim = %8.4f pu',Eprim);
fprintf(fd,'\n    Us = %8.4f pu',Us);
fprintf(fd,'\n   Xgs = %8.4f pu',Xgs);
fprintf(fd,'\n    Pm = %8.4f pu',Pm); 
fprintf(fd,'\n    Tm = %8.2f s ',Tm);
fprintf(fd,'\n   Dpu = %8.2f pu',Dpu);
fprintf(    '\n Parametry wejsciowe ukladu; GENERATOR - SYSTEM');
fprintf(    '\n   Sng = %8.2f MVA',Sng);
fprintf(    '\n   Ung = %8.2f kV',Ung);
fprintf(    '\n   Uns = %8.2f kV',Uns);
fprintf(    '\n   xdp = %8.2f pu',xdp);
fprintf(    '\n Eprim = %8.4f pu',Eprim);
fprintf(    '\n    Us = %8.4f pu',Us);
fprintf(    '\n   Xgs = %8.4f pu',Xgs);
fprintf(    '\n    Pm = %8.4f pu',Pm); 
fprintf(    '\n    Tm = %8.2f s ',Tm);
fprintf(    '\n   Dpu = %8.2f pu',Dpu);

d0st=d0*180/pi;
%
X=Xgs+xdp;
Pmax=Eprim*Us/X;
kp=(Pmax-Pm)/Pmax; kpprocent=kp*100;
PmaxMW=Pmax*Sng;
PmMW=Pm*Sng;
%
%dane

%
%Pe=Eprim*Us/X*sind
%sind=Pm*X/(Eprim*Us);
cosd1=cos(pi-d0)-2*d0*sind+pi*sind;
d1=acos(cosd1); d1st=d1*180/pi;
%
tz=sqrt(2*(d1-d0)*Tm/(100*pi*Pm) );
%
%
%

tk=2; %s czas symulacji 
fprintf('\n\n Zwarcie rozpoczyna sie w chwili t0=0 s');
fprintf('\n\n Ustalono czas symulacji tk = %8.1f s',tk);
fprintf('\n\n Podaj chwile wylaczenia zwarcia w sekundach:\n');
twyl=input(' twyl = ');
fprintf('\n\n Podano twyl = %9.3f s\n',twyl);;

% moc elektryczna rowna mocy mechanicznej
% MACIERZ stanu A dla Lzs = 2
M=Tm;
A2(1,1)=0; A2(1,2)=ws;
A2(2,1)= -Ped/Tm; A2(2,2)=-Dpu/Tm;
%
fprintf('\n\n ...... trwa calkowanie met. Eulera ...... \n\n\n');
% ZMODYFIKOWANA METODA EULERA
dk=[]; dw=[]; x=[]; px=[]; tp=[];
% 0. stan poczatkowy
ws=100*pi; M=Tm/ws; pt=Pm;
dw0=0; pe=0;
x(1)=d0;
x(2)=dw0;
dt=0.01; % przyrost czasu s
it=0; t=-dt;
while t < tk
    it=it+1;
    t=t+dt;
% 1. 1-sze obliczenie pochodnej 
px1(1)=x(2); 
    if t <= twyl pe=0; else pe=Eprim*Us/X*sin(x(1)); end
px1(2)=(pt-pe-Dpu*x(2)/ws)/M; 
% 2. 1-sze oszacowanie wektora stanu 
x1 = x + px1*dt;
% 3. 2-gie obliczenie pochodnej 
px2(1)=x1(2);
    if t <= twyl pe=0; else pe=Eprim*Us/X*sin(x1(1)); end
px2(2)=(pt-pe-Dpu*x(2)/ws)/M;
% 4. obliczenie sredniej wartosci pochodnej
px = (px1 + px2)*0.5;
% 5. ponowne oszacowanie wektora stanu 
x = x + px*dt;
%x
%px
tp(it)=t;
dk(it)=x(1);
dw(it)=x(2)/ws;
dpe(it)=pe;
dpt(it)=pt;
end
itmax=it;
%
dkst=dk*180/pi;
% wykres kata wirnika
plot(tp,dkst,'g-');  xlabel('t[s]'); grid on;
title('      Przebieg kata wirnika zwarciu 3-fazowym, stopnie');
disp('Dalej? ENTER'); pause;
% wykres przyrostu predkosci katowej wirnika
plot(tp,dw,'g-'); xlabel('t[s]'); grid on;
title('      Przebieg przyrostu predkosci katowej po zwarciu 3-fazowym, rad/s');
disp('Dalej? ENTER'); pause; xlabel('t[s]');
close;
%WYNIKI LICZBOWE
dptMW=dpt*Sng; dpeMW=dpe*Sng;
fprintf(fd,'\n\n Przebieg stanu przejsciowego po zwarciu 3-fazowym');
fprintf(fd,'\n      t,s       PT,MW    PG,MW      kat,st    dw,pu/s');
for i= 1:itmax
fprintf(fd,'\n  %6.3f  %8.3f  %8.3f    %8.3f   %9.6f',...
                tp(i),dptMW(i),dpeMW(i),dkst(i),dw(i));
end
fprintf(fd,'\n OBLICZENIA ZAKONCZONO');
fprintf(   '\n OBLICZENIA ZAKONCZONO');
%
fclose('all');
return


