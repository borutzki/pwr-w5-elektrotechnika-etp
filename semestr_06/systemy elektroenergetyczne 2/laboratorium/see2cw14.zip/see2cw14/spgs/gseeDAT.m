function [Sng,Ung,Usee,xdp,Xgs,Tm,P,Q]=gseedat;
  % dane do kryterium rownych pol
  Sng=10; %MVA
  Ung=10; %kV
  Usee=10; %kV na poziomie nap. 10 kV
  xdp=0.25;
  Xgs=0.5; %oreaktancja pol. GS z SEE, hm na pzoiomie nap. 10 kV
  P=8; %MW
  Q=6; %Mvar
  Tm=5; %s
  return
  
    