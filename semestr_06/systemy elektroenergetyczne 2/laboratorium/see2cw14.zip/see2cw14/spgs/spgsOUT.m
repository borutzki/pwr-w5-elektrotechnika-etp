
 Parametry wejsciowe ukladu; GENERATOR - SYSTEM
   Sng =    11.51 MVA
   Ung =    10.50 kV
   Uns =    10.00 kV
   xdp =     0.25 pu
 Eprim =   1.1253 pu
    Us =   0.9524 pu
   Xgs =   0.0364 pu
    Pm =   0.6950 pu
    Tm =     8.51 s 
   Dpu =     0.00 pu