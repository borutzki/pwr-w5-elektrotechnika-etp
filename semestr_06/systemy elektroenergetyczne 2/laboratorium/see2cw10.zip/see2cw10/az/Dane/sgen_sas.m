
%PAR. ZAST. ZWARCIOWE SILNIKOW ASYNCHRONICZNYCH
%Par. zast. nap. znam. silnika UNM
%UNSobl - nap. obliczeniowe
%tN - przekl. transf.: siecUNSobl -> siec UNS
%tN=tN1*tN2*...- siec promieniowa
%tN=UNS/UNSobl - tylko sieci oczkowe
UNSobl= 110; % kV
winf=1e+08; % nieskonczonosc 
sgen={
%Silnik     Od         Do         UNS     R1     X1     R0     X0   tN
%max12s     max12s     max12s     kV     om      om     om     om   -
'M       ' 'ROnN    ' 'ZIEMIA  ' 0.5 0.01855 0.04417   winf   winf 209.09
 };