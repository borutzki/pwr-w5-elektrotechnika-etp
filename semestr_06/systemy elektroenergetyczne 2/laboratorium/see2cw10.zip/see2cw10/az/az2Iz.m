function [Sk,Sk1,Ik,Ik1,r0x1,x0x1,c,drukIz]=...
 az2Iz(fd,nazwez,k,knazwa,Unk,zveck1,yveck1,zveck0,yveck0)
%Analiza wg IEC pradow i napiec w miejscu zwarcia 
winf=1e8; cinf='inf   ';% nieskonczonosc
j=sqrt(-1);
[nw,mw]=size(nazwez); % wymiar  zadania
%impedancja Thevenina dla k-tego wezla
Zkk1=zveck1(k); Rkk1=real(Zkk1); Xkk1=imag(Zkk1); %skl. 1
%impedancja Thevenina dla k-tego wezla
Zkk0=zveck0(k); Rkk0=real(Zkk0); Xkk0=imag(Zkk0); %skl. 0
drukIz=1; 
% eliminacja analizy dla wezlow fikcyjnych o nazwie poprzedonej *
node='*';    knazwa1c=knazwa(1);
knazwa1c=deblank(knazwa1c); strvcatnode=strvcat(node);
druk=[];  druk = strmatch(knazwa1c,strvcatnode,'exact');
if ~isempty(druk) drukIz=0; end % brak analizy
% Analiza zwarc 3-f, 2-f, 2-fz, 1-fz
% w k-tym wezle w ukl. 012 oraz ABC
az2Izns(fd,knazwa,Unk,Rkk1,Xkk1,Rkk0,Xkk0,drukIz);
% Rozplyw pr. zwar. w k-tym wezle dla zw. 3-f i 1-fz
p3=sqrt(3); Un=Unk;
% USTALANIE wsp. obl. zwarciowego c dla pradow max
c=1.1; cnN=1;if Un<1 c=cnN; end 
E=c*Un/p3; % sem Thevenina
I1=E/Zkk1; Ik=abs(I1); % zw. 3-f
I0=E/(2*Zkk1+Zkk0);  Ik1=abs(3*I0); % zw. 1-fz
Sk=p3*Un*Ik;   % moc zwarciowa 3-f
Sk1=p3*Un*Ik1; % moc zwarciowa 1-fz
%Analiza skutecznosci uziemienia PN
r0x1=Rkk0/Xkk1; x0x1=Xkk0/Xkk1;% wsp. skut. uziemienia 
pizol=0; if abs(x0x1)>9999 pizol=1; end
% Obl. rozplywu pradow skl. 1 w k-tym wezlem dla zwarcia 3-f
if drukIz
fprintf(fd,...
'\n --------------------------------------------------------------------');
fprintf(fd,...
'\n Rozplyw pradow I1 w miejscu zwarcia 3-f: %s ',knazwa);
fprintf(fd,...
'\n --------------------------------------------------------------------');
% Udzial galezi w pradzie zwarcia 
fprintf(fd,...
'\n --------------------------------------------------------------------');
fprintf(fd,...
'\n Zwarcie 3-f            udzialy pradowe   R1,om   X1,om (I1a+j*I1b)kA');
fprintf(fd,...
'\n --------------------------------------------------------------------');
az2Iki(fd,k,knazwa,Zkk1,Ik,I1,yveck1,zveck1,nazwez);
if pizol==0
fprintf(fd,...
'\n --------------------------------------------------------------------');
fprintf(fd,...
'\n Rozplyw pradow I0 w miejscu zwarcia 1-fz: %s ',knazwa);
fprintf(fd,...
'\n Zwarcie 1-fz skl. 0    udzialy pradowe   R0,om   X0,om (I0a+j*I0b)kA');
fprintf(fd,...
'\n --------------------------------------------------------------------');
% Obl. rozplywu pradow skl. 0 w k-tym wezlem dla zwarcia 1-fz
az2Iki(fd,k,knazwa,Zkk0,Ik1/3,I0,yveck0,zveck0,nazwez);
else
    fprintf(fd,'\n ... izolowany punkt neutralny w tym wezle ...');
end % if pizol==0
end %if drukIz
end % koniec az2Iz()
