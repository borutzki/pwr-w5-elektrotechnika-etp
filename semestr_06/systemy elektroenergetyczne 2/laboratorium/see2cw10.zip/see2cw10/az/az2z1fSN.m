function  az2z1fSN
%obliczanie pradow zmiemnozwarciowych w sieci SN
t0=clock; % czas rozpoczecia obliczen
rok=int2str(t0(1));miesiac=int2str(t0(2));dzien=int2str(t0(3));
godz=int2str(t0(4));mins=int2str(t0(5));secs=int2str(t0(6));
czas=['_' rok '-' miesiac '-' dzien '_' godz 'h' mins];
 sciezka0=pwd; cd([sciezka0 '\Wyniki']); sciezka1=pwd;
 plikWy= strcat([sciezka1 '\az2z1fSNout_',czas,'.m']);
 fd=fopen(plikWy,'wt');  % plik z przeczytanymi danymi do obliczen
 cd ..
fprintf(fd,'\n%% Analiza zwarcia 1-faz. w sieci SN:');
fprintf(fd,...
'\n czas = %5d-%2d-%2d  godz. %2dh, %2dmin, %6.2fs \n',...
clock);
wdold=cd;
[fname,sciezka]=uigetfile('datz1fSN*.m',...
'Wybierz plik danych do analizy z1f w sieci SN:  ');
fprintf('\n... wybrano: %s%s',sciezka,fname);
eval(['cd(''',sciezka,''')']);
zwdat=strtok(fname,'.');
[nazwa,Un,Ipoj,s_rozstr] = feval(zwdat);
eval(['cd(''',wdold,''')']);   % powrot do katalogu z programem
fprintf('\n ... powrot do katalogu roboczego: %s ',pwd);
winf=1e8; % nieskonczonosc
j=sqrt(-1); a=exp(j*2*pi/3);
S    =[1    1     1;
       1    a     a^2; 
       1    a^2   a  ]/3;
   %
invS =[1    1     1;
       1    a^2   a; 
       1    a     a^2  ];
E=Un/sqrt(3);
B0=Ipoj/3/E/1000*1e6; %B0 - skl.0, odpowiada Ipoj, A
RN=inf; XN=inf; f=50; w=2*pi*f;
C0=B0/w;
%s_rozstr=10% - zalecane roztrojenie cewki
fprintf(fd,'\n');
fprintf(fd,'\n ZWARCIE 1-fz w wezle: %s',nazwa);
fprintf(fd,...
'\n Nap. znam. sieci SN             Un = %8.1f kV',Un);
fprintf(fd,...
'\n Pomierzony prad pojemnosciowy Ipoj = %8.1f A',Ipoj);
fprintf(fd,...
'\n Susceptancja poprzeczna skl.0   B0 = %8.1f mikroS',B0);
fprintf(fd,...
'\n Pojemnosc poprzeczna skl.0      C0 = %8.1f mikroF',C0);
fprintf(fd,...
'\n Rozstrojenie  s=(IL-Izc)/Izc*100%% = %8.1f%%',s_rozstr);
zw=0; czw='przed zwarciem';
%sem Thevenina rowna sem fazowej zrodla zastepczego
E = Un/sqrt(3);
Uabc=[E; a^2*E; a*E];
Ua=Uabc(1); Ub=Uabc(2); Uc=Uabc(3);
mUa=abs(Ua); kUa=angle(Ua);
kUast=kUa*180/pi; wUa=num2str(mUa,3);
mUb=abs(Ub); kUb=angle(Ub);
kUbst=kUb*180/pi; wUb=num2str(mUb,3);
mUc=abs(Uc); kUc=angle(Uc);
kUcst=kUc*180/pi; wUc=num2str(mUc,3);
napabc =['UA=' wUa 'kV, ' 'UB=' wUb 'kV, ' 'UC=' wUc 'kV'];
opisUabc=napabc;
tytul=['Nap. fazowe przed zwarciem:' opisUabc];
compass(Ua,'k-'); hold on;
compass(Ub,'r--'); compass(Uc,'b-.');
legend('UA','UB','UC'); title(tytul); 
saveas(gcf,['UABC_',czw],'emf'); pause(5); close;
nap012=' U0,U1,U2, kV';      nap=' Ua,Ub,Uc, kV';
pr012=' I0,I1,I2, A';      prad=' Ia,Ib,Ic, A';
B0 = B0*1e-6; % susceptancja skl.0
Zy0=1/(j*B0); % imp. poprzeczna skl.0
cIzc=3*E/Zy0*1000; % zespolony prad poj., izol. PN
UN=-E; % nap. PN
Izc=abs(cIzc); sIzc=num2str(Izc,3);
XN=1/( 3*(1+s_rozstr/100)*B0 ); % rozstrojenie cewki +10%
cILN=-UN/(j*XN)*1000; % zespolony prad, kompensacja PN
ILN=abs(cILN); sILN=num2str(ILN,3);
LN = XN/w; LNmH=LN*1000; % ind. cewki
RN=floor(1/3.6/B0); % rezystor umziemienia PN
cIRN=-UN/RN*1000; % prad czynny po uziem. RN
IRN=abs(cIRN);
sIRN=num2str(IRN,3);
srozstr=num2str(s_rozstr,3); srozstr=[srozstr '%'];
sLN=num2str(LN,3);
sR=num2str(RN,3);
cINF=['Izc=' sIzc ' A, PN izol.: ']; %zw=1
cXN =['ILN=' sILN ' A, komp. LN=' sLN ' H: ']; %zw=2
cRN =['IRN=' sIRN ' A - uz. RN=' sR ' om: ']; %zw=3
cIk1LN=cIzc+cILN;  Ik1LN=abs(cIk1LN); 
cIk1RN=cIzc+cIRN;   Ik1RN=abs(cIk1RN); 
fprintf(fd,...
'\n ======================================================');
fprintf(fd,'\n   E = %7.3f kV',E);
fprintf(fd,'\n  UN = %7.3f kV',UN);
fprintf(fd,'\n Izc = %7.3f A, cIzc = (%7.3f +j%7.3f)A ',...
    Izc,real(cIzc),imag(cIzc) );
fprintf(fd,...
'\n ======================================================');
fprintf(fd,'\n   s = %8.1f%%',s_rozstr);
fprintf(fd,'\n  XN = %7.3f om',XN);
fprintf(fd,'\n  LN = %7.3f mH',LNmH);
fprintf(fd,'\n ILN = %7.3f A, cILN = (%7.3f +j%7.3f)A ',...
    ILN,real(cILN),imag(cILN));
fprintf(fd,'\n Izc = %7.3f A, cIzc = (%7.3f +j%7.3f)A ',...
    Izc,real(cIzc),imag(cIzc) );
fprintf(fd,'\n Ik1 = %7.3f A, cIk1 = (%7.3f +j%7.3f)A',...
    Ik1LN, real(cIk1LN),imag(cIk1LN));
fprintf(fd,...
'\n ======================================================');
fprintf(fd,'\n  RN = %8.2f om',RN);
fprintf(fd,'\n IRN = %7.3f A,  IRN = (%7.3f +j%7.3f)A',...
    IRN,real(cIRN),imag(cIRN));
fprintf(fd,'\n Izc = %7.3f A, cIzc = (%7.3f +j%7.3f)A ',...
    Izc,real(Izc),imag(Izc) );
fprintf(fd,'\n Ik1 = %7.3f A, cIk1 = (%7.3f +j%7.3f)A',...
    Ik1RN,real(cIk1RN),imag(cIk1RN));
fprintf(fd,...
'\n ======================================================');
% analiza numeryczna i graficzna zwarcia 1-f w sieci SN
while zw<3
    zw=zw+1; I1=[]; I2=[]; I0=[]; U0=[]; U1=[]; U2=[];
    if zw == 1
       ZN=inf;    Z0=Zy0; czw='izol';
       I1=E/Z0*1000; I2=I1; I0=I1; % prady 012 w A
       U1=E; U2=0; U0=-U1;         % napiecia 012 w kV 
       UN=-E;
       cIk1=cIzc; cIRN=0; IRN=0; cILN=0; ILN=0;
       Ik1=abs(cIk1);
    end % zw==1
    %
    if zw == 2
       ZN=j*XN;    Z0=3*ZN*Zy0/(3*ZN+Zy0); czw='LN';
       I1=E/Z0*1000; I2=I1; I0=I1; % prady 012 w A
       U1=E; U2=0; U0=-U1;         % napiecia 012 w kV
       UN=-E; cILN=-UN/ZN*1000;ILN=abs(cILN);
       cIk1=cIzc+cILN; cIRN=0; IRN=0;
       Ik1=abs(cIk1);
    end % zw==2
    %
    if zw == 3
         ZN=RN;     Z0=3*ZN*Zy0/(3*ZN+Zy0); czw='RN';
         I1=E/Z0*1000; I2=I1; I0=I1; % prady 012 w A
         U1=E; U2=0; U0=-U1;         % napiecia 012 w kV
         UN=-E; cIRN=-UN/RN*1000;IRN=abs(cIRN);
         cIk1=cIRN+cIzc; cILN=0; ILN=0;
         Ik1=abs(cIk1);
    end % zw==3
% analiza numeryczna w ukl. 012 oraz ABC
    I012=[I0; I1; I2];     U012=[U0; U1; U2];
    Iabc=invS*I012;        Uabc=invS*U012;
    % skl. symetryczne 012 
   mI1=abs(I1); kI1=angle(I1); kI1st=kI1*180/pi;
    if mI1<1e-8 mI1=0; I1=0; end
    wI1=num2str(mI1,3);
   mI2=abs(I2); kI2=angle(I2); kI2st=kI2*180/pi; 
    if mI2<1e-8 mI2=0; I2=0; end
    wI2=num2str(mI2,3);
   mI0=abs(I0); kI0=angle(I0); kI0st=kI0*180/pi;
    if mI0<1e-8 mI0=0; I0=0; end
    wI0=num2str(mI0,3);
   mU1=abs(U1); kU1=angle(U1); kU1st=kU1*180/pi;
    if mU1<1e-8 mU1=0; U1=0; end
    wU1=num2str(mU1,3);
   mU2=abs(U2); kU2=angle(U2); kU2st=kU2*180/pi;
    if mU2<1e-8 mU2=0; U2=0; end
    wU2=num2str(mU2,3);
   mU0=abs(U0); kU0=angle(U0); kU0st=kU0*180/pi;
    if mU0<1e-8 mU0=0; U0=0; end
    wU0=num2str(mU0,3);
    % WIELKOSCI FAZOWE               
    Ia=Iabc(1); Ib=Iabc(2); Ic=Iabc(3);
    Ua=Uabc(1); Ub=Uabc(2); Uc=Uabc(3);
   mIk1=abs(cIk1); kIk1=angle(cIk1); kIk1st=kIk1*180/pi;
    if mIk1<1e-8 mIk1=0; Ik1=0; end 
    wIk1=num2str(mIk1,3);
    wIzc=num2str(Izc,3);
  mILN=abs(cILN); kILN=angle(cILN); kILNst=kILN*180/pi;
    if mILN<1e-8 mILN=0; cILN=0; end 
    wILN=num2str(mILN,3);
  mIRN=abs(cIRN); kIRN=angle(cIRN); kIRNst=kIRN*180/pi;
    if mIRN<1e-8 mIRN=0; IRN=0; end 
    wIRN=num2str(mIRN,3);
  mUN=abs(UN); kUN=angle(UN); kUNst=kUN*180/pi;
    if mUN<1e-8 mUN=0; UN=0; end 
    wUN=num2str(UN,3);
  mUb=abs(Ub); kUb=angle(Ub); kUbst=kUb*180/pi;
    if mUb<1e-8 mUb=0; Ub=0; end 
    wUb=num2str(mUb);
  mUc=abs(Uc); kUc=angle(Uc); kUcst=kUc*180/pi;
    if mUc<1e-8 mUc=0; Uc=0; end 
    wUc=num2str(mUc,3);
    % z dokladnoscia do 1e-8 A/kV
    I012=[I0; I1; I2];     U012=[U0; U1; U2];
    Iabc=invS*I012;        Uabc=invS*U012;
nap012 =['U1='    wU1 'kV, U2='   wU2 'kV, U0='   wU0 'kV'];
napabc =['UN=-E=' wUN 'kV, Ub='   wUb 'kV, Uc='   wUc 'kV'];
pr012=['I1='    wI1 'A,  I2='   wI2 'A, I0='   wI0 'A'];
prabc=['Izc=' wIzc 'A, Ik1=' wIk1 'A, ILN=' wILN 'A, IRN=' wIRN 'A'];
    opis1=['PN izol. Izc=' sIzc ' A'];
    opis2=['PN komp., rozstr. s=' srozstr];
    opis3=['PN uziem. RN=' sR ' om'];
    opis=[];
    if zw == 1 opis=opis1; end
    if zw == 2 opis=opis2; end
    if zw == 3 opis=opis3; end
opisU012=[]; opisUabc=[];   opisUabco=[];
opisI012=[]; opisIabc=[];
    if zw == 1
        opisU012=[cINF nap012];  opisI012=[cINF pr012];
        opisUabc=[cINF napabc];  opisIabc=[cINF prabc];
    end
    if zw == 2
        opisU012=[cXN nap012];  opisI012=[cXN pr012];
        opisUabc=[cXN napabc];  opisIabc=[cXN prabc];
    end
    if zw == 3
        opisU012=[cRN nap012];  opisI012=[cRN pr012];
        opisUabc=[cRN napabc];  opisIabc=[cRN prabc];
    end
% analiza graficzna
    compass(I1,'k-'); hold on;
    compass(I2,'r--'); compass(I0,'b-.');
    legend('I1','I2','I0');    
    title(opisI012);
    saveas(gcf,['I012_',czw],'emf'); pause(5);close;
    if Izc>Ik1
    compass(cIzc,'r-'); hold on;
    compass(cILN,'g-.');compass(cIRN,'b:');compass(cIk1,'k-');
    legend('cIzc','cILN','cIRN','cIk1');    
    title(opisIabc);
    else
    compass(cIk1,'r-'); hold on;
    compass(cILN,'g-.');compass(cIRN,'b:');compass(cIzc,'k-');
    legend('cIk1','cILN','cIRN','cIzc');  
    title(opisIabc);
    end
    saveas(gcf,['IABC_',czw],'emf'); pause(5);close;
    % wykresy wektorow napiec
    compass(U1,'k-'); hold on;
    compass(U2,'r--'); compass(U0,'b-.');
    legend('U1','U2','U0');    
    title(opisU012); 
    saveas(gcf,['U012_',czw],'emf'); pause(5);close;
    compass(Ub,'r-'); hold on;
    compass(Uc,'g-.');compass(UN,'b:');compass(E,'k-');
    legend('UB','UC','UN','E');    
    title(opisUabc); 
    saveas(gcf,['UABC_',czw],'emf'); pause(5);close;
%analiza numeryczna    
    fprintf(fd,...
'\n ------------------------------------------------------');
   fprintf(fd,'\n%s',opis);
   fprintf(fd,...
'\n ------------------------------------------------------');
   fprintf(fd,'\nPrady - uklad 012');
   if mI0<1e-3 mI0=0; end
   if mI1<1e-3 mI1=0; end
   if mI1<1e-3 mI2=0; end
   fprintf(fd,...
'\nModuly:  mI1=%7.3g A,  mI2=%7.3g A,  mI0=%7.3g A',...
      mI1,  mI2,  mI0);
   fprintf(fd,...
'\nKaty:    kI1=%7.1f st, kI2=%7.1f st, kI0=%7.1f st',...
      kI1st,kI2st,kI0st);
   fprintf(fd,'\nNapiecia - uklad 012');
   if mU0<1e-3 mU0=0; end
   if mU1<1e-3 mU1=0; end
   if mU2<1e-3 mU2=0; end
   fprintf(fd,...
'\nModuly:  mU1=%7.3g kV, mU2=%7.3g kV, mU0=%7.3g kV',...
     mU1,  mU2,  mU0);   fprintf(fd,...
'\nKaty:    kU1=%7.1f st, kU2=%7.1f st, kU0=%7.1f st',...
     kU1st,kU2st,kU0st);
   fprintf(fd,'\nPrady - uklad ABC');
   if mIk1<1e-3 mIk1=0; end
   if mILN<1e-3 mILN=0; end
   if mIRN<1e-3 mIRN=0; end
   fprintf(fd,...
'\nModuly: mIk1=%7.3g A, mILN=%7.3g A, mIRN=%7.3g A',...
     mIk1,  mILN,  mIRN);
   fprintf(fd,...
'\nKaty:   kIk1=%7.1f st,kILN=%7.1f st,kIRN=%7.1f st',...
     kIk1st,kILNst,kIRNst);
   fprintf(fd,'\nNapiecia - uklad ABC');
   if mUN<1e-3 mUN=0; end
   if mUb<1e-3 mUb=0; end
   if mUc<1e-3 mUc=0; end
   fprintf(fd,...
'\nModuly:  mUN=%7.3g kV, mUB=%7.3g kV, mUC=%7.3g kV',...
     mUN,  mUb,  mUc);
   fprintf(fd,...
'\nKaty:    kUN=%7.1f st, kUB=%7.1f st, kUC=%7.1f st',...
     kUNst,kUbst,kUcst);
end %while zw<=3
  fclose(fd);
  fprintf('\n ... wyniki zapisano w m-pliku %s',plikWy);
end %koniec az2z1fSN.m
