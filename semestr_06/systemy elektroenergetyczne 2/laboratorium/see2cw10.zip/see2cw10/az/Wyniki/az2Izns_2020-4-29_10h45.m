
*** O:\OneDrive - Politechnika Wroclawska\studia\Systemy elektroenergetyczne 2\lab\see2cw10\az\Wyniki\az2Izns_2020-4-29_10h45.m - analiza pr. i nap. zwarc w wezle ***
 Data:  2020- 4-29  godz. 10, 45min, 17s


 ******************************************************
 ***  GPZ110kV     - miejsce zwarcia ***
 ******************************************************
 Unk =     110 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =  63.509 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =  69.859 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.022 om, Xkk1 =   6.416 om - imp. zwar. skl.1
Xkk0 =   0.044 om, Xkk0 =   5.585 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     10.89 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =    2074.6 MVA
 Zwarcie 2-fazowe                      Ik2 =      9.43 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     11.92 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     11.17 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     11.14 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     11.38 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =    2168.1 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.01
                       X0/X1 =  0.87 niespelnione
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   3.79 kA, mI2=   3.79 kA, mI0=   3.79 kA
Katy:   kI1=  -89.7 st, kI2=  -89.7 st, kI0=  -89.7 st
Napiecia - uklad 012
Moduly: mU1=   45.5 kV, mU2=   24.3 kV, mU0=   21.2 kV
Katy:   kU1=   -0.0 st, kU2= -179.9 st, kU0=  179.8 st
Prady - uklad ABC
Moduly: mIA=   11.4 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -89.7 st, kIB=   18.4 st, kIC=   18.4 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=   68.3 kV, mUC=   68.4 kV
Katy:   kUA=  179.6 st, kUB= -117.7 st, kUC=  117.7 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   5.44 kA, mI2=   5.44 kA, mI0=      0 kA
Katy:   kI1=  -89.8 st, kI2=   90.2 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   34.9 kV, mU2=   34.9 kV, mU0=      0 kV
Katy:   kU1=   -0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   9.43 kA, mIC=   9.43 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -179.8 st, kIC=    0.2 st
Napiecia - uklad ABC
Moduly: mUA=   69.9 kV, mUB=   34.9 kV, mUC=   34.9 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   7.43 kA, mI2=   3.46 kA, mI0=   3.97 kA
Katy:   kI1=  -89.8 st, kI2=   90.1 st, kI0=   90.4 st
Napiecia - uklad 012
Moduly: mU1=   22.2 kV, mU2=   22.2 kV, mU0=   22.2 kV
Katy:   kU1=   -0.1 st, kU2=   -0.1 st, kU0=   -0.1 st
Prady - uklad ABC
Moduly: mIB=   11.2 kA, mIC=   11.1 kA, mIA=      0 kA
Katy:   kIA=  180.0 st, kIB=  148.0 st, kIC=   32.5 st
Napiecia - uklad ABC
Moduly: mUA=   66.6 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=   -0.1 st, kUB=   69.4 st, kUC=    0.0 st