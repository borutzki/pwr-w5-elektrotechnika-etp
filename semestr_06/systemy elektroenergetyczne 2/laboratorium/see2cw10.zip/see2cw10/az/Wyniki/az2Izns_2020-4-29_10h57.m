
*** O:\OneDrive - Politechnika Wroclawska\studia\Systemy elektroenergetyczne 2\lab\see2cw10\az\Wyniki\az2Izns_2020-4-29_10h57.m - analiza pr. i nap. zwarc w wezle ***
 Data:  2020- 4-29  godz. 10, 57min, 50s


 ******************************************************
 ***  RO           - miejsce zwarcia ***
 ******************************************************
 Unk =      10 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =   5.774 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.10    - wsp. obliczen zwarciowych
  E1 =   6.351 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   1.280 om, Xkk1 =   1.358 om - imp. zwar. skl.1
Rkk0 =     inf     , Xkk0 =     inf      - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =     3.403 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =      58.9 MVA
 Zwarcie 2-fazowe                      Ik2 =     2.947 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =         0 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =       NaN kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =       NaN kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =         0 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =       0.0 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =   inf  PN izolowany
                       X0/X1 =   inf  PN izolowany
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=      0 kA, mI2=      0 kA, mI0=      0 kA
Katy:   kI1=    0.0 st, kI2=    0.0 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   6.35 kV, mU2=      0 kV, mU0=    NaN kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    NaN st
Prady - uklad ABC
Moduly: mIB=      0 kA, mIC=      0 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=    0.0 st, kIC=    0.0 st
Napiecia - uklad ABC
Moduly: mUA=    NaN kV, mUB=    NaN kV, mUC=    NaN kV
Katy:   kUA=    NaN st, kUB=    NaN st, kUC=    NaN st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=    1.7 kA, mI2=    1.7 kA, mI0=      0 kA
Katy:   kI1=  -46.7 st, kI2=  133.3 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=   3.18 kV, mU2=   3.18 kV, mU0=    NaN kV
Katy:   kU1=    0.0 st, kU2=   -0.0 st, kU0=    NaN st
Prady - uklad ABC
Moduly: mIB=   2.95 kA, mIC=   2.95 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -136.7 st, kIC=   43.3 st
Napiecia - uklad ABC
Moduly: mUA=    NaN kV, mUB=    NaN kV, mUC=    NaN kV
Katy:   kUA=    NaN st, kUB=    NaN st, kUC=    NaN st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=    NaN kA, mI2=    NaN kA, mI0=    NaN kA
Katy:   kI1=    NaN st, kI2=    NaN st, kI0=    NaN st
Napiecia - uklad 012
Moduly: mU1=    NaN kV, mU2=    NaN kV, mU0=    NaN kV
Katy:   kU1=    NaN st, kU2=    NaN st, kU0=    NaN st
Prady - uklad ABC
Moduly: mIB=    NaN kA, mIC=    NaN kA, mIA=    NaN kA
Katy:   kIA=    NaN st, kIB=    NaN st, kIC=    NaN st
Napiecia - uklad ABC
Moduly: mUA=    NaN kV, mUB=    NaN kV, mUC=    NaN kV
Katy:   kUA=    NaN st, kUB=    NaN st, kUC=    NaN st