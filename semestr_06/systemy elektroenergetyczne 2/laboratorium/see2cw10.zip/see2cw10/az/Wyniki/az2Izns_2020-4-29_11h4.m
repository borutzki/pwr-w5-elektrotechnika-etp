
*** O:\OneDrive - Politechnika Wroclawska\studia\Systemy elektroenergetyczne 2\lab\see2cw10\az\Wyniki\az2Izns_2020-4-29_11h4.m - analiza pr. i nap. zwarc w wezle ***
 Data:  2020- 4-29  godz. 11,  4min, 31s


 ******************************************************
 ***  silnik       - miejsce zwarcia ***
 ******************************************************
 Unk =     0.5 kV - nap. znam. sieci  w miejscu zwarcia
Unfk =   0.289 kV - nap. znam. fazowe w miejscu zwarcia
   c =    1.00    - wsp. obliczen zwarciowych
  E1 =   0.289 kV - sem. Thevenina zastepcza E1=c*Unfk
Rkk1 =   0.003 om, Xkk1 =   0.009 om - imp. zwar. skl.1
Xkk0 =   0.001 om, Xkk0 =   0.008 om - imp. zwar. skl.0
 Prad poczatkowy zwarcia 3-fazowego     Ik =      30.3 kA
 MOC ZWARCIOWA zwarcia   3-fazowego     Sk =      26.2 MVA
 Zwarcie 2-fazowe                      Ik2 =     26.24 kA
 ------------------------------------------------------
 Zwarcie 2-fazowe f.B i C do ziemi   Iek2e =     33.38 kA
 Zwarcie 2-fazowe f.B i C do ziemi   IBk2e =     28.48 kA
 Zwarcie 2-fazowe f.B i C do ziemi   ICk2e =     33.51 kA
 ------------------------------------------------------
 Zwarcie 1-fazowe f.A do ziemi         Ik1 =     31.89 kA
 MOC ZWARCIOWA zwarcia   1-fazowego    Sk1 =      27.6 MVA
 Warunki skutecznosci uziemienia
 1 <= X0/X1 <= 3  oraz  R0/X1 <= 1      - siec 110 kV
 1 <= X0/X1 <= 2  oraz  R0/X1 <= 0.5    - siec 220 i 400 kV
 Warunki skutecznosci uziemienia: R0/X1 =  0.08
                       X0/X1 =  0.93
 ------------------------------------------------------
Analiza pradow i napiec w ukladzie 012 oraz ABC
 ------------------------------------------------------
 *** ZWARCIE 1-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   10.6 kA, mI2=   10.6 kA, mI0=   10.6 kA
Katy:   kI1=  -74.0 st, kI2=  -74.0 st, kI0=  -74.0 st
Napiecia - uklad 012
Moduly: mU1=  0.188 kV, mU2=  0.101 kV, mU0= 0.0885 kV
Katy:   kU1=    2.6 st, kU2=  175.1 st, kU0= -168.8 st
Prady - uklad ABC
Moduly: mIA=   31.9 kA, mIB=      0 kA, mIC=      0 kA
Katy:   kIA=  -74.0 st, kIB=   33.7 st, kIC=   51.3 st
Napiecia - uklad ABC
Moduly: mUA=      0 kV, mUB=  0.305 kV, mUC=  0.259 kV
Katy:   kUA=  180.0 st, kUB= -115.3 st, kUC=  120.2 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   15.1 kA, mI2=   15.1 kA, mI0=      0 kA
Katy:   kI1=  -69.1 st, kI2=  110.9 st, kI0=    0.0 st
Napiecia - uklad 012
Moduly: mU1=  0.144 kV, mU2=  0.144 kV, mU0=      0 kV
Katy:   kU1=    0.0 st, kU2=    0.0 st, kU0=    0.0 st
Prady - uklad ABC
Moduly: mIB=   26.2 kA, mIC=   26.2 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB= -159.1 st, kIC=   20.9 st
Napiecia - uklad ABC
Moduly: mUA=  0.289 kV, mUB=  0.144 kV, mUC=  0.144 kV
Katy:   kUA=    0.0 st, kUB=  180.0 st, kUC=  180.0 st
 ------------------------------------------------------
 *** ZWARCIE 2-fazowe z ziemia *** 
 ------------------------------------------------------
Prady - uklad 012
Moduly: mI1=   20.6 kA, mI2=   9.73 kA, mI0=   11.1 kA
Katy:   kI1=  -71.8 st, kI2=  116.7 st, kI0=  100.7 st
Napiecia - uklad 012
Moduly: mU1= 0.0927 kV, mU2= 0.0927 kV, mU0= 0.0927 kV
Katy:   kU1=    5.8 st, kU2=    5.8 st, kU0=    5.8 st
Prady - uklad ABC
Moduly: mIB=   28.5 kA, mIC=   33.5 kA, mIA=      0 kA
Katy:   kIA=    0.0 st, kIB=  165.7 st, kIC=   50.3 st
Napiecia - uklad ABC
Moduly: mUA=  0.278 kV, mUB=      0 kV, mUC=      0 kV
Katy:   kUA=    5.8 st, kUB=  161.6 st, kUC=   97.1 st