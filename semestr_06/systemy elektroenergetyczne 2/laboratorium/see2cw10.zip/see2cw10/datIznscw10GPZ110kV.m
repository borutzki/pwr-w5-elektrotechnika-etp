function [nazwa,Unk,Rkk1,Xkk1,Rkk0,Xkk0,drukIz]=datIznscw10
%impedancje Thevenina widziane z miejsca zwarcia
nazwa='GPZ110kV';%wezel, w ktorym analizowane jest zwarcie
Unk=110; %kV - nap. znam. sieci w miejscu zwarcia
Rkk1=0.0219; Xkk1=6.4158;%om - skl. 1 imp. zw. przy Unk
Rkk0=0.0437; Xkk0=5.5851;%om - skl. 0 imp. zw. przy Unk
drukIz=1; % drukowanie wynikow w ukl. 012 oraz ABC
end   
