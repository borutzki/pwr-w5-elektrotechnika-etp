function [nazwa,Unk,Rkk1,Xkk1,Rkk0,Xkk0,drukIz]=datIznscw10
%impedancje Thevenina widziane z miejsca zwarcia
nazwa='GPZ10kV';%wezel, w ktorym analizowane jest zwarcie
Unk=10; %kV - nap. znam. sieci w miejscu zwarcia
Rkk1=0.0183; Xkk1=0.3176;%om - skl. 1 imp. zw. przy Unk
Rkk0=inf; Xkk0=inf;%om - skl. 0 imp. zw. przy Unk
drukIz=1; % drukowanie wynikow w ukl. 012 oraz ABC
end   
