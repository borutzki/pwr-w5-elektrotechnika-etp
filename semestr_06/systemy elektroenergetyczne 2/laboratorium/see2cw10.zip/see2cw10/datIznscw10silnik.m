function [nazwa,Unk,Rkk1,Xkk1,Rkk0,Xkk0,drukIz]=datIznscw10
%impedancje Thevenina widziane z miejsca zwarcia
nazwa='silnik';%wezel, w ktorym analizowane jest zwarcie
Unk=0.5; %kV - nap. znam. sieci w miejscu zwarcia
Rkk1=0.0034; Xkk1=0.0089;%om - skl. 1 imp. zw. przy Unk
Rkk0=0.0007; Xkk0=0.0083;%om - skl. 0 imp. zw. przy Unk
drukIz=1; % drukowanie wynikow w ukl. 012 oraz ABC
end   