
% Analiza zwarcia 1-faz. w sieci SN:
 czas =  2020- 5-13  godz. 17h, 56min,  10.32s 


 ZWARCIE 1-fz w wezle: GPZ10kV
 Nap. znam. sieci SN             Un =     10.0 kV
 Pomierzony prad pojemnosciowy Ipoj =    101.0 A
 Susceptancja poprzeczna skl.0   B0 =   5831.2 mikroS
 Pojemnosc poprzeczna skl.0      C0 =     18.6 mikroF
 Rozstrojenie  s=(IL-Izc)/Izc*100% =     10.0%
 ======================================================
   E =   5.774 kV
  UN =  -5.774 kV
 Izc = 101.000 A, cIzc = (  0.000 +j101.000)A 
 ======================================================
   s =     10.0%
  XN =  51.967 om
  LN = 165.415 mH
 ILN = 111.100 A, cILN = (  0.000 +j-111.100)A 
 Izc = 101.000 A, cIzc = (  0.000 +j101.000)A 
 Ik1 =  10.100 A, cIk1 = (  0.000 +j-10.100)A
 ======================================================
  RN =    47.00 om
 IRN = 122.840 A,  IRN = (122.840 +j  0.000)A
 Izc = 101.000 A, cIzc = (101.000 +j  0.000)A 
 Ik1 = 159.031 A, cIk1 = (122.840 +j101.000)A
 ======================================================
 ------------------------------------------------------
PN izol. Izc=101 A
 ------------------------------------------------------
Prady - uklad 012
Moduly:  mI1=   33.7 A,  mI2=   33.7 A,  mI0=   33.7 A
Katy:    kI1=   90.0 st, kI2=   90.0 st, kI0=   90.0 st
Napiecia - uklad 012
Moduly:  mU1=   5.77 kV, mU2=      0 kV, mU0=   5.77 kV
Katy:    kU1=    0.0 st, kU2=    0.0 st, kU0=  180.0 st
Prady - uklad ABC
Moduly: mIk1=    101 A, mILN=      0 A, mIRN=      0 A
Katy:   kIk1=   90.0 st,kILN=    0.0 st,kIRN=    0.0 st
Napiecia - uklad ABC
Moduly:  mUN=   5.77 kV, mUB=     10 kV, mUC=     10 kV
Katy:    kUN=  180.0 st, kUB= -150.0 st, kUC=  150.0 st
 ------------------------------------------------------
PN komp., rozstr. s=10%
 ------------------------------------------------------
Prady - uklad 012
Moduly:  mI1=   3.37 A,  mI2=   3.37 A,  mI0=   3.37 A
Katy:    kI1=  -90.0 st, kI2=  -90.0 st, kI0=  -90.0 st
Napiecia - uklad 012
Moduly:  mU1=   5.77 kV, mU2=      0 kV, mU0=   5.77 kV
Katy:    kU1=    0.0 st, kU2=    0.0 st, kU0=  180.0 st
Prady - uklad ABC
Moduly: mIk1=   10.1 A, mILN=    111 A, mIRN=      0 A
Katy:   kIk1=  -90.0 st,kILN=  -90.0 st,kIRN=    0.0 st
Napiecia - uklad ABC
Moduly:  mUN=   5.77 kV, mUB=     10 kV, mUC=     10 kV
Katy:    kUN=  180.0 st, kUB= -150.0 st, kUC=  150.0 st
 ------------------------------------------------------
PN uziem. RN=47 om
 ------------------------------------------------------
Prady - uklad 012
Moduly:  mI1=     53 A,  mI2=     53 A,  mI0=     53 A
Katy:    kI1=   39.4 st, kI2=   39.4 st, kI0=   39.4 st
Napiecia - uklad 012
Moduly:  mU1=   5.77 kV, mU2=      0 kV, mU0=   5.77 kV
Katy:    kU1=    0.0 st, kU2=    0.0 st, kU0=  180.0 st
Prady - uklad ABC
Moduly: mIk1=    159 A, mILN=      0 A, mIRN=    123 A
Katy:   kIk1=   39.4 st,kILN=    0.0 st,kIRN=    0.0 st
Napiecia - uklad ABC
Moduly:  mUN=   5.77 kV, mUB=     10 kV, mUC=     10 kV
Katy:    kUN=  180.0 st, kUB= -150.0 st, kUC=  150.0 st