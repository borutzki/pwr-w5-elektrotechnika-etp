
% PAR. ZAST. ZWARCIOWE transf. 2-uzw.
%Par. zast. na nap. znam. transf. UNP
%UNSobl - nap. znam. sieci jako nap. obliczeniowe
%tN - przekl. transf.: siec UNSobl -> transf. UNS
%tN=tN1*tN2*... - siec promieniowa
%tN=UNSobl/UNS  - tylko siec oczkowa
UNSobl= 110; % kV
winf=1e+08; % nieskonczonosc 
 stra={
%transf      Od         Do        UNS     R1     X1     R0     X0   tN
%max12s     max12s     max12s     kV     om     om     om     om   -
 % Dyn - polaczenie uzwojen P-K: 
'T2A     ' 'ROSN    ' '*T2     '  10 0.1529  1.661   winf   winf 10.455
'T2B     ' '*T2     ' 'ROnN    '  10 0.1529  1.661 0.1529  1.661 10.455
'T2E     ' '*T2     ' 'ZIEMIA  '  10   winf   winf 0.1301  1.533 10.455
 % YNd - polaczenie uzwojen P-K: 
'TBA     ' 'GPZ20kV ' '*TB     '  20 0.4424  3.846 0.4424  3.846 5.2273
'TBB     ' '*TB     ' 'MEW     '  20 0.4424  3.846   winf   winf 5.2273
'TBE     ' '*TB     ' 'ZIEMIA  '  20   winf   winf 0.3654  3.499 5.2273
 };