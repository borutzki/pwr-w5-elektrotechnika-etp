function az
% Program do analizy zwarc symetrycznych i niesymetrycznych
t0=clock; % poczatek analizy
%Opcje analizy zwarc
fprintf('\n\n');
fprintf('\n Wybierz rodzaj analizy zwarc: \n');
fprintf('\n 1 - analiza zwarc w sieciach skutecznie uziemionych\n');
fprintf('\n 2 - nieustalony prad zwarcia: izw(t),iAC(t),iDC(t)\n');
fprintf('\n 3 - prady wg IEC: ip,Ib,iDC,Ibasym, Ith\n');
fprintf('\n 4 - analiza zwarc w wezle w ukl. 012 oraz ABC \n');
fprintf('\n 5 - analiza zwarcia 1-fazowego w sieci SN\n');
fprintf('\n 6 - sgen{} dla generatorow synchr. wg gsazDAT*.m\n');
fprintf('\n 7 - sgen{} dla systemu zewnetrznego wg seeazDAT*.m\n');
fprintf('\n 8 - sgen{} dla silnik�w asynchr. wg sasazDAT*.m\n');
fprintf('\n 9 - slin{} dla linii wg lkazDAT*.m\n');
fprintf('\n10 - stra{} dla tr. 2-uzwojeniowych wg tr2azDAT*.m\n');
fprintf('\n11 - tworzenie stra{} dla tr. 3-uzw. wg tr3azDAT*.m\n');
fprintf(...
'\n12 - kasowanie plikow wynikow *.txt oraz *.m w katalogu ..Wyniki\n');
fprintf(...
'\n13 - kasowanie plikow graficznych *.emf w katalogu ..az\n');
fprintf('\n\n');
opcja = input( '  opcja =   ');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% opcja=1 %%%%%%%%%%%%%%%%%
if opcja==1
fprintf('\n 1 - analiza zwarc w sieciach skutecznie uziemionych\n');
    az2suz; % zwarcia w sieci skutecznie uziemionej
end %if opcja==1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% opcja=2 %%%%%%%%%%%%%%%%% 
if opcja==2
fprintf('\n 2 - nieustalony prad zwarcia: izw(t),iAC(t),iDC(t)\n');
    az2izw; % przebiegi czasowe: izw(t),iAC(t),iDC(t)
end %if opcja==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% opcja=3 %%%%%%%%%%%%%%%%% 
if opcja==3
fprintf('\n 3 - prady wg IEC: ip,Ib,iDC,Ibasm, Ith\n');
    az2Izs; % prady wg IEC: ip,Ib,iDC,Ibasm, Ith
end %if opcja==3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% opcja=4 %%%%%%%%%%%%%%%%%
if opcja==4
fprintf('\n 4 - analiza zwarcia w wezle w ukl. 012 oraz ABC\n');
    az2Izns; % analiza zwarcia w wezle w ukl. 012 oraz ABC
end %if opcja==4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% opcja=5 %%%%%%%%%%%%%%%%%
if opcja==5
fprintf('\n 5 - analiza zwarcia 1-fazowego w sieci SN \n');
    az2z1fSN; % analiza zwarcia 1-f w sieci SN
end %if opcja==5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% opcja=6 %%%%%%%%%%%%%%%%%
if opcja==6
fprintf('\n 6 - tworzenie sgen{} dla generatorow synchr.\n');
    gsaz; % sgen{} dla GS
end %if opcja==6
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% opcja=7 %%%%%%%%%%%%%%%%%
if opcja==7
    seeaz; % sgen{} dla SEE
end %if opcja==7
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% opcja=8 %%%%%%%%%%%%%%%%%
if opcja==8
fprintf('\n 8 - tworzenie sgen{} dla silnik�w asynchr.\n');
   sasaz; % sgen{} dla SAS
end %if opcja==8
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% opcja=9 %%%%%%%%%%%%%%%%%
if opcja==9
fprintf('\n 9 - tworzenie slin{} dla linii\n');
    lkaz; % slin{} dla linii nap. i kablowych
end %if opcja==9
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% opcja=10%%%%%%%%%%%%%%%%%
if opcja==10
fprintf('\n10 - tworzenie stra{} dla tr. 2-uzwojeniowych\n');
    tr2az; % stra{} dla tr. 2-uzw.
end %if opcja==10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% opcja=11%%%%%%%%%%%%%%%%%
if opcja==11
fprintf('\n11 - tworzenie stra{} dla tr. 3-uzwojeniowego\n');
    tr3az; % stra{} dla tr. 3-uzw.
end %if opcja==11
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if opcja==12    KasujPlikiWynikow;    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% opcja=13%%%%%%%%%%%%%%%%%%%%%%%
if opcja==13    KasujPlikiGraficzne;  end
et=etime(clock,t0); 
fprintf('\n Czas trwania analizy: %.2f sekund !', et);
fprintf('\n ... zakonczono obliczenia wg opcja = %d ...\n',opcja);
fprintf('\n ... dalsza analiza? Wywolaj ponownie az ...\n\n');
fclose('all');
end % koniec az.m
