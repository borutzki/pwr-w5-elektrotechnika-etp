function sasaz
% paramtery zastepcze zwarciowe silnikow asynchronicznych
j=sqrt(-1);
 sciezka0=pwd; cd([sciezka0 '\Dane']); sciezka1=pwd;
 plikWe= strcat([sciezka1 '\sgen_sas.m']);
 fd=fopen(plikWe,'wt');  % plik z przeczytanymi danymi do obliczen
 cd ..
fprintf(fd,'\n%%PAR. ZAST. ZWARCIOWE SILNIKOW ASYNCHRONICZNYCH');
% czytanie danych z m-pliku
cdold=cd;
[plik,sciezka]=...
uigetfile('sasazDAT*.m','Wybierz m-plik z danymi silnika');
fprintf('\n... wybrano: %s%s.m',sciezka,plik);
eval(['cd(''',sciezka,''')']); dane=strtok(plik,'.');
[sas,UNSobl,winf] = eval(dane);
eval(['cd(''',cdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
sp12='123456789012'; % nazwa max 12 znakow
[nsas,n]=size(sas);
if nsas
   nazgen =strvcat( sp12,char(sas(:,1)));
   nazgen=nazgen(2:end,:);  
   nazwgs =strvcat( sp12,char(sas(:,2)));
   nazwgs=nazwgs(2:end,:);
   gen=[cell2mat(sas(:,3:end)) ]; 
else  % brak silnikow
   nazgen=[]; gen=[];
end %if nsas
if ~isempty(gen)
fprintf(fd,'\n%%Par. zast. nap. znam. silnika UNM');
fprintf(fd,'\n%%UNSobl - nap. obliczeniowe');
fprintf(fd,'\n%%tN - przekl. transf.: siecUNSobl -> siec UNS');
fprintf(fd,'\n%%tN=tN1*tN2*...- siec promieniowa');
fprintf(fd,'\n%%tN=UNS/UNSobl - tylko sieci oczkowe');
fprintf(fd,'\nUNSobl=%4.3g; %% kV',UNSobl);
fprintf(fd,'\nwinf=%.0e; %% nieskonczonosc ',winf);
fprintf(fd,'\nsgen={');
fprintf(fd,...
'\n%%Silnik     Od         Do         ');
fprintf(fd,'UNS     R1     X1     R0     X0   tN');
fprintf(fd,...
 '\n%%max12s     max12s     max12s     ');
fprintf(fd,'kV     om      om     om     om   -');
for i=1:nsas
  UnM=gen(i,1); Uns=gen(i,2); PnM=gen(i,3); eta=gen(i,4);
  cosfin=gen(i,5); kr=gen(i,6);
  p=gen(i,7); ns=gen(i,8); tn=gen(i,9);
  % obciazenie znamionowe 1 silnika
  Pn=PnM/eta; Sn=Pn/cosfin;
  sinfin=sqrt(1-cosfin^2); Qn=Sn*sinfin;
  ZM=UnM^2/Sn/kr;
  PnMp=PnM/p; %moc znamionowa na liczbe par biegunow
  if PnMp>=1   XM=0.995*ZM; RM=0.1*XM;
  end % przy PNM/p >= 1 MW
  if PnMp<1    XM=0.989*ZM; RM=0.15*XM;
  end % przy PNM/p <  1 MW
  if UnM<1    XM=0.922*ZM; RM=0.42*XM;
  end % przy UNM < 1 kV - grupa nN
  RMns=RM/ns; XMns=XM/ns;
  R1=RMns; X1=XMns; R0=winf; X0=winf;
  naz1=nazgen(i,:); naz2=nazwgs(i,:);
  drukzr(fd,naz1,naz2,Uns,R1,X1,R0,X0,tn,winf);
end
   fprintf(fd,'\n };');
 else
   fprintf(fd,'\n%% brak silnikow asynchronicznych!');
end % ~isempty(gen)
fclose(fd);
fprintf('\n\n sgen{} zapisano w m-pliku: %s',plikWe');
end % koniec sasaz()
