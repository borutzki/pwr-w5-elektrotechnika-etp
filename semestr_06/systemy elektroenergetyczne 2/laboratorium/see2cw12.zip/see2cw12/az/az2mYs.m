function [Ys]=az2mYs(fd,UNSobl,n,nbrs,wps,wks,ggals,bgals)
% macierz wezlowych admitancji zwarciowych dla skl. s
j=sqrt(-1); winf='    inf  ';
ygals=ggals+j*bgals; Yzws=zeros(n,n);
for k=1:nbrs
kp=wps(k); kk=wks(k); ygs=ygals(k);
 if kp*kk > 0
  Yzws(kp,kp)=Yzws(kp,kp)+ygs;
  Yzws(kp,kk)=Yzws(kp,kk)-ygs;%galezie rownolegle
  Yzws(kk,kk)=Yzws(kk,kk)+ygs;
  Yzws(kk,kp)=Yzws(kk,kp)-ygs;%galezie rownolegle
  end
  if kp==0 Yzws(kk,kk)=Yzws(kk,kk)+ygs; end
  if kk==0 Yzws(kp,kp)=Yzws(kp,kp)+ygs; end
end  %for k=1:nbrs
Ys=sparse(Yzws);% technika m. rzadkich
end % koniec az2Ys()

