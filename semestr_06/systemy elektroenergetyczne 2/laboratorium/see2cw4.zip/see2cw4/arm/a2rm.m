function[Ybus,Vbus,YPP,YPK,YKP,YKK,TMK,...
    SLBUS,SGBUS,TUNBUS,sukces,Ureg]=...
a2rm(fd,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
REF,PU,PQ,Ybus,Vbus,Ureg,opt,...
WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,...
YPP,YPK,YKP,YKK,STATUS,SGMIN,SGMAX,nazwez,nazgal);
j=sqrt(-1); sukces=1; 
%    metoda N-R z wirtualnymi wezlami typ=6 
TYP=real(TUNBUS); UNBUS=imag(TUNBUS);
PU6=find( TYP(:)==6); %tablica wezlow typ=6
%TYP(PU6)=6;
PU=find( TYP(:)==2|TYP(:)==6);%tablica wezlow typu 2 i 6
PQ=find(TYP(:)==1|TYP(:)==5|TYP(:)==7|TYP(:)==8);
TUNBUS=TYP+j*UNBUS; 
Vbus0=Vbus; % zapamietany rozplyw mocy przed wywolaniem a2NR
% PLASKI start
REFPU=[REF;PU]; ebus=Vbus./Vbus; Vbus=(1+j*0.0001)*ebus;
Vbus(REFPU)=Ureg(REFPU);
[Vbus,SLBUS,SGBUS,sukces] =...
a2NR(fd,NRBUS,TUNBUS,SGBUS,SLBUS,REF,PU,PQ,Ybus,Vbus,Ureg,...
opt,SGMIN,SGMAX,nazwez);
if sukces==0 
  if opt==0
    fprintf(fd,...
'\n ... a2rm() - rozbiezny RM po wywolaniu a2NR.m!');
    fprintf(...
'\n ... a2rm() - rozbiezny RM po wywolaniu a2NR.m!');
   end
   return;
end
Vbus0=Vbus; % zapamietany zbiezny rozplyw mocy bez ARN
% ARN - sprawdzanie Qgmin<Qg<Qmax i nowy rozplyw mocy
if opt==0
   fprintf(fd,'\n... regulacja nap. gen. synchr. ...');
end
[PU,PQ,TUNBUS,Vbus,SLBUS,SGBUS,sukces,Ureg] =...
a2typ6(fd,nazwez,NRBUS,TUNBUS,SGBUS,SLBUS,...
REF,PU,PQ,Ybus,Vbus,Ureg,...
opt,SGMIN,SGMAX,WPK);
if sukces   Vbus0=Vbus; else  Vbus=Vbus0; return
end % zapamietany zbiezny rozplyw mocy po ARN
% Regulacja przekladni transformatorow
if opt==0
  fprintf(fd,'\n... regulacja przekladni transf. ...');
end
n=size(Vbus,1);     TYP=real(TUNBUS);
[Ybus,Vbus,YPP,YPK,YKP,YKK,TMK,sukces] = ...
a2treg(fd,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
REF,PU,PQ,Ybus,Vbus,Ureg,opt,...
WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,...
YPP,YPK,YKP,YKK,STATUS,SGMIN,SGMAX,nazwez,nazgal);
opt=1;
[Vbus,SLBUS,SGBUS,sukces] =...
a2NR(fd,NRBUS,TUNBUS,SGBUS,SLBUS,REF,PU,PQ,Ybus,Vbus,Ureg,...
opt,SGMIN,SGMAX,nazwez);
if sukces
 Vbus0=Vbus; %zbiezny rozplyw mocy po reg. przekladni transf.
 else 
  Vbus=Vbus0;
  return; % powrot, bo wyczerpano zakresy reg. przekladni transf.
end %if sukces
end %koniec a2rm()
 
 
