function linia(xp,xk,yp,yk)
line([xp xk],[yp yk],'color','r','LineStyle','--');
end
