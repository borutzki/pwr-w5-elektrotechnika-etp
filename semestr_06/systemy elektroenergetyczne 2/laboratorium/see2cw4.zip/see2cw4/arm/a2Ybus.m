function[Ybus,nshunt]=a2Ybus(WPK,YPP,YPK,YKP,YKK,dc,YSHBUS,TYP)
% Tworzenie macierzy admitancji wezlowych
n=size(YSHBUS,1); nbr=size(WPK,1); WP=real(WPK); WK=imag(WPK);
nmax=20*nbr+n; % przewidywana max. liczba galezi w wezle
STATwez(1:n,1)=1; wlwezly=find(TYP==4);  STATwez(wlwezly)=0;
Ysh=STATwez.*YSHBUS;
CP = sparse(WP, 1:nbr, ones(nbr, 1), n, nbr);   
CK = sparse(WK, 1:nbr, ones(nbr, 1), n, nbr); 
Ybus = spdiags(Ysh, 0, n, n) + ... % adm. poprzeczne w wezle
    CP * spdiags(YPP, 0, nbr, nbr) * CP' + ... % YPP 
    CP * spdiags(YPK, 0, nbr, nbr) * CK' + ... % YPK 
    CK * spdiags(YKP, 0, nbr, nbr) * CP' + ... % YKP 
    CK * spdiags(YKK, 0, nbr, nbr) * CK';      % YKK
nshunt=size(find(YSHBUS(:) ~= 0),1);% liczba odb. staloadm.
end



