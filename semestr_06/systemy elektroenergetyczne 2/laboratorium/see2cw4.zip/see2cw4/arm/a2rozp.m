function [Nrp,Snrp,Inrp,Nrk,Snrk,Inrk,Cp,Ck,Imaxgal,overdlug]=...
a2rozp(fd,Sbase,NRBUS,TUNBUS,UMK,SGBUS,SLBUS,YSHBUS,...
WPK,ZGAL,YSHGAL,TMK,TMOGR,DTRPU,...
STATUS,SMAX,YPP,YPK,YKP,YKK,...
Vbus,Ybus,REF,PU,PQ,opt,nazwez,nazgal,...
SGMIN,SGMAX,QKOMP,UKUZW);
 % rezerwacja tabel     
Nrp=[];Snrp=[];Inrp=[];Nrk=[];Snrk=[];Inrk=[];Cp=[];Ck=[];
Imaxgal=[]; tabgalwyl=[];
nrnazag=[]; nrWEZaw=[];
sumQKOMP=0; % inicjowanie zmiennych
wp=real(WPK); wk=imag(WPK); 
TYP=real(TUNBUS);   UNBUS=imag(TUNBUS); % typy i nap. znam.
nbr=length(wp); % liczba galezi
% OPIS WYLACZEN GALEZI
tabgalwyl=[];
tabgalwyl=find(STATUS==0);
j=sqrt(-1);
nap=[]; moce=[]; 
%max=900;
SGMIN0=SGMIN;SGMAX0=SGMAX;
% wyszukanie wezlow izolowanych
PQizol=find(TYP(:,1)==4);
% zerowanie mocy w PQizol
SLBUS(PQizol)=0; SGBUS(PQizol)=0; YSHBUS(PQizol)=0;
SGMIN(PQizol)=0; SGMAX(PQizol)=0;
sp=' ';     Swp=[]; Swk=[];
n=size(NRBUS,1);nPU=length(PU);npv=nPU+length(REF);% wymiary sieci
Um=abs(Vbus); %Um w jedn. wzgl. pu
Ukat=angle(Vbus).*(180/pi);% Ukat w stopniach
RPUQ=[REF; PU; PQ];
% z pu na MW, Mvar
SLBUS=SLBUS*Sbase; Pd=real(SLBUS); Qd=imag(SLBUS); 
SGBUS=SGBUS*Sbase; Pg=real(SGBUS); Qg=imag(SGBUS); 
QKomp=QKOMP.*Um.^2*Sbase; % aktualna moc kompensatorow
%moc shunt pomniejszona o Qkomp
Sshunt=Um.^2.*conj(YSHBUS)*Sbase - j*QKomp;
Psh=real(Sshunt); Qsh=imag(Sshunt); 
UkV=Um.*UNBUS;    wlacz=find(TYP~=4);
sumSL=sum(SLBUS(wlacz));  sumSG=sum(SGBUS(wlacz));
sumSH=sum(Sshunt(wlacz));     sumQKomp=sum(QKomp(wlacz)); 
pozos=find(TYP==4);
%PQizol - tablica z izolowanymi wezlami
REFPUPQ=[REF;PU;PQ]; NET=[REFPUPQ;PQizol]; nNET=size(NET,1);
branchloss=0; Sg2bil=0; pSF=0; pST=0; nbr=size(WPK,1); 
overdlug=zeros(nbr,3); % do wyznaczania km linii przeciazonych
tap=real(TMK);
tr=find(tap(:)>0&STATUS~=0);% nr galezi dla zal. TRANSFORMATOROW
nl=find(tap(:)==0 & STATUS(:)~=0);% nr galezi dla zal. LINII 
for i3=1:nbr
 k=wp(i3,1); UNwp=UNBUS(k,1);
 Ib(i3,1)=Sbase/sqrt(3)/UNwp;%prad bazowy dla wez. pocz.[kA]
end %for i3=1:nbr
Inrp=YPP.*Vbus(wp) + YPK.*Vbus(wk);
aInrp=abs(Inrp).*Ib*1000;
Inrk=YKP.*Vbus(wp) + YKK.*Vbus(wk);
aInrk=abs(Inrk).*Ib*1000;
Swp= Vbus(wp).*conj(Inrp);
Swk= Vbus(wk).*conj(Inrk); 
 % UWAGA! - analizowane wszystkie transformatory w SEE
transfall=find(TMK(:)~=0);
aInrp(transfall)=abs(Swp(transfall))*Sbase;
aInrk(transfall)=abs(Swk(transfall))*Sbase;% moc dla transf.
% STRATY PRZESYLOWE PODLUZNE we wszystkich ZALACZONYCH GALEZIACH
zer=find(tap==0);
tap(zer)=1.0;%chwilowo linie tm=1,aby wyliczyc straty
tap=tap.*exp(j*pi/180*imag(TMK));
straty=STATUS.*abs(Vbus(wp)./tap-Vbus(wk)).^2./conj(ZGAL);
PSF=aInrp./SMAX;    PST=aInrk./SMAX;
% wyniki rozplywu mocy zapamietane w tablicy wyniki
wyniki=[real(Swp) imag(Swp) PSF real(Swk) imag(Swk) PST SMAX aInrp]; 
Cp=wyniki(:,3); Ck=wyniki(:,6); Imaxgal=wyniki(:,7);
% STRATY POPRZECZNE we wszystkich ZALACZONYCH GALEZIACH
lad=STATUS.*(abs(Vbus(wp)./tap).^2+...
    abs(Vbus(wk)).^2).*conj(YSHGAL)/2;
wyniki(:,9:12)=[real(straty(:)) imag(straty(:))...
    real(lad(:)) imag(lad(:))];
ladp=STATUS.*abs(Vbus(wp)./tap).^2.*conj(YSHGAL)/2;
ladk=STATUS.*abs(Vbus(wk)).^2.*conj(YSHGAL)/2;
wyniki(:,[1,2,4,5,9:12])=wyniki(:,[1,2,4,5,9:12])*Sbase;
% wspolczynnik mocy na poczatku i koncu galezi 
znakwp=sign(real(Swp)).*sign(imag(Swp)); fiwp=angle(Swp);
cosfiwp=abs(cos(fiwp)).*znakwp;;
znakwk=sign(real(Swk)).*sign(imag(Swk)); fiwk=angle(Swk);
cosfiwk=abs(cos(fiwk)).*znakwk;
wyniki(:,13)=cosfiwp; wyniki(:,14)=cosfiwk;
% dlugosc i przekroj dla linii
lkm=real(UKUZW); smm2=imag(UKUZW);
wyniki(:,15)=lkm; wyniki(:,16)=smm2;
% STRATY PRZESYLOWE we wszystkich ZALACZONYCH transf.
ladTR=lad(tr)*Sbase; strTR=straty(tr)*Sbase;
dSHT=sum(ladTR); dST=sum(strTR);
% STRATY PRZESYLOWE we wszystkich ZALACZONYCH LINIACH
ladL=lad(nl)*Sbase;  strL=straty(nl)*Sbase;
dSHL=sum(ladL);
dSL=sum(strL);% linie - sumaryczna moc ladowania
dSH=dSHT+dSHL;
nazwag=char(nazgal); %nazwy galezi 12-znakowe
nrwezp=NRBUS(wp);              nrwezk=NRBUS(wk);
nazwap=char(nazwez(nrwezp,:));
nazwak=char(nazwez(nrwezk,:));  
dP=sum(wyniki(:,9)); dQ=sum(wyniki(:,10));
% argumenty wyjscia
Nrp=wp; Snrp=Swp; Nrk=wk;
Snrk=Swk; Inrp=Inrp.*Ib*1000; Inrk=Inrk.*Ib*1000;
if opt==1 
 % przywrocenie max oraz min do dalszych obliczen RM
 SGMIN=SGMIN0; SGMAX=SGMAX0; % powrot do miejsca wywolania
 return;
end %if opt==1 
% WYDRUK mocy i napiec wezlowych
[Uover]=a2nap(fd,opt,nazwez,...
    Sbase,Vbus,Ybus,SGBUS,SLBUS,...
    SGMIN,SGMAX,Sshunt,sumSG,sumSL,sumQKomp,...
    TYP,UNBUS,Um,Ukat,UkV,Pg,Qg,Pd,Qd,...
    Psh,Qsh,QKomp,wlacz,nap);
% WYDRUK mocy galeziowych       
[galover]=a2moce(fd,opt,nazgal,nazwap,nazwak,STATUS,TMK,wyniki);
% ANALIZA naruszenia ograniczen napieciowych
fprintf(fd,...
'\nANALIZA przekroczenia dop. wartosci nap. wez.');
a2Uover(fd,opt,Uover,nazwez);
OPISrys = [' ']; 
a2Uprofil(fd,opt,Vbus,TUNBUS,nazwez,OPISrys);
% ANALIZA naruszenia ograniczen pradowych w liniach i transf.
fprintf(fd,...
'\nANALIZA przekroczenia dop. pradow galezi');
a2Iover(fd,opt,galover,TMK,nazgal,nazwap,nazwak);
% Opis wylaczonych galezi
wydrukwylgal=0; if opt==0 wydrukwylgal=1; end
if wydrukwylgal
  a2opisGalWyl(fd,tabgalwyl,nazgal,nazwez,WPK,UNBUS,TMK);
end
SgenBil=-sumSG+sumSL+sumSH+dSL+dSHL+dST+dSHT+j*sumQKomp;
PgenBil=real(SgenBil); QgenBil=imag(SgenBil);
Sbil=-sumSG+sumSL+sumSH+dSL+dSHL+dST+dSHT+j*sumQKomp;
% przywrocenie max oraz min do dalszych analiz
SGMIN=SGMIN0; SGMAX=SGMAX0;
end % koniec a2rozp()


