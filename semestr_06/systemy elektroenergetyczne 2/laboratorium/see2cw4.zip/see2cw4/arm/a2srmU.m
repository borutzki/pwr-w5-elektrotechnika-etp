function a2srmU(fd,nwez,nazwez,TYP,UN,xbus,xa,xb,...
xchar,Nsym, wymiar)
    tp=clock; % aktualny czas
    rok=int2str(tp(1)); miesiac=int2str(tp(2));
    dzien=int2str(tp(3));
    godz=int2str(tp(4));mins=int2str(tp(5));
    secs=int2str(tp(6));
    czas=[rok miesiac dzien godz mins secs];
for i=1:nwez
 ityp=TYP(i);
 if ityp==1 | ityp==5
    Un=UN(i);
    nazwa=nazwez(i,:);
    rxbus=[];  rxbus=xbus(:,i);
    %Ex=mean(rxbus); Dx=std(rxbus);
    %xa=xmin; xb=xmax;
    xmin=min(rxbus); xmax=max(rxbus);
    % dystrybuanta empiryczna
    xsym=[]; xsym=rxbus;
    xsr=mean(xsym); xstd=std(xsym); 
    Ex=xsr; Dx=xstd; if ~Dx Dx=1e-12; end
    t=(xsym-xsr)/xstd; % standaryzacja zmiennej losowej
    tsort=sort(t);
     % wartosci dystrybuanty empirycznej
    ntsort=length(tsort); prsym(:,1)=(1:ntsort)';
    prsym=prsym/ntsort;
    ta=(xa-Ex)/Dx; tb=(xb-Ex)/Dx; 
    ita=[]; ita=find(tsort(:)<=ta); 
    if isempty(ita) Fta=prsym(1);
    else nita=length(ita); Fta=prsym(nita); end 
    itb=[]; itb=find(tsort(:)>=tb);
    if isempty(itb) Ftb=prsym(ntsort);
    else itb1=itb(1); Ftb=prsym(itb1); end 
    pemp=Ftb-Fta; % prawd. wg dystrybuanty empirycznej
    [FN]=FN01(tsort); % dystrybuanta rozkladu normalnego
    pN01=prnab(0,1,ta,tb); % prawdopodobienstwo wg FN01
    fprintf(fd,...
    '\n %2d %12s %2d %7.3f %9.3g %7.3f %7.3f  %7.3f %7.3f',...
                  i,nazwa,ityp, Ex,Dx,xa,xb,pemp,pN01);
    cNsym=int2str(Nsym); cmx=num2str(Ex,2);csx=num2str(Dx,2);
    opis=[nazwa ' m' xchar '=' cmx ',s'];
    opis=[opis xchar '=' csx ', Nsym=' cNsym];
    xsort=Ex+tsort*Dx; % powrot ze standaryzacji
    if pemp<0.99 & xstd>3.3333e-3
      xpocz=xmin; if xpocz>xa xpocz=xa; end
      xkonc=xmax; if xkonc<xb xkonc=xb; end
      % wykres dystrybuanty empirycznej i normalnej
      p1=plot(xsort,prsym,'--b',xsort,FN,':k','LineWidth',1.5);
      hold on;
      cxa=num2str(xa,2); cFta=num2str(Fta,2);
      opisFta=['F(Umin)=' cFta];
      p2=plot(xa,Fta,'ro'); text(xa,Fta+0.04,opisFta);
      hold on;
      cxb=num2str(xb,2); cFtb=num2str(Ftb,2);
      opisFtb=['F(Umax)=' cFtb];
      p3=plot(xb,Ftb,'ro'); text(xb,Ftb+0.04,opisFtb);
      linia(xa,xa,0,Ftb); linia(xpocz,xa,Fta,Fta);
      linia(xb,xb,0,Ftb); linia(xpocz,xb,Ftb,Ftb);
      probU=Ftb-Fta; cprobU=num2str(probU,2);
      text(xa, 0.32,['P(Umin=' cxa '<U<Umax=' cxb ')=',cprobU]);
      title(opis); grid on;  axis([xpocz 1.02*xkonc -0.02 1.24]);
      xlabel([xchar wymiar]);
      ylabel(['F(' xchar ') - dystrybuanta']);
      legend(p1,' rozklad empiryczny', ' rozklad normalny');
      fU = [xchar,'_',nazwa,'_',czas]; 
      saveas(gcf,fU,'emf'); close;
    end %if xstd>=1e-4
 end %if ityp~=3
end %for i=1:nwez
end % koniec a2srmprU()

