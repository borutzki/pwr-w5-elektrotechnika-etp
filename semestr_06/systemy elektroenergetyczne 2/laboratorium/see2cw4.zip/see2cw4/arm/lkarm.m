function lkarm
% parametry linii nap. lub kablowej
j=sqrt(-1);
sciezka0=pwd; cd([sciezka0 '\Dane']); sciezka1=pwd;
plikWy= strcat([sciezka1 '\slink_lk.m']);
fd=fopen(plikWy,'wt'); cd ..
fprintf(fd,...
'\n%s - parametry zast. linii w formacie arm()',plikWy);
fprintf(fd,...
'\n Data: %5d-%2d-%2d  godz. %2d, %2dmin, %2.0fs',clock);
% czytanie danych z m-pliku
cdold=cd;
[plik,sciezka]=...
uigetfile('lkarmDAT*.m','Wybierz plik z danymi linii');
fprintf('\n... wybrano: %s%s.m',sciezka,plik);
eval(['cd(''',sciezka,''')']); dane=strtok(plik,'.');
[slin] = eval(dane);
eval(['cd(''',cdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
[nl,n]=size(slin);
if nl
   nazlin=slin(:,1);
   nazwp =slin(:,2);   nazwk =slin(:,3); 
   line=[cell2mat(slin(:,4:end)) ];
else    % brak linii
   nazlin=[]; line=[];
end %if nl
if ~isempty(line)
 fprintf(fd,'\n slin={');
 fprintf(fd,...
 '\n%%Galaz      WezPocz    WezKonc        ');
 fprintf(fd,'R      X   G     B   Imax st  lkm Smm2');
 fprintf(fd,...
 '\n%%max12s     max12s     max12s        ');
 fprintf(fd,'om     om  mikS  mikS    A -    km mm2');
 for i=1:nl
  r=line(i,1); x=line(i,2); g=line(i,3); b=line(i,4);
  Imax=line(i,5); st=line(i,6);
  L=line(i,7); Smm2=line(i,8);
  R=r*L; X=x*L; G=g*L; B=b*L; 
  nzl=char(nazlin(i,:));
  nzlP=char(nazwp(i,:)); nzlK=char(nazwk(i,:)); 
  fprintf(fd,'\n''%-8s'' ''%-8s'' ''%-8s'' ',...
     nzl,nzlP,nzlK);
   fprintf(fd,'%6.4g %6.4g %3d %7.1f %4d %1d %5.3g %3d',...
     R,X,G,B,Imax,st,L,Smm2);
 end %for i=1:nl
   fprintf(fd,'\n };');
 else
     fprintf(fd,'\... w pliku brak danych linii!');
end % ~isempty(line)
fclose(fd);
fprintf('\n\n lkarm() - slin{} w pliku: %s',plikWy);
end % koniec lkarm()
