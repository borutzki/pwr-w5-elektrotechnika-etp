
... przeczytano dane do obl. rozplywu mocy:
 O:\OneDrive - Politechnika Wroclawska\studia\Systemy elektroenergetyczne 2\lab\see2cw4\armDATw6.m
... wybrano: O:\OneDrive - Politechnika Wroclawska\studia\Systemy elektroenergetyczne 2\lab\see2cw4\datPQwez_cw4.m.m
 Zmiana danych wezlowych
Wezel        typ       Pg           Qg           Pd        Qd  
-             -        MW          Mvar          MW       Mvar 
-       przed po    przed po    przed po    przed po    przed po
GPZ10kV      5 1     0     0     0     0 0.551  0.54 0.251 0.162
generator    7 1  9.21     0 -0.691     0     0     0     0     0
 ... wybrano SZYBKIE zmiany napiec ...
 Proces iteracyjny rozwiazania rownan wezlowych
 IT          w     normaF    Umin   wezUmin         wdetJ
  1      0.999    0.00315   0.950   odbior              1
  2          1   3.65e-06   0.949   odbior          1.031
  3          1   3.91e-12   0.949   odbior          1.018
 a2NR() - sukces=1, ITERACJE ZBIEZNE
 ... Rozplyw Mocy bez reg. przekl. transf.
          Napiecia i moce wezlowe
Nrw Nazwa      typ     U   kat     U    Pgen    Qgen     Podb    Qodb   Qkomp  tgfi
 -    -          -    pu    st    kV      MW    Mvar       MW    Mvar    Mvar    -
  1 SEE          3 1.000   0.0 110.0     2.2    -0.9        -       -       -  -0.4
  2 GPZ110kV     1 1.000  -0.1 110.1     -         -        -       -       - -
  3 GPZ10kV      1 1.056  -0.5  10.6     -         -      0.5     0.2    -2.2  -3.8
  4 generator    1 1.056  -0.5  10.6     -         -        -       -       - -
  5 odczep       1 1.033  -0.8  10.3     -         -        -       -       - -
  6 RO           1 1.025  -0.8  10.3     -         -        -       -       - -
  7 odbior       1 0.949  -3.8   0.5     -         -      1.6     0.6       -   0.4
                              Razem:     2.2    -0.9      2.1     0.8    -2.2     -   

                  Moce galeziowe
 Przeplyw mocy w galezi:(p-k) pocaztek-koniec, (k-p) koniec-poczatek  
 I/Imax - wsp. obc.,  > - I>Imax przeciazenie,  wyl - wylaczenie
Nrg galaz        Od           Do             P(p-k) Q(p-k)  P(k-p)  Q(k-p) I/Imax - 
  -    -         -            -                 MW    Mvar      MW    Mvar    -   - 
  1 XQ           SEE          GPZ110kV         2.2    -0.9    -2.2     0.9   0.00 
  2 lacznik      GPZ10kV      generator       -0.0    -0.0     0.0     0.0   0.00 
  3 Linia        GPZ10kV      odczep           1.6     0.8    -1.6    -0.8   0.34 
  4 Kabel        odczep       RO               1.6     0.8    -1.6    -0.8   0.37 
  5 T1           GPZ110kV     GPZ10kV          2.2    -0.9    -2.1     1.3   0.06 
  6 T2           RO           odbior           1.6     0.8    -1.6    -0.6   0.84 

ANALIZA przekroczenia dop. wartosci nap. wez.
 Nrw Wezel         Un   Umin   Umax    U   U-Udop  U-Udop
   -   -           kV     pu     pu   pu     pu       %
   7 odbior         1  0.950  1.100  0.949 -0.001   -0.1%
Umin 0.949 w odbior      
Umax 1.056 w generator   
ANALIZA przekroczenia dop. pradow galezi
 ... brak przekroczenia Imax lub Smax w sieci

 *** Analiza napiec po wymuszeniu zmian danych wezlowych ***
 Szybkie zmiany nap. - bez regulacji przekl. transf.
NrWez Nazwa       Uprzed     Upo     dU Uprzed    Upo  abs(dU)
  1 SEE           110.0  110.0    0.0  1.000  1.000    0.0
  2 GPZ110kV      110.0  110.1    0.1  1.000  1.000    0.1
  3 GPZ10kV        10.5   10.6    0.0  1.055  1.056    0.2
  4 generator      10.5   10.6    0.0  1.055  1.056    0.2
  5 odczep         10.3   10.3    0.0  1.031  1.033    0.2
  6 RO             10.2   10.3    0.0  1.024  1.025    0.2
  7 odbior          0.5    0.5    0.0  0.947  0.949    0.2
 *** Analiza pradow po wymuszeniu zmian danych wezlowych ***
 Galezie ze zwiekszonym pradem powyzej 10.0 A
  - w odniesieniu do pradu przed zmianami
Nrg Galaz        Od           Do             lkm Smm2 Iprzed  Ipo Idop Ipo/Imax
 -   -           -            -               km  mm2     A     A    A    -
  5 T1           GPZ110kV     GPZ10kV        0.0    0   -36    12   210  0.06 
  1 XQ           SEE          GPZ110kV       0.0    0   -36    12  9999  0.00 
  2 lacznik      GPZ10kV      generator      0.0    0  -503     0  9999  0.00 