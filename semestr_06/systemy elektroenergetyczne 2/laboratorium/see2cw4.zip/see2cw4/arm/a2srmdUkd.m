function [NrUkPocz, NrUkKonc,dUkdop]=a2srmdUkd(fd,nazwez)
% CZYTANIE nowych mocy wez. z m-pliku
wdold=cd;
[fname,sciezka]=...
uigetfile('datdUklos*.m','Wybierz plik do an. rozchylu katowego');
fprintf('\n... wybrano: %s%s.m',sciezka,fname);
eval(['cd(''',sciezka,''')']); datafile=strtok(fname,'.');
[sdUk]=feval(datafile);% czytanie danych
eval(['cd(''',wdold,''')']);% powrot do przeczytaniu
fprintf('\n ... sciezka dostepu po powrocie: %s',pwd);
sp12='123456789012';       % maksymalnie do 12 znakow
NrUkPocz=[]; NrUkKonc=[];
dUkdop=cell2mat(sdUk(:,3:end)); %dopuszczalny rozchyl katowy
[nl,n]=size(sdUk);
if nl   % brak wylii
   nazwp =strvcat( sp12,char(sdUk(:,1)));
   nazwp=nazwp(2:end,:);
   nazwk =strvcat( sp12,char(sdUk(:,2)));
   nazwk=nazwk(2:end,:); 
   wyle=zeros(nl,2);
   strvcatnazwp0=deblank(strvcat(nazwp));
   strvcatnazwk0=deblank(strvcat(nazwk));
   nw=size(nazwez,1);
   for ii=1:nw
      nazw0=deblank(nazwez(ii,:));
       wp = strmatch(nazw0,strvcatnazwp0,'exact');
        if ~isempty(wp) 
          wyle(wp,1)=ii; 
        end
       wk = strmatch(nazw0,strvcatnazwk0,'exact');
       if ~isempty(wk)
           wyle(wk,2)=ii;
       end
   end % for ii=1:nw
   prawid=wyle(:,1) .* wyle(:,2);
   nrwyle=find(prawid ==0);
   if ~isempty(nrwyle)
      for ii=1:length(nrwyle)
         fprintf(fd,...
         '\n Bledne nazwy wezlow dla pary Uk',nrwyle(ii) );
         fprintf(...
         '\n Bledne nazwy wezlow dla pary Uk',nrwyle(ii) );
      end     
      blad=1;   %blad nazw wylii
      return;
   end  %if ~isempty(nrwyle)
else
    wyle=[];
end  % if nl
NrUkPocz=wyle(:,1); NrUkKonc=wyle(:,2);
end %a2srmdUkd()