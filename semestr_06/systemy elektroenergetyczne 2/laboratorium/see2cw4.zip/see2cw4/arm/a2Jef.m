function a2Jef(fdJef,PU,PQ,Ybus,Vbus,nazwez,Sbase)
fprintf(fdJef,...
'\nPelna macierz Jacobiego J=[JPe,JPf;JU2e,JU2f;JQe,JQf]');
[Jmatrix]=a2Jac(PU,PQ,Ybus,Vbus);
PUQ=[PU;PQ];
nw=size(PUQ,1);
% PUQ - tablica numerow wezlow w kolejnosci PU, PQ
%Jmatrix = [ dPe , dPf; ...
%      		dU2e , dU2f;...
%            dQe  , dQf ];
Jef=full(Jmatrix); % zamiana sparse na full matrix
 % analiza modalna Jef
[na,lambda,Csort,iCsort]=Jeig(Jef);
detJef=prod(lambda); % wyznacznik m. J
fprintf(fdJef,...
'\n Wyznacznik det(J) = product(lambda) = %.4g',detJef);
rm=real(lambda); im=imag(lambda);
[rmsort,irmsort]=sort(abs(rm));
%rm,irmsort,rmsort
fprintf(fdJef,...
'\nNrw Wezel           dxk Re(lamb) Im(lamb) dxk/dyj=ckj');
fprintf(fdJef,...
'\n =====================================================');
crPQ=[]; cref=[];
inaMAX=100; % tylko z najmniejszymi wartosciami wlasnymi
ckjMAX=max(abs(Csort));
ckjDRUKmin=ckjMAX/10;
for ina =1:na
 if ina>inaMAX break; end
  k=irmsort(ina);
  if k<=nw i=k; ref=1; else i=(k-nw); ref=2; end
  wezi=PUQ(i); nazwi=nazwez(wezi,:); cref='dek/';
  if ref==2 cref='dfk/'; end
  dxk=sum(Csort(k,:))/Sbase;
  fprintf(fdJef,...
'\n%2d %-8s %7.2g %7.4g %7.1g   %3s',...
      wezi,nazwi,dxk,rm(k),im(k), cref );
  for kk=1:na
   ckj=Csort(k,kk);
   if abs(ckj)>=ckjDRUKmin
     jj=iCsort(k,kk);
     if jj<=nw j=jj; rPQ=1; else j=(jj-nw); rPQ=2; end
     crPQ='dPj'; if rPQ==2 crPQ='dQj'; end
     nrwez=PUQ(j);  nazw=nazwez(nrwez,:);
     fprintf(fdJef,...
 '\n                                           %3s=%7.2g, %-8s',...
         crPQ,ckj,nazw );
     end %if abs(cik)>=0.01
    end %for kk=1:na
fprintf(fdJef,...
'\n =====================================================');
end %for i =1:na
end % koniec a2Jef()

function [na,lambda,Csort,iCsort]=Jeig(A)
% wektory wlasne i wartosci wlasne macierzy A
[na,ma]=size(A); 
[V,D]=eig(A,'nobalance'); % wektory wlasne
for i=1:na lambda(i)=D(i,i); end % wartosci wlasne
M = V;  N = inv(M); % wektory prawo- i lewo-stronne
for k=1:na
 for j=1:na
  C(k,j)=0;
  for i = 1:na
  % wsp. udzialu P lub Q w przyroscie skl. nap. e lub f
   C(k,j) = C(k,j)+ M(k,i)*N(i,j)/lambda(i);
  end %for i = 1:na
 end %for j=1:na
end %for k=1:na
[Csort,iCsort]=sort(C,2,'descend');
% [Csort,iCsort]=sort(C,2); % starsze wersje
end %koniec Jeig()
