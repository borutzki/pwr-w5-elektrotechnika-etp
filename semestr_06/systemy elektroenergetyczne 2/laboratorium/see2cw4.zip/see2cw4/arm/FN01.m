function [FN]=FN01(tsort)
% dystrybuanta rozkladu normalnego standaryzowanej zmiennej losowej
nt=length(tsort); ta=-20; FN=[];
% function pr=prnab(Ex,Dx,xa,xb)
% Prawdopodbienstwo zmiennej losowej normalnej w przedziale:  xa <= X < xb
Et=0; Dt=1;
for i=1:nt
    tb=tsort(i);   FN(i)=prnab(Et,Dt,ta,tb);
end
end

