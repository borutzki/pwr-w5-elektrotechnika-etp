function[YPP,YPK,YKP,YKK,nl,nt]=...
    a2pi(WPK,ZGAL,YSHGAL,TMK,STATUS,dc)
% Tworzenie czwornikow PI dla wszystkich galezi
nbr=length(WPK);nl=0; nt=0;
WP=real(WPK); WK=imag(WPK); % WP, WK - poczatek i koniec galezi
jeden=ones(nbr,1); zero=zeros(nbr,1);
[YKK,YPP,YPK,YKP]=deal(zero);
yij=STATUS.*ZGAL.^(-1); %admitancje podluzne galezi
if dc == 1   
  tap=ones(nbr,1);
  tkat=zeros(nbr,1); % w przypadku rozplywu DC
else
   tmodul=real(TMK); tkat=imag(TMK); lin=find(tmodul==0);
   nl=length(lin); % linie
   nt=length(find(tmodul ~=0)); % transformatory
   tmodul(lin)=jeden(lin);  tkat(lin)=zero(lin);
   zalgal=find(STATUS==1); wylgal=find(STATUS~=1);
   awylgal=size(wylgal,1);
   tap=jeden; % jedynkowe przekladnie linii 
   tap(zalgal)=tmodul(zalgal).*exp(j*pi/180*tkat(zalgal));
end
Ypol=YSHGAL*(1-dc)/2; % G/2+jB/2 - admitancje poprzeczne
YKK=yij+STATUS.*Ypol;
YPP=YKK./(tap.*conj(tap));
YPK=-yij./(conj(tap));
YKP=-yij./tap;
end

      
