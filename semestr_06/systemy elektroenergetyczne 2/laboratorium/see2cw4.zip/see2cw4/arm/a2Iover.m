function a2Iover(fd,opt,galover,TMK,nazgal,nazwap,nazwak)
%Identyfikacja galezi z przeciazeniam
if ~isempty(galover)
 igal=galover(:,1); ImaxA=galover(:,2);
 cover=galover(:,3)/100;
 Smm2=galover(:,4); dlug=galover(:,5);
 [Isort,iIsort]=sort(-cover);% wg malejacych przeciazen
 kgal=igal(iIsort);   ngalover=size(igal);
 fprintf(fd,...
 '\nNrg Galaz       wez.pocz.    wez.konc. ');
 fprintf(fd,'   Idop I/Idop Smm2 dlug  Czynnik');
  fprintf(fd,...
 '\n -    -              -            -      ');
 fprintf(fd,'    A     -  mm2    km       - ');
 soverdlug=0; 
 for kk=1:ngalover % wydruk galezi z przeciazeniami
  czynnik='  przekroj ';
  k=kgal(kk,1);
  i=iIsort(kk,1);
  tm=real(TMK(k));  if tm czynnik='  aparatura'; end
  fprintf(fd,'\n%2d %8s %8s %8s %4.0f %5.1f %3.0f',...
  k,nazgal(k,:),nazwap(k,:),nazwak(k,:),ImaxA(i),cover(i) );
  if Smm2(i)
    fprintf(fd,' %3.0f',Smm2(i) );
  else
    fprintf(fd,'   -'); 
  end
  if abs(dlug(i))>0.001
    fprintf(fd,' %5.1f',dlug(i) );
    soverdlug=soverdlug+dlug(i);
  else
    fprintf(fd,'     -');
  end 
    fprintf(fd,'%10s',czynnik);
 end % for kk=1:ngalover
 else
  fprintf(fd,...
  '\n ... brak przekroczenia Imax lub Smax w sieci');
end %if ~isempty(galover)
end % koniec a2Iover()