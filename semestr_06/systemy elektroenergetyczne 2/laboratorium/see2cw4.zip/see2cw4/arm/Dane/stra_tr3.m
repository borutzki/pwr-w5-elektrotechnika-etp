
c:\arm\Dane\stra_tr3.m - parametry zast. tr.3-uzw.
 Data:  2017-11-23  godz. 12,  2min, 23s
 stra={
%Galaz    Od         Do             R      X    G       B Smax    tm  tk   tmin   tmax    dt st
%max12s   max12s     max12a        om     om mikS    mikS  MVA    pu  st     pu     pu     pu -
'TRA-1G' 'WezG1   ' 'TRA-1*  '  1.272   98.7  1.5    -6.0   16 0.9504  0 0.7904 1.1104 0.0133 1
'TRA-1S' 'TRA-1*  ' 'WezS1   '  1.246 -3.591  0.0     0.0   16 1.0000  0 0.0000 0.0000 0.0000 1
'TRA-1D' 'TRA-1*  ' 'WezD1   '   1.28   55.6  0.0     0.0   16 0.9504  0 0.7904 1.1104 0.0133 1
 }