function [datNewPQ]=datPQwez_cw4 
datNewPQ={
% nowe Pg,Qg,Pd,Qd,typ po nag�ym wy��czeniu generacji
%Wezel            Pg,MW Qq,Mvar  Pd,MW  Qd,Mvar    typ
'GPZ10kV'         0       0      0.540  0.162        1;
'generator'       0       0      0      0            1;
};
end


 
