
c:\arm\Dane\slink_lk.m - parametry zast. linii w formacie arm()
 Data:  2017-11-23  godz. 12,  1min, 58s
 slin={
%Galaz      WezPocz    WezKonc        R      X   G     B   Imax st  lkm Smm2
%max12s     max12s     max12s        om     om  mikS  mikS    A -    km mm2
'L401    ' 'FW411   ' 'SEE400  '      9     99   0   990.0 2000 1   300 350
'L402    ' 'ELW422  ' 'ELC412  '     15    165   0  1650.0 2000 1   500 350
'L403    ' 'SEE400  ' 'ELC412  '      2     20   0   150.0 2000 1    50 350
'L111    ' 'ODB111  ' 'ODB121  '      5     20   0   140.0  350 1    50 240
'L112    ' 'ODB131  ' 'ODB121  '      4     16   0   112.0  350 1    40 240
 };