function [slin] = lkarmDATpo
% parametry zastepcze linii nap. lub kablowych do programu arm()
slin={
%Linia  nazwpk   nazwk      r     x     g      b   Imax st lkm Smm2
%12s      12s      12s    om/km om/km mikS/km miS/km  A  -  km  mm2
'L401' 'FW411'  'SEE400'  0.03	0.33	0	  3.3  2000	 1 300 350
'L402' 'ELW422' 'ELC412'  0.03	0.33	0	  3.3  2000	 1 500 350
'L403' 'SEE400' 'ELC412'  0.04	0.4	    0	  3.0  2000	 1  50 350
'L111' 'ODB111' 'ODB121'  0.10	0.4	    0	  2.8   350	 1  50 240
'L112' 'ODB131' 'ODB121'  0.10  0.4	    0	  2.8   350	 1  40 240
};
end
