function [datNewPQ]=datPQwezpo 
datNewPQ={
% nowe Pg,Qg,Pd,Qd,typ po nag�ym wy��czeniu generacji
%Wezel            Pg,MW Qq,Mvar  Pd,MW Qd,Mvar    typ
'FW411'               0       0    100     40      1;
'ELW422'           1700     800    120     20      1;
'ELC412'           1000     800    200    100      1;
};
end

 
