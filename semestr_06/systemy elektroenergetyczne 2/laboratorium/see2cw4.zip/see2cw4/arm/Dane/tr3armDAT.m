function [Sn,UnG,UnS,UnD,UnGs,UnSs,UnDs,p,streg,...
    Pfe,Io,straGS,straGD,straSD]=tr3armDAT
%dane znam. transf. 3-uzw. z regulacja przekladni
%Sn, MVA - moc znamionowa
%UnG, kV - nap. znamionowe g�rne
%UnS, kV - nap. znamionowe srodkowe
%UnD, kV - nap. znamionowe dolne
%p=16, % - reg. nap. po stronie UnG w -/+%
%streg % - liczba stopni regulacyjnych +/-
%UnGs, kV - nap. znamionowe sieciowe g�rne
%UnSs, kV -nap. znamionowe sieciowe srodkowe; 
%UnDs, kV -nap. znamionowe sieciowe dolne; 
%PcuGS, MW - straty obciazeniowe G-S (gora - srodek)
%PcuGD, MW - straty obciazeniowe G-D (gora - dol)
%PcuSD, MW - straty obciazeniowe S-D (srodek - dol)
%ukGS,   % - napiecie zwarcia G-S (gora - srodek)
%ukGD,   % - napiecie zwarcia G-D (gora - dol)
%ukSD,   % - napiecie zwarcia S-D (srodek - dol)
%Pfe,   MW - straty w zelazie
%Io,     % - prad jalowy
% dane znamionowe wspolne dla par uzwojen
Sn=16;
UnG=115; p=16; streg=12; UnGs=110;
UnS=22; UnSs=20;
UnD=11; UnDs=10;
Pfe=0.0193; Io=0.5;
% dane znamionowe dla par uzwojen
straGS={
%trans.  wezp    wezk    PcuGS  ukGS
%max12s  max12s  max12s     MW   % 
'TRA-1' 'WezG1' 'WezS1' 0.04874 11.51};
straGD={
'TRA-1' 'WezG1' 'WezD1' 0.0494 18.67};
straSD={
'TRA-1' 'WezS1' 'WezD1' 0.0489  6.3};
end
