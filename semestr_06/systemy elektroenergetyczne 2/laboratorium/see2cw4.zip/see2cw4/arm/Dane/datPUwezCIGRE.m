function [tabPU]=datPUwezCIGRE
% krzywe nosowe P-U maksymalnie dla 20 wezlow
% Przyklad obliczeniowy
tabPU={
%armDATpo.m
 'B08211';  'B09211';  'B10211';  'B11112';
 'B12112';  'B13112';  'B14112';  'B15112';
 'B3L112';  'B4L112';  'B05211';  'B06211';
 'B07211';  'B3H211';  'B4H211';  'B01112';
 'B11112';
 };
end
 
