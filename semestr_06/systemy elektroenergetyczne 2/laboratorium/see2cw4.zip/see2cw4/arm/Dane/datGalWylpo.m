function [datwyl]=datGalWylpo
% Kryterium N-3  - przyklad obliczeniowy 
datwyl={
%N-1
{'L401'; ''};
{'L402'; ''};
{'L403'; ''};
{'L111'; ''};
{'L112'; ''};
{'T1'; ''}; %transf.
{'T2'; ''}; %transf.
% N-2
{'L401'; 'L111'}; %2 linie
% N-3
{'L403'; 'L111'; 'T1'}; % 2 linie + 1 transf.
};
end
