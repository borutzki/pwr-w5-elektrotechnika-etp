function [stra]=tr2armDATpo
% dane znam. transf. 2-uzw. z regulacja przekladni
%Sn, MVA  - moc znamionowa
%UnP, kV  - nap. znamionowe transformatora g�rne
%UnK, kV  - nap. znamionowe transformatora dolne
%p, %     - zmiany nap. -/+% wskutek regulacji przekladni
%streg,   - liczba stopni regulacyjnych +/-
%UnPs, kV - nap. znamionowe sieciowe g�rne
%UnKs, kV - nap. znamionowe sieciowe dolne; 
%Pcu, MW  - straty obciazeniowe 
%uk, %    - napiecie zwarcia w %
%Pfe, MW  - straty w zelazie
%Io, %    - prad jalowy w %
stra={
%nazwg  nazwp    nazwk     Sn UnP UnK  p streg UnPs UnKs Pcu uk Pfe  Io
%max12s max12s   max12s   MVA  kV  kV  %  -     kV   kV   MW  %  MW   %
 'T1'  'SEE400' 'ODB111'  250 420 118 10 12    400  110  0.9 17 0.2 0.1
 'T2'  'ELC412' 'ODB131'  500 420 115 10  8    400  110  2.0 15 0.5 0.5
 'PF'  'FW411'  'ELW422' 2000 400 400  0 10    400  400  0   15 0   0
};
end