function [sbus,slin,stra,Sbase]=armdatCIGREpgMAX
% Dane zmodyfikowanego systemu CIGRE
 Sbase =   100; % moc bazowa w MVA
 sbus={
% Uwaga! Dane wezlowe i galeziowe w jednostkach mianowanych.
%        W programie nastapi przeliczonie na pu w odniesieniu do Sb i Un.
% DANE WEZLOWE
% nazwa - nazwa wezla ujeta w apostrofy, max 12 znakow
% typ - sposob udzialu wezla w regulacji napiecia:
%   1 - PQ  - odbiorczy,  wymaga podania P,Q
%   2 - PU  - generacyjny bez ograniczen Q, wymaga Pg,Ug, nie wymaga podania Qmin, Qmax
%   3 - Pdelta   - wezel bilansujacy caly rozplyw, wymaga podania U oraz Uk=0
%   4 - izolowany - nie bierze udzialu w obliczeniach itearcyjnych
%   5 - PQ - odbiorczy z reg. przekl. TRANSF. pod obc., wymaga podania regulowanego nap. U
%   6 - PU - generacyjny z ograniczeniami Q, wymaga podania Pg oraz Qmin, Qmax
%   7 - PU - z ogr. Qmin, Qmax, przy czym Q=Qmin - typ=7, moze byc nadany w trakcie obliczen
%   8 - PU - z ogr. Qmin, Qmax, przy czym Q=Qmax - typ=8, moze byc nadany w trakcie obliczen
% Un   - napiecie znamionowe sieci, kV
% Uzad - zadana wartosc napiecia w pu, w wezlach typu 2,3,5,6
% Uk   - wartosc kata napiecia w stopniach, podawana jesli znany jest ostatni punkt pracy SEE
%    Pd(+), MW    - moc czynna odbierana w wezle, Pd(-)  - moc czynna doplywajaca do wezla
%    Qd(+), Mvar  - moc bierna odbierana w wezle,tzn. bierna indukcyjna,
%    Qd(-)  - moc bierna doplywajaca do wezla, tzn. bierna pojemnosciowa
%    Pg(+), MW    - moc czynna generowana w wezle,
%    Pg(-)  - moc czynna generowana z ujemnym znakiem,tzn. moc czynna odbierana w wezle
%    Qg(+), Mvar  - moc bierna gen. indukcyjna,tzn.oddawana do sieci
%    Qg(-), Mvar  - moc bierna gen. pojemnosciowa, tzn. moc bierna pobierana z sieci
%    Gsh(+) - moc czynna odb. jako konduktancja w mikroS (shunt - np. straty ulotu
%    Bsh(+) - moc bierna odb. jako susceptancja pojemnosciowej w mikroS(shunt),np. kondensator
%    Bsh(-) - moc bierna odb. w postaci susceptancji indukcyjnej w mikroS(shunt),np. dlawik
%    Qgmin, Mvar  - minimalna  moc bierna generowana w wezle
%    Qgmax, Mvar  - maksymalna moc bierna generowana w wezle
%    Qkomp  - moc bierna kompensatora w Mvar, przy UN: (-)poj, (+)ind
% Pgmin, MW  - minimalna  moc czynna generowana w wezle, Pg=Pgmin przy zmniejszeniu ponizej Pgmin
% Pgmax, MW  - maksymalna moc czynna generowana w wezle, Pg=Pgmax przy zwiekszeniu  powyzej Pgmax
%    nazwa   typ Un_kV   Um  Uk_st      Pd      Qd      Pg        Qg    Gsh    Bsh   Qgmin   Qgmax Qkomp  Pgmin Pgmax   
%      1      2    3      4       5       6       7         8     9      10      11      12    13    14      15    16
 'B02211'     3    220  1.1    0.00   24.0    14.0     0.0      0.0    0.0    -0.0     0.0     0.0    0       0     0;
 'B05211'     6    220  1.1    0.00   14.0     8.0   210.0     24.34   0.0    -0.0  -120.0   150.0    0      120  250;
 'B06211'     6    220  1.1    0.00   30.0    20.0   200.0     95.00   0.0    -0.0  -150.0   210.0    0      120  250;
 'B07211'     6    220  1.1    0.00   15.0     9.0   150.0     44.00   0.0    -0.0  -100.0   120.0    0      120  250;
 'B08211'     1    220  1.0    0.00  210.0    85.0     0.0     0.0     0.0    -0.0     0.0     0.0    0       0     0;
 'B09211'     1    220  1.0    0.00  440.0   180.0     0.0     0.0     0.0    -0.0     0.0     0.0    0       0     0;
 'B10211'     1    220  1.0    0.00  310.0   160.0     0.0     0.0     0.0    -0.0     0.0     0.0    0       0     0;
 'B3H211'     2    220  1.05   0.00   17.0    10.0   210.0   176.0     0.0    -0.0  -120.0   180.0    0     180   360;
 'B4H211'     2    220  1.05   0.00  276.0   105.0   450.0   246.0     0.0    -0.0  -240.0   320.0    0     300   500;
 'B01112'     2    110  1.05   0.00   18.0     9.0   110.0    47.0     0.0    -0.0   -30.0    80.0    0     120   140;
 'B11112'     1    110  1.0    0.00   50.0    19.0     0.0     0.0     0.0    -0.0     0.0     0.0    0       0     0;
 'B12112'     1    110  1.0    0.00   25.0     9.0     0.0     0.0     0.0    -0.0     0.0     0.0    0       0     0;
 'B13112'     1    110  1.0    0.00   35.0    13.0     0.0     0.0     0.0    -0.0     0.0     0.0    0       0     0;
 'B14112'     6    110  1.00   0.00   40.0    15.0   100.0   -74.831   0.0    -0.0   -80.0    80.0    0       0     0;
 'B15112'     1    110  1.0    0.00   40.0    15.0     0.0     0.0     0.0    -0.0     0.0     0.0  -10.2   100   150;
 'B3L112'     5    110  1.05   0.00   50.0    19.0     0.0     0.0     0.0    -0.0     0.0     0.0    0       0     0;
 'B4L112'     5    110  1.05   0.00  312.0    43.0     0.0     0.0     0.0    -0.0     0.0     0.0    0       0     0;
};
 slin={
% DANE GALEZI - linie, wylaczniki
% Galaz   - nazwa galezi, w apostrofach, max 12 znakow
% WezPocz - nazwa wezla poczatku galezi, w apostrofach, max 12 znakow
% WezKonc - nazwa wezla konca    galezi, w apostrofach, max 12 znakow
%   R,X - rezystancja i reaktancja podluzna galez, omy
%   G,B  - konduktancja i susceptancja poprzeczna,  B  >  0  - dodatnia wartosc w mikroSimensach
%   Imax    - dopuszczalne obciazenie termiczne linii w A
%   st: 1 - zal., 0 - wyl.
%   lkm - dlugosc w km, Smm2 - przekroj w mm2
%  nazwg  nazwpk    nazwk        R        X     G       B Imax/Smax st   lkm  Smm2
%                                1        2     3       4    5      6     7      8 
 'LIN10' 'B08211' 'B09211'  10.700   90.000   0.0    420.0  400     0   77.00  525;
 'LIN11' 'B06211' 'B08211'   3.500   30.800   0.0    180.0  400     1   77.00  525;
 'LIN12' 'B07211' 'B08211'   6.0     59.500   0.0    300.0  400     1  148.80  525;
 'LIN13' 'B02211' 'B10211'   5.250   65.0     0.0    320.0  875     1  162.50  525;
 'LIN2'  'B3H211' 'B09211'   5.750   58.0     0.0    290.0  615     1  145.20  525;
 'LIN20' 'B3L112' 'B01112'   2.500   10.500   0.0     53.0  320     1   26.30  240;
 'LIN21' 'B01112' 'B11112'   0.600    4.0     0.0     20.0  420     1   10.00  240;
 'LIN22' 'B11112' 'B15112'   1.800   12.0     0.0     65.0  320     1   30.00  240;
 'LIN23' 'B15112' 'B4L112'   0.500    4.0     0.0     20.0  320     1   10.00  240;
 'LIN24' 'B4L112' 'B12112'   0.450    3.500   0.0     17.5  320     1    8.80  240;
 'LIN25' 'B12112' 'B14112'   1.100    8.100   0.0     40.5  320     1   20.1   240;
 'LIN26' 'B14112' 'B13112'   1.100    8.100   0.0     40.5  320     1   20.2   240;
 'LIN27' 'B13112' 'B3L112'   0.450    3.500   0.0     17.5  320     1    8.80  240;
 'LIN4'  'B3H211' 'B02211'   7.800   82.600   0.0    410.0  875     1  206.50  525;
 'LIN6'  'B09211' 'B4H211'  11.700   96.0     0.0    422.0  875     1  240.00  525;
 'LIN7'  'B4H211' 'B06211'  12.750   97.0     0.0    430.0  875     1  242.50  525;
 'LIN8'  'B4H211' 'B05211'   5.450   60.0     0.0    305.0  875     1  150.00  525;
 'LIN9'  'B4H211' 'B10211'   5.250   55.0     0.0    290.0  875     1  137.50  525;
};
  stra={
% DANE TRANSFORMATOROW
% Galaz   - nazwa galezi modelujacej transformator, w apostrofach, max 12 znakow
% WezPocz - nazwa wezla poczatku galezi, w apostrofach, max 12 znakow
% WezKonc - nazwa wezla konca    galezi, w apostrofach, max 12 znakow
%   R,X   - rezystancja i reaktancja podluzna galezi, odniesione do poziomu napiecia WezPocz
%   G,B   - konduktancja i susceptancja poprzeczna, B  <  0  - ujemna wartosc w mikroSimensach
%   Smax  - maksymalne dopuszczalne obciazenie termiczne, zwykle Smax=Sn, MVA
% Przekladnia znam. transf.  tn = Uwpn/Uwkn, Uwpn - nap. znam. WezPocz, Uwkn - nap. znam. WezKonc
% Przekladnia znam. sieciowa tns = Uwpns/Uwkns
% Przekladnia aktualna tact = Up/Uk, Up - nap. aktualne w WezPocz, Uk - nap. aktualne w WezKonc
% Przekladnia transformatora w jednostkach wzglednych  t = tact/tns
% tm - modul przekladni transf. na poczatku regulacji, jednostki wzgledne
% tk - kat przekladni transformatora lub przesuwnika fazowego, stopnie
% tmin, tmax - minimalna i maksymalna wartosc przekladni, jednostki wzgledne
% dt - przyrost przekladni przypadajacy na zaczep, jednostki wzgledne
%  st: 1 - zal., 0 - wyl.
% nazwg    nazwp    nazwk        R       X     G    B  Smax      to   tk     tmin   tmax        dt  st
%                                1       2     3    4    5        6    7      8      9          10  11     
 'TRA-1' 'B4H211' 'B4L112'   2.500  25.400   0.0  0.0  250  1.04230  0.0  0.90164  1.12245  0.00883  1;
 'TRA-2' 'B3H211' 'B3L112'   3.900  39.600   0.0  0.0  500  0.96020  0.0  0.92643  1.08627  0.00639  1;
};
end
