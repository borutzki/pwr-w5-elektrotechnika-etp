clear all
k=str2num(input('Podaj warto�� k= ','s'));
T1=str2num(input('Podaj warto�� T1[s]= ','s'));
T2=str2num(input('Podaj warto�� T2[s]= ','s'));
B=str2num(input('Podaj warto�� B= ','s'));
a=str2num(input('Podaj warto�� a= ','s'));
Am=str2num(input('Podaj warto�� Am= ','s'));
A1=4*B/pi;
ws=(2*T1*T2-9*T2^2+(81*T2^4-36*T1*T2^3+4*(k*A1*T1*T2/Am)^2)^0.5)^0.5/(2^0.5*T1*T2);
fg=ws/(2*pi);
A2=2*a;
war=1/(T1*T2)^0.5;
if ws<war
 fi1=-atan(3*T2*ws/(1-T1*T2*ws^2));
else
 fi1=-pi-atan(3*T2*ws/(1-T1*T2*ws^2));
end
fi2=atan(((A2/a)^2-1)^(-0.5))-pi;
ds=fi2-fi1;

eval(['disp(''A1=' num2str(A1) ''')'])
eval(['disp(''ws=' num2str(ws) '[1/s]'')'])
eval(['disp(''fg=' num2str(fg) '[Hz]'')'])
eval(['disp(''Tg=1/fg=' num2str(1/fg) '[s]'')'])
eval(['disp(''A2=' num2str(A2) ''')'])


disp('Parametry korektora:')
alfa=(1+sin(ds))/(1-sin(ds));
A=A2/(Am*alfa^0.5);
T=alfa^0.5/ws;

eval(['disp(''A=' num2str(A) ''')'])
eval(['disp(''T=' num2str(T) '[s]'')'])
eval(['disp(''T/alfa=' num2str(T/alfa) '[s]'')'])

