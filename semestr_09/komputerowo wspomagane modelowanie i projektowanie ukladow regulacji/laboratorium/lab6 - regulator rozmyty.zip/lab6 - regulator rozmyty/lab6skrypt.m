% parametry układu %
Ke = 1;
Kde = 0.1;
Kdu = 500;
T = 0.2;

% nastawy wyjscia regulatora nieliniowego  % 
P = 1;
PG = 0.9;
PB = 0.7;
PS = 0.1;
Z = 0;
NS = -1*PS;
NB = -1*PB;
NG = -1*PG;
N = -1*P;


for Kdu = 100:100:500
    data = sim("lab6model.slx",2);

    figure(1)
    subplot(3,2,1)
    hold on
    plot(data.tout,data.w_3x3,data.tout,data.w_ref)
    xlabel("time")
    ylabel("w [rad/s]")
    title("Odpowiedź układu - 3 reguły")

    figure(1)
    subplot(3,2,3)
    hold on
    plot(data.tout,data.w_5x5,data.tout,data.w_ref)
    xlabel("time")
    ylabel("w [rad/s]")
    title("Odpowiedź układu - 5 reguł - liniowy")

    figure(1)
    subplot(3,2,5)
    hold on
    plot(data.tout,data.w_5x5nl,data.tout,data.w_ref)
    xlabel("time")
    ylabel("w [rad/s]")
    title("Odpowiedź układu - 5 reguł - nieliniowy")

    figure(1)
    subplot(3,2,2)
    hold on
    plot(data.tout,data.y_3x3)
    xlabel("time")
    ylabel("y")
    title("Sygnał sterujący - 3 reguły")

    figure(1)
    subplot(3,2,4)
    hold on
    plot(data.tout,data.y_5x5)
    xlabel("time")
    ylabel("y")
    title("Sygnał sterujący - 5 reguł - liniowy")

    figure(1)
    subplot(3,2,6)
    hold on
    plot(data.tout,data.y_5x5nl)
    xlabel("time")
    ylabel("y")
    title("Sygnał sterujący - 5 reguł - nieliniowy")



end
