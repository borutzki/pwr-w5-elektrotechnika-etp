% PREPARATION
clear all;
close all;

% MODEL PARAMETERS
T1=0.2;
T2=0.5;
%% wyznaczenie osobno każdej pętli
ksi = 1;

w1 = 50; 
w2 = 100;

for w2 = 10:40:90

    ki = T1*w1^2;
    kp = T1*2*ksi*w1;
    kz = T2*w2;
    
    % SCRIPT
    data = sim("lab2model.slx",5);
    
    % GRAPHS
    figure(1)
    hold on
    plot(data.tout,data.w1)
    xlabel("time")
    ylabel("w [rpm]")
    
%     figure(2)
%     hold on
%     plot(data.tout,data.u1)
%     xlabel("time")
%     ylabel("control signal")

end

%% całkowita transmitancja na raz:
w = 20
for w = 10:40:50

    kp = T1*(2*ksi*w+w);
    ki = T1*(2*ksi*w^2+w^2);
    kz = T1*T2*w^3/ki;
    
    % SCRIPT
    data = sim("lab2model.slx",5);
    
    % GRAPHS
    figure(3)
    hold on
    plot(data.tout,data.w1)
    xlabel("time")
    ylabel("w [rpm]")
    
%     figure(4)
%     hold on
%     plot(data.tout,data.u1)
%     xlabel("time")
%     ylabel("control signal")

end

