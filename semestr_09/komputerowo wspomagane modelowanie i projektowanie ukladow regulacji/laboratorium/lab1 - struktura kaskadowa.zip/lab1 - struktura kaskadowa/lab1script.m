% PREPARATION
clear all;
close all;

% MODEL PARAMETERS
T=1; 

w = 20; 
ksi = 1;
ki = T*w^2;
kp = T*2*ksi*w;

% SCRIPT
% data = sim("lab1model.slx",2);

% GRAPHS
% figure(1)
% hold on
% plot(data.tout,data.w1)
% plot(data.tout,data.w2)
% 
% figure(2)
% hold on
% plot(data.tout,data.u1)
% plot(data.tout,data.u2)

for ksi=0:0.25:2
    ki = T*w^2;
    kp = T*2*ksi*w;
    
    % SCRIPT
    data = sim("lab1model.slx",2);
    
    % GRAPHS
    figure(1)
    hold on
    plot(data.tout,data.w1,data.tout,data.w2)


end

ksi = 1;

for w=20:20:120
    ki = T*w^2;
    kp = T*2*ksi*w;

    data = sim("lab1model.slx",2);

    figure(2)
    hold on
    plot(data.tout,data.w1,data.tout,data.w2)
end