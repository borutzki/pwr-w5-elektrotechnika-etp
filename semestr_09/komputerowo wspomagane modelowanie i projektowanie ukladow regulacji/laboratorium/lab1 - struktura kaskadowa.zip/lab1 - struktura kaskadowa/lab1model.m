w = 20
ksi = 1

T=0.05

ki = T*w^2
kp = T*2*ksi*w
