ksi = 1;
T1 = 5;
T2 = 1;
Tc = 0.002

for w=20:40:100
% do punktu 2:
    %Obliczenia regulatora PID
    K1 = T1*2*ksi*w + w*T1; 
    K2 = T1*T2*w^2*ksi + w^2*T1*T2;
    Ki = w^3*T1*T2;

    %odpalenie modelu  - regulator stanu
    data1 = sim("lab4_regulator_stanu.slx",5);
    data2 = sim("lab4_regulator_stanu.slx",5);

    % układ dwumasowy
    K1 = 4*ksi*w*T1;
    K2 = T1*Tc*(2*w^2+4*ksi^2*w^2-1/(T2*Tc)-1/(T1*Tc));
    K3 = T1*T2*Tc*(4*ksi*w^3-K1/(T1*T2*Tc));
    Ki = w^4*T1*T2*Tc;

    data3 = sim("lab4_dwumasa.slx",5);

    figure(1)
    subplot(3,2,1)
    hold on
    plot(data1.tout,data1.a);
    xlabel("time")
    ylabel("a")
    title("Układ 1 - położenie wału")

    figure(1)
    subplot(3,2,2)
    hold on
    plot(data2.tout,data2.a);
    xlabel("time")
    ylabel("a")
    title("Układ 2 - położenie wału")
   
    figure(1)
    subplot(3,2,3)
    hold on
    plot(data1.tout,data1.w);
    xlabel("time")
    ylabel("w")
    title("Układ 1 - prędkość obrotowa")

    figure(1)
    subplot(3,2,4)
    hold on
    plot(data2.tout,data2.w);
    xlabel("time")
    ylabel("w")
    title("Układ 2 - prędkość obrotowa")

    figure(1)
    subplot(3,2,5)
    hold on
    plot(data1.tout,data1.e);
    xlabel("time")
    ylabel("e")
    title("Układ 1 - uchyb położenia")

    figure(1)
    subplot(3,2,6)
    hold on
    plot(data2.tout,data2.e);
    xlabel("time")
    ylabel("e")
    title("Układ 2 - uchyb położenia")

    
    figure(2)
    subplot(3,1,1)
    hold on
    plot(data3.tout,data3.w1)
    xlabel("time")
    ylabel("w2 [rad/s]")

    figure(2)
    subplot(3,1,2)
    hold on
    plot(data3.tout,data3.w2)
    xlabel("time")
    ylabel("w1 [rad/s]")

    figure(2)
    subplot(3,1,3)
    hold on
    plot(data3.tout,data3.e)
    xlabel("time")
    ylabel("e")
    
end

