% parametry układu %
Ke = 1;
Kde = 0.1;
Kdu = 500;
T = 0.2;
K1 = 1000;
K2 = 0.3;

% nastawy wyjscia regulatora % 
P = 1;
PG = 0.75;
PB = 0.5;
PS = 0.25;
Z = 0;

NS = -1*PS;
NB = -1*PB;
NG = -1*PG;
N = -1*P;


% for Kdu = 100:100:500
    data = sim("lab7_model.slx",5);
    figure(1)
    hold on
    plot(data.tout,data.w)
    xlabel("time")
    ylabel("w [rad/s]")

% end
