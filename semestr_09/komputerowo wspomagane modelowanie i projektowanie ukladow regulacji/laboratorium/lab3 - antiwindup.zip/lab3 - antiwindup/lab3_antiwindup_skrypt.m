ksi = 1;
w = 10;
T = 1;
gain = 1000;
t_obciazenia = 3.5;
m_obciazenia = 0.5;

% for w=20:20:100
% 
%     %Obliczenia regulatora PID
%     Kp = T*2*ksi*w; 
%     Ki = T*w^2;
% 
%     %odpalenie modelu
%     data = sim("lab3_antiwindup_model.slx",5);
% 
%     %rysowanie wykresu
%     subplot(3,1,1);
%     hold on
%     plot(data.tout,data.y1);
%     xlabel("time")
%     ylabel("w [rad/s]")
%     title("Odpowiedz ukladu")
%     
%     subplot(3,1,2);
%     hold on
%     plot(data.tout,data.w1)
%     xlabel("time")
%     ylabel("sygnał sterujący - za ograniczeniem")
%     title("sygnal sterujacy - za ograniczeniem")
% 
%     subplot(3,1,3);
%     hold on
%     plot(data.tout,data.w2)
%     xlabel("time")
%     ylabel("sygnał sterujący - przed ograniczeniem")
%     title("sygnal sterujacy - przed ograniczeniem")
%     
% end

% for w=20:20:100
% 
%     %Obliczenia regulatora PID
%     Kp = T*2*ksi*w; 
%     Ki = T*w^2;
% 
%     %odpalenie modelu
%     data1 = sim("lab3_antiwindup_model.slx",5);
%     data2 = sim("lab3_antiwindup_metoda2.slx",5);
%     data3 = sim("lab3_antiwindup_metoda1.slx",5);
%     data4 = sim("lab3_antiwindup_metoda3.slx",5);
% 
%     %rysowanie wykresu
%     subplot(4,1,1);
%     hold on
%     plot(data1.tout,data1.y1);
%     xlabel("time")
%     ylabel("w [rad/s]")
%     title("Układ 1")
%     
%     subplot(4,1,2);
%     hold on
%     plot(data2.tout,data2.y1)
%     xlabel("time")
%     ylabel("w [rad/s]")
%     title("Układ 2")
% 
%     subplot(4,1,3);
%     hold on
%     plot(data3.tout,data3.y1)
%     xlabel("time")
%     ylabel("w [rad/s]")
%     title("Układ 3")
%     
%     subplot(4,1,4);
%     hold on
%     plot(data4.tout,data4.y1)
%     xlabel("time")
%     ylabel("w [rad/s]")
%     title("Układ 4")
% 
%     
% end

for w=20:20:100

    %Obliczenia regulatora PID
    Kp = T*2*ksi*w; 
    Ki = T*w^2;

    %odpalenie modelu
    data1 = sim("lab3_antiwindup_model.slx",5);
    data2 = sim("lab3_antiwindup_metoda2.slx",5);
    data3 = sim("lab3_antiwindup_metoda1.slx",5);
    data4 = sim("lab3_antiwindup_metoda3.slx",5);

    %rysowanie wykresu
    subplot(4,2,1);
    hold on
    plot(data1.tout,data1.w2);
    xlabel("time")
    ylabel("y")
    title("Układ 1 - sygnał regulatora przed ograniczeniem")
    
    subplot(4,2,3);
    hold on
    plot(data2.tout,data2.w2)
    xlabel("time")
    ylabel("y")
    title("Układ 2 - sygnał regulatora przed ograniczeniem")

    subplot(4,2,5);
    hold on
    plot(data3.tout,data3.w2)
    xlabel("time")
    ylabel("y")
    title("Układ 3 - sygnał regulatora przed ograniczeniem")
    
    subplot(4,2,7);
    hold on
    plot(data4.tout,data4.w2)
    xlabel("time")
    ylabel("y")
    title("Układ 4 - sygnał regulatora przed ograniczeniem")

        subplot(4,2,2);
    hold on
    plot(data1.tout,data1.w1);
    xlabel("time")
    ylabel("y")
    title("Układ 1 - sygnał regulatora za ograniczeniem")
    
    subplot(4,2,4);
    hold on
    plot(data2.tout,data2.w1)
    xlabel("time")
    ylabel("y")
    title("Układ 2 - sygnał regulatora za ograniczeniem")

    subplot(4,2,6);
    hold on
    plot(data3.tout,data3.w1)
    xlabel("time")
    ylabel("y")
    title("Układ 3 - sygnał regulatora za ograniczeniem")
    
    subplot(4,2,8);
    hold on
    plot(data4.tout,data4.w1)
    xlabel("time")
    ylabel("y")
    title("Układ 4 - sygnał regulatora za ograniczeniem")

    
end