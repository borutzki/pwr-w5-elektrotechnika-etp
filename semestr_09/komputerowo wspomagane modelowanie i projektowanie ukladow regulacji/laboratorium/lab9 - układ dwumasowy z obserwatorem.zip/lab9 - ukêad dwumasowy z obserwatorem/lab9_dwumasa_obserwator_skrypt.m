% Lab 9: projektowanie obserwatora w układzie dwumasowym
% zamodelować układ dwumasowy, gdzie wszystkie współczynniki są dostępne
% pomiarowo

% projekt na kartce: regulator stanu
clear;
%przejete parametry
T1 = 0.3;
T2 = 0.3;
Tc = 0.002;

ksi = 1.2;
w = 50;

a = ksi;
p = 2*w;

% regulator stanu
k1 = 4*ksi*w*T1;
k2 = T1*Tc*(2*w^2+4*ksi^2*w^2-1/(T2*Tc)-1/(T1*Tc));
k3 = T1*T2*Tc*4*ksi*w^3-k1;
Ki = w^4*T1*T2*Tc;

% estymator stanu
% k1e = 4*a*p*T1;
% k2e = T1*Tc*(1/(T1*Tc)+1/(T2*Tc)-2*p^2*T1*Tc-4*a^2*p^2*T1*Tc);
% k3e = 4*a*p^3*T1*T2*Tc;
% k4e = p^4*T1*T2*Tc;

k1e = 4*a*p*T1;
k2e = (T1/T2)+1-((T1*(4*a^2)+2*p^2)*Tc);
k3e = 4*T1*a*p*(((T2*Tc)*(p^2))-1);
k4e = -T2*T1*p^4*Tc;
