clear
% parametry układu %
Ke = 1;
Kde = 0.1;
Kdu = 500;
T = 0.2;


for Kdu = 100:100:500
    data = sim("lab5_model.slx",2);

    figure(1)
    subplot(2,2,1)
    hold on
    plot(data.tout,data.w_5,data.tout,data.w_ref)
    xlabel("time")
    ylabel("w [rad/s]")
    title("Odpowiedź układu - 5 reguł")

    figure(1)
    subplot(2,2,2)
    hold on
    plot(data.tout,data.w_25,data.tout,data.w_ref)
    xlabel("time")
    ylabel("w [rad/s]")
    title("Odpowiedź układu - 25 reguł")

    figure(1)
    subplot(2,2,3)
    hold on
    plot(data.tout,data.y_5)
    xlabel("time")
    ylabel("w [rad/s]")
    title("Sygnał regulatora - 5 reguł")

    figure(1)
    subplot(2,2,4)
    hold on
    plot(data.tout,data.y_25)
    xlabel("time")
    ylabel("w [rad/s]")
    title("Sygnał regulatora - 25 reguł")


end
