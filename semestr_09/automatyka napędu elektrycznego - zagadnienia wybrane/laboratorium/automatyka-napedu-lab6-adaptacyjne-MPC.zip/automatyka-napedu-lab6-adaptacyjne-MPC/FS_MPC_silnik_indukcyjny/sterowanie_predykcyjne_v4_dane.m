 % Zmienne wymagane przez algorytm sterowania
 global Ts Rs Lr Lm Ls p  
 % Czas probkowania algorytmu predykcyjnego [s]
 Ts = 4e-5;
 % Parametry regulatora PI
 Tsw = 0.00001; % Czas probkowania [s]
 Kp = 30; % Wzmocnienie proporcjonalne
 Ki = 0.1; % Wzmocnienie calkowania
 % Parametry silnika indukcyjnego
 Unf = 230; % Napiecie znamionowe fazowe [V]
 Vn = Unf*sqrt(3); % Napiecie miedzyfazowe [V]
 In = 3.4; % Prad znamionowy uzwojenia stojana [A]
 Pn = In*Vn; % Moc znamionowa [VA]
 cosfi = 0.73; % cosinus fi
 fn = 50; % Czestotliwosc znamionowa [Hz]
 wsp_tarcia = 0.001; % Wspolczynnik tarcia
 J = 0.0023; % Moment bezwladnosci [kg m^2]
 p = 2; % Liczba par biegun�w
 Lm = 123.3/(2*pi*fn); % Indukcyjnosc magnesowania [H]
 Ls = 131.1/(2*pi*fn); % Indukcyjnosc stojana [H]
 Lr = 131.1/(2*pi*fn); % Indukcyjnosc wirnika [H]
 Lss = (131.1-123.3)/(2*pi*fn);
 Lrr = (131.1-123.3)/(2*pi*fn);
 S=1; % Parametr skaluj�cy rezystancj� uzwoje� stojana
 W=1; % Parametr skaluj�cy rezystancj� wirnika
 Rs = 5.9*S; % Rezystancja stojana [Ohm]
 Rr = 4.559*W; % Rezystancja wirnika [Ohm]
 psi_s_ref = 0.74; % Znamionowy strumie� stojana [Wb]
 mo_nom = 1.5; % Znamionowy moment [Nm]
 % Napi�cie zasilania falownika [V]
 Vdc = 563;
 
