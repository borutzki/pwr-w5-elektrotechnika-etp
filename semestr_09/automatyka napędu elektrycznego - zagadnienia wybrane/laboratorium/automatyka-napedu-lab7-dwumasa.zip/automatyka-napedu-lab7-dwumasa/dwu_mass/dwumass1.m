%Parametry regulatora PI z dodatkowym sprz�eniem zwrotnym od momentu
%skr�tnego
format compact
clear all
clc

% DANE
T1 = 0.203;
T2 = 0.203;
Tc = 0.0012;
% mo = 0

% Parametry wyliczone
ksi = 1.2;
K1 = ((T1*(4*ksi^2))/(T2))-1
Kp=2*sqrt((T1*(1+K1))/Tc)
Kw=T1/(T2*Tc)

ksi_k1=0.5*sqrt((T2*(1+K1))/T1)
w0_k1=sqrt(1/(T1*T2))
