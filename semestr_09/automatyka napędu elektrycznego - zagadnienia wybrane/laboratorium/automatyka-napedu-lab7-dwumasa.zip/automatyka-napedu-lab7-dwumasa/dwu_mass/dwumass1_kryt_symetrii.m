format compact
clear all
clc

% DANE
Tz=2e-2
T1 = 0.203;
T2 = 0.203;
Tc = 0.0012;
wo = sqrt(1/(T2*Tc))
ksi = 0.5*sqrt(T2/T1)

% Parametry wyliczone
Kp=(T1+T2)/(2*Tz)
Tr=4*Tz
Kw=Kp/Tr
K1=0

