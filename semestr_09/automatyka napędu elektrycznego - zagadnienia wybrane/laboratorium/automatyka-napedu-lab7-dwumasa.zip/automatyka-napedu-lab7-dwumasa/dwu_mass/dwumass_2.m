%parametry regulatora PI z dwoma dodatkowymi sprz�eniami zwrotnymi od
%momentu skr�tnego (K1) i od r�nicy pr�dko�ci (K8)
format compact;clc; clear all; 

% DANe
T1 = 0.2;
T2 = 0.2;
Tc = 0.0012;
    
w0 = 250;    
ksi = 1; 

    K8=(1/(w0^2*T2*Tc))-1;
    K1=((T1*(4*ksi^2-K8))/(T2*(1+K8)))-1;
    Kw=T1*T2*Tc*w0^4;
    Kp=4*ksi*w0^3*T1*T2*Tc;
    ksi_u=0.5*sqrt((T2*(1+K8)*(1+K1)+T1*K8)/T1)
    w0_u=sqrt(1/((K8+1)*Tc*T2))