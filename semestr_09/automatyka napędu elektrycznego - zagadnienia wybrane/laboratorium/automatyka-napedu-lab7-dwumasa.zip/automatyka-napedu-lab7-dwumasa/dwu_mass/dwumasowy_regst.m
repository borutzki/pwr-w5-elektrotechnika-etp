%parametry regulatora PI z dwoma dodatkowymi sprzężeniami zwrotnymi od
%momentu skrętnego (K1) i od różnicy prędkoci (K8)
format compact;clc; clear all; 

% DANe
T1 = 0.2;
T2 = 0.2;
Tc = 0.0012;
    
w = 50;    
ksi = 1.2;

k1 = 4*ksi*w*T1;
k2 = T1*Tc*(2*w^2+4*ksi^2*w^2-1/(T2*Tc)-1/(T1*Tc));
k3 = T1*T2*Tc*(4*ksi*w^3-k1/(T1*T2*Tc));
Ki = w^4*T1*T2*Tc;