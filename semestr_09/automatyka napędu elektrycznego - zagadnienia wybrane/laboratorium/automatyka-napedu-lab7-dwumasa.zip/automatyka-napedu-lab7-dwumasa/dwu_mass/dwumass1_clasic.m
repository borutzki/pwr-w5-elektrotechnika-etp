%regulator PI z nastawami wyliczonymi z uwzgl�dnienim sztywno�ci wa�u
format compact
clear all
clc

% DANE

T1 = 0.203;
T2 = 0.303;
Tc = 0.0012;
wo = sqrt(1/(T2*Tc))   
ksi = 0.5*sqrt(T2/T1)

% Parametry wyliczone
Kw = T1/(T2*Tc)
Kp = 2*sqrt(T1/Tc)
K1=0
