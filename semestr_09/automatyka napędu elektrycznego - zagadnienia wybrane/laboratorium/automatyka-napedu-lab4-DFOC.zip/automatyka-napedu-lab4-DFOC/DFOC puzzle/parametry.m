%clc, clear all, close all 

%Dane znamionowe
Pn=1100; 
Unf=230; 
In=3.4; 
nn=1380; 
fn=50; 
omegasynch=1500; 
Ni=0.74; 
cosFi=0.73; 
pb=2;
Tm=0.2;
J=0.0143;
Rs=5.9; 
Rr=4.559;
Lm=(123.3)/(2*pi*fn);
Lss=(131.1-123.3)/(2*pi*fn);
Lrr=(131.1-123.3)/(2*pi*fn);

Xm=Lm*(2*pi*fn); Xs=Xm+Lss*(2*pi*fn); Xr=Xm+Lrr*(2*pi*fn);

% Obliczanie wielko�ci bazowych SI
Ub  = (2^0.5)*(Unf);
Ib  = (2^0.5)*(In);
Zb  = Ub/Ib;
wb  = 2*pi*fn;
Sb  = (3/2)*Ub*Ib;
wmb = wb/pb;
Mb  = Sb/wmb;
Psib= Ub/wb;

% Obliczanie wielko�ci wzgl�dnych SI
rs = Rs/Zb;
rr = Rr/Zb;
xs = Xs/Zb;
xr = Xr/Zb;
xm = Xm/Zb; xrr=xr-xm; xss=xs-xm;
sigma =1-((xm*xm)/(xs*xr));

mn=((Pn/((2*pi*nn)/60))/Mb);
wrn=(1-((nn*pb)/(2*omegasynch)));
psirn=sqrt((mn*rr)/wrn); 
psisn=sqrt((mn*((rr/(sigma*xr))^2+wrn^2))/((xm/(sigma*xs*xr))^2*rr*wrn));  

%regulator PI predkosci
Krisy=55;     Trisy=0.05;      
%regulator PI skladowych wektora pradu stojana
kis=50;    Tis=0.05;    
%regulator PI amplitudy strumienia stojana
kpsi=25;   Tpsi=0.025;