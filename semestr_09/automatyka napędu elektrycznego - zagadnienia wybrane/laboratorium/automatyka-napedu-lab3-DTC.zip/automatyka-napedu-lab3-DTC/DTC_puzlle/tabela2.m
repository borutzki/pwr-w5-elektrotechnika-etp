function y=tabela2(x)

switch x
    case 0
        y=[0;0;0];
            case 1
        y=[1;0;0];
            case 2
        y=[1;1;0];
            case 3
        y=[0;1;0];
            case 4
        y=[0;1;1];
            case 5
        y=[0;0;1];
            case 6
        y=[1;0;1];
            case 7
        y=[1;1;1];
end
    
