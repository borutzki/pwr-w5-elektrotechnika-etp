load('plikstartowy.mat')
Kw=500;
Tw=0.5;
Hme1=.0007;
Hme2=.0005;
Hme=.05;
Hpsi=.05;
Ud=1.7;
