function y=tabela3(x)

if (x>=-pi/6)&&(x<pi/6)
    y=1;
elseif (x>=pi/6)&&(x<pi/2)
    y=2;
    elseif (x>=pi/2)&&(x<5*pi/6)
    y=3;
    elseif ((x>=2*pi/3)&&(x<=pi))||((x>=-pi)&&(x<-5*pi/6))
    y=4;
    elseif (x>=-5*pi/6)&&(x<-pi/2)
    y=5;
    elseif (x>=-pi/2)&&(x<-pi/6)
    y=6;
    
end
    
