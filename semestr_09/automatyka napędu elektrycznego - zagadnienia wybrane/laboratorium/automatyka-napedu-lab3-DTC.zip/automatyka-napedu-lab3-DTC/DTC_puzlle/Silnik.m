% Dane znamionowe bazowego silnika indukcyjnego STDA 200LU
Pn=50000;
%Unf=658.1793;       %wyja�ni� jakie napi�cie fazowe czy miedzyfazowe
Unf=380;
Unmf=sqrt(3)*Unf;
In=88;
nn=1917;
% Ni=0.74;
% cosFi=0.73;
fn=65;
pb=2;
Rs=0.645;
Rr=0.463;
Ls=0.025217;
Lr=0.025137;
Lm=0.02475;
J=5;
% Obliczanie wielko�ci bazowych SI
Ub=(2^0.5)*(Unf);
Ib=(2^0.5)*(In);
Zb=Ub/Ib;
wb=2*pi*fn;
Sb=(3/2)*Ub*Ib;
wmb=wb/pb;
Mb=Sb/wmb;
Psib=Ub/wb;
Tn=1/wb;
Ob=1/Tn

Xs=(wb*Ls);
Xr=(wb*Lr);
Xm=(wb*Lm);
%Tm=(J*wb)/(pb*Mb);
Tm=(J*wb)/(Mb);


% Obliczanie wielko�ci wzgl�dnych SI
rs=Rs/Zb;
rr=Rr/Zb;
xs=Xs/Zb;
xr=Xr/Zb;
xm=Xm/Zb;
xss=xs-xm;
xrr=xr-xm;
mn=((Pn/((2*pi*nn)/65))/Mb);
%wrn=(1-((nn*pb)/1950));
wrn=(1-((nn)/1950));

Psirn=((mn*rr)/(wrn))^0.5; % zadawany strumie� wirnika
ImRn=(Psirn/xm); % zadany pr�d magnesuj�cy

A=(xr*xs)-(xm*xm);
sigma=1-((xm*xm)/(xs*xr));
Ts=(rs)/xs;
Tr=(rr)/xr;
wn=wb;

rso=rs;
rro=rr;
xso=xs;
xro=xr;
xmo=xm;
Ao=(xr*xs)-(xmo*xmo);
sigmao=1-((xmo*xmo)/(xso*xro));
Tso=(rso)/xso;
Tro=(rro)/xro;

  

