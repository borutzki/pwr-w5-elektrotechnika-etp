function y=tabela(dpsi,dm,N)
y=1;

if dpsi==1
    if dm==1
        switch N
            case 1
                y=2;
            case 2
                y=3;
            case 3
                y=4;
            case 4
                y=5;
            case 5
                y=6;
            case 6
                y=1;
        end
    elseif dm==0
        switch N
            case 1
                y=7;
            case 2
                y=0;
            case 3
                y=7;
            case 4
                y=0;
            case 5
                y=7;
            case 6
                y=0;
        end

    elseif dm==-1
       switch N
            case 1
                y=6;
            case 2
                y=1;
            case 3
                y=2;
            case 4
                y=3;
            case 5
                y=4;
            case 6
                y=5;
       end
    end
end


if dpsi==0 
    if dm==1
        switch N
            case 1
                y=3;
            case 2
                y=4;
            case 3
                y=5;
            case 4
                y=6;
            case 5
                y=1;
            case 6
                y=2;
        end
    elseif dm==0
        switch N
            case 1
                y=0;
            case 2
                y=7;
            case 3
                y=0;
            case 4
                y=7;
            case 5
                y=0;
            case 6
                y=7;
        end
    
    elseif dm==-1
        switch N
            case 1
                y=5;
            case 2
                y=6;
            case 3
                y=1;
            case 4
                y=2;
            case 5
                y=3;
            case 6
                y=4;
        end
    end
end
