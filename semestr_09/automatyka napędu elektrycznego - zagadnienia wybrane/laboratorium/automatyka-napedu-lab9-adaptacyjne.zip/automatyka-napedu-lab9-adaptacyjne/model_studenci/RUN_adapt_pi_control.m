%clear all
%close all
warning off
clc
%---------------
wr0=20
ksi0=1
%-------------


ts=0.001
sim_time=30

wr=0.25
f=0.5

tf=0.9

tm=0.2
te=0.005
limit=3
% sprawdzić wpływ parametrów początkowych na działanie układu
kp_init=10
ki_init=10

tm=tm*1;

tf=0.01
%sprawdzić wpływ alfa na działanie układu
alpha=0.7

sim('adapt_pi_control')

figure(1)
subplot(222)
plot(t,omega)
grid;hold on
plot(t,wref,'k')
legend('\omega','\omega_r_e_f')
title('ADAPTIVE CONTROL')
xlabel('t[s]')
ylabel('\omega [p.u.]')

subplot(223)
plot(t,k1)
grid;hold on
title('params')
xlabel('t[s]')
ylabel('gains k_1')

subplot(224)
grid;hold on
plot(t,k2,'r')
title('params')
xlabel('t[s]')
ylabel('gains k_2')

subplot(221)
plot(t,me,'r');grid
title('ADAPTIVE CONTROL')
xlabel('t[s]')
ylabel('m_e [p.u.]')

clc
error_adaptive=(sum(abs(wref-omega)))/(length(wref))
