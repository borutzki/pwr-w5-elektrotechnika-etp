clear all;% close all
clc
%% parametry uk�adu
Tc = 0.0012;
tc=Tc;
d  = 0.0; 
T1 = 0.203; 
t1=T1;
T2 = 0.203;
t2=T2;
Tss=5e-5;

%% Model obiektu
A = [-d/T1      d/T1        -1/T1;
     d/T2       -d/T2       1/T2;
     1/Tc       -1/Tc       0];
B = [1/T1 0 0;
    0 -1/T2 0]';
C = [1 0 0; 
     0 1 0; 
     0 0 1];
D1 = zeros(size(C,1),1);
D=[D1 D1];

mod=ss(A,B,C,D);
mod.InputName = {'me','mL'};
mod.StateName = {'w1','w2','ms'};
mod.OutputName = {'w1','w2','ms'};
mod=setmpcsignals(mod,'MV',1,'MD',2,'MO',[1 2 3])%, 'UO', [3]); %definicja wyjsc
%% parametry regulatora predykcyjnego
Weights=struct('Input',[1e-5],'InputRate',[0],'Output',[8 8 1]); %wartosci wagowe
Ts = 0.001;             %okres probkowania regulatora
N = 10;                 %horyzont predykcji
Nc =4;                  %horyzont sterowania
MPC=mpc(mod,Ts,N,Nc,Weights);
%% ograniczenia sygnalow
MPC.MV.Min=-3;  % sygna� sterujacy +
MPC.MV.Max=3;   % sygna� sterujacy -
OV(1)=struct('Min',-inf,'Max',inf); %ograniczenie predkosci silnika
OV(2)=struct('Min',-1,'Max',1); %ograniczenie predkosci obciazenia
OV(3)=struct('Min',-1.5,'Max',1.5); %ograniczenie momentu skretnego
MPC.OV=OV;

%% obliczenie nastaw obserwatora Luenbergera
w=30;
k=3;                           %krotnosc wzmocnienia obserwatora
p=k*w;                           %miara szybkosci dzialania obserwatora
t=1;                         %wspolczynnik tlumienia obserwatora
w=60
q1=4*t1*t*p  
q2=(t1/t2)+1-((t1*(4*(t^2)+2)*(p^2))*tc)
q3=4*t1*t*p*(((t2*tc)*(p^2))-1)
q4=-(t2*t1*(p^4))*tc